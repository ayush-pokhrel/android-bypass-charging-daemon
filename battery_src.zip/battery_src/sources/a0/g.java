package a0;

/* JADX INFO: compiled from: Pools.kt */
/* JADX INFO: loaded from: classes.dex */
public class g<T> extends f<T> {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private final Object f7c;

    public g(int i10) {
        super(i10);
        this.f7c = new Object();
    }

    @Override // a0.f, a0.e
    public boolean a(T instance) {
        boolean zA;
        kotlin.jvm.internal.h.e(instance, "instance");
        synchronized (this.f7c) {
            zA = super.a(instance);
        }
        return zA;
    }

    @Override // a0.f, a0.e
    public T b() {
        T t10;
        synchronized (this.f7c) {
            t10 = (T) super.b();
        }
        return t10;
    }
}
