package a0;

/* JADX INFO: compiled from: Pools.kt */
/* JADX INFO: loaded from: classes.dex */
public class f<T> implements e<T> {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final Object[] f5a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private int f6b;

    public f(int i10) {
        if (i10 <= 0) {
            throw new IllegalArgumentException("The max pool size must be > 0");
        }
        this.f5a = new Object[i10];
    }

    private final boolean c(T t10) {
        int i10 = this.f6b;
        for (int i11 = 0; i11 < i10; i11++) {
            if (this.f5a[i11] == t10) {
                return true;
            }
        }
        return false;
    }

    @Override // a0.e
    public boolean a(T instance) {
        kotlin.jvm.internal.h.e(instance, "instance");
        if (c(instance)) {
            throw new IllegalStateException("Already in the pool!");
        }
        int i10 = this.f6b;
        Object[] objArr = this.f5a;
        if (i10 >= objArr.length) {
            return false;
        }
        objArr[i10] = instance;
        this.f6b = i10 + 1;
        return true;
    }

    @Override // a0.e
    public T b() {
        int i10 = this.f6b;
        if (i10 <= 0) {
            return null;
        }
        int i11 = i10 - 1;
        T t10 = (T) this.f5a[i11];
        kotlin.jvm.internal.h.c(t10, "null cannot be cast to non-null type T of androidx.core.util.Pools.SimplePool");
        this.f5a[i11] = null;
        this.f6b--;
        return t10;
    }
}
