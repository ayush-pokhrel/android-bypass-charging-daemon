package a0;

/* JADX INFO: compiled from: Pools.kt */
/* JADX INFO: loaded from: classes.dex */
public interface e<T> {
    boolean a(T t10);

    T b();
}
