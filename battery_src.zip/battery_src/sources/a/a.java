package a;

/* JADX INFO: compiled from: CoroutineDebugging.kt */
/* JADX INFO: loaded from: classes.dex */
public final class a {
    public final StackTraceElement a() {
        return b.b(new Exception(), c.class.getSimpleName());
    }
}
