package a5;

import android.content.Context;
import com.oplus.battery.secretdynamicfeature.monitor.BMMonitorRouteServer;
import com.oplus.battery.secretdynamicfeature.plugincommon.route.CommonRouteServer;
import com.oplus.statistics.gen.root_battery.TrackApi_20089;
import s4.d;

/* JADX INFO: compiled from: SecretApplication.java */
/* JADX INFO: loaded from: classes.dex */
public class b {
    private void b() {
        e5.a.e().f();
    }

    private void d() {
        BMMonitorRouteServer.getInstance().init();
        CommonRouteServer.getInstance().init();
    }

    public void c() {
        Context contextC = d.e().c();
        d5.a.a("SecretApplication", "OplusGuardElf secretPlugin onCreate");
        a.c(contextC, contextC);
        d();
        a();
        b();
        TrackApi_20089.init(contextC);
    }

    private void a() {
    }
}
