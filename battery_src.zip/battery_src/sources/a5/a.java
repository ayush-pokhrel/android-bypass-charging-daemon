package a5;

import android.app.ActivityManager;
import android.app.AlarmManager;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.BatteryManager;
import android.os.PowerManager;
import com.oplus.smartenginehelper.ParserTag;

/* JADX INFO: compiled from: PluginContext.java */
/* JADX INFO: loaded from: classes.dex */
public class a {

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private static volatile a f103h;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private Context f104a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private Context f105b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private ActivityManager f106c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private AlarmManager f107d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private PowerManager f108e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private BatteryManager f109f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private PackageManager f110g;

    private a(Context context, Context context2) {
        this.f106c = null;
        this.f107d = null;
        this.f108e = null;
        this.f109f = null;
        this.f110g = null;
        this.f104a = context;
        this.f105b = context2;
        this.f106c = (ActivityManager) context.getSystemService(ParserTag.TAG_ACTIVITY);
        this.f107d = (AlarmManager) context.getSystemService("alarm");
        this.f108e = (PowerManager) context.getSystemService("power");
        this.f109f = (BatteryManager) context.getSystemService("batterymanager");
        this.f110g = context.getPackageManager();
    }

    public static a b() {
        return f103h;
    }

    public static a c(Context context, Context context2) {
        if (f103h == null) {
            synchronized (a.class) {
                try {
                    if (f103h == null) {
                        f103h = new a(context, context2);
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
        }
        return f103h;
    }

    public Context a() {
        return this.f104a;
    }

    public Context d() {
        return this.f105b;
    }
}
