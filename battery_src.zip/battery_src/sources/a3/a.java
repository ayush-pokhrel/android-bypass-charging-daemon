package a3;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.text.TextUtils;
import android.text.method.LinkMovementMethod;
import android.view.TouchDelegate;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.TextView;
import com.support.tips.R$attr;
import com.support.tips.R$dimen;
import com.support.tips.R$id;
import com.support.tips.R$layout;
import com.support.tips.R$style;
import com.support.tips.R$styleable;

/* JADX INFO: compiled from: COUIDefaultBubbleStyleImpl.java */
/* JADX INFO: loaded from: classes.dex */
public class a implements a3.b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private f f45a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private Context f46b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private int[] f47c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private TextView f48d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private ScrollView f49e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private ImageView f50f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private int f51g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private CharSequence f52h;

    /* JADX INFO: renamed from: a3.a$a, reason: collision with other inner class name */
    /* JADX INFO: compiled from: COUIDefaultBubbleStyleImpl.java */
    class ViewOnClickListenerC0000a implements View.OnClickListener {
        ViewOnClickListenerC0000a() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            a.this.f45a.a();
        }
    }

    /* JADX INFO: compiled from: COUIDefaultBubbleStyleImpl.java */
    class b implements Runnable {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        final /* synthetic */ ViewGroup f54a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        final /* synthetic */ int f55b;

        b(ViewGroup viewGroup, int i10) {
            this.f54a = viewGroup;
            this.f55b = i10;
        }

        @Override // java.lang.Runnable
        public void run() {
            Rect rect = new Rect();
            androidx.coordinatorlayout.widget.b.a(this.f54a, a.this.f50f, rect);
            int i10 = this.f55b;
            rect.inset(-i10, -i10);
            this.f54a.setTouchDelegate(new TouchDelegate(rect, a.this.f50f));
        }
    }

    /* JADX INFO: compiled from: COUIDefaultBubbleStyleImpl.java */
    public static class c {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private CharSequence f57a;

        public a b() {
            return new a(this, null);
        }
    }

    /* synthetic */ a(c cVar, ViewOnClickListenerC0000a viewOnClickListenerC0000a) {
        this(cVar);
    }

    @Override // a3.b
    public TextView b() {
        return this.f48d;
    }

    @Override // a3.b
    public void c(ViewGroup viewGroup) {
        Context context = this.f46b;
        int[] iArr = R$styleable.COUIToolTips;
        int[] iArr2 = this.f47c;
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(null, iArr, iArr2[0], iArr2[1]);
        int i10 = typedArrayObtainStyledAttributes.getInt(R$styleable.COUIToolTips_couiToolTipsContainerLayoutGravity, 0);
        int dimensionPixelSize = typedArrayObtainStyledAttributes.getDimensionPixelSize(R$styleable.COUIToolTips_couiToolTipsContainerLayoutMarginStart, 0);
        int dimensionPixelSize2 = typedArrayObtainStyledAttributes.getDimensionPixelSize(R$styleable.COUIToolTips_couiToolTipsContainerLayoutMarginTop, 0);
        int dimensionPixelSize3 = typedArrayObtainStyledAttributes.getDimensionPixelSize(R$styleable.COUIToolTips_couiToolTipsContainerLayoutMarginEnd, 0);
        int dimensionPixelSize4 = typedArrayObtainStyledAttributes.getDimensionPixelSize(R$styleable.COUIToolTips_couiToolTipsContainerLayoutMarginBottom, 0);
        ColorStateList colorStateList = typedArrayObtainStyledAttributes.getColorStateList(R$styleable.COUIToolTips_couiToolTipsContentTextColor);
        typedArrayObtainStyledAttributes.recycle();
        TextView textView = (TextView) viewGroup.findViewById(R$id.contentTv);
        this.f48d = textView;
        textView.setMovementMethod(LinkMovementMethod.getInstance());
        ScrollView scrollView = (ScrollView) viewGroup.findViewById(R$id.scrollView);
        this.f49e = scrollView;
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) scrollView.getLayoutParams();
        layoutParams.gravity = i10;
        layoutParams.setMargins(dimensionPixelSize, dimensionPixelSize2, dimensionPixelSize3, dimensionPixelSize4);
        layoutParams.setMarginStart(dimensionPixelSize);
        layoutParams.setMarginEnd(dimensionPixelSize3);
        this.f49e.setLayoutParams(layoutParams);
        this.f48d.setTextSize(0, (int) w2.a.f(this.f46b.getResources().getDimensionPixelSize(this.f51g == 0 ? R$dimen.tool_tips_content_text_size : R$dimen.detail_floating_content_text_size), this.f46b.getResources().getConfiguration().fontScale, 4));
        if (colorStateList != null) {
            this.f48d.setTextColor(colorStateList);
        }
        if (!TextUtils.isEmpty(this.f52h)) {
            this.f48d.setText(this.f52h);
        }
        ImageView imageView = (ImageView) viewGroup.findViewById(R$id.dismissIv);
        this.f50f = imageView;
        if (this.f51g == 0) {
            imageView.setVisibility(0);
            this.f50f.setOnClickListener(new ViewOnClickListenerC0000a());
        } else {
            imageView.setVisibility(8);
        }
        this.f50f.post(new b(viewGroup, this.f46b.getResources().getDimensionPixelOffset(R$dimen.couiToolTipsCancelButtonInsects)));
    }

    @Override // a3.b
    public int d() {
        return R$layout.coui_tool_tips_layout;
    }

    @Override // a3.b
    public int e(int i10, ViewGroup viewGroup) {
        return Math.min(viewGroup.getMeasuredWidth(), i10);
    }

    @Override // a3.b
    public void f(CharSequence charSequence) {
        TextView textView = this.f48d;
        if (textView != null) {
            textView.setText(charSequence);
        } else {
            this.f52h = charSequence;
        }
    }

    @Override // a3.b
    public void g(f fVar, Context context, int i10) {
        this.f45a = fVar;
        this.f46b = context;
        this.f51g = i10;
    }

    @Override // a3.b
    public int[] h() {
        if (this.f51g == 0) {
            int[] iArr = this.f47c;
            iArr[0] = R$attr.couiToolTipsStyle;
            iArr[1] = a2.a.k(this.f46b) ? R$style.COUIToolTips_Dark : R$style.COUIToolTips;
        } else {
            int[] iArr2 = this.f47c;
            iArr2[0] = R$attr.couiToolTipsDetailFloatingStyle;
            iArr2[1] = a2.a.k(this.f46b) ? R$style.COUIToolTips_DetailFloating_Dark : R$style.COUIToolTips_DetailFloating;
        }
        return this.f47c;
    }

    @Override // a3.b
    public void i(ViewGroup viewGroup, int i10) {
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) this.f49e.getLayoutParams();
        this.f48d.setMaxWidth((((i10 - viewGroup.getPaddingLeft()) - viewGroup.getPaddingRight()) - layoutParams.leftMargin) - layoutParams.rightMargin);
    }

    @Override // a3.b
    public int j() {
        return this.f46b.getResources().getDimensionPixelSize(R$dimen.tool_tips_max_width);
    }

    private a(c cVar) {
        this.f47c = new int[2];
        this.f52h = cVar.f57a;
    }

    @Override // a3.b
    public void a() {
    }
}
