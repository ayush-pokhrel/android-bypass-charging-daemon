package a3;

import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Outline;
import android.graphics.Point;
import android.graphics.Rect;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.view.ViewParent;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.PopupWindow;
import android.widget.TextView;
import c3.i;
import com.coui.appcompat.poplist.COUIPopupWindow;
import com.coui.appcompat.poplist.WindowSpacingControlHelper;
import com.oplus.graphics.OplusOutline;
import com.oplus.graphics.OplusOutlineAdapter;
import com.support.appcompat.R$attr;
import com.support.appcompat.R$dimen;
import com.support.tips.R$color;
import com.support.tips.R$drawable;
import com.support.tips.R$styleable;

/* JADX INFO: compiled from: COUIToolTips.java */
/* JADX INFO: loaded from: classes.dex */
public class c extends COUIPopupWindow {
    private Drawable A;
    private Drawable B;
    private Drawable C;
    private int D;
    private int E;
    private boolean F;
    private int G;
    private boolean H;
    private int I;
    private int J;
    private int[] K;
    private float L;
    private float M;
    private boolean N;
    private int O;
    private float P;
    private float Q;
    private boolean R;
    private int S;
    private View.OnLayoutChangeListener T;
    private PopupWindow.OnDismissListener U;
    private a3.f V;
    private Runnable W;
    private Rect X;
    private Rect Y;
    private int Z;

    /* JADX INFO: renamed from: a0, reason: collision with root package name */
    private a3.b f58a0;

    /* JADX INFO: renamed from: b0, reason: collision with root package name */
    private int f59b0;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private final Context f60e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private final int[] f61f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private final Point f62g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private final g0.d<Float> f63h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private final g0.d<Float> f64i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private int f65j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    private View f66k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private Rect f67l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    private Rect f68m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    private ViewGroup f69n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    private ViewGroup f70o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    private ImageView f71p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    private View f72q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    private Drawable f73r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    private Drawable f74s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    private Drawable f75t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    private Drawable f76u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    private Drawable f77v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    private Drawable f78w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    private Drawable f79x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    private Drawable f80y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    private Drawable f81z;

    /* JADX INFO: compiled from: COUIToolTips.java */
    class a extends g0.d<Float> {
        a(String str) {
            super(str);
        }

        @Override // g0.d
        /* JADX INFO: renamed from: c, reason: merged with bridge method [inline-methods] */
        public float a(Float f10) {
            return c.this.P;
        }

        @Override // g0.d
        /* JADX INFO: renamed from: d, reason: merged with bridge method [inline-methods] */
        public void b(Float f10, float f11) {
            c.this.W(f11);
        }
    }

    /* JADX INFO: compiled from: COUIToolTips.java */
    class b extends g0.d<Float> {
        b(String str) {
            super(str);
        }

        @Override // g0.d
        /* JADX INFO: renamed from: c, reason: merged with bridge method [inline-methods] */
        public float a(Float f10) {
            return c.this.Q;
        }

        @Override // g0.d
        /* JADX INFO: renamed from: d, reason: merged with bridge method [inline-methods] */
        public void b(Float f10, float f11) {
            c.this.V(f11);
        }
    }

    /* JADX INFO: renamed from: a3.c$c, reason: collision with other inner class name */
    /* JADX INFO: compiled from: COUIToolTips.java */
    class ViewOnLayoutChangeListenerC0001c implements View.OnLayoutChangeListener {
        ViewOnLayoutChangeListenerC0001c() {
        }

        /* JADX INFO: Access modifiers changed from: private */
        public /* synthetic */ void b() {
            try {
                if (c.this.f66k != null) {
                    c.this.Q();
                } else {
                    e2.a.d("COUIToolTips", "onLayoutChange post mParent == null!");
                }
            } catch (Exception e10) {
                Log.e("COUIToolTips", "refreshWhileLayoutChange fail,e:" + e10.getMessage());
            }
        }

        @Override // android.view.View.OnLayoutChangeListener
        public void onLayoutChange(View view, int i10, int i11, int i12, int i13, int i14, int i15, int i16, int i17) {
            Rect rect = new Rect(i10, i11, i12, i13);
            Rect rect2 = new Rect(i14, i15, i16, i17);
            if (!c.this.isShowing() || rect.equals(rect2) || c.this.f72q == null) {
                return;
            }
            view.post(new Runnable() { // from class: a3.d
                @Override // java.lang.Runnable
                public final void run() {
                    this.f94a.b();
                }
            });
        }
    }

    /* JADX INFO: compiled from: COUIToolTips.java */
    class d implements PopupWindow.OnDismissListener {
        d() {
        }

        @Override // android.widget.PopupWindow.OnDismissListener
        public void onDismiss() {
            c.this.f69n.removeAllViews();
        }
    }

    /* JADX INFO: compiled from: COUIToolTips.java */
    class e implements a3.f {
        e() {
        }

        @Override // a3.f
        public void a() {
            c.this.dismiss();
            c.q(c.this);
        }
    }

    /* JADX INFO: compiled from: COUIToolTips.java */
    class f implements Runnable {
        f() {
        }

        @Override // java.lang.Runnable
        public void run() {
            if (c.this.N) {
                c.this.D();
                c.this.N = false;
            }
        }
    }

    /* JADX INFO: compiled from: COUIToolTips.java */
    class g extends ViewOutlineProvider {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        final /* synthetic */ int f88a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        final /* synthetic */ int f89b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        final /* synthetic */ int f90c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        final /* synthetic */ int f91d;

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        final /* synthetic */ float f92e;

        g(int i10, int i11, int i12, int i13, float f10) {
            this.f88a = i10;
            this.f89b = i11;
            this.f90c = i12;
            this.f91d = i13;
            this.f92e = f10;
        }

        @Override // android.view.ViewOutlineProvider
        public void getOutline(View view, Outline outline) {
            Rect rect = new Rect(this.f88a, this.f89b, view.getWidth() - this.f90c, view.getHeight() - this.f91d);
            if (m2.a.a() == 1) {
                new OplusOutlineAdapter(outline, 1).setSmoothRoundRect(rect, this.f92e);
            } else if (m2.a.a() == 0) {
                new OplusOutline(outline).setSmoothRoundRect(rect, this.f92e, a2.a.j(c.this.f60e, R$dimen.coui_round_corner_m_weight));
            } else {
                outline.setRoundRect(rect, this.f92e);
            }
        }
    }

    /* JADX INFO: compiled from: COUIToolTips.java */
    public interface h {
    }

    public c(Context context, int i10) {
        this(context, i10, new a3.a.c().b());
    }

    private void A(WindowSpacingControlHelper.AnchorViewTypeEnum anchorViewTypeEnum) {
        WindowSpacingControlHelper.AnchorViewTypeEnum anchorViewTypeEnumE = this.f6474d.e(this.f72q);
        if (anchorViewTypeEnumE == WindowSpacingControlHelper.AnchorViewTypeEnum.TOOLBAR || anchorViewTypeEnumE == WindowSpacingControlHelper.AnchorViewTypeEnum.NAVIGATION) {
            return;
        }
        this.Z = c(anchorViewTypeEnum);
    }

    private ViewGroup B(Context context) {
        FrameLayout frameLayout = new FrameLayout(context);
        frameLayout.setLayoutParams(new ViewGroup.LayoutParams(-2, -2));
        return frameLayout;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void D() {
        this.f58a0.a();
        d0();
        this.f66k = null;
        super.dismiss();
        this.f69n.removeAllViews();
        this.f69n.removeCallbacks(this.W);
    }

    private int F() {
        int height = getHeight();
        Rect rect = this.f68m;
        return (height - rect.top) + rect.bottom;
    }

    private int G() {
        int width = getWidth();
        Rect rect = this.f68m;
        return (width - rect.left) + rect.right;
    }

    private void H(FrameLayout.LayoutParams layoutParams, float f10, float f11, float f12, int i10) {
        float f13 = layoutParams.leftMargin;
        int i11 = this.f59b0;
        if (f13 < f11 + f10 + i11) {
            if (this.f81z == null) {
                this.f81z = a3.e.b(this.f60e, this.f77v, 0.0f, true);
            }
            this.D = 1;
            this.f71p.setBackground(this.f81z);
            layoutParams.leftMargin = Math.max((int) (f10 + f12 + this.f59b0), this.X.centerX());
            layoutParams.rightMargin = (getWidth() - layoutParams.leftMargin) - this.f81z.getIntrinsicWidth();
            layoutParams.topMargin = (this.f70o.getPaddingTop() - this.f81z.getIntrinsicHeight()) + this.S;
        } else {
            float f14 = f10 + f12;
            if (layoutParams.rightMargin < i11 + f14) {
                this.D = 3;
                this.f71p.setBackground(this.f77v);
                layoutParams.rightMargin = Math.max((int) (f14 + this.f59b0), i.m(this.f60e) - this.X.centerX());
                layoutParams.leftMargin = (getWidth() - layoutParams.rightMargin) - this.f77v.getIntrinsicWidth();
                layoutParams.topMargin = (this.f70o.getPaddingTop() - this.f77v.getIntrinsicHeight()) + this.S;
            } else {
                this.D = 2;
                this.f71p.setBackground(this.f73r);
                layoutParams.topMargin = (this.f70o.getPaddingTop() - this.f73r.getIntrinsicHeight()) + this.S;
            }
        }
        layoutParams.topMargin += i10;
    }

    private void I(Rect rect, FrameLayout.LayoutParams layoutParams, int i10, int i11) {
        if (this.f76u == null) {
            this.f76u = a3.e.b(this.f60e, this.f73r, 90.0f, false);
        }
        layoutParams.rightMargin = ((this.f70o.getPaddingRight() - this.f76u.getIntrinsicWidth()) - i10) + this.S;
        layoutParams.leftMargin = ((getWidth() - layoutParams.rightMargin) - this.f76u.getIntrinsicWidth()) - this.S;
        layoutParams.topMargin = ((rect.centerY() - this.f62g.y) - this.K[1]) - (this.f76u.getIntrinsicHeight() / 2);
        layoutParams.bottomMargin = (getHeight() - layoutParams.topMargin) - this.f76u.getIntrinsicHeight();
        float fD = a2.a.d(this.f60e, m2.a.f() ? R$attr.couiRoundCornerMRadius : R$attr.couiRoundCornerM);
        float paddingTop = this.f70o.getPaddingTop();
        float paddingBottom = this.f70o.getPaddingBottom();
        float f10 = paddingTop + fD;
        if (layoutParams.topMargin < f10) {
            if (this.A == null) {
                this.A = a3.e.b(this.f60e, this.f77v, 90.0f, true);
            }
            this.D = 4;
            this.f71p.setBackground(this.A);
            layoutParams.topMargin = (int) f10;
            layoutParams.bottomMargin = (getHeight() - layoutParams.topMargin) - this.A.getIntrinsicHeight();
        } else {
            float f11 = fD + paddingBottom;
            if (layoutParams.bottomMargin < f11) {
                if (this.f78w == null) {
                    this.f78w = a3.e.b(this.f60e, this.f77v, 90.0f, false);
                }
                this.D = 6;
                this.f71p.setBackground(this.f78w);
                layoutParams.bottomMargin = (int) f11;
                layoutParams.topMargin = (getHeight() - layoutParams.bottomMargin) - this.f78w.getIntrinsicHeight();
            } else {
                this.D = 5;
                this.f71p.setBackground(this.f76u);
            }
        }
        layoutParams.topMargin += i11;
    }

    private void J(Rect rect, FrameLayout.LayoutParams layoutParams, int i10, int i11) {
        if (this.f75t == null) {
            this.f75t = a3.e.b(this.f60e, this.f73r, 270.0f, false);
        }
        layoutParams.leftMargin = (this.f70o.getPaddingLeft() - this.f75t.getIntrinsicWidth()) + i10 + this.S;
        layoutParams.rightMargin = ((getWidth() - layoutParams.leftMargin) - this.f75t.getIntrinsicWidth()) - this.S;
        layoutParams.topMargin = ((rect.centerY() - this.f62g.y) - this.K[1]) - (this.f75t.getIntrinsicHeight() / 2);
        layoutParams.bottomMargin = (getHeight() - layoutParams.topMargin) - this.f75t.getIntrinsicHeight();
        float fD = a2.a.d(this.f60e, m2.a.f() ? R$attr.couiRoundCornerMRadius : R$attr.couiRoundCornerM);
        float paddingTop = this.f70o.getPaddingTop();
        float paddingBottom = this.f70o.getPaddingBottom();
        float f10 = paddingTop + fD;
        if (layoutParams.topMargin < f10) {
            if (this.f80y == null) {
                this.f80y = a3.e.b(this.f60e, this.f77v, 270.0f, false);
            }
            this.D = 12;
            this.f71p.setBackground(this.f80y);
            layoutParams.topMargin = (int) f10;
            layoutParams.bottomMargin = (getHeight() - layoutParams.topMargin) - this.f80y.getIntrinsicHeight();
        } else if (layoutParams.bottomMargin < fD + paddingBottom) {
            if (this.C == null) {
                this.C = a3.e.b(this.f60e, this.f77v, 270.0f, true);
            }
            this.D = 10;
            this.f71p.setBackground(this.C);
            layoutParams.bottomMargin = (int) f10;
            layoutParams.topMargin = (getHeight() - layoutParams.bottomMargin) - this.C.getIntrinsicHeight();
        } else {
            this.D = 11;
            this.f71p.setBackground(this.f75t);
        }
        layoutParams.topMargin += i11;
    }

    private void K(FrameLayout.LayoutParams layoutParams, float f10, float f11, float f12, int i10) {
        layoutParams.gravity = 80;
        if (layoutParams.leftMargin < f11 + f10 + this.f59b0) {
            if (this.f79x == null) {
                this.f79x = a3.e.b(this.f60e, this.f77v, 180.0f, false);
            }
            this.D = 9;
            this.f71p.setBackground(this.f79x);
            layoutParams.leftMargin = Math.max((int) (f10 + f12 + this.f59b0), this.X.centerX());
            layoutParams.rightMargin = (getWidth() - layoutParams.leftMargin) - this.f79x.getIntrinsicWidth();
            layoutParams.bottomMargin = (this.f70o.getPaddingBottom() - this.f79x.getIntrinsicHeight()) + this.S;
        } else {
            float f13 = f10 + f12;
            if (layoutParams.rightMargin < f13) {
                if (this.B == null) {
                    this.B = a3.e.b(this.f60e, this.f77v, 180.0f, true);
                }
                this.D = 7;
                this.f71p.setBackground(this.B);
                layoutParams.rightMargin = Math.max((int) (f13 + this.f59b0), i.m(this.f60e) - this.X.centerX());
                layoutParams.leftMargin = (getWidth() - layoutParams.rightMargin) - this.B.getIntrinsicWidth();
                layoutParams.bottomMargin = (this.f70o.getPaddingBottom() - this.B.getIntrinsicHeight()) + this.S;
            } else {
                if (this.f74s == null) {
                    this.f74s = a3.e.b(this.f60e, this.f73r, 180.0f, false);
                }
                this.D = 8;
                this.f71p.setBackground(this.f74s);
                layoutParams.bottomMargin = (this.f70o.getPaddingBottom() - this.f74s.getIntrinsicHeight()) + this.S;
            }
        }
        layoutParams.bottomMargin -= i10;
    }

    private void L(Rect rect, FrameLayout.LayoutParams layoutParams, int i10, int i11) {
        this.f66k.getRootView().getLocationOnScreen(this.f61f);
        int i12 = this.f61f[0];
        this.f66k.getRootView().getLocationInWindow(this.f61f);
        layoutParams.leftMargin = (((rect.centerX() - this.f62g.x) - (i12 - this.f61f[0])) - (this.f73r.getIntrinsicWidth() / 2)) + i10;
        layoutParams.rightMargin = (getWidth() - layoutParams.leftMargin) - this.f73r.getIntrinsicWidth();
        int i13 = rect.top - this.K[1];
        float fD = a2.a.d(this.f60e, m2.a.f() ? R$attr.couiRoundCornerMRadius : R$attr.couiRoundCornerM);
        float paddingLeft = this.f70o.getPaddingLeft();
        float paddingRight = this.f70o.getPaddingRight();
        if (this.f62g.y >= i13) {
            H(layoutParams, fD, paddingLeft, paddingRight, i11);
        } else {
            K(layoutParams, fD, paddingLeft, paddingRight, i11);
        }
    }

    private void O(Rect rect, boolean z10, int i10, int i11) {
        this.f69n.removeAllViews();
        this.f69n.addView(this.f70o);
        if (z10) {
            u(rect, i10, i11);
        }
    }

    private void P(Rect rect) {
        int iG;
        int iMax;
        int iF;
        int i10;
        this.O = -1;
        int iC = c(this.f6474d.e(this.f72q));
        int i11 = this.E;
        if (i11 == 4) {
            iG = Math.min(rect.centerX() - (G() / 2), this.f67l.right - ((G() - this.f70o.getPaddingRight()) + this.G));
            int i12 = rect.top;
            Rect rect2 = this.f67l;
            int i13 = i12 - rect2.top;
            int i14 = (rect2.bottom - rect.bottom) - iC;
            iF = F();
            if (i13 >= iF) {
                this.O = 4;
                i10 = rect.top;
                iMax = i10 - iF;
            } else if (i14 >= iF) {
                this.O = 128;
                iMax = rect.bottom;
            } else if (i13 > i14) {
                this.O = 4;
                iMax = this.f67l.top;
                setHeight(i13);
            } else {
                this.O = 128;
                iMax = rect.bottom;
                setHeight(i14);
            }
        } else if (i11 == 128) {
            iG = Math.min(rect.centerX() - (G() / 2), this.f67l.right - ((G() - this.f70o.getPaddingRight()) + this.G));
            int i15 = rect.top;
            Rect rect3 = this.f67l;
            int i16 = i15 - rect3.top;
            int i17 = (rect3.bottom - rect.bottom) - iC;
            iF = F();
            if (i17 >= iF) {
                this.O = 128;
                iMax = rect.bottom;
            } else if (i16 >= iF) {
                this.O = 4;
                i10 = rect.top;
                iMax = i10 - iF;
            } else if (i16 > i17) {
                this.O = 4;
                iMax = this.f67l.top;
                setHeight(i16);
            } else {
                this.O = 128;
                iMax = rect.bottom;
                setHeight(i17);
            }
        } else {
            iG = i11 == 16 ? rect.left - G() : rect.right;
            iMax = Math.max(rect.centerY() - (((F() + this.f70o.getPaddingTop()) - this.f70o.getPaddingBottom()) / 2), (this.f67l.top + this.f68m.top) - this.f70o.getPaddingTop());
        }
        this.f66k.getRootView().getLocationOnScreen(this.f61f);
        int[] iArr = this.f61f;
        int i18 = iArr[0];
        int i19 = iArr[1];
        this.f66k.getRootView().getLocationInWindow(this.f61f);
        int[] iArr2 = this.f61f;
        int i20 = iArr2[0];
        int i21 = iArr2[1];
        int[] iArr3 = this.K;
        int i22 = i18 - i20;
        iArr3[0] = i22;
        int i23 = i19 - i21;
        iArr3[1] = i23;
        int i24 = iG - i22;
        Rect rect4 = this.f68m;
        int i25 = i24 - rect4.left;
        int i26 = (iMax - i23) - rect4.top;
        int i27 = this.E;
        if (i27 == 8) {
            A(WindowSpacingControlHelper.AnchorViewTypeEnum.END);
            i25 += this.Z;
        } else if (i27 == 16) {
            A(WindowSpacingControlHelper.AnchorViewTypeEnum.START);
            i25 -= this.Z;
        } else {
            int i28 = this.O;
            if (i28 == 4) {
                A(WindowSpacingControlHelper.AnchorViewTypeEnum.TOP);
                i26 -= this.Z;
            } else if (i28 == 128) {
                A(WindowSpacingControlHelper.AnchorViewTypeEnum.BOTTOM);
                i26 += this.Z;
            }
        }
        this.f62g.set(Math.max(this.G - this.f70o.getPaddingLeft(), i25), Math.max(0, i26));
    }

    private void R() {
        d0();
        this.f66k.addOnLayoutChangeListener(this.T);
    }

    private void S(int i10, int i11, int i12, int i13, int i14) {
        float fD = a2.a.d(this.f60e, m2.a.a() == 0 ? R$attr.couiRoundCornerMRadius : R$attr.couiRoundCornerM);
        this.f70o.setBackgroundColor(i10);
        this.f70o.setPaddingRelative(i11, i12, i13, i14);
        this.f70o.setOutlineProvider(new g(i11, i12, i13, i14, fD));
        this.f70o.setClipToOutline(true);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void V(float f10) {
        float f11 = f10 / 10000.0f;
        this.Q = f11;
        float f12 = 1.0f;
        float f13 = 0.0f;
        if (this.R) {
            f13 = 1.0f;
            f12 = 0.0f;
        }
        this.f69n.setAlpha(i.i(f12, f13, f11));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void W(float f10) {
        float f11 = f10 / 10000.0f;
        this.P = f11;
        float f12 = 1.0f;
        float f13 = 0.0f;
        if (this.R) {
            f13 = 1.0f;
            f12 = 0.0f;
        }
        this.f69n.setScaleX(i.i(f12, f13, f11));
        this.f69n.setScaleY(i.i(f12, f13, this.P));
    }

    private void X() {
        Activity activityC = i.c(this.f60e);
        if (activityC == null || !(activityC.isFinishing() || activityC.isDestroyed())) {
            z();
            View view = this.f66k;
            Point point = this.f62g;
            showAtLocation(view, 0, point.x, point.y);
            i.q(this.f69n, false);
            for (ViewParent parent = this.f69n.getParent(); parent != null && (parent instanceof ViewGroup); parent = parent.getParent()) {
                ViewGroup viewGroup = (ViewGroup) parent;
                viewGroup.setClipToOutline(false);
                viewGroup.setClipChildren(false);
                i.q((View) parent, false);
            }
        }
    }

    private void c0() {
        int iJ = this.f58a0.j() + this.f70o.getPaddingLeft() + this.f70o.getPaddingRight();
        int i10 = this.E;
        if (i10 == 8) {
            iJ = Math.min((((this.f67l.right - this.X.right) - this.Z) + this.f70o.getPaddingRight()) - this.G, iJ);
        } else if (i10 == 16) {
            iJ = Math.min(((this.X.left - this.f67l.left) - this.Z) - (this.G - this.f70o.getPaddingLeft()), iJ);
        }
        Rect rect = this.f67l;
        int iMax = Math.max(Math.min(rect.right - rect.left, iJ), 0);
        this.f58a0.i(this.f70o, iMax);
        this.f70o.measure(0, 0);
        setWidth(this.f58a0.e(iMax, this.f70o));
        int measuredHeight = this.f70o.getMeasuredHeight();
        Rect rect2 = this.f67l;
        setHeight(Math.min(measuredHeight, rect2.bottom - rect2.top));
        if (((this.X.centerY() - (((F() + this.f70o.getPaddingTop()) - this.f70o.getPaddingBottom()) / 2)) + F()) - this.f70o.getPaddingBottom() >= this.f67l.bottom) {
            this.E = 4;
            int iJ2 = this.f58a0.j() + this.f70o.getPaddingLeft() + this.f70o.getPaddingRight();
            Rect rect3 = this.f67l;
            int iMax2 = Math.max(Math.min(rect3.right - rect3.left, iJ2), 0);
            this.f58a0.i(this.f70o, iMax2);
            this.f70o.measure(0, 0);
            setWidth(this.f58a0.e(iMax2, this.f70o));
            setHeight(this.f70o.getMeasuredHeight());
        }
    }

    private void d0() {
        View view = this.f66k;
        if (view != null) {
            view.removeOnLayoutChangeListener(this.T);
        }
    }

    static /* synthetic */ h q(c cVar) {
        cVar.getClass();
        return null;
    }

    private void u(Rect rect, int i10, int i11) {
        if (N(this.f72q)) {
            i10 = -i10;
        }
        int i12 = this.E;
        if (i12 == 128 || i12 == 4) {
            i11 = 0;
        } else {
            i10 = 0;
        }
        this.f71p = new ImageView(this.f60e);
        FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(-2, -2);
        int i13 = this.E;
        if (i13 == 4 || i13 == 128) {
            L(rect, layoutParams, i10, i11);
        } else if (i13 == 16) {
            I(rect, layoutParams, i10, i11);
        } else {
            J(rect, layoutParams, i10, i11);
        }
        this.f69n.addView(this.f71p, layoutParams);
        i.q(this.f71p, false);
    }

    private void v() {
        ViewGroup viewGroup = this.f70o;
        Resources resources = this.f60e.getResources();
        int i10 = R$dimen.support_shadow_size_level_four;
        int dimensionPixelOffset = resources.getDimensionPixelOffset(i10);
        Resources resources2 = this.f60e.getResources();
        int i11 = R$dimen.support_shadow_size_level_two;
        int dimensionPixelOffset2 = resources2.getDimensionPixelOffset(i11);
        Context context = this.f60e;
        int i12 = R$color.coui_tool_tips_shadow_color;
        c3.h.e(viewGroup, 3, dimensionPixelOffset, dimensionPixelOffset2, androidx.core.content.a.c(context, i12));
        c3.h.e(this.f71p, 3, this.f60e.getResources().getDimensionPixelOffset(i10), this.f60e.getResources().getDimensionPixelOffset(i11), androidx.core.content.a.c(this.f60e, i12));
        x(true);
    }

    private void w() {
        c3.h.b(this.f70o);
        c3.h.b(this.f71p);
        x(false);
        this.N = true;
        this.f69n.removeCallbacks(this.W);
        this.f69n.postDelayed(this.W, 320L);
    }

    private void x(boolean z10) {
        this.R = z10;
        this.f69n.setPivotX(this.L * getWidth());
        this.f69n.setPivotY(this.M * getHeight());
        v1.c cVar = new v1.c(Float.valueOf(this.P), this.f63h);
        v1.d dVar = new v1.d();
        dVar.d(0.2f);
        dVar.g(0.4f);
        cVar.y(dVar);
        cVar.n(0.0f);
        cVar.s(10000.0f);
        v1.c cVar2 = new v1.c(Float.valueOf(this.Q), this.f64i);
        v1.d dVar2 = new v1.d();
        dVar2.d(0.2f);
        dVar2.g(0.3f);
        cVar2.y(dVar2);
        cVar2.n(0.0f);
        cVar2.s(10000.0f);
    }

    private void y() {
        int i10 = this.E;
        if (i10 != 4 && i10 != 128) {
            this.L = i10 == 16 ? 1.0f : 0.0f;
            this.M = ((this.X.centerY() - this.f62g.y) - this.K[1]) / F();
            return;
        }
        if ((this.X.centerX() - this.K[0]) - this.f62g.x >= G()) {
            this.L = 1.0f;
        } else if (G() != 0) {
            int iCenterX = (this.X.centerX() - this.K[0]) - this.f62g.x;
            if (iCenterX <= 0) {
                iCenterX = -iCenterX;
            }
            this.L = iCenterX / G();
        } else {
            this.L = 0.5f;
        }
        if (this.f62g.y >= this.X.top - this.K[1]) {
            this.M = 0.0f;
        } else {
            this.M = 1.0f;
        }
    }

    private void z() {
        this.f66k.getWindowVisibleDisplayFrame(this.f67l);
        R();
        Rect rect = new Rect();
        this.X = rect;
        this.f72q.getGlobalVisibleRect(rect);
        Rect rect2 = new Rect();
        this.Y = rect2;
        this.f66k.getGlobalVisibleRect(rect2);
        int[] iArr = new int[2];
        this.f66k.getLocationOnScreen(iArr);
        this.X.offset(iArr[0], iArr[1]);
        this.Y.offset(iArr[0], iArr[1]);
        int[] iArr2 = new int[2];
        Rect rect3 = this.X;
        this.f6474d.j(new int[]{rect3.left, rect3.top}, iArr2, this.f72q);
        int width = this.f72q.getWidth();
        int height = this.f72q.getHeight();
        Rect rect4 = this.X;
        int i10 = iArr2[0];
        int i11 = width / 2;
        rect4.left = i10 - i11;
        int i12 = iArr2[1];
        int i13 = height / 2;
        rect4.top = i12 - i13;
        rect4.right = i10 + i11;
        rect4.bottom = i12 + i13;
        Rect rect5 = this.f67l;
        rect5.left = Math.max(rect5.left, this.Y.left);
        Rect rect6 = this.f67l;
        rect6.top = Math.max(rect6.top, this.Y.top);
        Rect rect7 = this.f67l;
        rect7.right = Math.min(rect7.right, this.Y.right);
        Rect rect8 = this.f67l;
        rect8.bottom = Math.min(rect8.bottom, this.Y.bottom);
        c0();
        P(this.X);
        if (this.H) {
            O(this.X, this.F, 0, 0);
        } else {
            O(this.X, this.F, -this.J, -this.I);
        }
        setContentView(this.f69n);
        y();
        v();
        if (N(this.f72q)) {
            this.f62g.x -= this.J;
        } else {
            this.f62g.x += this.J;
        }
        this.f62g.y += this.I;
    }

    public void C() {
        D();
        this.N = false;
    }

    @Deprecated
    public TextView E() {
        return this.f58a0.b();
    }

    public void M(int i10) {
        int i11 = this.f58a0.h()[0];
        int i12 = this.f58a0.h()[1];
        this.f65j = i10;
        if (this.f58a0 instanceof a3.a) {
            this.f73r = androidx.core.content.a.e(this.f60e, i10 == 0 ? R$drawable.coui_blue_sharp_middle_arrow_up : R$drawable.coui_white_sharp_middle_arrow_up);
            this.f77v = androidx.core.content.a.e(this.f60e, i10 == 0 ? R$drawable.coui_blue_sharp_edges_arrow_up_right : R$drawable.coui_white_sharp_edges_arrow_up_right);
        } else {
            this.f73r = androidx.core.content.a.e(this.f60e, R$drawable.coui_white_sharp_middle_arrow_up);
            this.f77v = androidx.core.content.a.e(this.f60e, R$drawable.coui_white_sharp_edges_arrow_up_right);
        }
        TypedArray typedArrayObtainStyledAttributes = this.f60e.obtainStyledAttributes(null, R$styleable.COUIToolTips, i11, i12);
        int color = typedArrayObtainStyledAttributes.getColor(R$styleable.COUIToolTips_couiToolTipsBackgroundColor, 0);
        int dimensionPixelSize = typedArrayObtainStyledAttributes.getDimensionPixelSize(R$styleable.COUIToolTips_couiToolTipsPaddingStart, -1);
        int dimensionPixelSize2 = typedArrayObtainStyledAttributes.getDimensionPixelSize(R$styleable.COUIToolTips_couiToolTipsPaddingTop, -1);
        int dimensionPixelSize3 = typedArrayObtainStyledAttributes.getDimensionPixelSize(R$styleable.COUIToolTips_couiToolTipsPaddingEnd, -1);
        int dimensionPixelSize4 = typedArrayObtainStyledAttributes.getDimensionPixelSize(R$styleable.COUIToolTips_couiToolTipsPaddingBottom, -1);
        int i13 = R$styleable.COUIToolTips_couiToolTipsArrowOverflowOffset;
        this.Z = typedArrayObtainStyledAttributes.getDimensionPixelSize(i13, 0);
        int dimensionPixelSize5 = typedArrayObtainStyledAttributes.getDimensionPixelSize(i13, 0);
        int dimensionPixelSize6 = typedArrayObtainStyledAttributes.getDimensionPixelSize(R$styleable.COUIToolTips_couiToolTipsMinWidth, 0);
        int dimensionPixelSize7 = typedArrayObtainStyledAttributes.getDimensionPixelSize(R$styleable.COUIToolTips_couiToolTipsViewportOffsetStart, 0);
        int dimensionPixelSize8 = typedArrayObtainStyledAttributes.getDimensionPixelSize(R$styleable.COUIToolTips_couiToolTipsViewportOffsetTop, 0);
        int dimensionPixelSize9 = typedArrayObtainStyledAttributes.getDimensionPixelSize(R$styleable.COUIToolTips_couiToolTipsViewportOffsetEnd, 0);
        int dimensionPixelSize10 = typedArrayObtainStyledAttributes.getDimensionPixelSize(R$styleable.COUIToolTips_couiToolTipsViewportOffsetBottom, 0);
        typedArrayObtainStyledAttributes.recycle();
        ViewGroup viewGroup = (ViewGroup) LayoutInflater.from(this.f60e).inflate(this.f58a0.d(), (ViewGroup) null);
        this.f70o = viewGroup;
        viewGroup.setMinimumWidth(dimensionPixelSize6);
        S(color, dimensionPixelSize, dimensionPixelSize2, dimensionPixelSize3, dimensionPixelSize4);
        ViewGroup viewGroupB = B(this.f60e);
        this.f69n = viewGroupB;
        b2.a.b(viewGroupB, false);
        this.f58a0.c(this.f70o);
        if (N(this.f70o)) {
            this.f68m = new Rect(dimensionPixelSize9, dimensionPixelSize8, dimensionPixelSize7, dimensionPixelSize10);
        } else {
            this.f68m = new Rect(dimensionPixelSize7, dimensionPixelSize8, dimensionPixelSize9, dimensionPixelSize10);
        }
        setClippingEnabled(false);
        setAnimationStyle(0);
        setElevation(this.f60e.getResources().getDimensionPixelOffset(R$dimen.support_shadow_size_level_four));
        setOnDismissListener(this.U);
        ImageView imageView = this.f71p;
        if (imageView != null) {
            imageView.setBackground(this.f73r);
        }
        this.f6473c = false;
        h(false);
        int dimensionPixelSize11 = this.f60e.getResources().getDimensionPixelSize(com.support.tips.R$dimen.coui_tooltips_vertical_and_horizontal_gap_top) + dimensionPixelSize5;
        int dimensionPixelSize12 = this.f60e.getResources().getDimensionPixelSize(com.support.tips.R$dimen.coui_tooltips_vertical_and_horizontal_gap_bottom) + dimensionPixelSize5;
        a(dimensionPixelSize11, WindowSpacingControlHelper.AnchorViewTypeEnum.TOP);
        a(dimensionPixelSize12, WindowSpacingControlHelper.AnchorViewTypeEnum.BOTTOM);
        a(dimensionPixelSize5, WindowSpacingControlHelper.AnchorViewTypeEnum.START);
        a(dimensionPixelSize5, WindowSpacingControlHelper.AnchorViewTypeEnum.END);
        a(this.f60e.getResources().getDimensionPixelSize(com.support.tips.R$dimen.coui_tooltips_navigation_margin), WindowSpacingControlHelper.AnchorViewTypeEnum.NAVIGATION);
        a(this.f60e.getResources().getDimensionPixelSize(com.support.tips.R$dimen.coui_tooltips_toolbar_margin), WindowSpacingControlHelper.AnchorViewTypeEnum.TOOLBAR);
        this.S = this.f60e.getResources().getDimensionPixelSize(com.support.tips.R$dimen.coui_tooltips_indicator_embed_distance);
        this.G = this.f60e.getResources().getDimensionPixelSize(com.support.tips.R$dimen.coui_tooltips_bubble_horizontal_padding);
        this.f59b0 = this.f60e.getResources().getDimensionPixelSize(com.support.tips.R$dimen.coui_tooltips_edge_extra_distance);
    }

    public boolean N(View view) {
        return view.getLayoutDirection() == 1;
    }

    public void Q() {
        Activity activityC = i.c(this.f60e);
        if (activityC != null && (activityC.isFinishing() || activityC.isDestroyed())) {
            e2.a.d("COUIToolTips", "activity is not active when refreshWhileLayoutChange");
            return;
        }
        View view = this.f72q;
        if (view == null || !i.o(view)) {
            C();
            e2.a.d("COUIToolTips", "mAnchor is now visible, so dismiss it.");
        } else {
            z();
            Point point = this.f62g;
            update(point.x, point.y, getWidth(), getHeight());
        }
    }

    public void T(CharSequence charSequence) {
        this.f58a0.f(charSequence);
    }

    public void U(boolean z10) {
        if (z10) {
            setTouchable(true);
            setFocusable(true);
            setOutsideTouchable(true);
        } else {
            setFocusable(false);
            setOutsideTouchable(false);
        }
        update();
    }

    public void Y(View view, int i10) {
        Z(view, i10, true);
    }

    public void Z(View view, int i10, boolean z10) {
        a0(view, i10, z10, 0, 0);
    }

    public void a0(View view, int i10, boolean z10, int i11, int i12) {
        b0(view, i10, z10, i11, i12, false);
    }

    public void b0(View view, int i10, boolean z10, int i11, int i12, boolean z11) {
        if (isShowing()) {
            return;
        }
        WindowSpacingControlHelper.AnchorViewTypeEnum anchorViewTypeEnumE = this.f6474d.e(view);
        if (anchorViewTypeEnumE == WindowSpacingControlHelper.AnchorViewTypeEnum.TOOLBAR) {
            this.Z = c(anchorViewTypeEnumE);
        } else if (anchorViewTypeEnumE == WindowSpacingControlHelper.AnchorViewTypeEnum.NAVIGATION) {
            this.Z = b(view, anchorViewTypeEnumE);
        }
        this.f66k = view.getRootView();
        this.F = z10;
        this.H = z11;
        this.I = i12;
        this.J = i11;
        this.E = i10;
        if (i10 == 32 || i10 == 64) {
            if (N(view)) {
                this.E = this.E == 32 ? 8 : 16;
            } else {
                this.E = this.E != 32 ? 8 : 16;
            }
        } else if (i10 == 256) {
            this.E = 4;
        }
        this.f72q = view;
        try {
            X();
        } catch (Exception e10) {
            Log.e("COUIToolTips", "showToolTips fail,e:" + e10.getMessage());
        }
        this.f69n.removeCallbacks(this.W);
    }

    @Override // android.widget.PopupWindow
    public void dismiss() {
        d0();
        if (!this.N) {
            w();
        } else {
            D();
            this.N = false;
        }
    }

    @Override // com.coui.appcompat.poplist.COUIPopupWindow
    protected void g(Context context, TypedArray typedArray) {
        setBackgroundDrawable(new ColorDrawable(0));
    }

    public c(Context context, int i10, a3.b bVar) {
        super(context);
        this.f61f = new int[2];
        this.f62g = new Point();
        this.f63h = new a("toolTipsScaleProperty");
        this.f64i = new b("toolTipsAlphaProperty");
        this.f67l = new Rect();
        this.D = 2;
        this.E = 4;
        this.K = new int[2];
        this.O = -1;
        this.P = 0.0f;
        this.Q = 0.0f;
        this.T = new ViewOnLayoutChangeListenerC0001c();
        this.U = new d();
        this.V = new e();
        this.W = new f();
        this.f60e = context;
        this.f58a0 = bVar;
        bVar.g(this.V, context, i10);
        M(i10);
    }
}
