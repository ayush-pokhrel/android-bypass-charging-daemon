package a3;

import android.content.Context;
import android.view.ViewGroup;
import android.widget.TextView;

/* JADX INFO: compiled from: COUIIBubbleStyle.java */
/* JADX INFO: loaded from: classes.dex */
public interface b {
    void a();

    TextView b();

    void c(ViewGroup viewGroup);

    int d();

    int e(int i10, ViewGroup viewGroup);

    void f(CharSequence charSequence);

    void g(f fVar, Context context, int i10);

    int[] h();

    void i(ViewGroup viewGroup, int i10);

    int j();
}
