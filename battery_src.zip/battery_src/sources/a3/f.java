package a3;

/* JADX INFO: compiled from: IToolTipsAction.java */
/* JADX INFO: loaded from: classes.dex */
public interface f {
    void a();
}
