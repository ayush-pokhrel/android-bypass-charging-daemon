package androidx.core.widget;

import android.content.res.Resources;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.AnimationUtils;
import android.view.animation.Interpolator;
import androidx.core.view.h0;

/* JADX INFO: compiled from: AutoScrollHelper.java */
/* JADX INFO: loaded from: classes.dex */
public abstract class a implements View.OnTouchListener {

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    private static final int f2448u = ViewConfiguration.getTapTimeout();

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    final View f2451c;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private Runnable f2452g;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private int f2455j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    private int f2456k;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    private boolean f2460o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    boolean f2461p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    boolean f2462q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    boolean f2463r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    private boolean f2464s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    private boolean f2465t;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    final C0020a f2449a = new C0020a();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private final Interpolator f2450b = new AccelerateInterpolator();

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private float[] f2453h = {0.0f, 0.0f};

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private float[] f2454i = {Float.MAX_VALUE, Float.MAX_VALUE};

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private float[] f2457l = {0.0f, 0.0f};

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    private float[] f2458m = {0.0f, 0.0f};

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    private float[] f2459n = {Float.MAX_VALUE, Float.MAX_VALUE};

    /* JADX INFO: renamed from: androidx.core.widget.a$a, reason: collision with other inner class name */
    /* JADX INFO: compiled from: AutoScrollHelper.java */
    private static class C0020a {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private int f2466a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private int f2467b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        private float f2468c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        private float f2469d;

        /* JADX INFO: renamed from: j, reason: collision with root package name */
        private float f2475j;

        /* JADX INFO: renamed from: k, reason: collision with root package name */
        private int f2476k;

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        private long f2470e = Long.MIN_VALUE;

        /* JADX INFO: renamed from: i, reason: collision with root package name */
        private long f2474i = -1;

        /* JADX INFO: renamed from: f, reason: collision with root package name */
        private long f2471f = 0;

        /* JADX INFO: renamed from: g, reason: collision with root package name */
        private int f2472g = 0;

        /* JADX INFO: renamed from: h, reason: collision with root package name */
        private int f2473h = 0;

        C0020a() {
        }

        private float e(long j10) {
            long j11 = this.f2470e;
            if (j10 < j11) {
                return 0.0f;
            }
            long j12 = this.f2474i;
            if (j12 < 0 || j10 < j12) {
                return a.e((j10 - j11) / this.f2466a, 0.0f, 1.0f) * 0.5f;
            }
            float f10 = this.f2475j;
            return (1.0f - f10) + (f10 * a.e((j10 - j12) / this.f2476k, 0.0f, 1.0f));
        }

        private float g(float f10) {
            return ((-4.0f) * f10 * f10) + (f10 * 4.0f);
        }

        public void a() {
            if (this.f2471f == 0) {
                throw new RuntimeException("Cannot compute scroll delta before calling start()");
            }
            long jCurrentAnimationTimeMillis = AnimationUtils.currentAnimationTimeMillis();
            float fG = g(e(jCurrentAnimationTimeMillis));
            long j10 = jCurrentAnimationTimeMillis - this.f2471f;
            this.f2471f = jCurrentAnimationTimeMillis;
            float f10 = j10 * fG;
            this.f2472g = (int) (this.f2468c * f10);
            this.f2473h = (int) (f10 * this.f2469d);
        }

        public int b() {
            return this.f2472g;
        }

        public int c() {
            return this.f2473h;
        }

        public int d() {
            float f10 = this.f2468c;
            return (int) (f10 / Math.abs(f10));
        }

        public int f() {
            float f10 = this.f2469d;
            return (int) (f10 / Math.abs(f10));
        }

        public boolean h() {
            return this.f2474i > 0 && AnimationUtils.currentAnimationTimeMillis() > this.f2474i + ((long) this.f2476k);
        }

        public void i() {
            long jCurrentAnimationTimeMillis = AnimationUtils.currentAnimationTimeMillis();
            this.f2476k = a.f((int) (jCurrentAnimationTimeMillis - this.f2470e), 0, this.f2467b);
            this.f2475j = e(jCurrentAnimationTimeMillis);
            this.f2474i = jCurrentAnimationTimeMillis;
        }

        public void j(int i10) {
            this.f2467b = i10;
        }

        public void k(int i10) {
            this.f2466a = i10;
        }

        public void l(float f10, float f11) {
            this.f2468c = f10;
            this.f2469d = f11;
        }

        public void m() {
            long jCurrentAnimationTimeMillis = AnimationUtils.currentAnimationTimeMillis();
            this.f2470e = jCurrentAnimationTimeMillis;
            this.f2474i = -1L;
            this.f2471f = jCurrentAnimationTimeMillis;
            this.f2475j = 0.5f;
            this.f2472g = 0;
            this.f2473h = 0;
        }
    }

    /* JADX INFO: compiled from: AutoScrollHelper.java */
    private class b implements Runnable {
        b() {
        }

        @Override // java.lang.Runnable
        public void run() {
            a aVar = a.this;
            if (aVar.f2463r) {
                if (aVar.f2461p) {
                    aVar.f2461p = false;
                    aVar.f2449a.m();
                }
                C0020a c0020a = a.this.f2449a;
                if (c0020a.h() || !a.this.u()) {
                    a.this.f2463r = false;
                    return;
                }
                a aVar2 = a.this;
                if (aVar2.f2462q) {
                    aVar2.f2462q = false;
                    aVar2.c();
                }
                c0020a.a();
                a.this.j(c0020a.b(), c0020a.c());
                h0.c0(a.this.f2451c, this);
            }
        }
    }

    public a(View view) {
        this.f2451c = view;
        float f10 = Resources.getSystem().getDisplayMetrics().density;
        float f11 = (int) ((1575.0f * f10) + 0.5f);
        o(f11, f11);
        float f12 = (int) ((f10 * 315.0f) + 0.5f);
        p(f12, f12);
        l(1);
        n(Float.MAX_VALUE, Float.MAX_VALUE);
        s(0.2f, 0.2f);
        t(1.0f, 1.0f);
        k(f2448u);
        r(500);
        q(500);
    }

    private float d(int i10, float f10, float f11, float f12) {
        float fH = h(this.f2453h[i10], f11, this.f2454i[i10], f10);
        if (fH == 0.0f) {
            return 0.0f;
        }
        float f13 = this.f2457l[i10];
        float f14 = this.f2458m[i10];
        float f15 = this.f2459n[i10];
        float f16 = f13 * f12;
        return fH > 0.0f ? e(fH * f16, f14, f15) : -e((-fH) * f16, f14, f15);
    }

    static float e(float f10, float f11, float f12) {
        if (f10 > f12) {
            return f12;
        }
        return f10 < f11 ? f11 : f10;
    }

    static int f(int i10, int i11, int i12) {
        if (i10 > i12) {
            return i12;
        }
        return i10 < i11 ? i11 : i10;
    }

    private float g(float f10, float f11) {
        if (f11 == 0.0f) {
            return 0.0f;
        }
        int i10 = this.f2455j;
        if (i10 == 0 || i10 == 1) {
            if (f10 < f11) {
                if (f10 >= 0.0f) {
                    return 1.0f - (f10 / f11);
                }
                if (this.f2463r && i10 == 1) {
                    return 1.0f;
                }
            }
        } else if (i10 == 2 && f10 < 0.0f) {
            return f10 / (-f11);
        }
        return 0.0f;
    }

    private float h(float f10, float f11, float f12, float f13) {
        float interpolation;
        float fE = e(f10 * f11, 0.0f, f12);
        float fG = g(f11 - f13, fE) - g(f13, fE);
        if (fG < 0.0f) {
            interpolation = -this.f2450b.getInterpolation(-fG);
        } else {
            if (fG <= 0.0f) {
                return 0.0f;
            }
            interpolation = this.f2450b.getInterpolation(fG);
        }
        return e(interpolation, -1.0f, 1.0f);
    }

    private void i() {
        if (this.f2461p) {
            this.f2463r = false;
        } else {
            this.f2449a.i();
        }
    }

    private void v() {
        int i10;
        if (this.f2452g == null) {
            this.f2452g = new b();
        }
        this.f2463r = true;
        this.f2461p = true;
        if (this.f2460o || (i10 = this.f2456k) <= 0) {
            this.f2452g.run();
        } else {
            h0.d0(this.f2451c, this.f2452g, i10);
        }
        this.f2460o = true;
    }

    public abstract boolean a(int i10);

    public abstract boolean b(int i10);

    void c() {
        long jUptimeMillis = SystemClock.uptimeMillis();
        MotionEvent motionEventObtain = MotionEvent.obtain(jUptimeMillis, jUptimeMillis, 3, 0.0f, 0.0f, 0);
        this.f2451c.onTouchEvent(motionEventObtain);
        motionEventObtain.recycle();
    }

    public abstract void j(int i10, int i11);

    public a k(int i10) {
        this.f2456k = i10;
        return this;
    }

    public a l(int i10) {
        this.f2455j = i10;
        return this;
    }

    public a m(boolean z10) {
        if (this.f2464s && !z10) {
            i();
        }
        this.f2464s = z10;
        return this;
    }

    public a n(float f10, float f11) {
        float[] fArr = this.f2454i;
        fArr[0] = f10;
        fArr[1] = f11;
        return this;
    }

    public a o(float f10, float f11) {
        float[] fArr = this.f2459n;
        fArr[0] = f10 / 1000.0f;
        fArr[1] = f11 / 1000.0f;
        return this;
    }

    /* JADX WARN: Code duplicated, block: B:13:0x0016  */
    @Override // android.view.View.OnTouchListener
    public boolean onTouch(View view, MotionEvent motionEvent) {
        if (!this.f2464s) {
            return false;
        }
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked != 0) {
            if (actionMasked == 1) {
                i();
            } else if (actionMasked != 2) {
                if (actionMasked == 3) {
                    i();
                }
            }
            return this.f2465t && this.f2463r;
        }
        this.f2462q = true;
        this.f2460o = false;
        this.f2449a.l(d(0, motionEvent.getX(), view.getWidth(), this.f2451c.getWidth()), d(1, motionEvent.getY(), view.getHeight(), this.f2451c.getHeight()));
        if (!this.f2463r && u()) {
            v();
        }
        if (this.f2465t) {
            return false;
        }
    }

    public a p(float f10, float f11) {
        float[] fArr = this.f2458m;
        fArr[0] = f10 / 1000.0f;
        fArr[1] = f11 / 1000.0f;
        return this;
    }

    public a q(int i10) {
        this.f2449a.j(i10);
        return this;
    }

    public a r(int i10) {
        this.f2449a.k(i10);
        return this;
    }

    public a s(float f10, float f11) {
        float[] fArr = this.f2453h;
        fArr[0] = f10;
        fArr[1] = f11;
        return this;
    }

    public a t(float f10, float f11) {
        float[] fArr = this.f2457l;
        fArr[0] = f10 / 1000.0f;
        fArr[1] = f11 / 1000.0f;
        return this;
    }

    boolean u() {
        C0020a c0020a = this.f2449a;
        int iF = c0020a.f();
        int iD = c0020a.d();
        return (iF != 0 && b(iF)) || (iD != 0 && a(iD));
    }
}
