package androidx.core.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.ProgressBar;

/* JADX INFO: loaded from: classes.dex */
public class ContentLoadingProgressBar extends ProgressBar {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    long f2417a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    boolean f2418b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    boolean f2419c;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    boolean f2420g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private final Runnable f2421h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private final Runnable f2422i;

    public ContentLoadingProgressBar(Context context) {
        this(context, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void c() {
        this.f2418b = false;
        this.f2417a = -1L;
        setVisibility(8);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void d() {
        this.f2419c = false;
        if (this.f2420g) {
            return;
        }
        this.f2417a = System.currentTimeMillis();
        setVisibility(0);
    }

    private void e() {
        removeCallbacks(this.f2421h);
        removeCallbacks(this.f2422i);
    }

    @Override // android.widget.ProgressBar, android.view.View
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        e();
    }

    @Override // android.widget.ProgressBar, android.view.View
    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        e();
    }

    public ContentLoadingProgressBar(Context context, AttributeSet attributeSet) {
        super(context, attributeSet, 0);
        this.f2417a = -1L;
        this.f2418b = false;
        this.f2419c = false;
        this.f2420g = false;
        this.f2421h = new Runnable() { // from class: androidx.core.widget.d
            @Override // java.lang.Runnable
            public final void run() {
                this.f2478a.c();
            }
        };
        this.f2422i = new Runnable() { // from class: androidx.core.widget.e
            @Override // java.lang.Runnable
            public final void run() {
                this.f2479a.d();
            }
        };
    }
}
