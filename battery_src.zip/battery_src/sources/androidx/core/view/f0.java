package androidx.core.view;

/* JADX INFO: compiled from: VelocityTrackerFallback.java */
/* JADX INFO: loaded from: classes.dex */
class f0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final float[] f2331a = new float[20];

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private final long[] f2332b = new long[20];

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private float f2333c = 0.0f;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private int f2334d = 0;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private int f2335e = 0;

    f0() {
    }

    private float b() {
        long[] jArr;
        long j10;
        int i10 = this.f2334d;
        if (i10 < 2) {
            return 0.0f;
        }
        int i11 = this.f2335e;
        int i12 = ((i11 + 20) - (i10 - 1)) % 20;
        long j11 = this.f2332b[i11];
        while (true) {
            jArr = this.f2332b;
            j10 = jArr[i12];
            if (j11 - j10 <= 100) {
                break;
            }
            this.f2334d--;
            i12 = (i12 + 1) % 20;
        }
        int i13 = this.f2334d;
        if (i13 < 2) {
            return 0.0f;
        }
        if (i13 == 2) {
            int i14 = (i12 + 1) % 20;
            long j12 = jArr[i14];
            if (j10 == j12) {
                return 0.0f;
            }
            return this.f2331a[i14] / (j12 - j10);
        }
        float fAbs = 0.0f;
        int i15 = 0;
        for (int i16 = 0; i16 < this.f2334d - 1; i16++) {
            int i17 = i16 + i12;
            long[] jArr2 = this.f2332b;
            long j13 = jArr2[i17 % 20];
            int i18 = (i17 + 1) % 20;
            if (jArr2[i18] != j13) {
                i15++;
                float fC = c(fAbs);
                float f10 = this.f2331a[i18] / (this.f2332b[i18] - j13);
                fAbs += (f10 - fC) * Math.abs(f10);
                if (i15 == 1) {
                    fAbs *= 0.5f;
                }
            }
        }
        return c(fAbs);
    }

    private static float c(float f10) {
        return (f10 < 0.0f ? -1.0f : 1.0f) * ((float) Math.sqrt(Math.abs(f10) * 2.0f));
    }

    void a(int i10, float f10) {
        float fB = b() * i10;
        this.f2333c = fB;
        if (fB < (-Math.abs(f10))) {
            this.f2333c = -Math.abs(f10);
        } else if (this.f2333c > Math.abs(f10)) {
            this.f2333c = Math.abs(f10);
        }
    }
}
