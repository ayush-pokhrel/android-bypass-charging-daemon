package androidx.core.view;

import android.graphics.Rect;
import android.view.DisplayCutout;
import java.util.List;

/* JADX INFO: compiled from: DisplayCutoutCompat.java */
/* JADX INFO: loaded from: classes.dex */
public final class g {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final DisplayCutout f2336a;

    /* JADX INFO: compiled from: DisplayCutoutCompat.java */
    static class a {
        static DisplayCutout a(Rect rect, List<Rect> list) {
            return new DisplayCutout(rect, list);
        }

        static List<Rect> b(DisplayCutout displayCutout) {
            return displayCutout.getBoundingRects();
        }

        static int c(DisplayCutout displayCutout) {
            return displayCutout.getSafeInsetBottom();
        }

        static int d(DisplayCutout displayCutout) {
            return displayCutout.getSafeInsetLeft();
        }

        static int e(DisplayCutout displayCutout) {
            return displayCutout.getSafeInsetRight();
        }

        static int f(DisplayCutout displayCutout) {
            return displayCutout.getSafeInsetTop();
        }
    }

    private g(DisplayCutout displayCutout) {
        this.f2336a = displayCutout;
    }

    static g e(DisplayCutout displayCutout) {
        if (displayCutout == null) {
            return null;
        }
        return new g(displayCutout);
    }

    public int a() {
        return a.c(this.f2336a);
    }

    public int b() {
        return a.d(this.f2336a);
    }

    public int c() {
        return a.e(this.f2336a);
    }

    public int d() {
        return a.f(this.f2336a);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || g.class != obj.getClass()) {
            return false;
        }
        return a0.c.a(this.f2336a, ((g) obj).f2336a);
    }

    public int hashCode() {
        DisplayCutout displayCutout = this.f2336a;
        if (displayCutout == null) {
            return 0;
        }
        return displayCutout.hashCode();
    }

    public String toString() {
        return "DisplayCutoutCompat{" + this.f2336a + "}";
    }
}
