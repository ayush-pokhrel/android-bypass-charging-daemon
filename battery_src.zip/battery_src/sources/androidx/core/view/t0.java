package androidx.core.view;

import android.annotation.SuppressLint;
import android.graphics.Rect;
import android.util.Log;
import android.view.View;
import android.view.WindowInsets;
import java.lang.reflect.Field;
import java.util.Objects;

/* JADX INFO: compiled from: WindowInsetsCompat.java */
/* JADX INFO: loaded from: classes.dex */
public class t0 {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final t0 f2384b = j.f2403l;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final k f2385a;

    /* JADX INFO: compiled from: WindowInsetsCompat.java */
    @SuppressLint({"SoonBlockedPrivateApi"})
    static class a {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private static Field f2386a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private static Field f2387b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        private static Field f2388c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        private static boolean f2389d;

        static {
            try {
                Field declaredField = View.class.getDeclaredField("mAttachInfo");
                f2386a = declaredField;
                declaredField.setAccessible(true);
                Class<?> cls = Class.forName("android.view.View$AttachInfo");
                Field declaredField2 = cls.getDeclaredField("mStableInsets");
                f2387b = declaredField2;
                declaredField2.setAccessible(true);
                Field declaredField3 = cls.getDeclaredField("mContentInsets");
                f2388c = declaredField3;
                declaredField3.setAccessible(true);
                f2389d = true;
            } catch (ReflectiveOperationException e10) {
                Log.w("WindowInsetsCompat", "Failed to get visible insets from AttachInfo " + e10.getMessage(), e10);
            }
        }

        public static t0 a(View view) {
            if (f2389d && view.isAttachedToWindow()) {
                try {
                    Object obj = f2386a.get(view.getRootView());
                    if (obj != null) {
                        Rect rect = (Rect) f2387b.get(obj);
                        Rect rect2 = (Rect) f2388c.get(obj);
                        if (rect != null && rect2 != null) {
                            t0 t0VarA = new b().b(androidx.core.graphics.b.c(rect)).c(androidx.core.graphics.b.c(rect2)).a();
                            t0VarA.t(t0VarA);
                            t0VarA.d(view.getRootView());
                            return t0VarA;
                        }
                    }
                } catch (IllegalAccessException e10) {
                    Log.w("WindowInsetsCompat", "Failed to get insets from AttachInfo. " + e10.getMessage(), e10);
                }
            }
            return null;
        }
    }

    /* JADX INFO: compiled from: WindowInsetsCompat.java */
    private static class d extends c {
        d() {
        }

        d(t0 t0Var) {
            super(t0Var);
        }
    }

    /* JADX INFO: compiled from: WindowInsetsCompat.java */
    private static class e {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private final t0 f2392a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        androidx.core.graphics.b[] f2393b;

        e() {
            this(new t0((t0) null));
        }

        protected final void a() {
            androidx.core.graphics.b[] bVarArr = this.f2393b;
            if (bVarArr != null) {
                androidx.core.graphics.b bVarF = bVarArr[l.b(1)];
                androidx.core.graphics.b bVarF2 = this.f2393b[l.b(2)];
                if (bVarF2 == null) {
                    bVarF2 = this.f2392a.f(2);
                }
                if (bVarF == null) {
                    bVarF = this.f2392a.f(1);
                }
                f(androidx.core.graphics.b.a(bVarF, bVarF2));
                androidx.core.graphics.b bVar = this.f2393b[l.b(16)];
                if (bVar != null) {
                    e(bVar);
                }
                androidx.core.graphics.b bVar2 = this.f2393b[l.b(32)];
                if (bVar2 != null) {
                    c(bVar2);
                }
                androidx.core.graphics.b bVar3 = this.f2393b[l.b(64)];
                if (bVar3 != null) {
                    g(bVar3);
                }
            }
        }

        t0 b() {
            throw null;
        }

        void c(androidx.core.graphics.b bVar) {
            throw null;
        }

        void d(androidx.core.graphics.b bVar) {
            throw null;
        }

        void e(androidx.core.graphics.b bVar) {
            throw null;
        }

        void f(androidx.core.graphics.b bVar) {
            throw null;
        }

        void g(androidx.core.graphics.b bVar) {
            throw null;
        }

        e(t0 t0Var) {
            this.f2392a = t0Var;
        }
    }

    /* JADX INFO: compiled from: WindowInsetsCompat.java */
    private static class h extends g {
        h(t0 t0Var, WindowInsets windowInsets) {
            super(t0Var, windowInsets);
        }

        @Override // androidx.core.view.t0.k
        t0 a() {
            return t0.v(this.f2394c.consumeDisplayCutout());
        }

        @Override // androidx.core.view.t0.f, androidx.core.view.t0.k
        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof h)) {
                return false;
            }
            h hVar = (h) obj;
            return Objects.equals(this.f2394c, hVar.f2394c) && Objects.equals(this.f2398g, hVar.f2398g);
        }

        @Override // androidx.core.view.t0.k
        androidx.core.view.g f() {
            return androidx.core.view.g.e(this.f2394c.getDisplayCutout());
        }

        @Override // androidx.core.view.t0.k
        public int hashCode() {
            return this.f2394c.hashCode();
        }

        h(t0 t0Var, h hVar) {
            super(t0Var, hVar);
        }
    }

    /* JADX INFO: compiled from: WindowInsetsCompat.java */
    private static class j extends i {

        /* JADX INFO: renamed from: l, reason: collision with root package name */
        static final t0 f2403l = t0.v(WindowInsets.CONSUMED);

        j(t0 t0Var, WindowInsets windowInsets) {
            super(t0Var, windowInsets);
        }

        @Override // androidx.core.view.t0.f, androidx.core.view.t0.k
        public androidx.core.graphics.b g(int i10) {
            return androidx.core.graphics.b.d(this.f2394c.getInsets(m.a(i10)));
        }

        j(t0 t0Var, j jVar) {
            super(t0Var, jVar);
        }

        @Override // androidx.core.view.t0.f, androidx.core.view.t0.k
        final void d(View view) {
        }
    }

    /* JADX INFO: compiled from: WindowInsetsCompat.java */
    public static final class l {
        public static int a() {
            return 8;
        }

        static int b(int i10) {
            if (i10 == 1) {
                return 0;
            }
            if (i10 == 2) {
                return 1;
            }
            if (i10 == 4) {
                return 2;
            }
            if (i10 == 8) {
                return 3;
            }
            if (i10 == 16) {
                return 4;
            }
            if (i10 == 32) {
                return 5;
            }
            if (i10 == 64) {
                return 6;
            }
            if (i10 == 128) {
                return 7;
            }
            if (i10 == 256) {
                return 8;
            }
            throw new IllegalArgumentException("type needs to be >= FIRST and <= LAST, type=" + i10);
        }

        public static int c() {
            return 32;
        }

        public static int d() {
            return 1;
        }

        public static int e() {
            return 7;
        }
    }

    /* JADX INFO: compiled from: WindowInsetsCompat.java */
    private static final class m {
        static int a(int i10) {
            int iStatusBars;
            int i11 = 0;
            for (int i12 = 1; i12 <= 256; i12 <<= 1) {
                if ((i10 & i12) != 0) {
                    if (i12 == 1) {
                        iStatusBars = WindowInsets.Type.statusBars();
                    } else if (i12 == 2) {
                        iStatusBars = WindowInsets.Type.navigationBars();
                    } else if (i12 == 4) {
                        iStatusBars = WindowInsets.Type.captionBar();
                    } else if (i12 == 8) {
                        iStatusBars = WindowInsets.Type.ime();
                    } else if (i12 == 16) {
                        iStatusBars = WindowInsets.Type.systemGestures();
                    } else if (i12 == 32) {
                        iStatusBars = WindowInsets.Type.mandatorySystemGestures();
                    } else if (i12 == 64) {
                        iStatusBars = WindowInsets.Type.tappableElement();
                    } else if (i12 == 128) {
                        iStatusBars = WindowInsets.Type.displayCutout();
                    }
                    i11 |= iStatusBars;
                }
            }
            return i11;
        }
    }

    private t0(WindowInsets windowInsets) {
        this.f2385a = new j(this, windowInsets);
    }

    static androidx.core.graphics.b o(androidx.core.graphics.b bVar, int i10, int i11, int i12, int i13) {
        int iMax = Math.max(0, bVar.f2236a - i10);
        int iMax2 = Math.max(0, bVar.f2237b - i11);
        int iMax3 = Math.max(0, bVar.f2238c - i12);
        int iMax4 = Math.max(0, bVar.f2239d - i13);
        return (iMax == i10 && iMax2 == i11 && iMax3 == i12 && iMax4 == i13) ? bVar : androidx.core.graphics.b.b(iMax, iMax2, iMax3, iMax4);
    }

    public static t0 v(WindowInsets windowInsets) {
        return w(windowInsets, null);
    }

    public static t0 w(WindowInsets windowInsets, View view) {
        t0 t0Var = new t0((WindowInsets) a0.h.e(windowInsets));
        if (view != null && view.isAttachedToWindow()) {
            t0Var.t(h0.D(view));
            t0Var.d(view.getRootView());
        }
        return t0Var;
    }

    @Deprecated
    public t0 a() {
        return this.f2385a.a();
    }

    @Deprecated
    public t0 b() {
        return this.f2385a.b();
    }

    @Deprecated
    public t0 c() {
        return this.f2385a.c();
    }

    void d(View view) {
        this.f2385a.d(view);
    }

    public androidx.core.view.g e() {
        return this.f2385a.f();
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof t0) {
            return a0.c.a(this.f2385a, ((t0) obj).f2385a);
        }
        return false;
    }

    public androidx.core.graphics.b f(int i10) {
        return this.f2385a.g(i10);
    }

    @Deprecated
    public androidx.core.graphics.b g() {
        return this.f2385a.i();
    }

    @Deprecated
    public androidx.core.graphics.b h() {
        return this.f2385a.j();
    }

    public int hashCode() {
        k kVar = this.f2385a;
        if (kVar == null) {
            return 0;
        }
        return kVar.hashCode();
    }

    @Deprecated
    public int i() {
        return this.f2385a.k().f2239d;
    }

    @Deprecated
    public int j() {
        return this.f2385a.k().f2236a;
    }

    @Deprecated
    public int k() {
        return this.f2385a.k().f2238c;
    }

    @Deprecated
    public int l() {
        return this.f2385a.k().f2237b;
    }

    @Deprecated
    public boolean m() {
        return !this.f2385a.k().equals(androidx.core.graphics.b.f2235e);
    }

    public t0 n(int i10, int i11, int i12, int i13) {
        return this.f2385a.m(i10, i11, i12, i13);
    }

    public boolean p() {
        return this.f2385a.n();
    }

    @Deprecated
    public t0 q(int i10, int i11, int i12, int i13) {
        return new b(this).c(androidx.core.graphics.b.b(i10, i11, i12, i13)).a();
    }

    void r(androidx.core.graphics.b[] bVarArr) {
        this.f2385a.p(bVarArr);
    }

    void s(androidx.core.graphics.b bVar) {
        this.f2385a.q(bVar);
    }

    void t(t0 t0Var) {
        this.f2385a.r(t0Var);
    }

    public WindowInsets u() {
        k kVar = this.f2385a;
        if (kVar instanceof f) {
            return ((f) kVar).f2394c;
        }
        return null;
    }

    /* JADX INFO: compiled from: WindowInsetsCompat.java */
    public static final class b {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private final e f2390a;

        public b() {
            this.f2390a = new d();
        }

        public t0 a() {
            return this.f2390a.b();
        }

        @Deprecated
        public b b(androidx.core.graphics.b bVar) {
            this.f2390a.d(bVar);
            return this;
        }

        @Deprecated
        public b c(androidx.core.graphics.b bVar) {
            this.f2390a.f(bVar);
            return this;
        }

        public b(t0 t0Var) {
            this.f2390a = new d(t0Var);
        }
    }

    /* JADX INFO: compiled from: WindowInsetsCompat.java */
    private static class c extends e {

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        final WindowInsets.Builder f2391c;

        c() {
            this.f2391c = new WindowInsets.Builder();
        }

        @Override // androidx.core.view.t0.e
        t0 b() {
            a();
            t0 t0VarV = t0.v(this.f2391c.build());
            t0VarV.r(this.f2393b);
            return t0VarV;
        }

        @Override // androidx.core.view.t0.e
        void c(androidx.core.graphics.b bVar) {
            this.f2391c.setMandatorySystemGestureInsets(bVar.e());
        }

        @Override // androidx.core.view.t0.e
        void d(androidx.core.graphics.b bVar) {
            this.f2391c.setStableInsets(bVar.e());
        }

        @Override // androidx.core.view.t0.e
        void e(androidx.core.graphics.b bVar) {
            this.f2391c.setSystemGestureInsets(bVar.e());
        }

        @Override // androidx.core.view.t0.e
        void f(androidx.core.graphics.b bVar) {
            this.f2391c.setSystemWindowInsets(bVar.e());
        }

        @Override // androidx.core.view.t0.e
        void g(androidx.core.graphics.b bVar) {
            this.f2391c.setTappableElementInsets(bVar.e());
        }

        c(t0 t0Var) {
            WindowInsets.Builder builder;
            super(t0Var);
            WindowInsets windowInsetsU = t0Var.u();
            if (windowInsetsU != null) {
                builder = new WindowInsets.Builder(windowInsetsU);
            } else {
                builder = new WindowInsets.Builder();
            }
            this.f2391c = builder;
        }
    }

    /* JADX INFO: compiled from: WindowInsetsCompat.java */
    private static class g extends f {

        /* JADX INFO: renamed from: h, reason: collision with root package name */
        private androidx.core.graphics.b f2399h;

        g(t0 t0Var, WindowInsets windowInsets) {
            super(t0Var, windowInsets);
            this.f2399h = null;
        }

        @Override // androidx.core.view.t0.k
        t0 b() {
            return t0.v(this.f2394c.consumeStableInsets());
        }

        @Override // androidx.core.view.t0.k
        t0 c() {
            return t0.v(this.f2394c.consumeSystemWindowInsets());
        }

        @Override // androidx.core.view.t0.k
        final androidx.core.graphics.b i() {
            if (this.f2399h == null) {
                this.f2399h = androidx.core.graphics.b.b(this.f2394c.getStableInsetLeft(), this.f2394c.getStableInsetTop(), this.f2394c.getStableInsetRight(), this.f2394c.getStableInsetBottom());
            }
            return this.f2399h;
        }

        @Override // androidx.core.view.t0.k
        boolean n() {
            return this.f2394c.isConsumed();
        }

        g(t0 t0Var, g gVar) {
            super(t0Var, gVar);
            this.f2399h = null;
            this.f2399h = gVar.f2399h;
        }
    }

    /* JADX INFO: compiled from: WindowInsetsCompat.java */
    private static class f extends k {

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        final WindowInsets f2394c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        private androidx.core.graphics.b[] f2395d;

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        private androidx.core.graphics.b f2396e;

        /* JADX INFO: renamed from: f, reason: collision with root package name */
        private t0 f2397f;

        /* JADX INFO: renamed from: g, reason: collision with root package name */
        androidx.core.graphics.b f2398g;

        f(t0 t0Var, WindowInsets windowInsets) {
            super(t0Var);
            this.f2396e = null;
            this.f2394c = windowInsets;
        }

        @SuppressLint({"WrongConstant"})
        private androidx.core.graphics.b s(int i10, boolean z10) {
            androidx.core.graphics.b bVarA = androidx.core.graphics.b.f2235e;
            for (int i11 = 1; i11 <= 256; i11 <<= 1) {
                if ((i10 & i11) != 0) {
                    bVarA = androidx.core.graphics.b.a(bVarA, t(i11, z10));
                }
            }
            return bVarA;
        }

        private androidx.core.graphics.b u() {
            t0 t0Var = this.f2397f;
            return t0Var != null ? t0Var.g() : androidx.core.graphics.b.f2235e;
        }

        private androidx.core.graphics.b v(View view) {
            throw new UnsupportedOperationException("getVisibleInsets() should not be called on API >= 30. Use WindowInsets.isVisible() instead.");
        }

        @Override // androidx.core.view.t0.k
        void d(View view) {
            androidx.core.graphics.b bVarV = v(view);
            if (bVarV == null) {
                bVarV = androidx.core.graphics.b.f2235e;
            }
            q(bVarV);
        }

        @Override // androidx.core.view.t0.k
        void e(t0 t0Var) {
            t0Var.t(this.f2397f);
            t0Var.s(this.f2398g);
        }

        @Override // androidx.core.view.t0.k
        public boolean equals(Object obj) {
            if (super.equals(obj)) {
                return Objects.equals(this.f2398g, ((f) obj).f2398g);
            }
            return false;
        }

        @Override // androidx.core.view.t0.k
        public androidx.core.graphics.b g(int i10) {
            return s(i10, false);
        }

        @Override // androidx.core.view.t0.k
        final androidx.core.graphics.b k() {
            if (this.f2396e == null) {
                this.f2396e = androidx.core.graphics.b.b(this.f2394c.getSystemWindowInsetLeft(), this.f2394c.getSystemWindowInsetTop(), this.f2394c.getSystemWindowInsetRight(), this.f2394c.getSystemWindowInsetBottom());
            }
            return this.f2396e;
        }

        @Override // androidx.core.view.t0.k
        t0 m(int i10, int i11, int i12, int i13) {
            b bVar = new b(t0.v(this.f2394c));
            bVar.c(t0.o(k(), i10, i11, i12, i13));
            bVar.b(t0.o(i(), i10, i11, i12, i13));
            return bVar.a();
        }

        @Override // androidx.core.view.t0.k
        boolean o() {
            return this.f2394c.isRound();
        }

        @Override // androidx.core.view.t0.k
        public void p(androidx.core.graphics.b[] bVarArr) {
            this.f2395d = bVarArr;
        }

        @Override // androidx.core.view.t0.k
        void q(androidx.core.graphics.b bVar) {
            this.f2398g = bVar;
        }

        @Override // androidx.core.view.t0.k
        void r(t0 t0Var) {
            this.f2397f = t0Var;
        }

        protected androidx.core.graphics.b t(int i10, boolean z10) {
            androidx.core.graphics.b bVarG;
            int i11;
            if (i10 == 1) {
                return z10 ? androidx.core.graphics.b.b(0, Math.max(u().f2237b, k().f2237b), 0, 0) : androidx.core.graphics.b.b(0, k().f2237b, 0, 0);
            }
            if (i10 == 2) {
                if (z10) {
                    androidx.core.graphics.b bVarU = u();
                    androidx.core.graphics.b bVarI = i();
                    return androidx.core.graphics.b.b(Math.max(bVarU.f2236a, bVarI.f2236a), 0, Math.max(bVarU.f2238c, bVarI.f2238c), Math.max(bVarU.f2239d, bVarI.f2239d));
                }
                androidx.core.graphics.b bVarK = k();
                t0 t0Var = this.f2397f;
                bVarG = t0Var != null ? t0Var.g() : null;
                int iMin = bVarK.f2239d;
                if (bVarG != null) {
                    iMin = Math.min(iMin, bVarG.f2239d);
                }
                return androidx.core.graphics.b.b(bVarK.f2236a, 0, bVarK.f2238c, iMin);
            }
            if (i10 != 8) {
                if (i10 == 16) {
                    return j();
                }
                if (i10 == 32) {
                    return h();
                }
                if (i10 == 64) {
                    return l();
                }
                if (i10 != 128) {
                    return androidx.core.graphics.b.f2235e;
                }
                t0 t0Var2 = this.f2397f;
                androidx.core.view.g gVarE = t0Var2 != null ? t0Var2.e() : f();
                return gVarE != null ? androidx.core.graphics.b.b(gVarE.b(), gVarE.d(), gVarE.c(), gVarE.a()) : androidx.core.graphics.b.f2235e;
            }
            androidx.core.graphics.b[] bVarArr = this.f2395d;
            bVarG = bVarArr != null ? bVarArr[l.b(8)] : null;
            if (bVarG != null) {
                return bVarG;
            }
            androidx.core.graphics.b bVarK2 = k();
            androidx.core.graphics.b bVarU2 = u();
            int i12 = bVarK2.f2239d;
            if (i12 > bVarU2.f2239d) {
                return androidx.core.graphics.b.b(0, 0, 0, i12);
            }
            androidx.core.graphics.b bVar = this.f2398g;
            return (bVar == null || bVar.equals(androidx.core.graphics.b.f2235e) || (i11 = this.f2398g.f2239d) <= bVarU2.f2239d) ? androidx.core.graphics.b.f2235e : androidx.core.graphics.b.b(0, 0, 0, i11);
        }

        f(t0 t0Var, f fVar) {
            this(t0Var, new WindowInsets(fVar.f2394c));
        }
    }

    public t0(t0 t0Var) {
        if (t0Var != null) {
            k kVar = t0Var.f2385a;
            if (kVar instanceof j) {
                this.f2385a = new j(this, (j) kVar);
            } else if (kVar instanceof i) {
                this.f2385a = new i(this, (i) kVar);
            } else if (kVar instanceof h) {
                this.f2385a = new h(this, (h) kVar);
            } else if (kVar instanceof g) {
                this.f2385a = new g(this, (g) kVar);
            } else if (kVar instanceof f) {
                this.f2385a = new f(this, (f) kVar);
            } else {
                this.f2385a = new k(this);
            }
            kVar.e(this);
            return;
        }
        this.f2385a = new k(this);
    }

    /* JADX INFO: compiled from: WindowInsetsCompat.java */
    private static class i extends h {

        /* JADX INFO: renamed from: i, reason: collision with root package name */
        private androidx.core.graphics.b f2400i;

        /* JADX INFO: renamed from: j, reason: collision with root package name */
        private androidx.core.graphics.b f2401j;

        /* JADX INFO: renamed from: k, reason: collision with root package name */
        private androidx.core.graphics.b f2402k;

        i(t0 t0Var, WindowInsets windowInsets) {
            super(t0Var, windowInsets);
            this.f2400i = null;
            this.f2401j = null;
            this.f2402k = null;
        }

        @Override // androidx.core.view.t0.k
        androidx.core.graphics.b h() {
            if (this.f2401j == null) {
                this.f2401j = androidx.core.graphics.b.d(this.f2394c.getMandatorySystemGestureInsets());
            }
            return this.f2401j;
        }

        @Override // androidx.core.view.t0.k
        androidx.core.graphics.b j() {
            if (this.f2400i == null) {
                this.f2400i = androidx.core.graphics.b.d(this.f2394c.getSystemGestureInsets());
            }
            return this.f2400i;
        }

        @Override // androidx.core.view.t0.k
        androidx.core.graphics.b l() {
            if (this.f2402k == null) {
                this.f2402k = androidx.core.graphics.b.d(this.f2394c.getTappableElementInsets());
            }
            return this.f2402k;
        }

        @Override // androidx.core.view.t0.f, androidx.core.view.t0.k
        t0 m(int i10, int i11, int i12, int i13) {
            return t0.v(this.f2394c.inset(i10, i11, i12, i13));
        }

        i(t0 t0Var, i iVar) {
            super(t0Var, iVar);
            this.f2400i = null;
            this.f2401j = null;
            this.f2402k = null;
        }
    }

    /* JADX INFO: compiled from: WindowInsetsCompat.java */
    private static class k {

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        static final t0 f2404b = new b().a().a().b().c();

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        final t0 f2405a;

        k(t0 t0Var) {
            this.f2405a = t0Var;
        }

        t0 a() {
            return this.f2405a;
        }

        t0 b() {
            return this.f2405a;
        }

        t0 c() {
            return this.f2405a;
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof k)) {
                return false;
            }
            k kVar = (k) obj;
            return o() == kVar.o() && n() == kVar.n() && a0.c.a(k(), kVar.k()) && a0.c.a(i(), kVar.i()) && a0.c.a(f(), kVar.f());
        }

        androidx.core.view.g f() {
            return null;
        }

        androidx.core.graphics.b g(int i10) {
            return androidx.core.graphics.b.f2235e;
        }

        androidx.core.graphics.b h() {
            return k();
        }

        public int hashCode() {
            return a0.c.b(Boolean.valueOf(o()), Boolean.valueOf(n()), k(), i(), f());
        }

        androidx.core.graphics.b i() {
            return androidx.core.graphics.b.f2235e;
        }

        androidx.core.graphics.b j() {
            return k();
        }

        androidx.core.graphics.b k() {
            return androidx.core.graphics.b.f2235e;
        }

        androidx.core.graphics.b l() {
            return k();
        }

        t0 m(int i10, int i11, int i12, int i13) {
            return f2404b;
        }

        boolean n() {
            return false;
        }

        boolean o() {
            return false;
        }

        void d(View view) {
        }

        void e(t0 t0Var) {
        }

        public void p(androidx.core.graphics.b[] bVarArr) {
        }

        void q(androidx.core.graphics.b bVar) {
        }

        void r(t0 t0Var) {
        }
    }
}
