package androidx.core.view;

import android.view.View;

/* JADX INFO: compiled from: OnApplyWindowInsetsListener.java */
/* JADX INFO: loaded from: classes.dex */
public interface x {
    t0 onApplyWindowInsets(View view, t0 t0Var);
}
