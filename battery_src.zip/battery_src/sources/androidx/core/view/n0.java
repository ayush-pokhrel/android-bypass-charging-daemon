package androidx.core.view;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.view.View;
import android.view.animation.Interpolator;
import java.lang.ref.WeakReference;

/* JADX INFO: compiled from: ViewPropertyAnimatorCompat.java */
/* JADX INFO: loaded from: classes.dex */
public final class n0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final WeakReference<View> f2358a;

    /* JADX INFO: compiled from: ViewPropertyAnimatorCompat.java */
    class a extends AnimatorListenerAdapter {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        final /* synthetic */ o0 f2359a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        final /* synthetic */ View f2360b;

        a(o0 o0Var, View view) {
            this.f2359a = o0Var;
            this.f2360b = view;
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationCancel(Animator animator) {
            this.f2359a.a(this.f2360b);
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
            this.f2359a.b(this.f2360b);
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationStart(Animator animator) {
            this.f2359a.c(this.f2360b);
        }
    }

    n0(View view) {
        this.f2358a = new WeakReference<>(view);
    }

    private void i(View view, o0 o0Var) {
        if (o0Var != null) {
            view.animate().setListener(new a(o0Var, view));
        } else {
            view.animate().setListener(null);
        }
    }

    public n0 b(float f10) {
        View view = this.f2358a.get();
        if (view != null) {
            view.animate().alpha(f10);
        }
        return this;
    }

    public void c() {
        View view = this.f2358a.get();
        if (view != null) {
            view.animate().cancel();
        }
    }

    public long d() {
        View view = this.f2358a.get();
        if (view != null) {
            return view.animate().getDuration();
        }
        return 0L;
    }

    public n0 f(long j10) {
        View view = this.f2358a.get();
        if (view != null) {
            view.animate().setDuration(j10);
        }
        return this;
    }

    public n0 g(Interpolator interpolator) {
        View view = this.f2358a.get();
        if (view != null) {
            view.animate().setInterpolator(interpolator);
        }
        return this;
    }

    public n0 h(o0 o0Var) {
        View view = this.f2358a.get();
        if (view != null) {
            i(view, o0Var);
        }
        return this;
    }

    public n0 j(long j10) {
        View view = this.f2358a.get();
        if (view != null) {
            view.animate().setStartDelay(j10);
        }
        return this;
    }

    public n0 k(final q0 q0Var) {
        final View view = this.f2358a.get();
        if (view != null) {
            view.animate().setUpdateListener(q0Var != null ? new ValueAnimator.AnimatorUpdateListener() { // from class: androidx.core.view.m0
                @Override // android.animation.ValueAnimator.AnimatorUpdateListener
                public final void onAnimationUpdate(ValueAnimator valueAnimator) {
                    q0Var.a(view);
                }
            } : null);
        }
        return this;
    }

    public void l() {
        View view = this.f2358a.get();
        if (view != null) {
            view.animate().start();
        }
    }

    public n0 m(float f10) {
        View view = this.f2358a.get();
        if (view != null) {
            view.animate().translationY(f10);
        }
        return this;
    }
}
