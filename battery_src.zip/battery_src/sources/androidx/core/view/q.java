package androidx.core.view;

import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

/* JADX INFO: compiled from: MenuProvider.java */
/* JADX INFO: loaded from: classes.dex */
public interface q {
    boolean a(MenuItem menuItem);

    void c(Menu menu, MenuInflater menuInflater);

    default void b(Menu menu) {
    }

    default void d(Menu menu) {
    }
}
