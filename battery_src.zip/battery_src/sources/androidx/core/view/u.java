package androidx.core.view;

import android.view.View;

/* JADX INFO: compiled from: NestedScrollingParent2.java */
/* JADX INFO: loaded from: classes.dex */
public interface u {
    void h(View view, View view2, int i10, int i11);

    void i(View view, int i10);

    void j(View view, int i10, int i11, int[] iArr, int i12);

    void n(View view, int i10, int i11, int i12, int i13, int i14);

    boolean o(View view, View view2, int i10, int i11);
}
