package androidx.core.view;

import android.view.View;
import android.view.Window;

/* JADX INFO: compiled from: WindowCompat.java */
/* JADX INFO: loaded from: classes.dex */
public final class r0 {

    /* JADX INFO: compiled from: WindowCompat.java */
    static class a {
        static void a(Window window, boolean z10) {
            window.setDecorFitsSystemWindows(z10);
        }
    }

    public static u0 a(Window window, View view) {
        return new u0(window, view);
    }

    public static void b(Window window, boolean z10) {
        a.a(window, z10);
    }
}
