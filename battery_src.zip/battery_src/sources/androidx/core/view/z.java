package androidx.core.view;

import android.view.View;
import android.view.ViewTreeObserver;

/* JADX INFO: compiled from: OneShotPreDrawListener.java */
/* JADX INFO: loaded from: classes.dex */
public final class z implements ViewTreeObserver.OnPreDrawListener, View.OnAttachStateChangeListener {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final View f2414a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private ViewTreeObserver f2415b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private final Runnable f2416c;

    private z(View view, Runnable runnable) {
        this.f2414a = view;
        this.f2415b = view.getViewTreeObserver();
        this.f2416c = runnable;
    }

    public static z a(View view, Runnable runnable) {
        if (view == null) {
            throw new NullPointerException("view == null");
        }
        if (runnable == null) {
            throw new NullPointerException("runnable == null");
        }
        z zVar = new z(view, runnable);
        view.getViewTreeObserver().addOnPreDrawListener(zVar);
        view.addOnAttachStateChangeListener(zVar);
        return zVar;
    }

    public void b() {
        if (this.f2415b.isAlive()) {
            this.f2415b.removeOnPreDrawListener(this);
        } else {
            this.f2414a.getViewTreeObserver().removeOnPreDrawListener(this);
        }
        this.f2414a.removeOnAttachStateChangeListener(this);
    }

    @Override // android.view.ViewTreeObserver.OnPreDrawListener
    public boolean onPreDraw() {
        b();
        this.f2416c.run();
        return true;
    }

    @Override // android.view.View.OnAttachStateChangeListener
    public void onViewAttachedToWindow(View view) {
        this.f2415b = view.getViewTreeObserver();
    }

    @Override // android.view.View.OnAttachStateChangeListener
    public void onViewDetachedFromWindow(View view) {
        b();
    }
}
