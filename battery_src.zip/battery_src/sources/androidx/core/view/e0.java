package androidx.core.view;

import android.view.MotionEvent;
import android.view.VelocityTracker;
import java.util.Collections;
import java.util.Map;
import java.util.WeakHashMap;

/* JADX INFO: compiled from: VelocityTrackerCompat.java */
/* JADX INFO: loaded from: classes.dex */
public final class e0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private static Map<VelocityTracker, f0> f2330a = Collections.synchronizedMap(new WeakHashMap());

    /* JADX INFO: compiled from: VelocityTrackerCompat.java */
    private static class a {
        static float a(VelocityTracker velocityTracker, int i10) {
            return velocityTracker.getAxisVelocity(i10);
        }

        static float b(VelocityTracker velocityTracker, int i10, int i11) {
            return velocityTracker.getAxisVelocity(i10, i11);
        }

        static boolean c(VelocityTracker velocityTracker, int i10) {
            return velocityTracker.isAxisSupported(i10);
        }
    }

    public static void a(VelocityTracker velocityTracker, MotionEvent motionEvent) {
        velocityTracker.addMovement(motionEvent);
    }

    public static void b(VelocityTracker velocityTracker, int i10) {
        c(velocityTracker, i10, Float.MAX_VALUE);
    }

    public static void c(VelocityTracker velocityTracker, int i10, float f10) {
        velocityTracker.computeCurrentVelocity(i10, f10);
        f0 f0VarE = e(velocityTracker);
        if (f0VarE != null) {
            f0VarE.a(i10, f10);
        }
    }

    public static float d(VelocityTracker velocityTracker, int i10) {
        return a.a(velocityTracker, i10);
    }

    private static f0 e(VelocityTracker velocityTracker) {
        return f2330a.get(velocityTracker);
    }
}
