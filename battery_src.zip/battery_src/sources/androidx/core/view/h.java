package androidx.core.view;

import android.content.Context;
import android.os.Handler;
import android.view.GestureDetector;
import android.view.MotionEvent;

/* JADX INFO: compiled from: GestureDetectorCompat.java */
/* JADX INFO: loaded from: classes.dex */
@Deprecated
public final class h {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final GestureDetector f2337a;

    public h(Context context, GestureDetector.OnGestureListener onGestureListener) {
        this(context, onGestureListener, null);
    }

    public boolean a(MotionEvent motionEvent) {
        return this.f2337a.onTouchEvent(motionEvent);
    }

    public h(Context context, GestureDetector.OnGestureListener onGestureListener, Handler handler) {
        this.f2337a = new GestureDetector(context, onGestureListener, handler);
    }
}
