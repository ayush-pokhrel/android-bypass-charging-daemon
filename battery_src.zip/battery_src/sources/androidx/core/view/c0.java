package androidx.core.view;

import android.R;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.inputmethod.InputMethodManager;
import java.util.concurrent.atomic.AtomicBoolean;

/* JADX INFO: compiled from: SoftwareKeyboardControllerCompat.java */
/* JADX INFO: loaded from: classes.dex */
public final class c0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final c f2315a;

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: compiled from: SoftwareKeyboardControllerCompat.java */
    static class a extends c {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private final View f2316a;

        a(View view) {
            this.f2316a = view;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static /* synthetic */ void d(View view) {
            ((InputMethodManager) view.getContext().getSystemService("input_method")).showSoftInput(view, 0);
        }

        @Override // androidx.core.view.c0.c
        void a() {
            View view = this.f2316a;
            if (view != null) {
                ((InputMethodManager) view.getContext().getSystemService("input_method")).hideSoftInputFromWindow(this.f2316a.getWindowToken(), 0);
            }
        }

        @Override // androidx.core.view.c0.c
        void b() {
            final View viewFindViewById = this.f2316a;
            if (viewFindViewById == null) {
                return;
            }
            if (viewFindViewById.isInEditMode() || viewFindViewById.onCheckIsTextEditor()) {
                viewFindViewById.requestFocus();
            } else {
                viewFindViewById = viewFindViewById.getRootView().findFocus();
            }
            if (viewFindViewById == null) {
                viewFindViewById = this.f2316a.getRootView().findViewById(R.id.content);
            }
            if (viewFindViewById == null || !viewFindViewById.hasWindowFocus()) {
                return;
            }
            viewFindViewById.post(new Runnable() { // from class: androidx.core.view.b0
                @Override // java.lang.Runnable
                public final void run() {
                    c0.a.d(viewFindViewById);
                }
            });
        }
    }

    /* JADX INFO: compiled from: SoftwareKeyboardControllerCompat.java */
    private static class c {
        c() {
        }

        void a() {
            throw null;
        }

        void b() {
            throw null;
        }
    }

    public c0(View view) {
        this.f2315a = new b(view);
    }

    public void a() {
        this.f2315a.a();
    }

    public void b() {
        this.f2315a.b();
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: compiled from: SoftwareKeyboardControllerCompat.java */
    static class b extends a {

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private View f2317b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        private WindowInsetsController f2318c;

        b(View view) {
            super(view);
            this.f2317b = view;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static /* synthetic */ void f(AtomicBoolean atomicBoolean, WindowInsetsController windowInsetsController, int i10) {
            atomicBoolean.set((i10 & 8) != 0);
        }

        @Override // androidx.core.view.c0.a, androidx.core.view.c0.c
        void a() {
            View view;
            WindowInsetsController windowInsetsController = this.f2318c;
            if (windowInsetsController == null) {
                View view2 = this.f2317b;
                windowInsetsController = view2 != null ? view2.getWindowInsetsController() : null;
            }
            if (windowInsetsController == null) {
                super.a();
                return;
            }
            final AtomicBoolean atomicBoolean = new AtomicBoolean(false);
            WindowInsetsController.OnControllableInsetsChangedListener onControllableInsetsChangedListener = new WindowInsetsController.OnControllableInsetsChangedListener() { // from class: androidx.core.view.d0
                @Override // android.view.WindowInsetsController.OnControllableInsetsChangedListener
                public final void onControllableInsetsChanged(WindowInsetsController windowInsetsController2, int i10) {
                    c0.b.f(atomicBoolean, windowInsetsController2, i10);
                }
            };
            windowInsetsController.addOnControllableInsetsChangedListener(onControllableInsetsChangedListener);
            if (!atomicBoolean.get() && (view = this.f2317b) != null) {
                ((InputMethodManager) view.getContext().getSystemService("input_method")).hideSoftInputFromWindow(this.f2317b.getWindowToken(), 0);
            }
            windowInsetsController.removeOnControllableInsetsChangedListener(onControllableInsetsChangedListener);
            windowInsetsController.hide(WindowInsets.Type.ime());
        }

        @Override // androidx.core.view.c0.a, androidx.core.view.c0.c
        void b() {
            View view = this.f2317b;
            WindowInsetsController windowInsetsController = this.f2318c;
            if (windowInsetsController == null) {
                windowInsetsController = view != null ? view.getWindowInsetsController() : null;
            }
            if (windowInsetsController != null) {
                windowInsetsController.show(WindowInsets.Type.ime());
            }
            super.b();
        }

        b(WindowInsetsController windowInsetsController) {
            super(null);
            this.f2318c = windowInsetsController;
        }
    }

    @Deprecated
    c0(WindowInsetsController windowInsetsController) {
        this.f2315a = new b(windowInsetsController);
    }
}
