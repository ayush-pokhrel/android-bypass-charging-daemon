package androidx.core.view;

import android.view.View;

/* JADX INFO: compiled from: NestedScrollingParent3.java */
/* JADX INFO: loaded from: classes.dex */
public interface v extends u {
    void m(View view, int i10, int i11, int i12, int i13, int i14, int[] iArr);
}
