package androidx.core.view;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.view.PointerIcon;

/* JADX INFO: compiled from: PointerIconCompat.java */
/* JADX INFO: loaded from: classes.dex */
public final class a0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final PointerIcon f2313a;

    /* JADX INFO: compiled from: PointerIconCompat.java */
    static class a {
        static PointerIcon a(Bitmap bitmap, float f10, float f11) {
            return PointerIcon.create(bitmap, f10, f11);
        }

        static PointerIcon b(Context context, int i10) {
            return PointerIcon.getSystemIcon(context, i10);
        }

        static PointerIcon c(Resources resources, int i10) {
            return PointerIcon.load(resources, i10);
        }
    }

    private a0(PointerIcon pointerIcon) {
        this.f2313a = pointerIcon;
    }

    public static a0 b(Context context, int i10) {
        return new a0(a.b(context, i10));
    }

    public Object a() {
        return this.f2313a;
    }
}
