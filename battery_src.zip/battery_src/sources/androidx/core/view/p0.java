package androidx.core.view;

import android.view.View;

/* JADX INFO: compiled from: ViewPropertyAnimatorListenerAdapter.java */
/* JADX INFO: loaded from: classes.dex */
public class p0 implements o0 {
    @Override // androidx.core.view.o0
    public void a(View view) {
    }

    @Override // androidx.core.view.o0
    public void c(View view) {
    }
}
