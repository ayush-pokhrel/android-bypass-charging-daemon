package androidx.core.view;

import android.view.View;
import android.view.Window;
import android.view.WindowInsetsController;

/* JADX INFO: compiled from: WindowInsetsControllerCompat.java */
/* JADX INFO: loaded from: classes.dex */
public final class u0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final b f2406a;

    /* JADX INFO: compiled from: WindowInsetsControllerCompat.java */
    private static class b {
        b() {
        }

        void a(int i10) {
            throw null;
        }

        public boolean b() {
            throw null;
        }

        public void c(boolean z10) {
            throw null;
        }

        public void d(boolean z10) {
            throw null;
        }

        void e(int i10) {
            throw null;
        }
    }

    @Deprecated
    private u0(WindowInsetsController windowInsetsController) {
        this.f2406a = new a(windowInsetsController, this, new c0(windowInsetsController));
    }

    @Deprecated
    public static u0 f(WindowInsetsController windowInsetsController) {
        return new u0(windowInsetsController);
    }

    public void a(int i10) {
        this.f2406a.a(i10);
    }

    public boolean b() {
        return this.f2406a.b();
    }

    public void c(boolean z10) {
        this.f2406a.c(z10);
    }

    public void d(boolean z10) {
        this.f2406a.d(z10);
    }

    public void e(int i10) {
        this.f2406a.e(i10);
    }

    /* JADX INFO: compiled from: WindowInsetsControllerCompat.java */
    private static class a extends b {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        final u0 f2407a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        final WindowInsetsController f2408b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        final c0 f2409c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        private final r.g<Object, WindowInsetsController.OnControllableInsetsChangedListener> f2410d;

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        protected Window f2411e;

        a(Window window, u0 u0Var, c0 c0Var) {
            this(window.getInsetsController(), u0Var, c0Var);
            this.f2411e = window;
        }

        @Override // androidx.core.view.u0.b
        void a(int i10) {
            if ((i10 & 8) != 0) {
                this.f2409c.a();
            }
            this.f2408b.hide(i10 & (-9));
        }

        @Override // androidx.core.view.u0.b
        public boolean b() {
            this.f2408b.setSystemBarsAppearance(0, 0);
            return (this.f2408b.getSystemBarsAppearance() & 8) != 0;
        }

        @Override // androidx.core.view.u0.b
        public void c(boolean z10) {
            if (z10) {
                if (this.f2411e != null) {
                    f(16);
                }
                this.f2408b.setSystemBarsAppearance(16, 16);
            } else {
                if (this.f2411e != null) {
                    g(16);
                }
                this.f2408b.setSystemBarsAppearance(0, 16);
            }
        }

        @Override // androidx.core.view.u0.b
        public void d(boolean z10) {
            if (z10) {
                if (this.f2411e != null) {
                    f(8192);
                }
                this.f2408b.setSystemBarsAppearance(8, 8);
            } else {
                if (this.f2411e != null) {
                    g(8192);
                }
                this.f2408b.setSystemBarsAppearance(0, 8);
            }
        }

        @Override // androidx.core.view.u0.b
        void e(int i10) {
            if ((i10 & 8) != 0) {
                this.f2409c.b();
            }
            this.f2408b.show(i10 & (-9));
        }

        protected void f(int i10) {
            View decorView = this.f2411e.getDecorView();
            decorView.setSystemUiVisibility(i10 | decorView.getSystemUiVisibility());
        }

        protected void g(int i10) {
            View decorView = this.f2411e.getDecorView();
            decorView.setSystemUiVisibility((~i10) & decorView.getSystemUiVisibility());
        }

        a(WindowInsetsController windowInsetsController, u0 u0Var, c0 c0Var) {
            this.f2410d = new r.g<>();
            this.f2408b = windowInsetsController;
            this.f2407a = u0Var;
            this.f2409c = c0Var;
        }
    }

    public u0(Window window, View view) {
        this.f2406a = new a(window, this, new c0(view));
    }
}
