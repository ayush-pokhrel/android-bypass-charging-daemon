package androidx.core.view;

import android.view.View;
import android.view.ViewGroup;

/* JADX INFO: compiled from: NestedScrollingParentHelper.java */
/* JADX INFO: loaded from: classes.dex */
public class w {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private int f2412a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private int f2413b;

    public w(ViewGroup viewGroup) {
    }

    public int a() {
        return this.f2413b | this.f2412a;
    }

    public void b(View view, View view2, int i10) {
        c(view, view2, i10, 0);
    }

    public void c(View view, View view2, int i10, int i11) {
        if (i11 == 1) {
            this.f2413b = i10;
        } else {
            this.f2412a = i10;
        }
    }

    public void d(View view, int i10) {
        if (i10 == 1) {
            this.f2413b = 0;
        } else {
            this.f2412a = 0;
        }
    }
}
