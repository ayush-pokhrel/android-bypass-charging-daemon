package androidx.core.view;

import android.annotation.SuppressLint;
import android.content.ClipData;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Log;
import android.view.Display;
import android.view.KeyEvent;
import android.view.PointerIcon;
import android.view.View;
import android.view.ViewParent;
import android.view.ViewTreeObserver;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityManager;
import android.view.autofill.AutofillId;
import android.view.contentcapture.ContentCaptureSession;
import androidx.core.R$id;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Objects;
import java.util.WeakHashMap;

/* JADX INFO: compiled from: ViewCompat.java */
/* JADX INFO: loaded from: classes.dex */
@SuppressLint({"PrivateConstructorForUtilityClass"})
public class h0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private static WeakHashMap<View, n0> f2338a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private static final int[] f2339b = {R$id.accessibility_custom_action_0, R$id.accessibility_custom_action_1, R$id.accessibility_custom_action_2, R$id.accessibility_custom_action_3, R$id.accessibility_custom_action_4, R$id.accessibility_custom_action_5, R$id.accessibility_custom_action_6, R$id.accessibility_custom_action_7, R$id.accessibility_custom_action_8, R$id.accessibility_custom_action_9, R$id.accessibility_custom_action_10, R$id.accessibility_custom_action_11, R$id.accessibility_custom_action_12, R$id.accessibility_custom_action_13, R$id.accessibility_custom_action_14, R$id.accessibility_custom_action_15, R$id.accessibility_custom_action_16, R$id.accessibility_custom_action_17, R$id.accessibility_custom_action_18, R$id.accessibility_custom_action_19, R$id.accessibility_custom_action_20, R$id.accessibility_custom_action_21, R$id.accessibility_custom_action_22, R$id.accessibility_custom_action_23, R$id.accessibility_custom_action_24, R$id.accessibility_custom_action_25, R$id.accessibility_custom_action_26, R$id.accessibility_custom_action_27, R$id.accessibility_custom_action_28, R$id.accessibility_custom_action_29, R$id.accessibility_custom_action_30, R$id.accessibility_custom_action_31};

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private static final y f2340c = new y() { // from class: androidx.core.view.g0
    };

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private static final e f2341d = new e();

    /* JADX INFO: compiled from: ViewCompat.java */
    class a extends f<Boolean> {
        a(int i10, Class cls, int i11) {
            super(i10, cls, i11);
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        @Override // androidx.core.view.h0.f
        /* JADX INFO: renamed from: h, reason: merged with bridge method [inline-methods] */
        public Boolean c(View view) {
            return Boolean.valueOf(l.d(view));
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        @Override // androidx.core.view.h0.f
        /* JADX INFO: renamed from: i, reason: merged with bridge method [inline-methods] */
        public void d(View view, Boolean bool) {
            l.j(view, bool.booleanValue());
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        @Override // androidx.core.view.h0.f
        /* JADX INFO: renamed from: j, reason: merged with bridge method [inline-methods] */
        public boolean g(Boolean bool, Boolean bool2) {
            return !a(bool, bool2);
        }
    }

    /* JADX INFO: compiled from: ViewCompat.java */
    class b extends f<CharSequence> {
        b(int i10, Class cls, int i11, int i12) {
            super(i10, cls, i11, i12);
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        @Override // androidx.core.view.h0.f
        /* JADX INFO: renamed from: h, reason: merged with bridge method [inline-methods] */
        public CharSequence c(View view) {
            return l.b(view);
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        @Override // androidx.core.view.h0.f
        /* JADX INFO: renamed from: i, reason: merged with bridge method [inline-methods] */
        public void d(View view, CharSequence charSequence) {
            l.h(view, charSequence);
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        @Override // androidx.core.view.h0.f
        /* JADX INFO: renamed from: j, reason: merged with bridge method [inline-methods] */
        public boolean g(CharSequence charSequence, CharSequence charSequence2) {
            return !TextUtils.equals(charSequence, charSequence2);
        }
    }

    /* JADX INFO: compiled from: ViewCompat.java */
    class c extends f<CharSequence> {
        c(int i10, Class cls, int i11, int i12) {
            super(i10, cls, i11, i12);
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        @Override // androidx.core.view.h0.f
        /* JADX INFO: renamed from: h, reason: merged with bridge method [inline-methods] */
        public CharSequence c(View view) {
            return n.b(view);
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        @Override // androidx.core.view.h0.f
        /* JADX INFO: renamed from: i, reason: merged with bridge method [inline-methods] */
        public void d(View view, CharSequence charSequence) {
            n.f(view, charSequence);
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        @Override // androidx.core.view.h0.f
        /* JADX INFO: renamed from: j, reason: merged with bridge method [inline-methods] */
        public boolean g(CharSequence charSequence, CharSequence charSequence2) {
            return !TextUtils.equals(charSequence, charSequence2);
        }
    }

    /* JADX INFO: compiled from: ViewCompat.java */
    class d extends f<Boolean> {
        d(int i10, Class cls, int i11) {
            super(i10, cls, i11);
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        @Override // androidx.core.view.h0.f
        /* JADX INFO: renamed from: h, reason: merged with bridge method [inline-methods] */
        public Boolean c(View view) {
            return Boolean.valueOf(l.c(view));
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        @Override // androidx.core.view.h0.f
        /* JADX INFO: renamed from: i, reason: merged with bridge method [inline-methods] */
        public void d(View view, Boolean bool) {
            l.g(view, bool.booleanValue());
        }

        /* JADX INFO: Access modifiers changed from: package-private */
        @Override // androidx.core.view.h0.f
        /* JADX INFO: renamed from: j, reason: merged with bridge method [inline-methods] */
        public boolean g(Boolean bool, Boolean bool2) {
            return !a(bool, bool2);
        }
    }

    /* JADX INFO: compiled from: ViewCompat.java */
    static abstract class f<T> {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private final int f2343a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private final Class<T> f2344b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        private final int f2345c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        private final int f2346d;

        f(int i10, Class<T> cls, int i11) {
            this(i10, cls, 0, i11);
        }

        private boolean b() {
            return Build.VERSION.SDK_INT >= this.f2345c;
        }

        boolean a(Boolean bool, Boolean bool2) {
            return (bool != null && bool.booleanValue()) == (bool2 != null && bool2.booleanValue());
        }

        abstract T c(View view);

        abstract void d(View view, T t10);

        T e(View view) {
            if (b()) {
                return c(view);
            }
            T t10 = (T) view.getTag(this.f2343a);
            if (this.f2344b.isInstance(t10)) {
                return t10;
            }
            return null;
        }

        void f(View view, T t10) {
            if (b()) {
                d(view, t10);
            } else if (g(e(view), t10)) {
                h0.h(view);
                view.setTag(this.f2343a, t10);
                h0.U(view, this.f2346d);
            }
        }

        abstract boolean g(T t10, T t11);

        f(int i10, Class<T> cls, int i11, int i12) {
            this.f2343a = i10;
            this.f2344b = cls;
            this.f2346d = i11;
            this.f2345c = i12;
        }
    }

    /* JADX INFO: compiled from: ViewCompat.java */
    static class g {
        static WindowInsets a(View view, WindowInsets windowInsets) {
            return view.dispatchApplyWindowInsets(windowInsets);
        }

        static WindowInsets b(View view, WindowInsets windowInsets) {
            return view.onApplyWindowInsets(windowInsets);
        }

        static void c(View view) {
            view.requestApplyInsets();
        }
    }

    /* JADX INFO: compiled from: ViewCompat.java */
    private static class h {

        /* JADX INFO: compiled from: ViewCompat.java */
        class a implements View.OnApplyWindowInsetsListener {

            /* JADX INFO: renamed from: a, reason: collision with root package name */
            t0 f2347a = null;

            /* JADX INFO: renamed from: b, reason: collision with root package name */
            final /* synthetic */ View f2348b;

            /* JADX INFO: renamed from: c, reason: collision with root package name */
            final /* synthetic */ x f2349c;

            a(View view, x xVar) {
                this.f2348b = view;
                this.f2349c = xVar;
            }

            @Override // android.view.View.OnApplyWindowInsetsListener
            public WindowInsets onApplyWindowInsets(View view, WindowInsets windowInsets) {
                t0 t0VarW = t0.w(windowInsets, view);
                this.f2347a = t0VarW;
                return this.f2349c.onApplyWindowInsets(view, t0VarW).u();
            }
        }

        static void a(WindowInsets windowInsets, View view) {
            View.OnApplyWindowInsetsListener onApplyWindowInsetsListener = (View.OnApplyWindowInsetsListener) view.getTag(R$id.tag_window_insets_animation_callback);
            if (onApplyWindowInsetsListener != null) {
                onApplyWindowInsetsListener.onApplyWindowInsets(view, windowInsets);
            }
        }

        static t0 b(View view, t0 t0Var, Rect rect) {
            WindowInsets windowInsetsU = t0Var.u();
            if (windowInsetsU != null) {
                return t0.w(view.computeSystemWindowInsets(windowInsetsU, rect), view);
            }
            rect.setEmpty();
            return t0Var;
        }

        static boolean c(View view, float f10, float f11, boolean z10) {
            return view.dispatchNestedFling(f10, f11, z10);
        }

        static boolean d(View view, float f10, float f11) {
            return view.dispatchNestedPreFling(f10, f11);
        }

        static boolean e(View view, int i10, int i11, int[] iArr, int[] iArr2) {
            return view.dispatchNestedPreScroll(i10, i11, iArr, iArr2);
        }

        static boolean f(View view, int i10, int i11, int i12, int i13, int[] iArr) {
            return view.dispatchNestedScroll(i10, i11, i12, i13, iArr);
        }

        static ColorStateList g(View view) {
            return view.getBackgroundTintList();
        }

        static PorterDuff.Mode h(View view) {
            return view.getBackgroundTintMode();
        }

        static float i(View view) {
            return view.getElevation();
        }

        public static t0 j(View view) {
            return t0.a.a(view);
        }

        static String k(View view) {
            return view.getTransitionName();
        }

        static float l(View view) {
            return view.getTranslationZ();
        }

        static float m(View view) {
            return view.getZ();
        }

        static boolean n(View view) {
            return view.hasNestedScrollingParent();
        }

        static boolean o(View view) {
            return view.isImportantForAccessibility();
        }

        static boolean p(View view) {
            return view.isNestedScrollingEnabled();
        }

        static void q(View view, ColorStateList colorStateList) {
            view.setBackgroundTintList(colorStateList);
        }

        static void r(View view, PorterDuff.Mode mode) {
            view.setBackgroundTintMode(mode);
        }

        static void s(View view, float f10) {
            view.setElevation(f10);
        }

        static void t(View view, boolean z10) {
            view.setNestedScrollingEnabled(z10);
        }

        static void u(View view, x xVar) {
            if (xVar == null) {
                view.setOnApplyWindowInsetsListener((View.OnApplyWindowInsetsListener) view.getTag(R$id.tag_window_insets_animation_callback));
            } else {
                view.setOnApplyWindowInsetsListener(new a(view, xVar));
            }
        }

        static void v(View view, String str) {
            view.setTransitionName(str);
        }

        static void w(View view, float f10) {
            view.setTranslationZ(f10);
        }

        static void x(View view, float f10) {
            view.setZ(f10);
        }

        static boolean y(View view, int i10) {
            return view.startNestedScroll(i10);
        }

        static void z(View view) {
            view.stopNestedScroll();
        }
    }

    /* JADX INFO: compiled from: ViewCompat.java */
    private static class i {
        public static t0 a(View view) {
            WindowInsets rootWindowInsets = view.getRootWindowInsets();
            if (rootWindowInsets == null) {
                return null;
            }
            t0 t0VarV = t0.v(rootWindowInsets);
            t0VarV.t(t0VarV);
            t0VarV.d(view.getRootView());
            return t0VarV;
        }

        static int b(View view) {
            return view.getScrollIndicators();
        }

        static void c(View view, int i10) {
            view.setScrollIndicators(i10);
        }

        static void d(View view, int i10, int i11) {
            view.setScrollIndicators(i10, i11);
        }
    }

    /* JADX INFO: compiled from: ViewCompat.java */
    static class j {
        static void a(View view) {
            view.cancelDragAndDrop();
        }

        static void b(View view) {
            view.dispatchFinishTemporaryDetach();
        }

        static void c(View view) {
            view.dispatchStartTemporaryDetach();
        }

        static void d(View view, PointerIcon pointerIcon) {
            view.setPointerIcon(pointerIcon);
        }

        static boolean e(View view, ClipData clipData, View.DragShadowBuilder dragShadowBuilder, Object obj, int i10) {
            return view.startDragAndDrop(clipData, dragShadowBuilder, obj, i10);
        }

        static void f(View view, View.DragShadowBuilder dragShadowBuilder) {
            view.updateDragShadow(dragShadowBuilder);
        }
    }

    /* JADX INFO: compiled from: ViewCompat.java */
    static class k {
        static void a(View view, Collection<View> collection, int i10) {
            view.addKeyboardNavigationClusters(collection, i10);
        }

        public static AutofillId b(View view) {
            return view.getAutofillId();
        }

        static int c(View view) {
            return view.getImportantForAutofill();
        }

        static int d(View view) {
            return view.getNextClusterForwardId();
        }

        static boolean e(View view) {
            return view.hasExplicitFocusable();
        }

        static boolean f(View view) {
            return view.isFocusedByDefault();
        }

        static boolean g(View view) {
            return view.isImportantForAutofill();
        }

        static boolean h(View view) {
            return view.isKeyboardNavigationCluster();
        }

        static View i(View view, View view2, int i10) {
            return view.keyboardNavigationClusterSearch(view2, i10);
        }

        static boolean j(View view) {
            return view.restoreDefaultFocus();
        }

        static void k(View view, String... strArr) {
            view.setAutofillHints(strArr);
        }

        static void l(View view, boolean z10) {
            view.setFocusedByDefault(z10);
        }

        static void m(View view, int i10) {
            view.setImportantForAutofill(i10);
        }

        static void n(View view, boolean z10) {
            view.setKeyboardNavigationCluster(z10);
        }

        static void o(View view, int i10) {
            view.setNextClusterForwardId(i10);
        }

        static void p(View view, CharSequence charSequence) {
            view.setTooltipText(charSequence);
        }
    }

    /* JADX INFO: compiled from: ViewCompat.java */
    static class l {
        static void a(View view, final o oVar) {
            int i10 = R$id.tag_unhandled_key_listeners;
            r.g gVar = (r.g) view.getTag(i10);
            if (gVar == null) {
                gVar = new r.g();
                view.setTag(i10, gVar);
            }
            Objects.requireNonNull(oVar);
            View.OnUnhandledKeyEventListener onUnhandledKeyEventListener = new View.OnUnhandledKeyEventListener(oVar) { // from class: androidx.core.view.i0

                /* JADX INFO: renamed from: a, reason: collision with root package name */
                public final /* synthetic */ h0.o f2350a;

                @Override // android.view.View.OnUnhandledKeyEventListener
                public final boolean onUnhandledKeyEvent(View view2, KeyEvent keyEvent) {
                    return this.f2350a.onUnhandledKeyEvent(view2, keyEvent);
                }
            };
            gVar.put(oVar, onUnhandledKeyEventListener);
            view.addOnUnhandledKeyEventListener(onUnhandledKeyEventListener);
        }

        static CharSequence b(View view) {
            return view.getAccessibilityPaneTitle();
        }

        static boolean c(View view) {
            return view.isAccessibilityHeading();
        }

        static boolean d(View view) {
            return view.isScreenReaderFocusable();
        }

        static void e(View view, o oVar) {
            View.OnUnhandledKeyEventListener onUnhandledKeyEventListener;
            r.g gVar = (r.g) view.getTag(R$id.tag_unhandled_key_listeners);
            if (gVar == null || (onUnhandledKeyEventListener = (View.OnUnhandledKeyEventListener) gVar.get(oVar)) == null) {
                return;
            }
            view.removeOnUnhandledKeyEventListener(onUnhandledKeyEventListener);
        }

        static <T> T f(View view, int i10) {
            return (T) view.requireViewById(i10);
        }

        static void g(View view, boolean z10) {
            view.setAccessibilityHeading(z10);
        }

        static void h(View view, CharSequence charSequence) {
            view.setAccessibilityPaneTitle(charSequence);
        }

        public static void i(View view, c0.a aVar) {
            view.setAutofillId(null);
        }

        static void j(View view, boolean z10) {
            view.setScreenReaderFocusable(z10);
        }
    }

    /* JADX INFO: compiled from: ViewCompat.java */
    private static class m {
        static View.AccessibilityDelegate a(View view) {
            return view.getAccessibilityDelegate();
        }

        static ContentCaptureSession b(View view) {
            return view.getContentCaptureSession();
        }

        static List<Rect> c(View view) {
            return view.getSystemGestureExclusionRects();
        }

        static void d(View view, Context context, int[] iArr, AttributeSet attributeSet, TypedArray typedArray, int i10, int i11) {
            view.saveAttributeDataForStyleable(context, iArr, attributeSet, typedArray, i10, i11);
        }

        static void e(View view, d0.a aVar) {
            view.setContentCaptureSession(null);
        }

        static void f(View view, List<Rect> list) {
            view.setSystemGestureExclusionRects(list);
        }
    }

    /* JADX INFO: compiled from: ViewCompat.java */
    private static class n {
        static int a(View view) {
            return view.getImportantForContentCapture();
        }

        static CharSequence b(View view) {
            return view.getStateDescription();
        }

        public static u0 c(View view) {
            WindowInsetsController windowInsetsController = view.getWindowInsetsController();
            if (windowInsetsController != null) {
                return u0.f(windowInsetsController);
            }
            return null;
        }

        static boolean d(View view) {
            return view.isImportantForContentCapture();
        }

        static void e(View view, int i10) {
            view.setImportantForContentCapture(i10);
        }

        static void f(View view, CharSequence charSequence) {
            view.setStateDescription(charSequence);
        }
    }

    /* JADX INFO: compiled from: ViewCompat.java */
    public interface o {
        boolean onUnhandledKeyEvent(View view, KeyEvent keyEvent);
    }

    @Deprecated
    public static int A(View view) {
        return view.getPaddingEnd();
    }

    public static void A0(View view, boolean z10) {
        h.t(view, z10);
    }

    @Deprecated
    public static int B(View view) {
        return view.getPaddingStart();
    }

    public static void B0(View view, x xVar) {
        h.u(view, xVar);
    }

    @Deprecated
    public static ViewParent C(View view) {
        return view.getParentForAccessibility();
    }

    @Deprecated
    public static void C0(View view, int i10, int i11, int i12, int i13) {
        view.setPaddingRelative(i10, i11, i12, i13);
    }

    public static t0 D(View view) {
        return i.a(view);
    }

    public static void D0(View view, a0 a0Var) {
        j.d(view, (PointerIcon) (a0Var != null ? a0Var.a() : null));
    }

    public static CharSequence E(View view) {
        return K0().e(view);
    }

    public static void E0(View view, int i10, int i11) {
        i.d(view, i10, i11);
    }

    public static String F(View view) {
        return h.k(view);
    }

    public static void F0(View view, CharSequence charSequence) {
        K0().f(view, charSequence);
    }

    public static float G(View view) {
        return h.l(view);
    }

    public static void G0(View view, String str) {
        h.v(view, str);
    }

    @Deprecated
    public static u0 H(View view) {
        return n.c(view);
    }

    public static void H0(View view, float f10) {
        h.w(view, f10);
    }

    @Deprecated
    public static int I(View view) {
        return view.getWindowSystemUiVisibility();
    }

    public static void I0(View view, s0.b bVar) {
        s0.c(view, bVar);
    }

    public static float J(View view) {
        return h.m(view);
    }

    public static void J0(View view, float f10) {
        h.x(view, f10);
    }

    public static boolean K(View view) {
        return k(view) != null;
    }

    private static f<CharSequence> K0() {
        return new c(R$id.tag_state_description, CharSequence.class, 64, 30);
    }

    @Deprecated
    public static boolean L(View view) {
        return view.hasOnClickListeners();
    }

    public static void L0(View view) {
        h.z(view);
    }

    @Deprecated
    public static boolean M(View view) {
        return view.hasOverlappingRendering();
    }

    @Deprecated
    public static boolean N(View view) {
        return view.hasTransientState();
    }

    public static boolean O(View view) {
        Boolean boolE = a().e(view);
        return boolE != null && boolE.booleanValue();
    }

    @Deprecated
    public static boolean P(View view) {
        return view.isAttachedToWindow();
    }

    @Deprecated
    public static boolean Q(View view) {
        return view.isLaidOut();
    }

    public static boolean R(View view) {
        return h.p(view);
    }

    @Deprecated
    public static boolean S(View view) {
        return view.isPaddingRelative();
    }

    public static boolean T(View view) {
        Boolean boolE = k0().e(view);
        return boolE != null && boolE.booleanValue();
    }

    static void U(View view, int i10) {
        AccessibilityManager accessibilityManager = (AccessibilityManager) view.getContext().getSystemService("accessibility");
        if (accessibilityManager.isEnabled()) {
            boolean z10 = l(view) != null && view.isShown() && view.getWindowVisibility() == 0;
            if (view.getAccessibilityLiveRegion() != 0 || z10) {
                AccessibilityEvent accessibilityEventObtain = AccessibilityEvent.obtain();
                accessibilityEventObtain.setEventType(z10 ? 32 : 2048);
                accessibilityEventObtain.setContentChangeTypes(i10);
                if (z10) {
                    accessibilityEventObtain.getText().add(l(view));
                    x0(view);
                }
                view.sendAccessibilityEventUnchecked(accessibilityEventObtain);
                return;
            }
            if (i10 == 32) {
                AccessibilityEvent accessibilityEventObtain2 = AccessibilityEvent.obtain();
                view.onInitializeAccessibilityEvent(accessibilityEventObtain2);
                accessibilityEventObtain2.setEventType(32);
                accessibilityEventObtain2.setContentChangeTypes(i10);
                accessibilityEventObtain2.setSource(view);
                view.onPopulateAccessibilityEvent(accessibilityEventObtain2);
                accessibilityEventObtain2.getText().add(l(view));
                accessibilityManager.sendAccessibilityEvent(accessibilityEventObtain2);
                return;
            }
            if (view.getParent() != null) {
                try {
                    view.getParent().notifySubtreeAccessibilityStateChanged(view, view, i10);
                } catch (AbstractMethodError e10) {
                    Log.e("ViewCompat", view.getParent().getClass().getSimpleName() + " does not fully implement ViewParent", e10);
                }
            }
        }
    }

    public static void V(View view, int i10) {
        view.offsetLeftAndRight(i10);
    }

    public static void W(View view, int i10) {
        view.offsetTopAndBottom(i10);
    }

    public static t0 X(View view, t0 t0Var) {
        WindowInsets windowInsetsU = t0Var.u();
        if (windowInsetsU != null) {
            WindowInsets windowInsetsB = g.b(view, windowInsetsU);
            if (!windowInsetsB.equals(windowInsetsU)) {
                return t0.w(windowInsetsB, view);
            }
        }
        return t0Var;
    }

    @Deprecated
    public static void Y(View view, b0.d dVar) {
        view.onInitializeAccessibilityNodeInfo(dVar.K0());
    }

    private static f<CharSequence> Z() {
        return new b(R$id.tag_accessibility_pane_title, CharSequence.class, 8, 28);
    }

    private static f<Boolean> a() {
        return new d(R$id.tag_accessibility_heading, Boolean.class, 28);
    }

    @Deprecated
    public static boolean a0(View view, int i10, Bundle bundle) {
        return view.performAccessibilityAction(i10, bundle);
    }

    public static int b(View view, CharSequence charSequence, b0.g gVar) {
        int iN = n(view, charSequence);
        if (iN != -1) {
            c(view, new b0.d.a(iN, charSequence, gVar));
        }
        return iN;
    }

    @Deprecated
    public static void b0(View view) {
        view.postInvalidateOnAnimation();
    }

    private static void c(View view, b0.d.a aVar) {
        h(view);
        f0(aVar.b(), view);
        m(view).add(aVar);
        U(view, 0);
    }

    @Deprecated
    public static void c0(View view, Runnable runnable) {
        view.postOnAnimation(runnable);
    }

    @Deprecated
    public static n0 d(View view) {
        if (f2338a == null) {
            f2338a = new WeakHashMap<>();
        }
        n0 n0Var = f2338a.get(view);
        if (n0Var != null) {
            return n0Var;
        }
        n0 n0Var2 = new n0(view);
        f2338a.put(view, n0Var2);
        return n0Var2;
    }

    @SuppressLint({"LambdaLast"})
    @Deprecated
    public static void d0(View view, Runnable runnable, long j10) {
        view.postOnAnimationDelayed(runnable, j10);
    }

    public static t0 e(View view, t0 t0Var, Rect rect) {
        return h.b(view, t0Var, rect);
    }

    public static void e0(View view, int i10) {
        f0(i10, view);
        U(view, 0);
    }

    public static t0 f(View view, t0 t0Var) {
        WindowInsets windowInsetsU = t0Var.u();
        if (windowInsetsU != null) {
            WindowInsets windowInsetsA = g.a(view, windowInsetsU);
            if (!windowInsetsA.equals(windowInsetsU)) {
                return t0.w(windowInsetsA, view);
            }
        }
        return t0Var;
    }

    private static void f0(int i10, View view) {
        List<b0.d.a> listM = m(view);
        for (int i11 = 0; i11 < listM.size(); i11++) {
            if (listM.get(i11).b() == i10) {
                listM.remove(i11);
                return;
            }
        }
    }

    static boolean g(View view, KeyEvent keyEvent) {
        return false;
    }

    public static void g0(View view, b0.d.a aVar, CharSequence charSequence, b0.g gVar) {
        if (gVar == null && charSequence == null) {
            e0(view, aVar.b());
        } else {
            c(view, aVar.a(charSequence, gVar));
        }
    }

    static void h(View view) {
        androidx.core.view.a aVarJ = j(view);
        if (aVarJ == null) {
            aVarJ = new androidx.core.view.a();
        }
        l0(view, aVarJ);
    }

    public static void h0(View view) {
        g.c(view);
    }

    @Deprecated
    public static int i() {
        return View.generateViewId();
    }

    @Deprecated
    public static int i0(int i10, int i11, int i12) {
        return View.resolveSizeAndState(i10, i11, i12);
    }

    public static androidx.core.view.a j(View view) {
        View.AccessibilityDelegate accessibilityDelegateK = k(view);
        if (accessibilityDelegateK == null) {
            return null;
        }
        return accessibilityDelegateK instanceof androidx.core.view.a.C0017a ? ((androidx.core.view.a.C0017a) accessibilityDelegateK).f2312a : new androidx.core.view.a(accessibilityDelegateK);
    }

    public static void j0(View view, @SuppressLint({"ContextFirst"}) Context context, int[] iArr, AttributeSet attributeSet, TypedArray typedArray, int i10, int i11) {
        m.d(view, context, iArr, attributeSet, typedArray, i10, i11);
    }

    private static View.AccessibilityDelegate k(View view) {
        return m.a(view);
    }

    private static f<Boolean> k0() {
        return new a(R$id.tag_screen_reader_focusable, Boolean.class, 28);
    }

    public static CharSequence l(View view) {
        return Z().e(view);
    }

    public static void l0(View view, androidx.core.view.a aVar) {
        if (aVar == null && (k(view) instanceof androidx.core.view.a.C0017a)) {
            aVar = new androidx.core.view.a();
        }
        x0(view);
        view.setAccessibilityDelegate(aVar == null ? null : aVar.getBridge());
    }

    private static List<b0.d.a> m(View view) {
        int i10 = R$id.tag_accessibility_actions;
        ArrayList arrayList = (ArrayList) view.getTag(i10);
        if (arrayList != null) {
            return arrayList;
        }
        ArrayList arrayList2 = new ArrayList();
        view.setTag(i10, arrayList2);
        return arrayList2;
    }

    public static void m0(View view, boolean z10) {
        a().f(view, Boolean.valueOf(z10));
    }

    private static int n(View view, CharSequence charSequence) {
        List<b0.d.a> listM = m(view);
        for (int i10 = 0; i10 < listM.size(); i10++) {
            if (TextUtils.equals(charSequence, listM.get(i10).c())) {
                return listM.get(i10).b();
            }
        }
        int i11 = -1;
        int i12 = 0;
        while (true) {
            int[] iArr = f2339b;
            if (i12 >= iArr.length || i11 != -1) {
                break;
            }
            int i13 = iArr[i12];
            boolean z10 = true;
            for (int i14 = 0; i14 < listM.size(); i14++) {
                z10 &= listM.get(i14).b() != i13;
            }
            if (z10) {
                i11 = i13;
            }
            i12++;
        }
        return i11;
    }

    @Deprecated
    public static void n0(View view, int i10) {
        view.setAccessibilityLiveRegion(i10);
    }

    public static ColorStateList o(View view) {
        return h.g(view);
    }

    public static void o0(View view, CharSequence charSequence) {
        Z().f(view, charSequence);
        if (charSequence != null) {
            f2341d.a(view);
        } else {
            f2341d.c(view);
        }
    }

    public static PorterDuff.Mode p(View view) {
        return h.h(view);
    }

    @Deprecated
    public static void p0(View view, Drawable drawable) {
        view.setBackground(drawable);
    }

    @Deprecated
    public static Rect q(View view) {
        return view.getClipBounds();
    }

    public static void q0(View view, ColorStateList colorStateList) {
        h.q(view, colorStateList);
    }

    @Deprecated
    public static Display r(View view) {
        return view.getDisplay();
    }

    public static void r0(View view, PorterDuff.Mode mode) {
        h.r(view, mode);
    }

    public static float s(View view) {
        return h.i(view);
    }

    @Deprecated
    public static void s0(View view, Rect rect) {
        view.setClipBounds(rect);
    }

    @Deprecated
    public static boolean t(View view) {
        return view.getFitsSystemWindows();
    }

    public static void t0(View view, float f10) {
        h.s(view, f10);
    }

    @Deprecated
    public static int u(View view) {
        return view.getImportantForAccessibility();
    }

    @Deprecated
    public static void u0(View view, boolean z10) {
        view.setFitsSystemWindows(z10);
    }

    @SuppressLint({"InlinedApi"})
    public static int v(View view) {
        return k.c(view);
    }

    @Deprecated
    public static void v0(View view, boolean z10) {
        view.setHasTransientState(z10);
    }

    @Deprecated
    public static int w(View view) {
        return view.getLayoutDirection();
    }

    @Deprecated
    public static void w0(View view, int i10) {
        view.setImportantForAccessibility(i10);
    }

    @Deprecated
    public static int x(View view) {
        return view.getMeasuredState();
    }

    private static void x0(View view) {
        if (view.getImportantForAccessibility() == 0) {
            view.setImportantForAccessibility(1);
        }
    }

    @Deprecated
    public static int y(View view) {
        return view.getMinimumHeight();
    }

    public static void y0(View view, int i10) {
        k.m(view, i10);
    }

    @Deprecated
    public static int z(View view) {
        return view.getMinimumWidth();
    }

    @Deprecated
    public static void z0(View view, int i10) {
        view.setLabelFor(i10);
    }

    /* JADX INFO: compiled from: ViewCompat.java */
    static class e implements ViewTreeObserver.OnGlobalLayoutListener, View.OnAttachStateChangeListener {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private final WeakHashMap<View, Boolean> f2342a = new WeakHashMap<>();

        e() {
        }

        private void b(View view) {
            view.getViewTreeObserver().addOnGlobalLayoutListener(this);
        }

        private void d(View view) {
            view.getViewTreeObserver().removeOnGlobalLayoutListener(this);
        }

        void a(View view) {
            this.f2342a.put(view, Boolean.valueOf(view.isShown() && view.getWindowVisibility() == 0));
            view.addOnAttachStateChangeListener(this);
            if (view.isAttachedToWindow()) {
                b(view);
            }
        }

        void c(View view) {
            this.f2342a.remove(view);
            view.removeOnAttachStateChangeListener(this);
            d(view);
        }

        @Override // android.view.View.OnAttachStateChangeListener
        public void onViewAttachedToWindow(View view) {
            b(view);
        }

        @Override // android.view.ViewTreeObserver.OnGlobalLayoutListener
        public void onGlobalLayout() {
        }

        @Override // android.view.View.OnAttachStateChangeListener
        public void onViewDetachedFromWindow(View view) {
        }
    }
}
