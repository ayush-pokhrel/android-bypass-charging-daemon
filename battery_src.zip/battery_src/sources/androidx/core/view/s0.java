package androidx.core.view;

import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsAnimation;
import android.view.animation.Interpolator;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

/* JADX INFO: compiled from: WindowInsetsAnimationCompat.java */
/* JADX INFO: loaded from: classes.dex */
public final class s0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private d f2367a;

    /* JADX INFO: compiled from: WindowInsetsAnimationCompat.java */
    public static final class a {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private final androidx.core.graphics.b f2368a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private final androidx.core.graphics.b f2369b;

        private a(WindowInsetsAnimation.Bounds bounds) {
            this.f2368a = c.f(bounds);
            this.f2369b = c.e(bounds);
        }

        public static a d(WindowInsetsAnimation.Bounds bounds) {
            return new a(bounds);
        }

        public androidx.core.graphics.b a() {
            return this.f2368a;
        }

        public androidx.core.graphics.b b() {
            return this.f2369b;
        }

        public WindowInsetsAnimation.Bounds c() {
            return c.d(this);
        }

        public String toString() {
            return "Bounds{lower=" + this.f2368a + " upper=" + this.f2369b + "}";
        }
    }

    /* JADX INFO: compiled from: WindowInsetsAnimationCompat.java */
    public static abstract class b {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private final int f2370a;

        public b(int i10) {
            this.f2370a = i10;
        }

        public final int a() {
            return this.f2370a;
        }

        public abstract void b(s0 s0Var);

        public abstract void c(s0 s0Var);

        public abstract t0 d(t0 t0Var, List<s0> list);

        public abstract a e(s0 s0Var, a aVar);
    }

    /* JADX INFO: compiled from: WindowInsetsAnimationCompat.java */
    private static class d {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private final int f2376a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private final Interpolator f2377b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        private final long f2378c;

        d(int i10, Interpolator interpolator, long j10) {
            this.f2376a = i10;
            this.f2377b = interpolator;
            this.f2378c = j10;
        }

        public float a() {
            throw null;
        }

        public int b() {
            throw null;
        }

        public void c(float f10) {
            throw null;
        }
    }

    public s0(int i10, Interpolator interpolator, long j10) {
        this.f2367a = new c(i10, interpolator, j10);
    }

    static void c(View view, b bVar) {
        c.g(view, bVar);
    }

    static s0 e(WindowInsetsAnimation windowInsetsAnimation) {
        return new s0(windowInsetsAnimation);
    }

    public float a() {
        return this.f2367a.a();
    }

    public int b() {
        return this.f2367a.b();
    }

    public void d(float f10) {
        this.f2367a.c(f10);
    }

    /* JADX INFO: compiled from: WindowInsetsAnimationCompat.java */
    private static class c extends d {

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        private final WindowInsetsAnimation f2371d;

        /* JADX INFO: compiled from: WindowInsetsAnimationCompat.java */
        private static class a extends WindowInsetsAnimation.Callback {

            /* JADX INFO: renamed from: a, reason: collision with root package name */
            private final b f2372a;

            /* JADX INFO: renamed from: b, reason: collision with root package name */
            private List<s0> f2373b;

            /* JADX INFO: renamed from: c, reason: collision with root package name */
            private ArrayList<s0> f2374c;

            /* JADX INFO: renamed from: d, reason: collision with root package name */
            private final HashMap<WindowInsetsAnimation, s0> f2375d;

            a(b bVar) {
                super(bVar.a());
                this.f2375d = new HashMap<>();
                this.f2372a = bVar;
            }

            private s0 a(WindowInsetsAnimation windowInsetsAnimation) {
                s0 s0Var = this.f2375d.get(windowInsetsAnimation);
                if (s0Var != null) {
                    return s0Var;
                }
                s0 s0VarE = s0.e(windowInsetsAnimation);
                this.f2375d.put(windowInsetsAnimation, s0VarE);
                return s0VarE;
            }

            @Override // android.view.WindowInsetsAnimation.Callback
            public void onEnd(WindowInsetsAnimation windowInsetsAnimation) {
                this.f2372a.b(a(windowInsetsAnimation));
                this.f2375d.remove(windowInsetsAnimation);
            }

            @Override // android.view.WindowInsetsAnimation.Callback
            public void onPrepare(WindowInsetsAnimation windowInsetsAnimation) {
                this.f2372a.c(a(windowInsetsAnimation));
            }

            @Override // android.view.WindowInsetsAnimation.Callback
            public WindowInsets onProgress(WindowInsets windowInsets, List<WindowInsetsAnimation> list) {
                ArrayList<s0> arrayList = this.f2374c;
                if (arrayList == null) {
                    ArrayList<s0> arrayList2 = new ArrayList<>(list.size());
                    this.f2374c = arrayList2;
                    this.f2373b = Collections.unmodifiableList(arrayList2);
                } else {
                    arrayList.clear();
                }
                for (int size = list.size() - 1; size >= 0; size--) {
                    WindowInsetsAnimation windowInsetsAnimation = list.get(size);
                    s0 s0VarA = a(windowInsetsAnimation);
                    s0VarA.d(windowInsetsAnimation.getFraction());
                    this.f2374c.add(s0VarA);
                }
                return this.f2372a.d(t0.v(windowInsets), this.f2373b).u();
            }

            @Override // android.view.WindowInsetsAnimation.Callback
            public WindowInsetsAnimation.Bounds onStart(WindowInsetsAnimation windowInsetsAnimation, WindowInsetsAnimation.Bounds bounds) {
                return this.f2372a.e(a(windowInsetsAnimation), a.d(bounds)).c();
            }
        }

        c(WindowInsetsAnimation windowInsetsAnimation) {
            super(0, null, 0L);
            this.f2371d = windowInsetsAnimation;
        }

        public static WindowInsetsAnimation.Bounds d(a aVar) {
            return new WindowInsetsAnimation.Bounds(aVar.a().e(), aVar.b().e());
        }

        public static androidx.core.graphics.b e(WindowInsetsAnimation.Bounds bounds) {
            return androidx.core.graphics.b.d(bounds.getUpperBound());
        }

        public static androidx.core.graphics.b f(WindowInsetsAnimation.Bounds bounds) {
            return androidx.core.graphics.b.d(bounds.getLowerBound());
        }

        public static void g(View view, b bVar) {
            view.setWindowInsetsAnimationCallback(bVar != null ? new a(bVar) : null);
        }

        @Override // androidx.core.view.s0.d
        public float a() {
            return this.f2371d.getInterpolatedFraction();
        }

        @Override // androidx.core.view.s0.d
        public int b() {
            return this.f2371d.getTypeMask();
        }

        @Override // androidx.core.view.s0.d
        public void c(float f10) {
            this.f2371d.setFraction(f10);
        }

        c(int i10, Interpolator interpolator, long j10) {
            this(new WindowInsetsAnimation(i10, interpolator, j10));
        }
    }

    private s0(WindowInsetsAnimation windowInsetsAnimation) {
        this(0, null, 0L);
        this.f2367a = new c(windowInsetsAnimation);
    }
}
