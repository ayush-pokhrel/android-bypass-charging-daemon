package androidx.core.view;

import android.view.View;

/* JADX INFO: compiled from: ViewPropertyAnimatorListener.java */
/* JADX INFO: loaded from: classes.dex */
public interface o0 {
    void a(View view);

    void b(View view);

    void c(View view);
}
