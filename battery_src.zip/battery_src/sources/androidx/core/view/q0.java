package androidx.core.view;

import android.view.View;

/* JADX INFO: compiled from: ViewPropertyAnimatorUpdateListener.java */
/* JADX INFO: loaded from: classes.dex */
public interface q0 {
    void a(View view);
}
