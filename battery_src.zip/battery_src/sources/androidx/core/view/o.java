package androidx.core.view;

import android.annotation.SuppressLint;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import androidx.lifecycle.Lifecycle;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;

/* JADX INFO: compiled from: MenuHostHelper.java */
/* JADX INFO: loaded from: classes.dex */
public class o {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final Runnable f2362a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private final CopyOnWriteArrayList<q> f2363b = new CopyOnWriteArrayList<>();

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private final Map<q, a> f2364c = new HashMap();

    /* JADX INFO: compiled from: MenuHostHelper.java */
    private static class a {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        final Lifecycle f2365a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private androidx.lifecycle.i f2366b;

        a(Lifecycle lifecycle, androidx.lifecycle.i iVar) {
            this.f2365a = lifecycle;
            this.f2366b = iVar;
            lifecycle.a(iVar);
        }

        void a() {
            this.f2365a.d(this.f2366b);
            this.f2366b = null;
        }
    }

    public o(Runnable runnable) {
        this.f2362a = runnable;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void f(q qVar, androidx.lifecycle.l lVar, Lifecycle.Event event) {
        if (event == Lifecycle.Event.ON_DESTROY) {
            l(qVar);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void g(Lifecycle.State state, q qVar, androidx.lifecycle.l lVar, Lifecycle.Event event) {
        if (event == Lifecycle.Event.d(state)) {
            c(qVar);
            return;
        }
        if (event == Lifecycle.Event.ON_DESTROY) {
            l(qVar);
        } else if (event == Lifecycle.Event.b(state)) {
            this.f2363b.remove(qVar);
            this.f2362a.run();
        }
    }

    public void c(q qVar) {
        this.f2363b.add(qVar);
        this.f2362a.run();
    }

    public void d(final q qVar, androidx.lifecycle.l lVar) {
        c(qVar);
        Lifecycle lifecycle = lVar.getLifecycle();
        a aVarRemove = this.f2364c.remove(qVar);
        if (aVarRemove != null) {
            aVarRemove.a();
        }
        this.f2364c.put(qVar, new a(lifecycle, new androidx.lifecycle.i() { // from class: androidx.core.view.n
            @Override // androidx.lifecycle.i
            public final void a(androidx.lifecycle.l lVar2, Lifecycle.Event event) {
                this.f2356a.f(qVar, lVar2, event);
            }
        }));
    }

    @SuppressLint({"LambdaLast"})
    public void e(final q qVar, androidx.lifecycle.l lVar, final Lifecycle.State state) {
        Lifecycle lifecycle = lVar.getLifecycle();
        a aVarRemove = this.f2364c.remove(qVar);
        if (aVarRemove != null) {
            aVarRemove.a();
        }
        this.f2364c.put(qVar, new a(lifecycle, new androidx.lifecycle.i() { // from class: androidx.core.view.m
            @Override // androidx.lifecycle.i
            public final void a(androidx.lifecycle.l lVar2, Lifecycle.Event event) {
                this.f2351a.g(state, qVar, lVar2, event);
            }
        }));
    }

    public void h(Menu menu, MenuInflater menuInflater) {
        Iterator<q> it = this.f2363b.iterator();
        while (it.hasNext()) {
            it.next().c(menu, menuInflater);
        }
    }

    public void i(Menu menu) {
        Iterator<q> it = this.f2363b.iterator();
        while (it.hasNext()) {
            it.next().b(menu);
        }
    }

    public boolean j(MenuItem menuItem) {
        Iterator<q> it = this.f2363b.iterator();
        while (it.hasNext()) {
            if (it.next().a(menuItem)) {
                return true;
            }
        }
        return false;
    }

    public void k(Menu menu) {
        Iterator<q> it = this.f2363b.iterator();
        while (it.hasNext()) {
            it.next().d(menu);
        }
    }

    public void l(q qVar) {
        this.f2363b.remove(qVar);
        a aVarRemove = this.f2364c.remove(qVar);
        if (aVarRemove != null) {
            aVarRemove.a();
        }
        this.f2362a.run();
    }
}
