package androidx.core;

/* JADX INFO: loaded from: classes.dex */
public final class R$layout {
    public static final int custom_dialog = 2131493043;
    public static final int ime_base_split_test_activity = 2131493066;
    public static final int ime_secondary_split_test_activity = 2131493067;
    public static final int notification_action = 2131493126;
    public static final int notification_action_tombstone = 2131493127;
    public static final int notification_template_custom_big = 2131493128;
    public static final int notification_template_icon_group = 2131493129;
    public static final int notification_template_part_chronometer = 2131493130;
    public static final int notification_template_part_time = 2131493131;

    private R$layout() {
    }
}
