package androidx.core.graphics;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.os.CancellationSignal;
import android.os.Handler;

/* JADX INFO: compiled from: TypefaceCompat.java */
/* JADX INFO: loaded from: classes.dex */
public class e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private static final g f2256a = new f();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private static final r.e<String, Typeface> f2257b = new r.e<>(16);

    /* JADX INFO: compiled from: TypefaceCompat.java */
    public static class a extends z.g.c {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private androidx.core.content.res.h.e f2258a;

        public a(androidx.core.content.res.h.e eVar) {
            this.f2258a = eVar;
        }

        @Override // z.g.c
        public void a(int i10) {
            androidx.core.content.res.h.e eVar = this.f2258a;
            if (eVar != null) {
                eVar.f(i10);
            }
        }

        @Override // z.g.c
        public void b(Typeface typeface) {
            androidx.core.content.res.h.e eVar = this.f2258a;
            if (eVar != null) {
                eVar.g(typeface);
            }
        }
    }

    public static Typeface a(Context context, Typeface typeface, int i10) {
        if (context != null) {
            return Typeface.create(typeface, i10);
        }
        throw new IllegalArgumentException("Context cannot be null");
    }

    public static Typeface b(Context context, CancellationSignal cancellationSignal, z.g.b[] bVarArr, int i10) {
        return f2256a.b(context, cancellationSignal, bVarArr, i10);
    }

    public static Typeface c(Context context, androidx.core.content.res.e.b bVar, Resources resources, int i10, String str, int i11, int i12, androidx.core.content.res.h.e eVar, Handler handler, boolean z10) {
        Typeface typefaceA;
        if (bVar instanceof androidx.core.content.res.e.C0012e) {
            androidx.core.content.res.e.C0012e c0012e = (androidx.core.content.res.e.C0012e) bVar;
            Typeface typefaceG = g(c0012e.c());
            if (typefaceG != null) {
                if (eVar != null) {
                    eVar.d(typefaceG, handler);
                }
                return typefaceG;
            }
            typefaceA = z.g.c(context, c0012e.b(), i12, !z10 ? eVar != null : c0012e.a() != 0, z10 ? c0012e.d() : -1, androidx.core.content.res.h.e.e(handler), new a(eVar));
        } else {
            typefaceA = f2256a.a(context, (androidx.core.content.res.e.c) bVar, resources, i12);
            if (eVar != null) {
                if (typefaceA != null) {
                    eVar.d(typefaceA, handler);
                } else {
                    eVar.c(-3, handler);
                }
            }
        }
        if (typefaceA != null) {
            f2257b.d(e(resources, i10, str, i11, i12), typefaceA);
        }
        return typefaceA;
    }

    public static Typeface d(Context context, Resources resources, int i10, String str, int i11, int i12) {
        Typeface typefaceC = f2256a.c(context, resources, i10, str, i12);
        if (typefaceC != null) {
            f2257b.d(e(resources, i10, str, i11, i12), typefaceC);
        }
        return typefaceC;
    }

    private static String e(Resources resources, int i10, String str, int i11, int i12) {
        return resources.getResourcePackageName(i10) + '-' + str + '-' + i11 + '-' + i10 + '-' + i12;
    }

    public static Typeface f(Resources resources, int i10, String str, int i11, int i12) {
        return f2257b.c(e(resources, i10, str, i11, i12));
    }

    private static Typeface g(String str) {
        if (str == null || str.isEmpty()) {
            return null;
        }
        Typeface typefaceCreate = Typeface.create(str, 0);
        Typeface typefaceCreate2 = Typeface.create(Typeface.DEFAULT, 0);
        if (typefaceCreate == null || typefaceCreate.equals(typefaceCreate2)) {
            return null;
        }
        return typefaceCreate;
    }
}
