package androidx.core.graphics;

import android.graphics.Insets;
import android.graphics.Rect;

/* JADX INFO: compiled from: Insets.java */
/* JADX INFO: loaded from: classes.dex */
public final class b {

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final b f2235e = new b(0, 0, 0, 0);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final int f2236a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final int f2237b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final int f2238c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public final int f2239d;

    /* JADX INFO: compiled from: Insets.java */
    static class a {
        static Insets a(int i10, int i11, int i12, int i13) {
            return Insets.of(i10, i11, i12, i13);
        }
    }

    private b(int i10, int i11, int i12, int i13) {
        this.f2236a = i10;
        this.f2237b = i11;
        this.f2238c = i12;
        this.f2239d = i13;
    }

    public static b a(b bVar, b bVar2) {
        return b(Math.max(bVar.f2236a, bVar2.f2236a), Math.max(bVar.f2237b, bVar2.f2237b), Math.max(bVar.f2238c, bVar2.f2238c), Math.max(bVar.f2239d, bVar2.f2239d));
    }

    public static b b(int i10, int i11, int i12, int i13) {
        return (i10 == 0 && i11 == 0 && i12 == 0 && i13 == 0) ? f2235e : new b(i10, i11, i12, i13);
    }

    public static b c(Rect rect) {
        return b(rect.left, rect.top, rect.right, rect.bottom);
    }

    public static b d(Insets insets) {
        return b(insets.left, insets.top, insets.right, insets.bottom);
    }

    public Insets e() {
        return a.a(this.f2236a, this.f2237b, this.f2238c, this.f2239d);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || b.class != obj.getClass()) {
            return false;
        }
        b bVar = (b) obj;
        return this.f2239d == bVar.f2239d && this.f2236a == bVar.f2236a && this.f2238c == bVar.f2238c && this.f2237b == bVar.f2237b;
    }

    public int hashCode() {
        return (((((this.f2236a * 31) + this.f2237b) * 31) + this.f2238c) * 31) + this.f2239d;
    }

    public String toString() {
        return "Insets{left=" + this.f2236a + ", top=" + this.f2237b + ", right=" + this.f2238c + ", bottom=" + this.f2239d + '}';
    }
}
