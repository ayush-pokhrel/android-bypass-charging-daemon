package androidx.core.graphics.drawable;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.PorterDuff;
import android.graphics.drawable.AdaptiveIconDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Icon;
import android.net.Uri;
import android.os.Parcelable;
import android.text.TextUtils;
import androidx.versionedparcelable.CustomVersionedParcelable;
import java.io.ByteArrayOutputStream;
import java.nio.charset.Charset;

/* JADX INFO: loaded from: classes.dex */
public class IconCompat extends CustomVersionedParcelable {

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    static final PorterDuff.Mode f2245k = PorterDuff.Mode.SRC_IN;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    Object f2247b;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public String f2255j;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f2246a = -1;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public byte[] f2248c = null;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public Parcelable f2249d = null;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f2250e = 0;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public int f2251f = 0;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public ColorStateList f2252g = null;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    PorterDuff.Mode f2253h = f2245k;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public String f2254i = null;

    static class a {
        static int a(Object obj) {
            return c.a(obj);
        }

        static String b(Object obj) {
            return c.b(obj);
        }

        static Uri c(Object obj) {
            return c.d(obj);
        }

        static Drawable d(Icon icon, Context context) {
            return icon.loadDrawable(context);
        }

        static Icon e(IconCompat iconCompat, Context context) {
            Icon iconCreateWithBitmap;
            switch (iconCompat.f2246a) {
                case -1:
                    return (Icon) iconCompat.f2247b;
                case 0:
                default:
                    throw new IllegalArgumentException("Unknown type");
                case 1:
                    iconCreateWithBitmap = Icon.createWithBitmap((Bitmap) iconCompat.f2247b);
                    break;
                case 2:
                    iconCreateWithBitmap = Icon.createWithResource(iconCompat.b(), iconCompat.f2250e);
                    break;
                case 3:
                    iconCreateWithBitmap = Icon.createWithData((byte[]) iconCompat.f2247b, iconCompat.f2250e, iconCompat.f2251f);
                    break;
                case 4:
                    iconCreateWithBitmap = Icon.createWithContentUri((String) iconCompat.f2247b);
                    break;
                case 5:
                    iconCreateWithBitmap = b.b((Bitmap) iconCompat.f2247b);
                    break;
                case 6:
                    iconCreateWithBitmap = d.a(iconCompat.c());
                    break;
            }
            ColorStateList colorStateList = iconCompat.f2252g;
            if (colorStateList != null) {
                iconCreateWithBitmap.setTintList(colorStateList);
            }
            PorterDuff.Mode mode = iconCompat.f2253h;
            if (mode != IconCompat.f2245k) {
                iconCreateWithBitmap.setTintMode(mode);
            }
            return iconCreateWithBitmap;
        }
    }

    static class b {
        static Drawable a(Drawable drawable, Drawable drawable2) {
            return new AdaptiveIconDrawable(drawable, drawable2);
        }

        static Icon b(Bitmap bitmap) {
            return Icon.createWithAdaptiveBitmap(bitmap);
        }
    }

    static class c {
        static int a(Object obj) {
            return ((Icon) obj).getResId();
        }

        static String b(Object obj) {
            return ((Icon) obj).getResPackage();
        }

        static int c(Object obj) {
            return ((Icon) obj).getType();
        }

        static Uri d(Object obj) {
            return ((Icon) obj).getUri();
        }
    }

    static class d {
        static Icon a(Uri uri) {
            return Icon.createWithAdaptiveBitmapContentUri(uri);
        }
    }

    private static String f(int i10) {
        switch (i10) {
            case 1:
                return "BITMAP";
            case 2:
                return "RESOURCE";
            case 3:
                return "DATA";
            case 4:
                return "URI";
            case 5:
                return "BITMAP_MASKABLE";
            case 6:
                return "URI_MASKABLE";
            default:
                return "UNKNOWN";
        }
    }

    public int a() {
        int i10 = this.f2246a;
        if (i10 == -1) {
            return a.a(this.f2247b);
        }
        if (i10 == 2) {
            return this.f2250e;
        }
        throw new IllegalStateException("called getResId() on " + this);
    }

    public String b() {
        int i10 = this.f2246a;
        if (i10 == -1) {
            return a.b(this.f2247b);
        }
        if (i10 == 2) {
            String str = this.f2255j;
            return (str == null || TextUtils.isEmpty(str)) ? ((String) this.f2247b).split(":", -1)[0] : this.f2255j;
        }
        throw new IllegalStateException("called getResPackage() on " + this);
    }

    public Uri c() {
        int i10 = this.f2246a;
        if (i10 == -1) {
            return a.c(this.f2247b);
        }
        if (i10 == 4 || i10 == 6) {
            return Uri.parse((String) this.f2247b);
        }
        throw new IllegalStateException("called getUri() on " + this);
    }

    public void d() {
        this.f2253h = PorterDuff.Mode.valueOf(this.f2254i);
        switch (this.f2246a) {
            case -1:
                Parcelable parcelable = this.f2249d;
                if (parcelable == null) {
                    throw new IllegalArgumentException("Invalid icon");
                }
                this.f2247b = parcelable;
                return;
            case 0:
            default:
                return;
            case 1:
            case 5:
                Parcelable parcelable2 = this.f2249d;
                if (parcelable2 != null) {
                    this.f2247b = parcelable2;
                    return;
                }
                byte[] bArr = this.f2248c;
                this.f2247b = bArr;
                this.f2246a = 3;
                this.f2250e = 0;
                this.f2251f = bArr.length;
                return;
            case 2:
            case 4:
            case 6:
                String str = new String(this.f2248c, Charset.forName("UTF-16"));
                this.f2247b = str;
                if (this.f2246a == 2 && this.f2255j == null) {
                    this.f2255j = str.split(":", -1)[0];
                    return;
                }
                return;
            case 3:
                this.f2247b = this.f2248c;
                return;
        }
    }

    public void e(boolean z10) {
        this.f2254i = this.f2253h.name();
        switch (this.f2246a) {
            case -1:
                if (z10) {
                    throw new IllegalArgumentException("Can't serialize Icon created with IconCompat#createFromIcon");
                }
                this.f2249d = (Parcelable) this.f2247b;
                return;
            case 0:
            default:
                return;
            case 1:
            case 5:
                if (!z10) {
                    this.f2249d = (Parcelable) this.f2247b;
                    return;
                }
                Bitmap bitmap = (Bitmap) this.f2247b;
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.PNG, 90, byteArrayOutputStream);
                this.f2248c = byteArrayOutputStream.toByteArray();
                return;
            case 2:
                this.f2248c = ((String) this.f2247b).getBytes(Charset.forName("UTF-16"));
                return;
            case 3:
                this.f2248c = (byte[]) this.f2247b;
                return;
            case 4:
            case 6:
                this.f2248c = this.f2247b.toString().getBytes(Charset.forName("UTF-16"));
                return;
        }
    }

    public String toString() {
        if (this.f2246a == -1) {
            return String.valueOf(this.f2247b);
        }
        StringBuilder sb2 = new StringBuilder("Icon(typ=");
        sb2.append(f(this.f2246a));
        switch (this.f2246a) {
            case 1:
            case 5:
                sb2.append(" size=");
                sb2.append(((Bitmap) this.f2247b).getWidth());
                sb2.append("x");
                sb2.append(((Bitmap) this.f2247b).getHeight());
                break;
            case 2:
                sb2.append(" pkg=");
                sb2.append(this.f2255j);
                sb2.append(" id=");
                sb2.append(String.format("0x%08x", Integer.valueOf(a())));
                break;
            case 3:
                sb2.append(" len=");
                sb2.append(this.f2250e);
                if (this.f2251f != 0) {
                    sb2.append(" off=");
                    sb2.append(this.f2251f);
                }
                break;
            case 4:
            case 6:
                sb2.append(" uri=");
                sb2.append(this.f2247b);
                break;
        }
        if (this.f2252g != null) {
            sb2.append(" tint=");
            sb2.append(this.f2252g);
        }
        if (this.f2253h != f2245k) {
            sb2.append(" mode=");
            sb2.append(this.f2253h);
        }
        sb2.append(")");
        return sb2.toString();
    }
}
