package androidx.core.graphics.drawable;

import android.content.res.ColorStateList;
import android.os.Parcelable;

/* JADX INFO: loaded from: classes.dex */
public class IconCompatParcelizer {
    public static IconCompat read(androidx.versionedparcelable.a aVar) {
        IconCompat iconCompat = new IconCompat();
        iconCompat.f2246a = aVar.p(iconCompat.f2246a, 1);
        iconCompat.f2248c = aVar.j(iconCompat.f2248c, 2);
        iconCompat.f2249d = aVar.r(iconCompat.f2249d, 3);
        iconCompat.f2250e = aVar.p(iconCompat.f2250e, 4);
        iconCompat.f2251f = aVar.p(iconCompat.f2251f, 5);
        iconCompat.f2252g = (ColorStateList) aVar.r(iconCompat.f2252g, 6);
        iconCompat.f2254i = aVar.t(iconCompat.f2254i, 7);
        iconCompat.f2255j = aVar.t(iconCompat.f2255j, 8);
        iconCompat.d();
        return iconCompat;
    }

    public static void write(IconCompat iconCompat, androidx.versionedparcelable.a aVar) {
        aVar.x(true, true);
        iconCompat.e(aVar.f());
        int i10 = iconCompat.f2246a;
        if (-1 != i10) {
            aVar.F(i10, 1);
        }
        byte[] bArr = iconCompat.f2248c;
        if (bArr != null) {
            aVar.B(bArr, 2);
        }
        Parcelable parcelable = iconCompat.f2249d;
        if (parcelable != null) {
            aVar.H(parcelable, 3);
        }
        int i11 = iconCompat.f2250e;
        if (i11 != 0) {
            aVar.F(i11, 4);
        }
        int i12 = iconCompat.f2251f;
        if (i12 != 0) {
            aVar.F(i12, 5);
        }
        ColorStateList colorStateList = iconCompat.f2252g;
        if (colorStateList != null) {
            aVar.H(colorStateList, 6);
        }
        String str = iconCompat.f2254i;
        if (str != null) {
            aVar.J(str, 7);
        }
        String str2 = iconCompat.f2255j;
        if (str2 != null) {
            aVar.J(str2, 8);
        }
    }
}
