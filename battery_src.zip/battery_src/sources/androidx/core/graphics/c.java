package androidx.core.graphics;

import android.graphics.Paint;
import android.graphics.Rect;

/* JADX INFO: compiled from: PaintCompat.java */
/* JADX INFO: loaded from: classes.dex */
public final class c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private static final ThreadLocal<a0.d<Rect, Rect>> f2240a = new ThreadLocal<>();

    /* JADX INFO: compiled from: PaintCompat.java */
    static class a {
        static boolean a(Paint paint, String str) {
            return paint.hasGlyph(str);
        }
    }

    public static boolean a(Paint paint, String str) {
        return a.a(paint, str);
    }
}
