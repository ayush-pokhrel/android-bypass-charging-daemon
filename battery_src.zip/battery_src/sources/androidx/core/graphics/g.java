package androidx.core.graphics;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.os.CancellationSignal;
import java.util.concurrent.ConcurrentHashMap;

/* JADX INFO: compiled from: TypefaceCompatBaseImpl.java */
/* JADX INFO: loaded from: classes.dex */
class g {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    @SuppressLint({"BanConcurrentHashMap"})
    private ConcurrentHashMap<Long, androidx.core.content.res.e.c> f2259a = new ConcurrentHashMap<>();

    g() {
    }

    public Typeface a(Context context, androidx.core.content.res.e.c cVar, Resources resources, int i10) {
        throw null;
    }

    public Typeface b(Context context, CancellationSignal cancellationSignal, z.g.b[] bVarArr, int i10) {
        throw null;
    }

    public Typeface c(Context context, Resources resources, int i10, String str, int i11) {
        throw null;
    }
}
