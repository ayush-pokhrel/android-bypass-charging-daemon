package androidx.core;

/* JADX INFO: loaded from: classes.dex */
public final class R$string {
    public static final int call_notification_answer_action = 2131820698;
    public static final int call_notification_answer_video_action = 2131820699;
    public static final int call_notification_decline_action = 2131820700;
    public static final int call_notification_hang_up_action = 2131820701;
    public static final int call_notification_incoming_text = 2131820702;
    public static final int call_notification_ongoing_text = 2131820703;
    public static final int call_notification_screening_text = 2131820704;
    public static final int status_bar_notification_info_overflow = 2131821322;

    private R$string() {
    }
}
