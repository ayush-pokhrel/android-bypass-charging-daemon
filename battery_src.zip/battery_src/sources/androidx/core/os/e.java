package androidx.core.os;

import android.os.LocaleList;
import java.util.Locale;

/* JADX INFO: compiled from: LocaleListCompat.java */
/* JADX INFO: loaded from: classes.dex */
public final class e {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private static final e f2271b = a(new Locale[0]);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final f f2272a;

    /* JADX INFO: compiled from: LocaleListCompat.java */
    static class a {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private static final Locale[] f2273a = {new Locale("en", "XA"), new Locale("ar", "XB")};

        static Locale a(String str) {
            return Locale.forLanguageTag(str);
        }

        private static boolean b(Locale locale) {
            for (Locale locale2 : f2273a) {
                if (locale2.equals(locale)) {
                    return true;
                }
            }
            return false;
        }

        static boolean c(Locale locale, Locale locale2) {
            if (locale.equals(locale2)) {
                return true;
            }
            if (!locale.getLanguage().equals(locale2.getLanguage()) || b(locale) || b(locale2)) {
                return false;
            }
            String strA = androidx.core.text.b.a(locale);
            if (!strA.isEmpty()) {
                return strA.equals(androidx.core.text.b.a(locale2));
            }
            String country = locale.getCountry();
            return country.isEmpty() || country.equals(locale2.getCountry());
        }
    }

    /* JADX INFO: compiled from: LocaleListCompat.java */
    static class b {
        static LocaleList a(Locale... localeArr) {
            return new LocaleList(localeArr);
        }

        static LocaleList b() {
            return LocaleList.getAdjustedDefault();
        }

        static LocaleList c() {
            return LocaleList.getDefault();
        }
    }

    private e(f fVar) {
        this.f2272a = fVar;
    }

    public static e a(Locale... localeArr) {
        return f(b.a(localeArr));
    }

    public static e b(String str) {
        if (str == null || str.isEmpty()) {
            return c();
        }
        String[] strArrSplit = str.split(",", -1);
        int length = strArrSplit.length;
        Locale[] localeArr = new Locale[length];
        for (int i10 = 0; i10 < length; i10++) {
            localeArr[i10] = a.a(strArrSplit[i10]);
        }
        return a(localeArr);
    }

    public static e c() {
        return f2271b;
    }

    public static e f(LocaleList localeList) {
        return new e(new g(localeList));
    }

    public boolean d() {
        return this.f2272a.isEmpty();
    }

    public String e() {
        return this.f2272a.a();
    }

    public boolean equals(Object obj) {
        return (obj instanceof e) && this.f2272a.equals(((e) obj).f2272a);
    }

    public int hashCode() {
        return this.f2272a.hashCode();
    }

    public String toString() {
        return this.f2272a.toString();
    }
}
