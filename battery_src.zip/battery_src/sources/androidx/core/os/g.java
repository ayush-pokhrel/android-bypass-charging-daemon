package androidx.core.os;

import android.os.LocaleList;

/* JADX INFO: compiled from: LocaleListPlatformWrapper.java */
/* JADX INFO: loaded from: classes.dex */
final class g implements f {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final LocaleList f2274a;

    g(Object obj) {
        this.f2274a = (LocaleList) obj;
    }

    @Override // androidx.core.os.f
    public String a() {
        return this.f2274a.toLanguageTags();
    }

    @Override // androidx.core.os.f
    public Object b() {
        return this.f2274a;
    }

    public boolean equals(Object obj) {
        return this.f2274a.equals(((f) obj).b());
    }

    public int hashCode() {
        return this.f2274a.hashCode();
    }

    @Override // androidx.core.os.f
    public boolean isEmpty() {
        return this.f2274a.isEmpty();
    }

    public String toString() {
        return this.f2274a.toString();
    }
}
