package androidx.core.os;

import android.os.CancellationSignal;

/* JADX INFO: compiled from: CancellationSignal.java */
/* JADX INFO: loaded from: classes.dex */
@Deprecated
public final class d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private boolean f2267a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private a f2268b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private Object f2269c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private boolean f2270d;

    /* JADX INFO: compiled from: CancellationSignal.java */
    public interface a {
        void a();
    }

    private void d() {
        while (this.f2270d) {
            try {
                wait();
            } catch (InterruptedException unused) {
            }
        }
    }

    public void a() {
        synchronized (this) {
            try {
                if (this.f2267a) {
                    return;
                }
                this.f2267a = true;
                this.f2270d = true;
                a aVar = this.f2268b;
                Object obj = this.f2269c;
                if (aVar != null) {
                    try {
                        aVar.a();
                    } catch (Throwable th) {
                        synchronized (this) {
                            this.f2270d = false;
                            notifyAll();
                            throw th;
                        }
                    }
                }
                if (obj != null) {
                    ((CancellationSignal) obj).cancel();
                }
                synchronized (this) {
                    this.f2270d = false;
                    notifyAll();
                }
            } catch (Throwable th2) {
                throw th2;
            }
        }
    }

    public boolean b() {
        boolean z10;
        synchronized (this) {
            z10 = this.f2267a;
        }
        return z10;
    }

    public void c(a aVar) {
        synchronized (this) {
            try {
                d();
                if (this.f2268b == aVar) {
                    return;
                }
                this.f2268b = aVar;
                if (this.f2267a && aVar != null) {
                    aVar.a();
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }
}
