package androidx.core.os;

/* JADX INFO: compiled from: LocaleListInterface.java */
/* JADX INFO: loaded from: classes.dex */
interface f {
    String a();

    Object b();

    boolean isEmpty();
}
