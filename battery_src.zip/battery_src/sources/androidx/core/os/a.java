package androidx.core.os;

import android.os.ext.SdkExtensions;

/* JADX INFO: compiled from: BuildCompat.kt */
/* JADX INFO: loaded from: classes.dex */
public final class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final a f2260a = new a();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final int f2261b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final int f2262c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final int f2263d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final int f2264e;

    /* JADX INFO: renamed from: androidx.core.os.a$a, reason: collision with other inner class name */
    /* JADX INFO: compiled from: BuildCompat.kt */
    private static final class C0014a {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public static final C0014a f2265a = new C0014a();

        private C0014a() {
        }

        public final int a(int i10) {
            return SdkExtensions.getExtensionVersion(i10);
        }
    }

    static {
        C0014a c0014a = C0014a.f2265a;
        f2261b = c0014a.a(30);
        f2262c = c0014a.a(31);
        f2263d = c0014a.a(33);
        f2264e = c0014a.a(1000000);
    }

    private a() {
    }

    public static final boolean a() {
        return true;
    }
}
