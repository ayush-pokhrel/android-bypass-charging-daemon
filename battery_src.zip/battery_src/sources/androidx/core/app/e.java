package androidx.core.app;

import android.content.res.Configuration;

/* JADX INFO: compiled from: MultiWindowModeChangedInfo.kt */
/* JADX INFO: loaded from: classes.dex */
public final class e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final boolean f2169a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private Configuration f2170b;

    public e(boolean z10) {
        this.f2169a = z10;
    }

    /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
    public e(boolean z10, Configuration newConfig) {
        this(z10);
        kotlin.jvm.internal.h.e(newConfig, "newConfig");
        this.f2170b = newConfig;
    }
}
