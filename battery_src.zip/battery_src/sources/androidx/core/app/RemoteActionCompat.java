package androidx.core.app;

import android.app.PendingIntent;
import androidx.core.graphics.drawable.IconCompat;

/* JADX INFO: loaded from: classes.dex */
public final class RemoteActionCompat implements u0.a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public IconCompat f2163a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public CharSequence f2164b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public CharSequence f2165c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public PendingIntent f2166d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public boolean f2167e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public boolean f2168f;
}
