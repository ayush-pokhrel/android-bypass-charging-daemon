package androidx.core.app;

import android.app.PendingIntent;
import androidx.core.graphics.drawable.IconCompat;

/* JADX INFO: loaded from: classes.dex */
public class RemoteActionCompatParcelizer {
    public static RemoteActionCompat read(androidx.versionedparcelable.a aVar) {
        RemoteActionCompat remoteActionCompat = new RemoteActionCompat();
        remoteActionCompat.f2163a = (IconCompat) aVar.v(remoteActionCompat.f2163a, 1);
        remoteActionCompat.f2164b = aVar.l(remoteActionCompat.f2164b, 2);
        remoteActionCompat.f2165c = aVar.l(remoteActionCompat.f2165c, 3);
        remoteActionCompat.f2166d = (PendingIntent) aVar.r(remoteActionCompat.f2166d, 4);
        remoteActionCompat.f2167e = aVar.h(remoteActionCompat.f2167e, 5);
        remoteActionCompat.f2168f = aVar.h(remoteActionCompat.f2168f, 6);
        return remoteActionCompat;
    }

    public static void write(RemoteActionCompat remoteActionCompat, androidx.versionedparcelable.a aVar) {
        aVar.x(false, false);
        aVar.M(remoteActionCompat.f2163a, 1);
        aVar.D(remoteActionCompat.f2164b, 2);
        aVar.D(remoteActionCompat.f2165c, 3);
        aVar.H(remoteActionCompat.f2166d, 4);
        aVar.z(remoteActionCompat.f2167e, 5);
        aVar.z(remoteActionCompat.f2168f, 6);
    }
}
