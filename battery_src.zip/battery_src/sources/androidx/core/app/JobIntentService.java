package androidx.core.app;

import android.app.Service;
import android.app.job.JobParameters;
import android.app.job.JobServiceEngine;
import android.app.job.JobWorkItem;
import android.content.ComponentName;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.IBinder;
import java.util.ArrayList;
import java.util.HashMap;

/* JADX INFO: loaded from: classes.dex */
@Deprecated
public abstract class JobIntentService extends Service {

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    static final Object f2145k = new Object();

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    static final HashMap<ComponentName, f> f2146l = new HashMap<>();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    b f2147a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    f f2148b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    a f2149c;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    boolean f2150g = false;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    boolean f2151h = false;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    boolean f2152i = false;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    final ArrayList<c> f2153j = null;

    final class a extends AsyncTask<Void, Void, Void> {
        a() {
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public Void doInBackground(Void... voidArr) {
            while (true) {
                d dVarA = JobIntentService.this.a();
                if (dVarA == null) {
                    return null;
                }
                JobIntentService.this.d(dVarA.getIntent());
                dVarA.a();
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
        public void onCancelled(Void r10) {
            JobIntentService.this.f();
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        /* JADX INFO: renamed from: c, reason: merged with bridge method [inline-methods] */
        public void onPostExecute(Void r10) {
            JobIntentService.this.f();
        }
    }

    interface b {
        d a();

        IBinder b();
    }

    final class c implements d {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        final Intent f2155a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        final int f2156b;

        c(Intent intent, int i10) {
            this.f2155a = intent;
            this.f2156b = i10;
        }

        @Override // androidx.core.app.JobIntentService.d
        public void a() {
            JobIntentService.this.stopSelf(this.f2156b);
        }

        @Override // androidx.core.app.JobIntentService.d
        public Intent getIntent() {
            return this.f2155a;
        }
    }

    interface d {
        void a();

        Intent getIntent();
    }

    static final class e extends JobServiceEngine implements b {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        final JobIntentService f2158a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        final Object f2159b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        JobParameters f2160c;

        final class a implements d {

            /* JADX INFO: renamed from: a, reason: collision with root package name */
            final JobWorkItem f2161a;

            a(JobWorkItem jobWorkItem) {
                this.f2161a = jobWorkItem;
            }

            @Override // androidx.core.app.JobIntentService.d
            public void a() {
                synchronized (e.this.f2159b) {
                    try {
                        JobParameters jobParameters = e.this.f2160c;
                        if (jobParameters != null) {
                            jobParameters.completeWork(this.f2161a);
                        }
                    } catch (Throwable th) {
                        throw th;
                    }
                }
            }

            @Override // androidx.core.app.JobIntentService.d
            public Intent getIntent() {
                return this.f2161a.getIntent();
            }
        }

        e(JobIntentService jobIntentService) {
            super(jobIntentService);
            this.f2159b = new Object();
            this.f2158a = jobIntentService;
        }

        @Override // androidx.core.app.JobIntentService.b
        public d a() {
            synchronized (this.f2159b) {
                try {
                    JobParameters jobParameters = this.f2160c;
                    if (jobParameters == null) {
                        return null;
                    }
                    JobWorkItem jobWorkItemDequeueWork = jobParameters.dequeueWork();
                    if (jobWorkItemDequeueWork == null) {
                        return null;
                    }
                    jobWorkItemDequeueWork.getIntent().setExtrasClassLoader(this.f2158a.getClassLoader());
                    return new a(jobWorkItemDequeueWork);
                } catch (Throwable th) {
                    throw th;
                }
            }
        }

        @Override // androidx.core.app.JobIntentService.b
        public IBinder b() {
            return getBinder();
        }

        @Override // android.app.job.JobServiceEngine
        public boolean onStartJob(JobParameters jobParameters) {
            this.f2160c = jobParameters;
            this.f2158a.c(false);
            return true;
        }

        @Override // android.app.job.JobServiceEngine
        public boolean onStopJob(JobParameters jobParameters) {
            boolean zB = this.f2158a.b();
            synchronized (this.f2159b) {
                this.f2160c = null;
            }
            return zB;
        }
    }

    static abstract class f {
        public abstract void a();

        public abstract void b();

        public abstract void c();
    }

    d a() {
        b bVar = this.f2147a;
        if (bVar != null) {
            return bVar.a();
        }
        synchronized (this.f2153j) {
            try {
                if (this.f2153j.size() <= 0) {
                    return null;
                }
                return this.f2153j.remove(0);
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    boolean b() {
        a aVar = this.f2149c;
        if (aVar != null) {
            aVar.cancel(this.f2150g);
        }
        this.f2151h = true;
        return e();
    }

    void c(boolean z10) {
        if (this.f2149c == null) {
            this.f2149c = new a();
            this.f2149c.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, new Void[0]);
        }
    }

    protected abstract void d(Intent intent);

    public boolean e() {
        return true;
    }

    void f() {
        ArrayList<c> arrayList = this.f2153j;
        if (arrayList != null) {
            synchronized (arrayList) {
                try {
                    this.f2149c = null;
                    ArrayList<c> arrayList2 = this.f2153j;
                    if (arrayList2 != null && arrayList2.size() > 0) {
                        c(false);
                    } else if (!this.f2152i) {
                        this.f2148b.a();
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
        }
    }

    @Override // android.app.Service
    public IBinder onBind(Intent intent) {
        b bVar = this.f2147a;
        if (bVar != null) {
            return bVar.b();
        }
        return null;
    }

    @Override // android.app.Service
    public void onCreate() {
        super.onCreate();
        this.f2147a = new e(this);
    }

    @Override // android.app.Service
    public void onDestroy() {
        super.onDestroy();
        ArrayList<c> arrayList = this.f2153j;
        if (arrayList != null) {
            synchronized (arrayList) {
                this.f2152i = true;
                this.f2148b.a();
            }
        }
    }

    @Override // android.app.Service
    public int onStartCommand(Intent intent, int i10, int i11) {
        if (this.f2153j == null) {
            return 2;
        }
        this.f2148b.c();
        synchronized (this.f2153j) {
            ArrayList<c> arrayList = this.f2153j;
            if (intent == null) {
                intent = new Intent();
            }
            arrayList.add(new c(intent, i11));
            c(true);
        }
        return 3;
    }
}
