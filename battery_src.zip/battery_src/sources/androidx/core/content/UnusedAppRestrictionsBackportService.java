package androidx.core.content;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.os.RemoteException;

/* JADX INFO: loaded from: classes.dex */
public abstract class UnusedAppRestrictionsBackportService extends Service {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private w.b.a f2177a = new a();

    class a extends w.b.a {
        a() {
        }

        @Override // w.b
        public void x(w.a aVar) throws RemoteException {
            if (aVar == null) {
                return;
            }
            UnusedAppRestrictionsBackportService.this.a(new c(aVar));
        }
    }

    protected abstract void a(c cVar);

    @Override // android.app.Service
    public IBinder onBind(Intent intent) {
        return this.f2177a;
    }
}
