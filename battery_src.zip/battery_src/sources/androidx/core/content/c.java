package androidx.core.content;

/* JADX INFO: compiled from: UnusedAppRestrictionsBackportCallback.java */
/* JADX INFO: loaded from: classes.dex */
public class c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private w.a f2180a;

    public c(w.a aVar) {
        this.f2180a = aVar;
    }
}
