package androidx.core.content.res;

import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.LinearGradient;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.graphics.SweepGradient;
import android.util.AttributeSet;
import androidx.core.R$styleable;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

/* JADX INFO: compiled from: GradientColorInflaterCompat.java */
/* JADX INFO: loaded from: classes.dex */
final class f {
    private static a a(a aVar, int i10, int i11, boolean z10, int i12) {
        if (aVar != null) {
            return aVar;
        }
        return z10 ? new a(i10, i12, i11) : new a(i10, i11);
    }

    static Shader b(Resources resources, XmlPullParser xmlPullParser, AttributeSet attributeSet, Resources.Theme theme) throws XmlPullParserException, IOException {
        String name = xmlPullParser.getName();
        if (!name.equals("gradient")) {
            throw new XmlPullParserException(xmlPullParser.getPositionDescription() + ": invalid gradient color tag " + name);
        }
        TypedArray typedArrayS = k.s(resources, theme, attributeSet, R$styleable.GradientColor);
        float fJ = k.j(typedArrayS, xmlPullParser, "startX", R$styleable.GradientColor_android_startX, 0.0f);
        float fJ2 = k.j(typedArrayS, xmlPullParser, "startY", R$styleable.GradientColor_android_startY, 0.0f);
        float fJ3 = k.j(typedArrayS, xmlPullParser, "endX", R$styleable.GradientColor_android_endX, 0.0f);
        float fJ4 = k.j(typedArrayS, xmlPullParser, "endY", R$styleable.GradientColor_android_endY, 0.0f);
        float fJ5 = k.j(typedArrayS, xmlPullParser, "centerX", R$styleable.GradientColor_android_centerX, 0.0f);
        float fJ6 = k.j(typedArrayS, xmlPullParser, "centerY", R$styleable.GradientColor_android_centerY, 0.0f);
        int iK = k.k(typedArrayS, xmlPullParser, "type", R$styleable.GradientColor_android_type, 0);
        int iF = k.f(typedArrayS, xmlPullParser, "startColor", R$styleable.GradientColor_android_startColor, 0);
        boolean zR = k.r(xmlPullParser, "centerColor");
        int iF2 = k.f(typedArrayS, xmlPullParser, "centerColor", R$styleable.GradientColor_android_centerColor, 0);
        int iF3 = k.f(typedArrayS, xmlPullParser, "endColor", R$styleable.GradientColor_android_endColor, 0);
        int iK2 = k.k(typedArrayS, xmlPullParser, "tileMode", R$styleable.GradientColor_android_tileMode, 0);
        float fJ7 = k.j(typedArrayS, xmlPullParser, "gradientRadius", R$styleable.GradientColor_android_gradientRadius, 0.0f);
        typedArrayS.recycle();
        a aVarA = a(c(resources, xmlPullParser, attributeSet, theme), iF, iF3, zR, iF2);
        if (iK != 1) {
            return iK != 2 ? new LinearGradient(fJ, fJ2, fJ3, fJ4, aVarA.f2209a, aVarA.f2210b, d(iK2)) : new SweepGradient(fJ5, fJ6, aVarA.f2209a, aVarA.f2210b);
        }
        if (fJ7 > 0.0f) {
            return new RadialGradient(fJ5, fJ6, fJ7, aVarA.f2209a, aVarA.f2210b, d(iK2));
        }
        throw new XmlPullParserException("<gradient> tag requires 'gradientRadius' attribute with radial type");
    }

    private static a c(Resources resources, XmlPullParser xmlPullParser, AttributeSet attributeSet, Resources.Theme theme) throws XmlPullParserException, IOException {
        int depth;
        int depth2 = xmlPullParser.getDepth() + 1;
        ArrayList arrayList = new ArrayList(20);
        ArrayList arrayList2 = new ArrayList(20);
        while (true) {
            int next = xmlPullParser.next();
            if (next == 1 || ((depth = xmlPullParser.getDepth()) < depth2 && next == 3)) {
                break;
            }
            if (next == 2 && depth <= depth2 && xmlPullParser.getName().equals("item")) {
                TypedArray typedArrayS = k.s(resources, theme, attributeSet, R$styleable.GradientColorItem);
                int i10 = R$styleable.GradientColorItem_android_color;
                boolean zHasValue = typedArrayS.hasValue(i10);
                int i11 = R$styleable.GradientColorItem_android_offset;
                boolean zHasValue2 = typedArrayS.hasValue(i11);
                if (!zHasValue || !zHasValue2) {
                    throw new XmlPullParserException(xmlPullParser.getPositionDescription() + ": <item> tag requires a 'color' attribute and a 'offset' attribute!");
                }
                int color = typedArrayS.getColor(i10, 0);
                float f10 = typedArrayS.getFloat(i11, 0.0f);
                typedArrayS.recycle();
                arrayList2.add(Integer.valueOf(color));
                arrayList.add(Float.valueOf(f10));
            }
        }
        if (arrayList2.size() > 0) {
            return new a(arrayList2, arrayList);
        }
        return null;
    }

    private static Shader.TileMode d(int i10) {
        if (i10 != 1) {
            return i10 != 2 ? Shader.TileMode.CLAMP : Shader.TileMode.MIRROR;
        }
        return Shader.TileMode.REPEAT;
    }

    /* JADX INFO: compiled from: GradientColorInflaterCompat.java */
    static final class a {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        final int[] f2209a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        final float[] f2210b;

        a(List<Integer> list, List<Float> list2) {
            int size = list.size();
            this.f2209a = new int[size];
            this.f2210b = new float[size];
            for (int i10 = 0; i10 < size; i10++) {
                this.f2209a[i10] = list.get(i10).intValue();
                this.f2210b[i10] = list2.get(i10).floatValue();
            }
        }

        a(int i10, int i11) {
            this.f2209a = new int[]{i10, i11};
            this.f2210b = new float[]{0.0f, 1.0f};
        }

        a(int i10, int i11, int i12) {
            this.f2209a = new int[]{i10, i11, i12};
            this.f2210b = new float[]{0.0f, 0.5f, 1.0f};
        }
    }
}
