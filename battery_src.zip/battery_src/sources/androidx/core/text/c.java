package androidx.core.text;

import android.text.PrecomputedText;
import android.text.Spannable;
import android.text.TextDirectionHeuristic;
import android.text.TextPaint;
import android.text.TextUtils;
import android.text.style.MetricAffectingSpan;

/* JADX INFO: compiled from: PrecomputedTextCompat.java */
/* JADX INFO: loaded from: classes.dex */
public class c implements Spannable {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private static final Object f2292c = new Object();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final Spannable f2293a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private final PrecomputedText f2294b;

    /* JADX INFO: compiled from: PrecomputedTextCompat.java */
    public static final class a {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private final TextPaint f2295a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private final TextDirectionHeuristic f2296b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        private final int f2297c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        private final int f2298d;

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        final PrecomputedText.Params f2299e;

        public a(PrecomputedText.Params params) {
            this.f2295a = params.getTextPaint();
            this.f2296b = params.getTextDirection();
            this.f2297c = params.getBreakStrategy();
            this.f2298d = params.getHyphenationFrequency();
            this.f2299e = params;
        }

        public boolean a(a aVar) {
            if (this.f2297c != aVar.b() || this.f2298d != aVar.c() || this.f2295a.getTextSize() != aVar.e().getTextSize() || this.f2295a.getTextScaleX() != aVar.e().getTextScaleX() || this.f2295a.getTextSkewX() != aVar.e().getTextSkewX() || this.f2295a.getLetterSpacing() != aVar.e().getLetterSpacing() || !TextUtils.equals(this.f2295a.getFontFeatureSettings(), aVar.e().getFontFeatureSettings()) || this.f2295a.getFlags() != aVar.e().getFlags() || !this.f2295a.getTextLocales().equals(aVar.e().getTextLocales())) {
                return false;
            }
            if (this.f2295a.getTypeface() == null) {
                return aVar.e().getTypeface() == null;
            }
            return this.f2295a.getTypeface().equals(aVar.e().getTypeface());
        }

        public int b() {
            return this.f2297c;
        }

        public int c() {
            return this.f2298d;
        }

        public TextDirectionHeuristic d() {
            return this.f2296b;
        }

        public TextPaint e() {
            return this.f2295a;
        }

        public boolean equals(Object obj) {
            if (obj == this) {
                return true;
            }
            if (!(obj instanceof a)) {
                return false;
            }
            a aVar = (a) obj;
            return a(aVar) && this.f2296b == aVar.d();
        }

        public int hashCode() {
            return a0.c.b(Float.valueOf(this.f2295a.getTextSize()), Float.valueOf(this.f2295a.getTextScaleX()), Float.valueOf(this.f2295a.getTextSkewX()), Float.valueOf(this.f2295a.getLetterSpacing()), Integer.valueOf(this.f2295a.getFlags()), this.f2295a.getTextLocales(), this.f2295a.getTypeface(), Boolean.valueOf(this.f2295a.isElegantTextHeight()), this.f2296b, Integer.valueOf(this.f2297c), Integer.valueOf(this.f2298d));
        }

        public String toString() {
            StringBuilder sb2 = new StringBuilder("{");
            sb2.append("textSize=" + this.f2295a.getTextSize());
            sb2.append(", textScaleX=" + this.f2295a.getTextScaleX());
            sb2.append(", textSkewX=" + this.f2295a.getTextSkewX());
            sb2.append(", letterSpacing=" + this.f2295a.getLetterSpacing());
            sb2.append(", elegantTextHeight=" + this.f2295a.isElegantTextHeight());
            sb2.append(", textLocale=" + this.f2295a.getTextLocales());
            sb2.append(", typeface=" + this.f2295a.getTypeface());
            sb2.append(", variationSettings=" + this.f2295a.getFontVariationSettings());
            sb2.append(", textDir=" + this.f2296b);
            sb2.append(", breakStrategy=" + this.f2297c);
            sb2.append(", hyphenationFrequency=" + this.f2298d);
            sb2.append("}");
            return sb2.toString();
        }
    }

    public PrecomputedText a() {
        Spannable spannable = this.f2293a;
        if (spannable instanceof PrecomputedText) {
            return (PrecomputedText) spannable;
        }
        return null;
    }

    @Override // java.lang.CharSequence
    public char charAt(int i10) {
        return this.f2293a.charAt(i10);
    }

    @Override // android.text.Spanned
    public int getSpanEnd(Object obj) {
        return this.f2293a.getSpanEnd(obj);
    }

    @Override // android.text.Spanned
    public int getSpanFlags(Object obj) {
        return this.f2293a.getSpanFlags(obj);
    }

    @Override // android.text.Spanned
    public int getSpanStart(Object obj) {
        return this.f2293a.getSpanStart(obj);
    }

    @Override // android.text.Spanned
    public <T> T[] getSpans(int i10, int i11, Class<T> cls) {
        return (T[]) this.f2294b.getSpans(i10, i11, cls);
    }

    @Override // java.lang.CharSequence
    public int length() {
        return this.f2293a.length();
    }

    @Override // android.text.Spanned
    public int nextSpanTransition(int i10, int i11, Class cls) {
        return this.f2293a.nextSpanTransition(i10, i11, cls);
    }

    @Override // android.text.Spannable
    public void removeSpan(Object obj) {
        if (obj instanceof MetricAffectingSpan) {
            throw new IllegalArgumentException("MetricAffectingSpan can not be removed from PrecomputedText.");
        }
        this.f2294b.removeSpan(obj);
    }

    @Override // android.text.Spannable
    public void setSpan(Object obj, int i10, int i11, int i12) {
        if (obj instanceof MetricAffectingSpan) {
            throw new IllegalArgumentException("MetricAffectingSpan can not be set to PrecomputedText.");
        }
        this.f2294b.setSpan(obj, i10, i11, i12);
    }

    @Override // java.lang.CharSequence
    public CharSequence subSequence(int i10, int i11) {
        return this.f2293a.subSequence(i10, i11);
    }

    @Override // java.lang.CharSequence
    public String toString() {
        return this.f2293a.toString();
    }
}
