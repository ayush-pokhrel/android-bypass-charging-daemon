package androidx.core.text;

import java.util.Locale;

/* JADX INFO: compiled from: TextDirectionHeuristicsCompat.java */
/* JADX INFO: loaded from: classes.dex */
public final class e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static final androidx.core.text.d f2300a = new C0016e(null, false);

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static final androidx.core.text.d f2301b = new C0016e(null, true);

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static final androidx.core.text.d f2302c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public static final androidx.core.text.d f2303d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final androidx.core.text.d f2304e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public static final androidx.core.text.d f2305f;

    /* JADX INFO: compiled from: TextDirectionHeuristicsCompat.java */
    private static class a implements c {

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        static final a f2306b = new a(true);

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private final boolean f2307a;

        private a(boolean z10) {
            this.f2307a = z10;
        }

        @Override // androidx.core.text.e.c
        public int a(CharSequence charSequence, int i10, int i11) {
            int i12 = i11 + i10;
            boolean z10 = false;
            while (i10 < i12) {
                int iA = e.a(Character.getDirectionality(charSequence.charAt(i10)));
                if (iA != 0) {
                    if (iA != 1) {
                        continue;
                    } else if (!this.f2307a) {
                        return 1;
                    }
                    i10++;
                    z10 = z10;
                } else if (this.f2307a) {
                    return 0;
                }
                z10 = true;
                i10++;
                z10 = z10;
            }
            if (z10) {
                return this.f2307a ? 1 : 0;
            }
            return 2;
        }
    }

    /* JADX INFO: compiled from: TextDirectionHeuristicsCompat.java */
    private static class b implements c {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        static final b f2308a = new b();

        private b() {
        }

        @Override // androidx.core.text.e.c
        public int a(CharSequence charSequence, int i10, int i11) {
            int i12 = i11 + i10;
            int iB = 2;
            while (i10 < i12 && iB == 2) {
                iB = e.b(Character.getDirectionality(charSequence.charAt(i10)));
                i10++;
            }
            return iB;
        }
    }

    /* JADX INFO: compiled from: TextDirectionHeuristicsCompat.java */
    private interface c {
        int a(CharSequence charSequence, int i10, int i11);
    }

    /* JADX INFO: compiled from: TextDirectionHeuristicsCompat.java */
    private static abstract class d implements androidx.core.text.d {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private final c f2309a;

        d(c cVar) {
            this.f2309a = cVar;
        }

        private boolean c(CharSequence charSequence, int i10, int i11) {
            int iA = this.f2309a.a(charSequence, i10, i11);
            if (iA == 0) {
                return true;
            }
            if (iA != 1) {
                return b();
            }
            return false;
        }

        @Override // androidx.core.text.d
        public boolean a(CharSequence charSequence, int i10, int i11) {
            if (charSequence == null || i10 < 0 || i11 < 0 || charSequence.length() - i11 < i10) {
                throw new IllegalArgumentException();
            }
            return this.f2309a == null ? b() : c(charSequence, i10, i11);
        }

        protected abstract boolean b();
    }

    /* JADX INFO: renamed from: androidx.core.text.e$e, reason: collision with other inner class name */
    /* JADX INFO: compiled from: TextDirectionHeuristicsCompat.java */
    private static class C0016e extends d {

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private final boolean f2310b;

        C0016e(c cVar, boolean z10) {
            super(cVar);
            this.f2310b = z10;
        }

        @Override // androidx.core.text.e.d
        protected boolean b() {
            return this.f2310b;
        }
    }

    /* JADX INFO: compiled from: TextDirectionHeuristicsCompat.java */
    private static class f extends d {

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        static final f f2311b = new f();

        f() {
            super(null);
        }

        @Override // androidx.core.text.e.d
        protected boolean b() {
            return androidx.core.text.f.a(Locale.getDefault()) == 1;
        }
    }

    static {
        b bVar = b.f2308a;
        f2302c = new C0016e(bVar, false);
        f2303d = new C0016e(bVar, true);
        f2304e = new C0016e(a.f2306b, false);
        f2305f = f.f2311b;
    }

    static int a(int i10) {
        if (i10 != 0) {
            return (i10 == 1 || i10 == 2) ? 0 : 2;
        }
        return 1;
    }

    static int b(int i10) {
        if (i10 != 0) {
            if (i10 == 1 || i10 == 2) {
                return 0;
            }
            switch (i10) {
                case 14:
                case 15:
                    break;
                case 16:
                case 17:
                    return 0;
                default:
                    return 2;
            }
        }
        return 1;
    }
}
