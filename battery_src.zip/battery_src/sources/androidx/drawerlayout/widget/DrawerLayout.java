package androidx.drawerlayout.widget;

import android.R;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.view.accessibility.AccessibilityEvent;
import androidx.core.view.h0;
import androidx.core.view.i;
import androidx.core.view.t0;
import androidx.customview.view.AbsSavedState;
import androidx.drawerlayout.R$attr;
import androidx.drawerlayout.R$dimen;
import androidx.drawerlayout.R$styleable;
import java.util.ArrayList;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public class DrawerLayout extends ViewGroup {
    private static final int[] O = {R.attr.colorPrimaryDark};
    static final int[] P = {R.attr.layout_gravity};
    static final boolean Q = true;
    private static final boolean R = true;
    private static boolean S = true;
    private Drawable A;
    private Drawable B;
    private CharSequence C;
    private CharSequence D;
    private Object E;
    private boolean F;
    private Drawable G;
    private Drawable H;
    private Drawable I;
    private Drawable J;
    private final ArrayList<View> K;
    private Rect L;
    private Matrix M;
    private final b0.g N;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final d f2510a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private float f2511b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private int f2512c;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private int f2513g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private float f2514h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private Paint f2515i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private final f0.c f2516j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    private final f0.c f2517k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private final g f2518l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    private final g f2519m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    private int f2520n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    private boolean f2521o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    private boolean f2522p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    private int f2523q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    private int f2524r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    private int f2525s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    private int f2526t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    private boolean f2527u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    private e f2528v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    private List<e> f2529w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    private float f2530x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    private float f2531y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    private Drawable f2532z;

    class a implements b0.g {
        a() {
        }

        @Override // b0.g
        public boolean perform(View view, b0.g.a aVar) {
            if (!DrawerLayout.this.A(view) || DrawerLayout.this.p(view) == 2) {
                return false;
            }
            DrawerLayout.this.d(view);
            return true;
        }
    }

    class b implements View.OnApplyWindowInsetsListener {
        b() {
        }

        @Override // android.view.View.OnApplyWindowInsetsListener
        public WindowInsets onApplyWindowInsets(View view, WindowInsets windowInsets) {
            ((DrawerLayout) view).M(windowInsets, windowInsets.getSystemWindowInsetTop() > 0);
            return windowInsets.consumeSystemWindowInsets();
        }
    }

    class c extends androidx.core.view.a {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private final Rect f2544a = new Rect();

        c() {
        }

        private void a(b0.d dVar, ViewGroup viewGroup) {
            int childCount = viewGroup.getChildCount();
            for (int i10 = 0; i10 < childCount; i10++) {
                View childAt = viewGroup.getChildAt(i10);
                if (DrawerLayout.y(childAt)) {
                    dVar.c(childAt);
                }
            }
        }

        private void b(b0.d dVar, b0.d dVar2) {
            Rect rect = this.f2544a;
            dVar2.l(rect);
            dVar.c0(rect);
            dVar.J0(dVar2.T());
            dVar.u0(dVar2.v());
            dVar.g0(dVar2.o());
            dVar.k0(dVar2.r());
            dVar.m0(dVar2.I());
            dVar.p0(dVar2.K());
            dVar.a0(dVar2.D());
            dVar.C0(dVar2.Q());
            dVar.a(dVar2.i());
        }

        @Override // androidx.core.view.a
        public boolean dispatchPopulateAccessibilityEvent(View view, AccessibilityEvent accessibilityEvent) {
            if (accessibilityEvent.getEventType() != 32) {
                return super.dispatchPopulateAccessibilityEvent(view, accessibilityEvent);
            }
            List<CharSequence> text = accessibilityEvent.getText();
            View viewN = DrawerLayout.this.n();
            if (viewN == null) {
                return true;
            }
            CharSequence charSequenceQ = DrawerLayout.this.q(DrawerLayout.this.r(viewN));
            if (charSequenceQ == null) {
                return true;
            }
            text.add(charSequenceQ);
            return true;
        }

        @Override // androidx.core.view.a
        public void onInitializeAccessibilityEvent(View view, AccessibilityEvent accessibilityEvent) {
            super.onInitializeAccessibilityEvent(view, accessibilityEvent);
            accessibilityEvent.setClassName("androidx.drawerlayout.widget.DrawerLayout");
        }

        @Override // androidx.core.view.a
        public void onInitializeAccessibilityNodeInfo(View view, b0.d dVar) {
            if (DrawerLayout.Q) {
                super.onInitializeAccessibilityNodeInfo(view, dVar);
            } else {
                b0.d dVarW = b0.d.W(dVar);
                super.onInitializeAccessibilityNodeInfo(view, dVarW);
                dVar.E0(view);
                Object objC = h0.C(view);
                if (objC instanceof View) {
                    dVar.w0((View) objC);
                }
                b(dVar, dVarW);
                dVarW.Y();
                a(dVar, (ViewGroup) view);
            }
            dVar.g0("androidx.drawerlayout.widget.DrawerLayout");
            dVar.o0(false);
            dVar.p0(false);
            dVar.Z(b0.d.a.f4668e);
            dVar.Z(b0.d.a.f4669f);
        }

        @Override // androidx.core.view.a
        public boolean onRequestSendAccessibilityEvent(ViewGroup viewGroup, View view, AccessibilityEvent accessibilityEvent) {
            if (DrawerLayout.Q || DrawerLayout.y(view)) {
                return super.onRequestSendAccessibilityEvent(viewGroup, view, accessibilityEvent);
            }
            return false;
        }
    }

    static final class d extends androidx.core.view.a {
        d() {
        }

        @Override // androidx.core.view.a
        public void onInitializeAccessibilityNodeInfo(View view, b0.d dVar) {
            super.onInitializeAccessibilityNodeInfo(view, dVar);
            if (DrawerLayout.y(view)) {
                return;
            }
            dVar.w0(null);
        }
    }

    public interface e {
        void a(int i10);

        void b(View view, float f10);

        void c(View view);

        void d(View view);
    }

    private class g extends f0.c.AbstractC0116c {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private final int f2546a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private f0.c f2547b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        private final Runnable f2548c = new a();

        class a implements Runnable {
            a() {
            }

            @Override // java.lang.Runnable
            public void run() {
                g.this.o();
            }
        }

        g(int i10) {
            this.f2546a = i10;
        }

        private void n() {
            View viewL = DrawerLayout.this.l(this.f2546a == 3 ? 5 : 3);
            if (viewL != null) {
                DrawerLayout.this.d(viewL);
            }
        }

        @Override // f0.c.AbstractC0116c
        public int a(View view, int i10, int i11) {
            if (DrawerLayout.this.c(view, 3)) {
                return Math.max(-view.getWidth(), Math.min(i10, 0));
            }
            int width = DrawerLayout.this.getWidth();
            return Math.max(width - view.getWidth(), Math.min(i10, width));
        }

        @Override // f0.c.AbstractC0116c
        public int b(View view, int i10, int i11) {
            return view.getTop();
        }

        @Override // f0.c.AbstractC0116c
        public int d(View view) {
            if (DrawerLayout.this.B(view)) {
                return view.getWidth();
            }
            return 0;
        }

        @Override // f0.c.AbstractC0116c
        public void f(int i10, int i11) {
            View viewL = (i10 & 1) == 1 ? DrawerLayout.this.l(3) : DrawerLayout.this.l(5);
            if (viewL == null || DrawerLayout.this.p(viewL) != 0) {
                return;
            }
            this.f2547b.b(viewL, i11);
        }

        @Override // f0.c.AbstractC0116c
        public boolean g(int i10) {
            return false;
        }

        @Override // f0.c.AbstractC0116c
        public void h(int i10, int i11) {
            DrawerLayout.this.postDelayed(this.f2548c, 160L);
        }

        @Override // f0.c.AbstractC0116c
        public void i(View view, int i10) {
            ((LayoutParams) view.getLayoutParams()).f2535c = false;
            n();
        }

        @Override // f0.c.AbstractC0116c
        public void j(int i10) {
            DrawerLayout.this.R(i10, this.f2547b.v());
        }

        @Override // f0.c.AbstractC0116c
        public void k(View view, int i10, int i11, int i12, int i13) {
            int width = view.getWidth();
            float width2 = (DrawerLayout.this.c(view, 3) ? i10 + width : DrawerLayout.this.getWidth() - i10) / width;
            DrawerLayout.this.O(view, width2);
            view.setVisibility(width2 == 0.0f ? 4 : 0);
            DrawerLayout.this.invalidate();
        }

        @Override // f0.c.AbstractC0116c
        public void l(View view, float f10, float f11) {
            int i10;
            float fS = DrawerLayout.this.s(view);
            int width = view.getWidth();
            if (DrawerLayout.this.c(view, 3)) {
                i10 = (f10 > 0.0f || (f10 == 0.0f && fS > 0.5f)) ? 0 : -width;
            } else {
                int width2 = DrawerLayout.this.getWidth();
                if (f10 < 0.0f || (f10 == 0.0f && fS > 0.5f)) {
                    width2 -= width;
                }
                i10 = width2;
            }
            this.f2547b.O(i10, view.getTop());
            DrawerLayout.this.invalidate();
        }

        @Override // f0.c.AbstractC0116c
        public boolean m(View view, int i10) {
            return DrawerLayout.this.B(view) && DrawerLayout.this.c(view, this.f2546a) && DrawerLayout.this.p(view) == 0;
        }

        void o() {
            View viewL;
            int width;
            int iX = this.f2547b.x();
            boolean z10 = this.f2546a == 3;
            if (z10) {
                viewL = DrawerLayout.this.l(3);
                width = (viewL != null ? -viewL.getWidth() : 0) + iX;
            } else {
                viewL = DrawerLayout.this.l(5);
                width = DrawerLayout.this.getWidth() - iX;
            }
            if (viewL != null) {
                if (((!z10 || viewL.getLeft() >= width) && (z10 || viewL.getLeft() <= width)) || DrawerLayout.this.p(viewL) != 0) {
                    return;
                }
                LayoutParams layoutParams = (LayoutParams) viewL.getLayoutParams();
                this.f2547b.Q(viewL, width, viewL.getTop());
                layoutParams.f2535c = true;
                DrawerLayout.this.invalidate();
                n();
                DrawerLayout.this.b();
            }
        }

        public void p() {
            DrawerLayout.this.removeCallbacks(this.f2548c);
        }

        public void q(f0.c cVar) {
            this.f2547b = cVar;
        }
    }

    public DrawerLayout(Context context) {
        this(context, null);
    }

    private boolean D(float f10, float f11, View view) {
        if (this.L == null) {
            this.L = new Rect();
        }
        view.getHitRect(this.L);
        return this.L.contains((int) f10, (int) f11);
    }

    private void E(Drawable drawable, int i10) {
        if (drawable == null || !androidx.core.graphics.drawable.a.h(drawable)) {
            return;
        }
        androidx.core.graphics.drawable.a.m(drawable, i10);
    }

    private Drawable J() {
        int iW = h0.w(this);
        if (iW == 0) {
            Drawable drawable = this.G;
            if (drawable != null) {
                E(drawable, iW);
                return this.G;
            }
        } else {
            Drawable drawable2 = this.H;
            if (drawable2 != null) {
                E(drawable2, iW);
                return this.H;
            }
        }
        return this.I;
    }

    private Drawable K() {
        int iW = h0.w(this);
        if (iW == 0) {
            Drawable drawable = this.H;
            if (drawable != null) {
                E(drawable, iW);
                return this.H;
            }
        } else {
            Drawable drawable2 = this.G;
            if (drawable2 != null) {
                E(drawable2, iW);
                return this.G;
            }
        }
        return this.J;
    }

    private void L() {
        if (R) {
            return;
        }
        this.A = J();
        this.B = K();
    }

    private void P(View view) {
        b0.d.a aVar = b0.d.a.f4688y;
        h0.e0(view, aVar.b());
        if (!A(view) || p(view) == 2) {
            return;
        }
        h0.g0(view, aVar, null, this.N);
    }

    private void Q(View view, boolean z10) {
        int childCount = getChildCount();
        for (int i10 = 0; i10 < childCount; i10++) {
            View childAt = getChildAt(i10);
            if ((z10 || B(childAt)) && !(z10 && childAt == view)) {
                h0.w0(childAt, 4);
            } else {
                h0.w0(childAt, 1);
            }
        }
    }

    private boolean k(MotionEvent motionEvent, View view) {
        if (!view.getMatrix().isIdentity()) {
            MotionEvent motionEventT = t(motionEvent, view);
            boolean zDispatchGenericMotionEvent = view.dispatchGenericMotionEvent(motionEventT);
            motionEventT.recycle();
            return zDispatchGenericMotionEvent;
        }
        float scrollX = getScrollX() - view.getLeft();
        float scrollY = getScrollY() - view.getTop();
        motionEvent.offsetLocation(scrollX, scrollY);
        boolean zDispatchGenericMotionEvent2 = view.dispatchGenericMotionEvent(motionEvent);
        motionEvent.offsetLocation(-scrollX, -scrollY);
        return zDispatchGenericMotionEvent2;
    }

    private MotionEvent t(MotionEvent motionEvent, View view) {
        float scrollX = getScrollX() - view.getLeft();
        float scrollY = getScrollY() - view.getTop();
        MotionEvent motionEventObtain = MotionEvent.obtain(motionEvent);
        motionEventObtain.offsetLocation(scrollX, scrollY);
        Matrix matrix = view.getMatrix();
        if (!matrix.isIdentity()) {
            if (this.M == null) {
                this.M = new Matrix();
            }
            matrix.invert(this.M);
            motionEventObtain.transform(this.M);
        }
        return motionEventObtain;
    }

    static String u(int i10) {
        if ((i10 & 3) == 3) {
            return "LEFT";
        }
        return (i10 & 5) == 5 ? "RIGHT" : Integer.toHexString(i10);
    }

    private static boolean v(View view) {
        Drawable background = view.getBackground();
        return background != null && background.getOpacity() == -1;
    }

    private boolean w() {
        int childCount = getChildCount();
        for (int i10 = 0; i10 < childCount; i10++) {
            if (((LayoutParams) getChildAt(i10).getLayoutParams()).f2535c) {
                return true;
            }
        }
        return false;
    }

    private boolean x() {
        return n() != null;
    }

    static boolean y(View view) {
        return (h0.u(view) == 4 || h0.u(view) == 2) ? false : true;
    }

    public boolean A(View view) {
        if (B(view)) {
            return (((LayoutParams) view.getLayoutParams()).f2536d & 1) == 1;
        }
        throw new IllegalArgumentException("View " + view + " is not a drawer");
    }

    boolean B(View view) {
        int iB = i.b(((LayoutParams) view.getLayoutParams()).f2533a, h0.w(view));
        return ((iB & 3) == 0 && (iB & 5) == 0) ? false : true;
    }

    public boolean C(View view) {
        if (B(view)) {
            return ((LayoutParams) view.getLayoutParams()).f2534b > 0.0f;
        }
        throw new IllegalArgumentException("View " + view + " is not a drawer");
    }

    void F(View view, float f10) {
        float fS = s(view);
        float width = view.getWidth();
        int i10 = ((int) (width * f10)) - ((int) (fS * width));
        if (!c(view, 3)) {
            i10 = -i10;
        }
        view.offsetLeftAndRight(i10);
        O(view, f10);
    }

    public void G(View view) {
        H(view, true);
    }

    public void H(View view, boolean z10) {
        if (!B(view)) {
            throw new IllegalArgumentException("View " + view + " is not a sliding drawer");
        }
        LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
        if (this.f2522p) {
            layoutParams.f2534b = 1.0f;
            layoutParams.f2536d = 1;
            Q(view, true);
            P(view);
        } else if (z10) {
            layoutParams.f2536d |= 2;
            if (c(view, 3)) {
                this.f2516j.Q(view, 0, view.getTop());
            } else {
                this.f2517k.Q(view, getWidth() - view.getWidth(), view.getTop());
            }
        } else {
            F(view, 1.0f);
            R(0, view);
            view.setVisibility(0);
        }
        invalidate();
    }

    public void I(e eVar) {
        List<e> list;
        if (eVar == null || (list = this.f2529w) == null) {
            return;
        }
        list.remove(eVar);
    }

    public void M(Object obj, boolean z10) {
        this.E = obj;
        this.F = z10;
        setWillNotDraw(!z10 && getBackground() == null);
        requestLayout();
    }

    public void N(int i10, int i11) {
        View viewL;
        int iB = i.b(i11, h0.w(this));
        if (i11 == 3) {
            this.f2523q = i10;
        } else if (i11 == 5) {
            this.f2524r = i10;
        } else if (i11 == 8388611) {
            this.f2525s = i10;
        } else if (i11 == 8388613) {
            this.f2526t = i10;
        }
        if (i10 != 0) {
            (iB == 3 ? this.f2516j : this.f2517k).a();
        }
        if (i10 != 1) {
            if (i10 == 2 && (viewL = l(iB)) != null) {
                G(viewL);
                return;
            }
            return;
        }
        View viewL2 = l(iB);
        if (viewL2 != null) {
            d(viewL2);
        }
    }

    void O(View view, float f10) {
        LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
        if (f10 == layoutParams.f2534b) {
            return;
        }
        layoutParams.f2534b = f10;
        j(view, f10);
    }

    void R(int i10, View view) {
        int i11;
        int iA = this.f2516j.A();
        int iA2 = this.f2517k.A();
        if (iA == 1 || iA2 == 1) {
            i11 = 1;
        } else {
            i11 = 2;
            if (iA != 2 && iA2 != 2) {
                i11 = 0;
            }
        }
        if (view != null && i10 == 0) {
            float f10 = ((LayoutParams) view.getLayoutParams()).f2534b;
            if (f10 == 0.0f) {
                h(view);
            } else if (f10 == 1.0f) {
                i(view);
            }
        }
        if (i11 != this.f2520n) {
            this.f2520n = i11;
            List<e> list = this.f2529w;
            if (list != null) {
                for (int size = list.size() - 1; size >= 0; size--) {
                    this.f2529w.get(size).a(i11);
                }
            }
        }
    }

    public void a(e eVar) {
        if (eVar == null) {
            return;
        }
        if (this.f2529w == null) {
            this.f2529w = new ArrayList();
        }
        this.f2529w.add(eVar);
    }

    @Override // android.view.ViewGroup, android.view.View
    public void addFocusables(ArrayList<View> arrayList, int i10, int i11) {
        if (getDescendantFocusability() == 393216) {
            return;
        }
        int childCount = getChildCount();
        boolean z10 = false;
        for (int i12 = 0; i12 < childCount; i12++) {
            View childAt = getChildAt(i12);
            if (!B(childAt)) {
                this.K.add(childAt);
            } else if (A(childAt)) {
                childAt.addFocusables(arrayList, i10, i11);
                z10 = true;
            }
        }
        if (!z10) {
            int size = this.K.size();
            for (int i13 = 0; i13 < size; i13++) {
                View view = this.K.get(i13);
                if (view.getVisibility() == 0) {
                    view.addFocusables(arrayList, i10, i11);
                }
            }
        }
        this.K.clear();
    }

    @Override // android.view.ViewGroup
    public void addView(View view, int i10, ViewGroup.LayoutParams layoutParams) {
        super.addView(view, i10, layoutParams);
        if (m() != null || B(view)) {
            h0.w0(view, 4);
        } else {
            h0.w0(view, 1);
        }
        if (Q) {
            return;
        }
        h0.l0(view, this.f2510a);
    }

    void b() {
        if (this.f2527u) {
            return;
        }
        long jUptimeMillis = SystemClock.uptimeMillis();
        MotionEvent motionEventObtain = MotionEvent.obtain(jUptimeMillis, jUptimeMillis, 3, 0.0f, 0.0f, 0);
        int childCount = getChildCount();
        for (int i10 = 0; i10 < childCount; i10++) {
            getChildAt(i10).dispatchTouchEvent(motionEventObtain);
        }
        motionEventObtain.recycle();
        this.f2527u = true;
    }

    boolean c(View view, int i10) {
        return (r(view) & i10) == i10;
    }

    @Override // android.view.ViewGroup
    protected boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return (layoutParams instanceof LayoutParams) && super.checkLayoutParams(layoutParams);
    }

    @Override // android.view.View
    public void computeScroll() {
        int childCount = getChildCount();
        float fMax = 0.0f;
        for (int i10 = 0; i10 < childCount; i10++) {
            fMax = Math.max(fMax, ((LayoutParams) getChildAt(i10).getLayoutParams()).f2534b);
        }
        this.f2514h = fMax;
        boolean zM = this.f2516j.m(true);
        boolean zM2 = this.f2517k.m(true);
        if (zM || zM2) {
            h0.b0(this);
        }
    }

    public void d(View view) {
        e(view, true);
    }

    @Override // android.view.View
    public boolean dispatchGenericMotionEvent(MotionEvent motionEvent) {
        if ((motionEvent.getSource() & 2) == 0 || motionEvent.getAction() == 10 || this.f2514h <= 0.0f) {
            return super.dispatchGenericMotionEvent(motionEvent);
        }
        int childCount = getChildCount();
        if (childCount == 0) {
            return false;
        }
        float x10 = motionEvent.getX();
        float y10 = motionEvent.getY();
        for (int i10 = childCount - 1; i10 >= 0; i10--) {
            View childAt = getChildAt(i10);
            if (D(x10, y10, childAt) && !z(childAt) && k(motionEvent, childAt)) {
                return true;
            }
        }
        return false;
    }

    @Override // android.view.ViewGroup
    protected boolean drawChild(Canvas canvas, View view, long j10) {
        int height = getHeight();
        boolean z10 = z(view);
        int width = getWidth();
        int iSave = canvas.save();
        int i10 = 0;
        if (z10) {
            int childCount = getChildCount();
            int i11 = 0;
            for (int i12 = 0; i12 < childCount; i12++) {
                View childAt = getChildAt(i12);
                if (childAt != view && childAt.getVisibility() == 0 && v(childAt) && B(childAt) && childAt.getHeight() >= height) {
                    if (c(childAt, 3)) {
                        int right = childAt.getRight();
                        if (right > i11) {
                            i11 = right;
                        }
                    } else {
                        int left = childAt.getLeft();
                        if (left < width) {
                            width = left;
                        }
                    }
                }
            }
            canvas.clipRect(i11, 0, width, getHeight());
            i10 = i11;
        }
        boolean zDrawChild = super.drawChild(canvas, view, j10);
        canvas.restoreToCount(iSave);
        float f10 = this.f2514h;
        if (f10 > 0.0f && z10) {
            int i13 = this.f2513g;
            this.f2515i.setColor((i13 & 16777215) | (((int) ((((-16777216) & i13) >>> 24) * f10)) << 24));
            canvas.drawRect(i10, 0.0f, width, getHeight(), this.f2515i);
        } else if (this.A != null && c(view, 3)) {
            int intrinsicWidth = this.A.getIntrinsicWidth();
            int right2 = view.getRight();
            float fMax = Math.max(0.0f, Math.min(right2 / this.f2516j.x(), 1.0f));
            this.A.setBounds(right2, view.getTop(), intrinsicWidth + right2, view.getBottom());
            this.A.setAlpha((int) (fMax * 255.0f));
            this.A.draw(canvas);
        } else if (this.B != null && c(view, 5)) {
            int intrinsicWidth2 = this.B.getIntrinsicWidth();
            int left2 = view.getLeft();
            float fMax2 = Math.max(0.0f, Math.min((getWidth() - left2) / this.f2517k.x(), 1.0f));
            this.B.setBounds(left2 - intrinsicWidth2, view.getTop(), left2, view.getBottom());
            this.B.setAlpha((int) (fMax2 * 255.0f));
            this.B.draw(canvas);
        }
        return zDrawChild;
    }

    public void e(View view, boolean z10) {
        if (!B(view)) {
            throw new IllegalArgumentException("View " + view + " is not a sliding drawer");
        }
        LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
        if (this.f2522p) {
            layoutParams.f2534b = 0.0f;
            layoutParams.f2536d = 0;
        } else if (z10) {
            layoutParams.f2536d |= 4;
            if (c(view, 3)) {
                this.f2516j.Q(view, -view.getWidth(), view.getTop());
            } else {
                this.f2517k.Q(view, getWidth(), view.getTop());
            }
        } else {
            F(view, 0.0f);
            R(0, view);
            view.setVisibility(4);
        }
        invalidate();
    }

    public void f() {
        g(false);
    }

    void g(boolean z10) {
        int childCount = getChildCount();
        boolean zQ = false;
        for (int i10 = 0; i10 < childCount; i10++) {
            View childAt = getChildAt(i10);
            LayoutParams layoutParams = (LayoutParams) childAt.getLayoutParams();
            if (B(childAt) && (!z10 || layoutParams.f2535c)) {
                zQ |= c(childAt, 3) ? this.f2516j.Q(childAt, -childAt.getWidth(), childAt.getTop()) : this.f2517k.Q(childAt, getWidth(), childAt.getTop());
                layoutParams.f2535c = false;
            }
        }
        this.f2518l.p();
        this.f2519m.p();
        if (zQ) {
            invalidate();
        }
    }

    @Override // android.view.ViewGroup
    protected ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new LayoutParams(-1, -1);
    }

    @Override // android.view.ViewGroup
    protected ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        if (layoutParams instanceof LayoutParams) {
            return new LayoutParams((LayoutParams) layoutParams);
        }
        return layoutParams instanceof ViewGroup.MarginLayoutParams ? new LayoutParams((ViewGroup.MarginLayoutParams) layoutParams) : new LayoutParams(layoutParams);
    }

    public float getDrawerElevation() {
        if (R) {
            return this.f2511b;
        }
        return 0.0f;
    }

    public Drawable getStatusBarBackgroundDrawable() {
        return this.f2532z;
    }

    void h(View view) {
        View rootView;
        LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
        if ((layoutParams.f2536d & 1) == 1) {
            layoutParams.f2536d = 0;
            List<e> list = this.f2529w;
            if (list != null) {
                for (int size = list.size() - 1; size >= 0; size--) {
                    this.f2529w.get(size).d(view);
                }
            }
            Q(view, false);
            P(view);
            if (!hasWindowFocus() || (rootView = getRootView()) == null) {
                return;
            }
            rootView.sendAccessibilityEvent(32);
        }
    }

    void i(View view) {
        LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
        if ((layoutParams.f2536d & 1) == 0) {
            layoutParams.f2536d = 1;
            List<e> list = this.f2529w;
            if (list != null) {
                for (int size = list.size() - 1; size >= 0; size--) {
                    this.f2529w.get(size).c(view);
                }
            }
            Q(view, true);
            P(view);
            if (hasWindowFocus()) {
                sendAccessibilityEvent(32);
            }
        }
    }

    void j(View view, float f10) {
        List<e> list = this.f2529w;
        if (list != null) {
            for (int size = list.size() - 1; size >= 0; size--) {
                this.f2529w.get(size).b(view, f10);
            }
        }
    }

    View l(int i10) {
        int iB = i.b(i10, h0.w(this)) & 7;
        int childCount = getChildCount();
        for (int i11 = 0; i11 < childCount; i11++) {
            View childAt = getChildAt(i11);
            if ((r(childAt) & 7) == iB) {
                return childAt;
            }
        }
        return null;
    }

    View m() {
        int childCount = getChildCount();
        for (int i10 = 0; i10 < childCount; i10++) {
            View childAt = getChildAt(i10);
            if ((((LayoutParams) childAt.getLayoutParams()).f2536d & 1) == 1) {
                return childAt;
            }
        }
        return null;
    }

    View n() {
        int childCount = getChildCount();
        for (int i10 = 0; i10 < childCount; i10++) {
            View childAt = getChildAt(i10);
            if (B(childAt) && C(childAt)) {
                return childAt;
            }
        }
        return null;
    }

    public int o(int i10) {
        int iW = h0.w(this);
        if (i10 == 3) {
            int i11 = this.f2523q;
            if (i11 != 3) {
                return i11;
            }
            int i12 = iW == 0 ? this.f2525s : this.f2526t;
            if (i12 != 3) {
                return i12;
            }
            return 0;
        }
        if (i10 == 5) {
            int i13 = this.f2524r;
            if (i13 != 3) {
                return i13;
            }
            int i14 = iW == 0 ? this.f2526t : this.f2525s;
            if (i14 != 3) {
                return i14;
            }
            return 0;
        }
        if (i10 == 8388611) {
            int i15 = this.f2525s;
            if (i15 != 3) {
                return i15;
            }
            int i16 = iW == 0 ? this.f2523q : this.f2524r;
            if (i16 != 3) {
                return i16;
            }
            return 0;
        }
        if (i10 != 8388613) {
            return 0;
        }
        int i17 = this.f2526t;
        if (i17 != 3) {
            return i17;
        }
        int i18 = iW == 0 ? this.f2524r : this.f2523q;
        if (i18 != 3) {
            return i18;
        }
        return 0;
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.f2522p = true;
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        this.f2522p = true;
    }

    @Override // android.view.View
    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (!this.F || this.f2532z == null) {
            return;
        }
        Object obj = this.E;
        int systemWindowInsetTop = obj != null ? ((WindowInsets) obj).getSystemWindowInsetTop() : 0;
        if (systemWindowInsetTop > 0) {
            this.f2532z.setBounds(0, 0, getWidth(), systemWindowInsetTop);
            this.f2532z.draw(canvas);
        }
    }

    /* JADX WARN: Code duplicated, block: B:12:0x0031  */
    @Override // android.view.ViewGroup
    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        boolean z10;
        View viewT;
        int actionMasked = motionEvent.getActionMasked();
        boolean zP = this.f2516j.P(motionEvent) | this.f2517k.P(motionEvent);
        if (actionMasked != 0) {
            if (actionMasked == 1) {
                g(true);
                this.f2527u = false;
            } else if (actionMasked != 2) {
                if (actionMasked == 3) {
                    g(true);
                    this.f2527u = false;
                }
            } else if (this.f2516j.d(3)) {
                this.f2518l.p();
                this.f2519m.p();
            }
            z10 = false;
        } else {
            float x10 = motionEvent.getX();
            float y10 = motionEvent.getY();
            this.f2530x = x10;
            this.f2531y = y10;
            z10 = this.f2514h > 0.0f && (viewT = this.f2516j.t((int) x10, (int) y10)) != null && z(viewT);
            this.f2527u = false;
        }
        return zP || z10 || w() || this.f2527u;
    }

    @Override // android.view.View, android.view.KeyEvent.Callback
    public boolean onKeyDown(int i10, KeyEvent keyEvent) {
        if (i10 != 4 || !x()) {
            return super.onKeyDown(i10, keyEvent);
        }
        keyEvent.startTracking();
        return true;
    }

    @Override // android.view.View, android.view.KeyEvent.Callback
    public boolean onKeyUp(int i10, KeyEvent keyEvent) {
        if (i10 != 4) {
            return super.onKeyUp(i10, keyEvent);
        }
        View viewN = n();
        if (viewN != null && p(viewN) == 0) {
            f();
        }
        return viewN != null;
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onLayout(boolean z10, int i10, int i11, int i12, int i13) {
        WindowInsets rootWindowInsets;
        float f10;
        int i14;
        boolean z11 = true;
        this.f2521o = true;
        int i15 = i12 - i10;
        int childCount = getChildCount();
        int i16 = 0;
        while (i16 < childCount) {
            View childAt = getChildAt(i16);
            if (childAt.getVisibility() != 8) {
                LayoutParams layoutParams = (LayoutParams) childAt.getLayoutParams();
                if (z(childAt)) {
                    int i17 = ((ViewGroup.MarginLayoutParams) layoutParams).leftMargin;
                    childAt.layout(i17, ((ViewGroup.MarginLayoutParams) layoutParams).topMargin, childAt.getMeasuredWidth() + i17, ((ViewGroup.MarginLayoutParams) layoutParams).topMargin + childAt.getMeasuredHeight());
                } else {
                    int measuredWidth = childAt.getMeasuredWidth();
                    int measuredHeight = childAt.getMeasuredHeight();
                    if (c(childAt, 3)) {
                        float f11 = measuredWidth;
                        i14 = (-measuredWidth) + ((int) (layoutParams.f2534b * f11));
                        f10 = (measuredWidth + i14) / f11;
                    } else {
                        float f12 = measuredWidth;
                        int i18 = i15 - ((int) (layoutParams.f2534b * f12));
                        f10 = (i15 - i18) / f12;
                        i14 = i18;
                    }
                    boolean z12 = f10 != layoutParams.f2534b ? z11 : false;
                    int i19 = layoutParams.f2533a & 112;
                    if (i19 == 16) {
                        int i20 = i13 - i11;
                        int i21 = (i20 - measuredHeight) / 2;
                        int i22 = ((ViewGroup.MarginLayoutParams) layoutParams).topMargin;
                        if (i21 < i22) {
                            i21 = i22;
                        } else {
                            int i23 = i21 + measuredHeight;
                            int i24 = ((ViewGroup.MarginLayoutParams) layoutParams).bottomMargin;
                            if (i23 > i20 - i24) {
                                i21 = (i20 - i24) - measuredHeight;
                            }
                        }
                        childAt.layout(i14, i21, measuredWidth + i14, measuredHeight + i21);
                    } else if (i19 != 80) {
                        int i25 = ((ViewGroup.MarginLayoutParams) layoutParams).topMargin;
                        childAt.layout(i14, i25, measuredWidth + i14, measuredHeight + i25);
                    } else {
                        int i26 = i13 - i11;
                        childAt.layout(i14, (i26 - ((ViewGroup.MarginLayoutParams) layoutParams).bottomMargin) - childAt.getMeasuredHeight(), measuredWidth + i14, i26 - ((ViewGroup.MarginLayoutParams) layoutParams).bottomMargin);
                    }
                    if (z12) {
                        O(childAt, f10);
                    }
                    int i27 = layoutParams.f2534b > 0.0f ? 0 : 4;
                    if (childAt.getVisibility() != i27) {
                        childAt.setVisibility(i27);
                    }
                }
            }
            i16++;
            z11 = true;
        }
        if (S && (rootWindowInsets = getRootWindowInsets()) != null) {
            androidx.core.graphics.b bVarH = t0.v(rootWindowInsets).h();
            f0.c cVar = this.f2516j;
            cVar.L(Math.max(cVar.w(), bVarH.f2236a));
            f0.c cVar2 = this.f2517k;
            cVar2.L(Math.max(cVar2.w(), bVarH.f2238c));
        }
        this.f2521o = false;
        this.f2522p = false;
    }

    @Override // android.view.View
    @SuppressLint({"WrongConstant"})
    protected void onMeasure(int i10, int i11) {
        int mode = View.MeasureSpec.getMode(i10);
        int mode2 = View.MeasureSpec.getMode(i11);
        int size = View.MeasureSpec.getSize(i10);
        int size2 = View.MeasureSpec.getSize(i11);
        if (mode != 1073741824 || mode2 != 1073741824) {
            if (!isInEditMode()) {
                throw new IllegalArgumentException("DrawerLayout must be measured with MeasureSpec.EXACTLY.");
            }
            if (mode == 0) {
                size = 300;
            }
            if (mode2 == 0) {
                size2 = 300;
            }
        }
        setMeasuredDimension(size, size2);
        boolean z10 = this.E != null && h0.t(this);
        int iW = h0.w(this);
        int childCount = getChildCount();
        boolean z11 = false;
        boolean z12 = false;
        for (int i12 = 0; i12 < childCount; i12++) {
            View childAt = getChildAt(i12);
            if (childAt.getVisibility() != 8) {
                LayoutParams layoutParams = (LayoutParams) childAt.getLayoutParams();
                if (z10) {
                    int iB = i.b(layoutParams.f2533a, iW);
                    if (h0.t(childAt)) {
                        WindowInsets windowInsetsReplaceSystemWindowInsets = (WindowInsets) this.E;
                        if (iB == 3) {
                            windowInsetsReplaceSystemWindowInsets = windowInsetsReplaceSystemWindowInsets.replaceSystemWindowInsets(windowInsetsReplaceSystemWindowInsets.getSystemWindowInsetLeft(), windowInsetsReplaceSystemWindowInsets.getSystemWindowInsetTop(), 0, windowInsetsReplaceSystemWindowInsets.getSystemWindowInsetBottom());
                        } else if (iB == 5) {
                            windowInsetsReplaceSystemWindowInsets = windowInsetsReplaceSystemWindowInsets.replaceSystemWindowInsets(0, windowInsetsReplaceSystemWindowInsets.getSystemWindowInsetTop(), windowInsetsReplaceSystemWindowInsets.getSystemWindowInsetRight(), windowInsetsReplaceSystemWindowInsets.getSystemWindowInsetBottom());
                        }
                        childAt.dispatchApplyWindowInsets(windowInsetsReplaceSystemWindowInsets);
                    } else {
                        WindowInsets windowInsetsReplaceSystemWindowInsets2 = (WindowInsets) this.E;
                        if (iB == 3) {
                            windowInsetsReplaceSystemWindowInsets2 = windowInsetsReplaceSystemWindowInsets2.replaceSystemWindowInsets(windowInsetsReplaceSystemWindowInsets2.getSystemWindowInsetLeft(), windowInsetsReplaceSystemWindowInsets2.getSystemWindowInsetTop(), 0, windowInsetsReplaceSystemWindowInsets2.getSystemWindowInsetBottom());
                        } else if (iB == 5) {
                            windowInsetsReplaceSystemWindowInsets2 = windowInsetsReplaceSystemWindowInsets2.replaceSystemWindowInsets(0, windowInsetsReplaceSystemWindowInsets2.getSystemWindowInsetTop(), windowInsetsReplaceSystemWindowInsets2.getSystemWindowInsetRight(), windowInsetsReplaceSystemWindowInsets2.getSystemWindowInsetBottom());
                        }
                        ((ViewGroup.MarginLayoutParams) layoutParams).leftMargin = windowInsetsReplaceSystemWindowInsets2.getSystemWindowInsetLeft();
                        ((ViewGroup.MarginLayoutParams) layoutParams).topMargin = windowInsetsReplaceSystemWindowInsets2.getSystemWindowInsetTop();
                        ((ViewGroup.MarginLayoutParams) layoutParams).rightMargin = windowInsetsReplaceSystemWindowInsets2.getSystemWindowInsetRight();
                        ((ViewGroup.MarginLayoutParams) layoutParams).bottomMargin = windowInsetsReplaceSystemWindowInsets2.getSystemWindowInsetBottom();
                    }
                }
                if (z(childAt)) {
                    childAt.measure(View.MeasureSpec.makeMeasureSpec((size - ((ViewGroup.MarginLayoutParams) layoutParams).leftMargin) - ((ViewGroup.MarginLayoutParams) layoutParams).rightMargin, 1073741824), View.MeasureSpec.makeMeasureSpec((size2 - ((ViewGroup.MarginLayoutParams) layoutParams).topMargin) - ((ViewGroup.MarginLayoutParams) layoutParams).bottomMargin, 1073741824));
                } else {
                    if (!B(childAt)) {
                        throw new IllegalStateException("Child " + childAt + " at index " + i12 + " does not have a valid layout_gravity - must be Gravity.LEFT, Gravity.RIGHT or Gravity.NO_GRAVITY");
                    }
                    if (R) {
                        float fS = h0.s(childAt);
                        float f10 = this.f2511b;
                        if (fS != f10) {
                            h0.t0(childAt, f10);
                        }
                    }
                    int iR = r(childAt) & 7;
                    boolean z13 = iR == 3;
                    if ((z13 && z11) || (!z13 && z12)) {
                        throw new IllegalStateException("Child drawer has absolute gravity " + u(iR) + " but this DrawerLayout already has a drawer view along that edge");
                    }
                    if (z13) {
                        z11 = true;
                    } else {
                        z12 = true;
                    }
                    childAt.measure(ViewGroup.getChildMeasureSpec(i10, this.f2512c + ((ViewGroup.MarginLayoutParams) layoutParams).leftMargin + ((ViewGroup.MarginLayoutParams) layoutParams).rightMargin, ((ViewGroup.MarginLayoutParams) layoutParams).width), ViewGroup.getChildMeasureSpec(i11, ((ViewGroup.MarginLayoutParams) layoutParams).topMargin + ((ViewGroup.MarginLayoutParams) layoutParams).bottomMargin, ((ViewGroup.MarginLayoutParams) layoutParams).height));
                }
            }
        }
    }

    @Override // android.view.View
    protected void onRestoreInstanceState(Parcelable parcelable) {
        View viewL;
        if (!(parcelable instanceof SavedState)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        SavedState savedState = (SavedState) parcelable;
        super.onRestoreInstanceState(savedState.getSuperState());
        int i10 = savedState.f2537a;
        if (i10 != 0 && (viewL = l(i10)) != null) {
            G(viewL);
        }
        int i11 = savedState.f2538b;
        if (i11 != 3) {
            N(i11, 3);
        }
        int i12 = savedState.f2539c;
        if (i12 != 3) {
            N(i12, 5);
        }
        int i13 = savedState.f2540g;
        if (i13 != 3) {
            N(i13, 8388611);
        }
        int i14 = savedState.f2541h;
        if (i14 != 3) {
            N(i14, 8388613);
        }
    }

    @Override // android.view.View
    public void onRtlPropertiesChanged(int i10) {
        L();
    }

    @Override // android.view.View
    protected Parcelable onSaveInstanceState() {
        SavedState savedState = new SavedState(super.onSaveInstanceState());
        int childCount = getChildCount();
        for (int i10 = 0; i10 < childCount; i10++) {
            LayoutParams layoutParams = (LayoutParams) getChildAt(i10).getLayoutParams();
            int i11 = layoutParams.f2536d;
            boolean z10 = i11 == 1;
            boolean z11 = i11 == 2;
            if (z10 || z11) {
                savedState.f2537a = layoutParams.f2533a;
                break;
            }
        }
        savedState.f2538b = this.f2523q;
        savedState.f2539c = this.f2524r;
        savedState.f2540g = this.f2525s;
        savedState.f2541h = this.f2526t;
        return savedState;
    }

    /* JADX WARN: Code duplicated, block: B:19:0x005a  */
    @Override // android.view.View
    public boolean onTouchEvent(MotionEvent motionEvent) {
        boolean z10;
        View viewM;
        this.f2516j.F(motionEvent);
        this.f2517k.F(motionEvent);
        int action = motionEvent.getAction() & 255;
        if (action == 0) {
            float x10 = motionEvent.getX();
            float y10 = motionEvent.getY();
            this.f2530x = x10;
            this.f2531y = y10;
            this.f2527u = false;
        } else if (action == 1) {
            float x11 = motionEvent.getX();
            float y11 = motionEvent.getY();
            View viewT = this.f2516j.t((int) x11, (int) y11);
            if (viewT != null && z(viewT)) {
                float f10 = x11 - this.f2530x;
                float f11 = y11 - this.f2531y;
                int iZ = this.f2516j.z();
                z10 = (f10 * f10) + (f11 * f11) >= ((float) (iZ * iZ)) || (viewM = m()) == null || p(viewM) == 2;
            }
            g(z10);
        } else if (action == 3) {
            g(true);
            this.f2527u = false;
        }
        return true;
    }

    public int p(View view) {
        if (B(view)) {
            return o(((LayoutParams) view.getLayoutParams()).f2533a);
        }
        throw new IllegalArgumentException("View " + view + " is not a drawer");
    }

    public CharSequence q(int i10) {
        int iB = i.b(i10, h0.w(this));
        if (iB == 3) {
            return this.C;
        }
        if (iB == 5) {
            return this.D;
        }
        return null;
    }

    int r(View view) {
        return i.b(((LayoutParams) view.getLayoutParams()).f2533a, h0.w(this));
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void requestDisallowInterceptTouchEvent(boolean z10) {
        super.requestDisallowInterceptTouchEvent(z10);
        if (z10) {
            g(true);
        }
    }

    @Override // android.view.View, android.view.ViewParent
    public void requestLayout() {
        if (this.f2521o) {
            return;
        }
        super.requestLayout();
    }

    float s(View view) {
        return ((LayoutParams) view.getLayoutParams()).f2534b;
    }

    public void setDrawerElevation(float f10) {
        this.f2511b = f10;
        for (int i10 = 0; i10 < getChildCount(); i10++) {
            View childAt = getChildAt(i10);
            if (B(childAt)) {
                h0.t0(childAt, this.f2511b);
            }
        }
    }

    @Deprecated
    public void setDrawerListener(e eVar) {
        e eVar2 = this.f2528v;
        if (eVar2 != null) {
            I(eVar2);
        }
        if (eVar != null) {
            a(eVar);
        }
        this.f2528v = eVar;
    }

    public void setDrawerLockMode(int i10) {
        N(i10, 3);
        N(i10, 5);
    }

    public void setScrimColor(int i10) {
        this.f2513g = i10;
        invalidate();
    }

    public void setStatusBarBackground(Drawable drawable) {
        this.f2532z = drawable;
        invalidate();
    }

    public void setStatusBarBackgroundColor(int i10) {
        this.f2532z = new ColorDrawable(i10);
        invalidate();
    }

    boolean z(View view) {
        return ((LayoutParams) view.getLayoutParams()).f2533a == 0;
    }

    public DrawerLayout(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R$attr.drawerLayoutStyle);
    }

    public DrawerLayout(Context context, AttributeSet attributeSet, int i10) {
        super(context, attributeSet, i10);
        this.f2510a = new d();
        this.f2513g = -1728053248;
        this.f2515i = new Paint();
        this.f2522p = true;
        this.f2523q = 3;
        this.f2524r = 3;
        this.f2525s = 3;
        this.f2526t = 3;
        this.G = null;
        this.H = null;
        this.I = null;
        this.J = null;
        this.N = new a();
        setDescendantFocusability(262144);
        float f10 = getResources().getDisplayMetrics().density;
        this.f2512c = (int) ((64.0f * f10) + 0.5f);
        float f11 = f10 * 400.0f;
        g gVar = new g(3);
        this.f2518l = gVar;
        g gVar2 = new g(5);
        this.f2519m = gVar2;
        f0.c cVarN = f0.c.n(this, 1.0f, gVar);
        this.f2516j = cVarN;
        cVarN.M(1);
        cVarN.N(f11);
        gVar.q(cVarN);
        f0.c cVarN2 = f0.c.n(this, 1.0f, gVar2);
        this.f2517k = cVarN2;
        cVarN2.M(2);
        cVarN2.N(f11);
        gVar2.q(cVarN2);
        setFocusableInTouchMode(true);
        h0.w0(this, 1);
        h0.l0(this, new c());
        setMotionEventSplittingEnabled(false);
        if (h0.t(this)) {
            setOnApplyWindowInsetsListener(new b());
            setSystemUiVisibility(1280);
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(O);
            try {
                this.f2532z = typedArrayObtainStyledAttributes.getDrawable(0);
                typedArrayObtainStyledAttributes.recycle();
            } catch (Throwable th) {
                typedArrayObtainStyledAttributes.recycle();
                throw th;
            }
        }
        TypedArray typedArrayObtainStyledAttributes2 = context.obtainStyledAttributes(attributeSet, R$styleable.DrawerLayout, i10, 0);
        try {
            int i11 = R$styleable.DrawerLayout_elevation;
            if (typedArrayObtainStyledAttributes2.hasValue(i11)) {
                this.f2511b = typedArrayObtainStyledAttributes2.getDimension(i11, 0.0f);
            } else {
                this.f2511b = getResources().getDimension(R$dimen.def_drawer_elevation);
            }
            typedArrayObtainStyledAttributes2.recycle();
            this.K = new ArrayList<>();
        } catch (Throwable th2) {
            typedArrayObtainStyledAttributes2.recycle();
            throw th2;
        }
    }

    public void setStatusBarBackground(int i10) {
        this.f2532z = i10 != 0 ? androidx.core.content.a.e(getContext(), i10) : null;
        invalidate();
    }

    public static class LayoutParams extends ViewGroup.MarginLayoutParams {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public int f2533a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        float f2534b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        boolean f2535c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        int f2536d;

        public LayoutParams(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            this.f2533a = 0;
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, DrawerLayout.P);
            this.f2533a = typedArrayObtainStyledAttributes.getInt(0, 0);
            typedArrayObtainStyledAttributes.recycle();
        }

        public LayoutParams(int i10, int i11) {
            super(i10, i11);
            this.f2533a = 0;
        }

        public LayoutParams(LayoutParams layoutParams) {
            super((ViewGroup.MarginLayoutParams) layoutParams);
            this.f2533a = 0;
            this.f2533a = layoutParams.f2533a;
        }

        public LayoutParams(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
            this.f2533a = 0;
        }

        public LayoutParams(ViewGroup.MarginLayoutParams marginLayoutParams) {
            super(marginLayoutParams);
            this.f2533a = 0;
        }
    }

    @Override // android.view.ViewGroup
    public ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new LayoutParams(getContext(), attributeSet);
    }

    protected static class SavedState extends AbsSavedState {
        public static final Parcelable.Creator<SavedState> CREATOR = new a();

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        int f2537a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        int f2538b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        int f2539c;

        /* JADX INFO: renamed from: g, reason: collision with root package name */
        int f2540g;

        /* JADX INFO: renamed from: h, reason: collision with root package name */
        int f2541h;

        class a implements Parcelable.ClassLoaderCreator<SavedState> {
            a() {
            }

            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public SavedState createFromParcel(Parcel parcel) {
                return new SavedState(parcel, null);
            }

            @Override // android.os.Parcelable.ClassLoaderCreator
            /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
            public SavedState createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new SavedState(parcel, classLoader);
            }

            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: c, reason: merged with bridge method [inline-methods] */
            public SavedState[] newArray(int i10) {
                return new SavedState[i10];
            }
        }

        public SavedState(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            this.f2537a = 0;
            this.f2537a = parcel.readInt();
            this.f2538b = parcel.readInt();
            this.f2539c = parcel.readInt();
            this.f2540g = parcel.readInt();
            this.f2541h = parcel.readInt();
        }

        @Override // androidx.customview.view.AbsSavedState, android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i10) {
            super.writeToParcel(parcel, i10);
            parcel.writeInt(this.f2537a);
            parcel.writeInt(this.f2538b);
            parcel.writeInt(this.f2539c);
            parcel.writeInt(this.f2540g);
            parcel.writeInt(this.f2541h);
        }

        public SavedState(Parcelable parcelable) {
            super(parcelable);
            this.f2537a = 0;
        }
    }

    public static abstract class f implements e {
        @Override // androidx.drawerlayout.widget.DrawerLayout.e
        public void a(int i10) {
        }

        @Override // androidx.drawerlayout.widget.DrawerLayout.e
        public void b(View view, float f10) {
        }
    }
}
