package androidx.drawerlayout;

/* JADX INFO: loaded from: classes.dex */
public final class R$integer {
    public static final int status_bar_notification_info_maxnum = 2131361898;

    private R$integer() {
    }
}
