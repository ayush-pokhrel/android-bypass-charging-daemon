package androidx.databinding;

import java.io.Serializable;

/* JADX INFO: loaded from: classes.dex */
public class ObservableField<T> extends b implements Serializable {
    static final long serialVersionUID = 1;
    private T mValue;

    public ObservableField(T t10) {
        this.mValue = t10;
    }

    public T p() {
        return this.mValue;
    }

    public ObservableField() {
    }
}
