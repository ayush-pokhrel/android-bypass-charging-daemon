package androidx.databinding;

import android.annotation.TargetApi;
import android.os.Build;
import android.os.Handler;
import android.view.Choreographer;
import android.view.View;
import androidx.databinding.library.R$id;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.k;
import androidx.lifecycle.l;
import androidx.lifecycle.t;
import java.lang.ref.ReferenceQueue;
import java.lang.ref.WeakReference;

/* JADX INFO: loaded from: classes.dex */
public abstract class ViewDataBinding extends androidx.databinding.a {

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    static int f2490m = Build.VERSION.SDK_INT;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    private static final boolean f2491n = true;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    private static final androidx.databinding.d f2492o = new a();

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    private static final androidx.databinding.d f2493p = new b();

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    private static final androidx.databinding.d f2494q = new c();

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    private static final androidx.databinding.d f2495r = new d();

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    private static final androidx.databinding.c<Object, ViewDataBinding, Void> f2496s = new e();

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    private static final ReferenceQueue<ViewDataBinding> f2497t = new ReferenceQueue<>();

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    private static final View.OnAttachStateChangeListener f2498u = new f();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final Runnable f2499a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private boolean f2500b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private boolean f2501c;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private boolean f2502g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private Choreographer f2503h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private final Choreographer.FrameCallback f2504i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private Handler f2505j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    private ViewDataBinding f2506k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private l f2507l;

    static class OnStartListener implements k {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        final WeakReference<ViewDataBinding> f2508a;

        @t(Lifecycle.Event.ON_START)
        public void onStart() {
            ViewDataBinding viewDataBinding = this.f2508a.get();
            if (viewDataBinding != null) {
                viewDataBinding.s();
            }
        }
    }

    class a implements androidx.databinding.d {
        a() {
        }
    }

    class b implements androidx.databinding.d {
        b() {
        }
    }

    class c implements androidx.databinding.d {
        c() {
        }
    }

    class d implements androidx.databinding.d {
        d() {
        }
    }

    class e extends androidx.databinding.c<Object, ViewDataBinding, Void> {
        e() {
        }
    }

    private void r() {
        if (this.f2502g) {
            v();
        } else if (u()) {
            this.f2502g = true;
            this.f2501c = false;
            q();
            this.f2502g = false;
        }
    }

    static ViewDataBinding t(View view) {
        if (view != null) {
            return (ViewDataBinding) view.getTag(R$id.dataBinding);
        }
        return null;
    }

    protected abstract void q();

    public void s() {
        ViewDataBinding viewDataBinding = this.f2506k;
        if (viewDataBinding == null) {
            r();
        } else {
            viewDataBinding.s();
        }
    }

    public abstract boolean u();

    protected void v() {
        ViewDataBinding viewDataBinding = this.f2506k;
        if (viewDataBinding != null) {
            viewDataBinding.v();
            return;
        }
        l lVar = this.f2507l;
        if (lVar == null || lVar.getLifecycle().b().b(Lifecycle.State.STARTED)) {
            synchronized (this) {
                try {
                    if (this.f2500b) {
                        return;
                    }
                    this.f2500b = true;
                    if (f2491n) {
                        this.f2503h.postFrameCallback(this.f2504i);
                    } else {
                        this.f2505j.post(this.f2499a);
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
        }
    }

    class f implements View.OnAttachStateChangeListener {
        f() {
        }

        @Override // android.view.View.OnAttachStateChangeListener
        @TargetApi(19)
        public void onViewAttachedToWindow(View view) {
            ViewDataBinding.t(view).f2499a.run();
            view.removeOnAttachStateChangeListener(this);
        }

        @Override // android.view.View.OnAttachStateChangeListener
        public void onViewDetachedFromWindow(View view) {
        }
    }
}
