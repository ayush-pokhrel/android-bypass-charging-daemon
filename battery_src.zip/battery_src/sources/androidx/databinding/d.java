package androidx.databinding;

/* JADX INFO: compiled from: CreateWeakListener.java */
/* JADX INFO: loaded from: classes.dex */
interface d {
}
