package androidx.databinding.library;

/* JADX INFO: loaded from: classes.dex */
public final class R$dimen {
    public static final int compat_button_inset_horizontal_material = 2131165348;
    public static final int compat_button_inset_vertical_material = 2131165349;
    public static final int compat_button_padding_horizontal_material = 2131165350;
    public static final int compat_button_padding_vertical_material = 2131165351;
    public static final int compat_control_corner_material = 2131165352;
    public static final int compat_notification_large_icon_max_height = 2131165353;
    public static final int compat_notification_large_icon_max_width = 2131165354;
    public static final int notification_action_icon_size = 2131167156;
    public static final int notification_action_text_size = 2131167157;
    public static final int notification_big_circle_margin = 2131167158;
    public static final int notification_content_margin_start = 2131167159;
    public static final int notification_large_icon_height = 2131167160;
    public static final int notification_large_icon_width = 2131167161;
    public static final int notification_main_column_padding_top = 2131167162;
    public static final int notification_media_narrow_margin = 2131167163;
    public static final int notification_right_icon_size = 2131167164;
    public static final int notification_right_side_padding_top = 2131167165;
    public static final int notification_small_icon_background_padding = 2131167166;
    public static final int notification_small_icon_size_as_large = 2131167167;
    public static final int notification_subtext_size = 2131167168;
    public static final int notification_top_pad = 2131167169;
    public static final int notification_top_pad_large_text = 2131167170;

    private R$dimen() {
    }
}
