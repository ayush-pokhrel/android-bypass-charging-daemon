package androidx.databinding.library;

/* JADX INFO: loaded from: classes.dex */
public final class R$id {
    public static final int action_container = 2131296322;
    public static final int action_divider = 2131296324;
    public static final int action_image = 2131296325;
    public static final int action_text = 2131296331;
    public static final int actions = 2131296332;
    public static final int async = 2131296361;
    public static final int blocking = 2131296411;
    public static final int bottom = 2131296415;
    public static final int chronometer = 2131296451;
    public static final int dataBinding = 2131296536;
    public static final int end = 2131296593;
    public static final int forever = 2131296619;
    public static final int icon = 2131296654;
    public static final int icon_group = 2131296656;
    public static final int info = 2131296669;
    public static final int italic = 2131296677;
    public static final int left = 2131296701;
    public static final int line1 = 2131296707;
    public static final int line3 = 2131296708;
    public static final int none = 2131296808;
    public static final int normal = 2131296809;
    public static final int notification_background = 2131296812;
    public static final int notification_main_column = 2131296813;
    public static final int notification_main_column_container = 2131296814;
    public static final int right = 2131296926;
    public static final int right_icon = 2131296928;
    public static final int right_side = 2131296929;
    public static final int start = 2131297029;
    public static final int tag_transition_group = 2131297060;
    public static final int tag_unhandled_key_event_manager = 2131297061;
    public static final int tag_unhandled_key_listeners = 2131297062;
    public static final int text = 2131297065;
    public static final int text2 = 2131297066;
    public static final int time = 2131297088;
    public static final int title = 2131297099;
    public static final int top = 2131297107;
    public static final int view_tree_lifecycle_owner = 2131297149;
    public static final int view_tree_view_model_store_owner = 2131297152;

    private R$id() {
    }
}
