package androidx.databinding.library;

/* JADX INFO: loaded from: classes.dex */
public final class R$style {
    public static final int TextAppearance_Compat_Notification = 2131886887;
    public static final int TextAppearance_Compat_Notification_Info = 2131886888;
    public static final int TextAppearance_Compat_Notification_Line2 = 2131886889;
    public static final int TextAppearance_Compat_Notification_Time = 2131886890;
    public static final int TextAppearance_Compat_Notification_Title = 2131886891;
    public static final int Widget_Compat_NotificationActionContainer = 2131887421;
    public static final int Widget_Compat_NotificationActionText = 2131887422;
    public static final int Widget_Support_CoordinatorLayout = 2131887724;

    private R$style() {
    }
}
