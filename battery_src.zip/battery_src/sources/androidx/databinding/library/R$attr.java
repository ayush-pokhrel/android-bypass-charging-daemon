package androidx.databinding.library;

/* JADX INFO: loaded from: classes.dex */
public final class R$attr {
    public static final int alpha = 2130968629;
    public static final int coordinatorLayoutStyle = 2130968966;
    public static final int font = 2130969812;
    public static final int fontProviderAuthority = 2130969814;
    public static final int fontProviderCerts = 2130969815;
    public static final int fontProviderFetchStrategy = 2130969816;
    public static final int fontProviderFetchTimeout = 2130969817;
    public static final int fontProviderPackage = 2130969818;
    public static final int fontProviderQuery = 2130969819;
    public static final int fontStyle = 2130969821;
    public static final int fontVariationSettings = 2130969822;
    public static final int fontWeight = 2130969823;
    public static final int keylines = 2130969976;
    public static final int layout_anchor = 2130969990;
    public static final int layout_anchorGravity = 2130969991;
    public static final int layout_behavior = 2130969992;
    public static final int layout_dodgeInsetEdges = 2130970037;
    public static final int layout_insetEdge = 2130970047;
    public static final int layout_keyline = 2130970048;
    public static final int statusBarBackground = 2130970472;
    public static final int ttcIndex = 2130970707;

    private R$attr() {
    }
}
