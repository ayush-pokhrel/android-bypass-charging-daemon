package androidx.databinding.library.baseAdapters;

/* JADX INFO: loaded from: classes.dex */
public final class R$integer {
    public static final int abc_config_activityDefaultDur = 2131361792;
    public static final int abc_config_activityShortDur = 2131361793;
    public static final int cancel_button_image_alpha = 2131361796;
    public static final int config_tooltipAnimTime = 2131361797;
    public static final int status_bar_notification_info_maxnum = 2131361898;

    private R$integer() {
    }
}
