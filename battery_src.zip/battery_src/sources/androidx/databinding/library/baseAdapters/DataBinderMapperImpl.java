package androidx.databinding.library.baseAdapters;

import android.util.SparseIntArray;
import androidx.databinding.e;

/* JADX INFO: loaded from: classes.dex */
public class DataBinderMapperImpl extends e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private static final SparseIntArray f2509a = new SparseIntArray(0);
}
