package androidx.databinding;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;

/* JADX INFO: loaded from: classes.dex */
public class MergedDataBinderMapper extends e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private Set<Class<? extends e>> f2487a = new HashSet();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private List<e> f2488b = new CopyOnWriteArrayList();

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private List<String> f2489c = new CopyOnWriteArrayList();
}
