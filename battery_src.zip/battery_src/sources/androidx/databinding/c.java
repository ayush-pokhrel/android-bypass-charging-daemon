package androidx.databinding;

/* JADX INFO: compiled from: CallbackRegistry.java */
/* JADX INFO: loaded from: classes.dex */
public abstract class c<C, T, A> {
}
