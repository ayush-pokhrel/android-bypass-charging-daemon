package androidx.databinding;

/* JADX INFO: compiled from: DataBinderMapper.java */
/* JADX INFO: loaded from: classes.dex */
public abstract class e {
}
