package androidx.coordinatorlayout.widget;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Region;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.SystemClock;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.ViewTreeObserver;
import androidx.coordinatorlayout.R$attr;
import androidx.coordinatorlayout.R$style;
import androidx.coordinatorlayout.R$styleable;
import androidx.core.view.h0;
import androidx.core.view.i;
import androidx.core.view.t0;
import androidx.core.view.u;
import androidx.core.view.v;
import androidx.core.view.w;
import androidx.core.view.x;
import androidx.customview.view.AbsSavedState;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/* JADX INFO: loaded from: classes.dex */
public class CoordinatorLayout extends ViewGroup implements u, v {
    static final Comparator<View> A;
    private static final a0.e<Rect> B;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    static final String f2094x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    static final Class<?>[] f2095y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    static final ThreadLocal<Map<String, Constructor<Behavior>>> f2096z;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final List<View> f2097a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private final androidx.coordinatorlayout.widget.a<View> f2098b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private final List<View> f2099c;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private final List<View> f2100g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private Paint f2101h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private final int[] f2102i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private final int[] f2103j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    private boolean f2104k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private boolean f2105l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    private int[] f2106m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    private View f2107n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    private View f2108o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    private f f2109p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    private boolean f2110q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    private t0 f2111r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    private boolean f2112s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    private Drawable f2113t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    ViewGroup.OnHierarchyChangeListener f2114u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    private x f2115v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    private final w f2116w;

    public static abstract class Behavior<V extends View> {
        public Behavior() {
        }

        public static Object getTag(View view) {
            return ((e) view.getLayoutParams()).f2137r;
        }

        public static void setTag(View view, Object obj) {
            ((e) view.getLayoutParams()).f2137r = obj;
        }

        public boolean blocksInteractionBelow(CoordinatorLayout coordinatorLayout, V v10) {
            return getScrimOpacity(coordinatorLayout, v10) > 0.0f;
        }

        public boolean getInsetDodgeRect(CoordinatorLayout coordinatorLayout, V v10, Rect rect) {
            return false;
        }

        public int getScrimColor(CoordinatorLayout coordinatorLayout, V v10) {
            return -16777216;
        }

        public float getScrimOpacity(CoordinatorLayout coordinatorLayout, V v10) {
            return 0.0f;
        }

        public boolean layoutDependsOn(CoordinatorLayout coordinatorLayout, V v10, View view) {
            return false;
        }

        public boolean onDependentViewChanged(CoordinatorLayout coordinatorLayout, V v10, View view) {
            return false;
        }

        public boolean onInterceptTouchEvent(CoordinatorLayout coordinatorLayout, V v10, MotionEvent motionEvent) {
            return false;
        }

        public boolean onLayoutChild(CoordinatorLayout coordinatorLayout, V v10, int i10) {
            return false;
        }

        public boolean onMeasureChild(CoordinatorLayout coordinatorLayout, V v10, int i10, int i11, int i12, int i13) {
            return false;
        }

        public boolean onNestedFling(CoordinatorLayout coordinatorLayout, V v10, View view, float f10, float f11, boolean z10) {
            return false;
        }

        public boolean onNestedPreFling(CoordinatorLayout coordinatorLayout, V v10, View view, float f10, float f11) {
            return false;
        }

        @Deprecated
        public void onNestedPreScroll(CoordinatorLayout coordinatorLayout, V v10, View view, int i10, int i11, int[] iArr) {
        }

        @Deprecated
        public void onNestedScroll(CoordinatorLayout coordinatorLayout, V v10, View view, int i10, int i11, int i12, int i13) {
        }

        @Deprecated
        public void onNestedScrollAccepted(CoordinatorLayout coordinatorLayout, V v10, View view, View view2, int i10) {
        }

        public boolean onRequestChildRectangleOnScreen(CoordinatorLayout coordinatorLayout, V v10, Rect rect, boolean z10) {
            return false;
        }

        public Parcelable onSaveInstanceState(CoordinatorLayout coordinatorLayout, V v10) {
            return View.BaseSavedState.EMPTY_STATE;
        }

        @Deprecated
        public boolean onStartNestedScroll(CoordinatorLayout coordinatorLayout, V v10, View view, View view2, int i10) {
            return false;
        }

        @Deprecated
        public void onStopNestedScroll(CoordinatorLayout coordinatorLayout, V v10, View view) {
        }

        public boolean onTouchEvent(CoordinatorLayout coordinatorLayout, V v10, MotionEvent motionEvent) {
            return false;
        }

        public Behavior(Context context, AttributeSet attributeSet) {
        }

        public void onNestedPreScroll(CoordinatorLayout coordinatorLayout, V v10, View view, int i10, int i11, int[] iArr, int i12) {
            if (i12 == 0) {
                onNestedPreScroll(coordinatorLayout, v10, view, i10, i11, iArr);
            }
        }

        @Deprecated
        public void onNestedScroll(CoordinatorLayout coordinatorLayout, V v10, View view, int i10, int i11, int i12, int i13, int i14) {
            if (i14 == 0) {
                onNestedScroll(coordinatorLayout, v10, view, i10, i11, i12, i13);
            }
        }

        public void onNestedScrollAccepted(CoordinatorLayout coordinatorLayout, V v10, View view, View view2, int i10, int i11) {
            if (i11 == 0) {
                onNestedScrollAccepted(coordinatorLayout, v10, view, view2, i10);
            }
        }

        public boolean onStartNestedScroll(CoordinatorLayout coordinatorLayout, V v10, View view, View view2, int i10, int i11) {
            if (i11 == 0) {
                return onStartNestedScroll(coordinatorLayout, v10, view, view2, i10);
            }
            return false;
        }

        public void onStopNestedScroll(CoordinatorLayout coordinatorLayout, V v10, View view, int i10) {
            if (i10 == 0) {
                onStopNestedScroll(coordinatorLayout, v10, view);
            }
        }

        public void onNestedScroll(CoordinatorLayout coordinatorLayout, V v10, View view, int i10, int i11, int i12, int i13, int i14, int[] iArr) {
            iArr[0] = iArr[0] + i12;
            iArr[1] = iArr[1] + i13;
            onNestedScroll(coordinatorLayout, v10, view, i10, i11, i12, i13, i14);
        }

        public void onDetachedFromLayoutParams() {
        }

        public void onAttachedToLayoutParams(e eVar) {
        }

        public t0 onApplyWindowInsets(CoordinatorLayout coordinatorLayout, V v10, t0 t0Var) {
            return t0Var;
        }

        public void onDependentViewRemoved(CoordinatorLayout coordinatorLayout, V v10, View view) {
        }

        public void onRestoreInstanceState(CoordinatorLayout coordinatorLayout, V v10, Parcelable parcelable) {
        }
    }

    class a implements x {
        a() {
        }

        @Override // androidx.core.view.x
        public t0 onApplyWindowInsets(View view, t0 t0Var) {
            return CoordinatorLayout.this.a0(t0Var);
        }
    }

    public interface b {
        Behavior getBehavior();
    }

    @Retention(RetentionPolicy.RUNTIME)
    @Deprecated
    public @interface c {
        Class<? extends Behavior> value();
    }

    private class d implements ViewGroup.OnHierarchyChangeListener {
        d() {
        }

        @Override // android.view.ViewGroup.OnHierarchyChangeListener
        public void onChildViewAdded(View view, View view2) {
            ViewGroup.OnHierarchyChangeListener onHierarchyChangeListener = CoordinatorLayout.this.f2114u;
            if (onHierarchyChangeListener != null) {
                onHierarchyChangeListener.onChildViewAdded(view, view2);
            }
        }

        @Override // android.view.ViewGroup.OnHierarchyChangeListener
        public void onChildViewRemoved(View view, View view2) {
            CoordinatorLayout.this.L(2);
            ViewGroup.OnHierarchyChangeListener onHierarchyChangeListener = CoordinatorLayout.this.f2114u;
            if (onHierarchyChangeListener != null) {
                onHierarchyChangeListener.onChildViewRemoved(view, view2);
            }
        }
    }

    class f implements ViewTreeObserver.OnPreDrawListener {
        f() {
        }

        @Override // android.view.ViewTreeObserver.OnPreDrawListener
        public boolean onPreDraw() {
            CoordinatorLayout.this.L(0);
            return true;
        }
    }

    static class g implements Comparator<View> {
        g() {
        }

        @Override // java.util.Comparator
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public int compare(View view, View view2) {
            float fJ = h0.J(view);
            float fJ2 = h0.J(view2);
            if (fJ > fJ2) {
                return -1;
            }
            return fJ < fJ2 ? 1 : 0;
        }
    }

    static {
        Package r10 = CoordinatorLayout.class.getPackage();
        f2094x = r10 != null ? r10.getName() : null;
        A = new g();
        f2095y = new Class[]{Context.class, AttributeSet.class};
        f2096z = new ThreadLocal<>();
        B = new a0.g(12);
    }

    public CoordinatorLayout(Context context) {
        this(context, null);
    }

    private int A(int i10) {
        int[] iArr = this.f2106m;
        if (iArr == null) {
            Log.e("CoordinatorLayout", "No keylines defined for " + this + " - attempted index lookup " + i10);
            return 0;
        }
        if (i10 >= 0 && i10 < iArr.length) {
            return iArr[i10];
        }
        Log.e("CoordinatorLayout", "Keyline index " + i10 + " out of range for " + this);
        return 0;
    }

    private void D(List<View> list) {
        list.clear();
        boolean zIsChildrenDrawingOrderEnabled = isChildrenDrawingOrderEnabled();
        int childCount = getChildCount();
        for (int i10 = childCount - 1; i10 >= 0; i10--) {
            list.add(getChildAt(zIsChildrenDrawingOrderEnabled ? getChildDrawingOrder(childCount, i10) : i10));
        }
        Comparator<View> comparator = A;
        if (comparator != null) {
            Collections.sort(list, comparator);
        }
    }

    private boolean E(View view) {
        return this.f2098b.j(view);
    }

    private void G(View view, int i10) {
        e eVar = (e) view.getLayoutParams();
        Rect rectE = e();
        rectE.set(getPaddingLeft() + ((ViewGroup.MarginLayoutParams) eVar).leftMargin, getPaddingTop() + ((ViewGroup.MarginLayoutParams) eVar).topMargin, (getWidth() - getPaddingRight()) - ((ViewGroup.MarginLayoutParams) eVar).rightMargin, (getHeight() - getPaddingBottom()) - ((ViewGroup.MarginLayoutParams) eVar).bottomMargin);
        if (this.f2111r != null && h0.t(this) && !h0.t(view)) {
            rectE.left += this.f2111r.j();
            rectE.top += this.f2111r.l();
            rectE.right -= this.f2111r.k();
            rectE.bottom -= this.f2111r.i();
        }
        Rect rectE2 = e();
        i.a(W(eVar.f2122c), view.getMeasuredWidth(), view.getMeasuredHeight(), rectE, rectE2, i10);
        view.layout(rectE2.left, rectE2.top, rectE2.right, rectE2.bottom);
        S(rectE);
        S(rectE2);
    }

    private void H(View view, View view2, int i10) {
        Rect rectE = e();
        Rect rectE2 = e();
        try {
            x(view2, rectE);
            y(view, i10, rectE, rectE2);
            view.layout(rectE2.left, rectE2.top, rectE2.right, rectE2.bottom);
        } finally {
            S(rectE);
            S(rectE2);
        }
    }

    private void I(View view, int i10, int i11) {
        int i12;
        e eVar = (e) view.getLayoutParams();
        int iB = i.b(X(eVar.f2122c), i11);
        int i13 = iB & 7;
        int i14 = iB & 112;
        int width = getWidth();
        int height = getHeight();
        int measuredWidth = view.getMeasuredWidth();
        int measuredHeight = view.getMeasuredHeight();
        if (i11 == 1) {
            i10 = width - i10;
        }
        int iA = A(i10) - measuredWidth;
        if (i13 == 1) {
            iA += measuredWidth / 2;
        } else if (i13 == 5) {
            iA += measuredWidth;
        }
        if (i14 != 16) {
            i12 = i14 != 80 ? 0 : measuredHeight;
        } else {
            i12 = measuredHeight / 2;
        }
        int iMax = Math.max(getPaddingLeft() + ((ViewGroup.MarginLayoutParams) eVar).leftMargin, Math.min(iA, ((width - getPaddingRight()) - measuredWidth) - ((ViewGroup.MarginLayoutParams) eVar).rightMargin));
        int iMax2 = Math.max(getPaddingTop() + ((ViewGroup.MarginLayoutParams) eVar).topMargin, Math.min(i12, ((height - getPaddingBottom()) - measuredHeight) - ((ViewGroup.MarginLayoutParams) eVar).bottomMargin));
        view.layout(iMax, iMax2, measuredWidth + iMax, measuredHeight + iMax2);
    }

    private void J(View view, Rect rect, int i10) {
        boolean z10;
        boolean z11;
        int width;
        int i11;
        int i12;
        int i13;
        int height;
        int i14;
        int i15;
        int i16;
        if (h0.Q(view) && view.getWidth() > 0 && view.getHeight() > 0) {
            e eVar = (e) view.getLayoutParams();
            Behavior behaviorF = eVar.f();
            Rect rectE = e();
            Rect rectE2 = e();
            rectE2.set(view.getLeft(), view.getTop(), view.getRight(), view.getBottom());
            if (behaviorF == null || !behaviorF.getInsetDodgeRect(this, view, rectE)) {
                rectE.set(rectE2);
            } else if (!rectE2.contains(rectE)) {
                throw new IllegalArgumentException("Rect should be within the child's bounds. Rect:" + rectE.toShortString() + " | Bounds:" + rectE2.toShortString());
            }
            S(rectE2);
            if (rectE.isEmpty()) {
                S(rectE);
                return;
            }
            int iB = i.b(eVar.f2127h, i10);
            boolean z12 = true;
            if ((iB & 48) != 48 || (i15 = (rectE.top - ((ViewGroup.MarginLayoutParams) eVar).topMargin) - eVar.f2129j) >= (i16 = rect.top)) {
                z10 = false;
            } else {
                Z(view, i16 - i15);
                z10 = true;
            }
            if ((iB & 80) == 80 && (height = ((getHeight() - rectE.bottom) - ((ViewGroup.MarginLayoutParams) eVar).bottomMargin) + eVar.f2129j) < (i14 = rect.bottom)) {
                Z(view, height - i14);
                z10 = true;
            }
            if (!z10) {
                Z(view, 0);
            }
            if ((iB & 3) != 3 || (i12 = (rectE.left - ((ViewGroup.MarginLayoutParams) eVar).leftMargin) - eVar.f2128i) >= (i13 = rect.left)) {
                z11 = false;
            } else {
                Y(view, i13 - i12);
                z11 = true;
            }
            if ((iB & 5) != 5 || (width = ((getWidth() - rectE.right) - ((ViewGroup.MarginLayoutParams) eVar).rightMargin) + eVar.f2128i) >= (i11 = rect.right)) {
                z12 = z11;
            } else {
                Y(view, width - i11);
            }
            if (!z12) {
                Y(view, 0);
            }
            S(rectE);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    static Behavior O(Context context, AttributeSet attributeSet, String str) {
        if (TextUtils.isEmpty(str)) {
            return null;
        }
        if (str.startsWith(".")) {
            str = context.getPackageName() + str;
        } else if (str.indexOf(46) < 0) {
            String str2 = f2094x;
            if (!TextUtils.isEmpty(str2)) {
                str = str2 + '.' + str;
            }
        }
        try {
            ThreadLocal<Map<String, Constructor<Behavior>>> threadLocal = f2096z;
            Map<String, Constructor<Behavior>> map = threadLocal.get();
            if (map == null) {
                map = new HashMap<>();
                threadLocal.set(map);
            }
            Constructor<Behavior> constructor = map.get(str);
            if (constructor == null) {
                constructor = Class.forName(str, false, context.getClassLoader()).getConstructor(f2095y);
                constructor.setAccessible(true);
                map.put(str, constructor);
            }
            return constructor.newInstance(context, attributeSet);
        } catch (Exception e10) {
            throw new RuntimeException("Could not inflate Behavior subclass " + str, e10);
        }
    }

    private boolean P(MotionEvent motionEvent, int i10) {
        int actionMasked = motionEvent.getActionMasked();
        List<View> list = this.f2099c;
        D(list);
        int size = list.size();
        MotionEvent motionEventObtain = null;
        boolean zOnInterceptTouchEvent = false;
        boolean z10 = false;
        for (int i11 = 0; i11 < size; i11++) {
            View view = list.get(i11);
            e eVar = (e) view.getLayoutParams();
            Behavior behaviorF = eVar.f();
            if (!(zOnInterceptTouchEvent || z10) || actionMasked == 0) {
                if (!zOnInterceptTouchEvent && behaviorF != null) {
                    if (i10 == 0) {
                        zOnInterceptTouchEvent = behaviorF.onInterceptTouchEvent(this, view, motionEvent);
                    } else if (i10 == 1) {
                        zOnInterceptTouchEvent = behaviorF.onTouchEvent(this, view, motionEvent);
                    }
                    if (zOnInterceptTouchEvent) {
                        this.f2107n = view;
                    }
                }
                boolean zC = eVar.c();
                boolean zI = eVar.i(this, view);
                z10 = zI && !zC;
                if (zI && !z10) {
                    break;
                }
            } else if (behaviorF != null) {
                if (motionEventObtain == null) {
                    long jUptimeMillis = SystemClock.uptimeMillis();
                    motionEventObtain = MotionEvent.obtain(jUptimeMillis, jUptimeMillis, 3, 0.0f, 0.0f, 0);
                }
                if (i10 == 0) {
                    behaviorF.onInterceptTouchEvent(this, view, motionEventObtain);
                } else if (i10 == 1) {
                    behaviorF.onTouchEvent(this, view, motionEventObtain);
                }
            }
        }
        list.clear();
        return zOnInterceptTouchEvent;
    }

    private void Q() {
        this.f2097a.clear();
        this.f2098b.c();
        int childCount = getChildCount();
        for (int i10 = 0; i10 < childCount; i10++) {
            View childAt = getChildAt(i10);
            e eVarC = C(childAt);
            eVarC.d(this, childAt);
            this.f2098b.b(childAt);
            for (int i11 = 0; i11 < childCount; i11++) {
                if (i11 != i10) {
                    View childAt2 = getChildAt(i11);
                    if (eVarC.b(this, childAt, childAt2)) {
                        if (!this.f2098b.d(childAt2)) {
                            this.f2098b.b(childAt2);
                        }
                        this.f2098b.a(childAt2, childAt);
                    }
                }
            }
        }
        this.f2097a.addAll(this.f2098b.i());
        Collections.reverse(this.f2097a);
    }

    private static void S(Rect rect) {
        rect.setEmpty();
        B.a(rect);
    }

    private void U(boolean z10) {
        int childCount = getChildCount();
        for (int i10 = 0; i10 < childCount; i10++) {
            View childAt = getChildAt(i10);
            Behavior behaviorF = ((e) childAt.getLayoutParams()).f();
            if (behaviorF != null) {
                long jUptimeMillis = SystemClock.uptimeMillis();
                MotionEvent motionEventObtain = MotionEvent.obtain(jUptimeMillis, jUptimeMillis, 3, 0.0f, 0.0f, 0);
                if (z10) {
                    behaviorF.onInterceptTouchEvent(this, childAt, motionEventObtain);
                } else {
                    behaviorF.onTouchEvent(this, childAt, motionEventObtain);
                }
                motionEventObtain.recycle();
            }
        }
        for (int i11 = 0; i11 < childCount; i11++) {
            ((e) getChildAt(i11).getLayoutParams()).m();
        }
        this.f2107n = null;
        this.f2104k = false;
    }

    private static int V(int i10) {
        if (i10 == 0) {
            return 17;
        }
        return i10;
    }

    private static int W(int i10) {
        if ((i10 & 7) == 0) {
            i10 |= 8388611;
        }
        return (i10 & 112) == 0 ? i10 | 48 : i10;
    }

    private static int X(int i10) {
        if (i10 == 0) {
            return 8388661;
        }
        return i10;
    }

    private void Y(View view, int i10) {
        e eVar = (e) view.getLayoutParams();
        int i11 = eVar.f2128i;
        if (i11 != i10) {
            h0.V(view, i10 - i11);
            eVar.f2128i = i10;
        }
    }

    private void Z(View view, int i10) {
        e eVar = (e) view.getLayoutParams();
        int i11 = eVar.f2129j;
        if (i11 != i10) {
            h0.W(view, i10 - i11);
            eVar.f2129j = i10;
        }
    }

    private void b0() {
        if (!h0.t(this)) {
            h0.B0(this, null);
            return;
        }
        if (this.f2115v == null) {
            this.f2115v = new a();
        }
        h0.B0(this, this.f2115v);
        setSystemUiVisibility(1280);
    }

    private static Rect e() {
        Rect rectB = B.b();
        return rectB == null ? new Rect() : rectB;
    }

    private static int g(int i10, int i11, int i12) {
        if (i10 < i11) {
            return i11;
        }
        return i10 > i12 ? i12 : i10;
    }

    private void k(e eVar, Rect rect, int i10, int i11) {
        int width = getWidth();
        int height = getHeight();
        int iMax = Math.max(getPaddingLeft() + ((ViewGroup.MarginLayoutParams) eVar).leftMargin, Math.min(rect.left, ((width - getPaddingRight()) - i10) - ((ViewGroup.MarginLayoutParams) eVar).rightMargin));
        int iMax2 = Math.max(getPaddingTop() + ((ViewGroup.MarginLayoutParams) eVar).topMargin, Math.min(rect.top, ((height - getPaddingBottom()) - i11) - ((ViewGroup.MarginLayoutParams) eVar).bottomMargin));
        rect.set(iMax, iMax2, i10 + iMax, i11 + iMax2);
    }

    private t0 l(t0 t0Var) {
        Behavior behaviorF;
        if (t0Var.p()) {
            return t0Var;
        }
        int childCount = getChildCount();
        for (int i10 = 0; i10 < childCount; i10++) {
            View childAt = getChildAt(i10);
            if (h0.t(childAt) && (behaviorF = ((e) childAt.getLayoutParams()).f()) != null) {
                t0Var = behaviorF.onApplyWindowInsets(this, childAt, t0Var);
                if (t0Var.p()) {
                    break;
                }
            }
        }
        return t0Var;
    }

    private void z(View view, int i10, Rect rect, Rect rect2, e eVar, int i11, int i12) {
        int iWidth;
        int iHeight;
        int iB = i.b(V(eVar.f2122c), i10);
        int iB2 = i.b(W(eVar.f2123d), i10);
        int i13 = iB & 7;
        int i14 = iB & 112;
        int i15 = iB2 & 7;
        int i16 = iB2 & 112;
        if (i15 != 1) {
            iWidth = i15 != 5 ? rect.left : rect.right;
        } else {
            iWidth = rect.left + (rect.width() / 2);
        }
        if (i16 != 16) {
            iHeight = i16 != 80 ? rect.top : rect.bottom;
        } else {
            iHeight = rect.top + (rect.height() / 2);
        }
        if (i13 == 1) {
            iWidth -= i11 / 2;
        } else if (i13 != 5) {
            iWidth -= i11;
        }
        if (i14 == 16) {
            iHeight -= i12 / 2;
        } else if (i14 != 80) {
            iHeight -= i12;
        }
        rect2.set(iWidth, iHeight, i11 + iWidth, i12 + iHeight);
    }

    void B(View view, Rect rect) {
        rect.set(((e) view.getLayoutParams()).h());
    }

    /* JADX WARN: Multi-variable type inference failed */
    e C(View view) {
        e eVar = (e) view.getLayoutParams();
        if (!eVar.f2121b) {
            if (view instanceof b) {
                Behavior behavior = ((b) view).getBehavior();
                if (behavior == null) {
                    Log.e("CoordinatorLayout", "Attached behavior class is null");
                }
                eVar.o(behavior);
                eVar.f2121b = true;
            } else {
                c cVar = null;
                for (Class<?> superclass = view.getClass(); superclass != null; superclass = superclass.getSuperclass()) {
                    cVar = (c) superclass.getAnnotation(c.class);
                    if (cVar != null) {
                        break;
                    }
                }
                if (cVar != null) {
                    try {
                        eVar.o(cVar.value().getDeclaredConstructor(null).newInstance(null));
                    } catch (Exception e10) {
                        Log.e("CoordinatorLayout", "Default behavior class " + cVar.value().getName() + " could not be instantiated. Did you forget a default constructor?", e10);
                    }
                }
                eVar.f2121b = true;
            }
        }
        return eVar;
    }

    public boolean F(View view, int i10, int i11) {
        Rect rectE = e();
        x(view, rectE);
        try {
            return rectE.contains(i10, i11);
        } finally {
            S(rectE);
        }
    }

    void K(View view, int i10) {
        Behavior behaviorF;
        e eVar = (e) view.getLayoutParams();
        if (eVar.f2130k != null) {
            Rect rectE = e();
            Rect rectE2 = e();
            Rect rectE3 = e();
            x(eVar.f2130k, rectE);
            u(view, false, rectE2);
            int measuredWidth = view.getMeasuredWidth();
            int measuredHeight = view.getMeasuredHeight();
            z(view, i10, rectE, rectE3, eVar, measuredWidth, measuredHeight);
            boolean z10 = (rectE3.left == rectE2.left && rectE3.top == rectE2.top) ? false : true;
            k(eVar, rectE3, measuredWidth, measuredHeight);
            int i11 = rectE3.left - rectE2.left;
            int i12 = rectE3.top - rectE2.top;
            if (i11 != 0) {
                h0.V(view, i11);
            }
            if (i12 != 0) {
                h0.W(view, i12);
            }
            if (z10 && (behaviorF = eVar.f()) != null) {
                behaviorF.onDependentViewChanged(this, view, eVar.f2130k);
            }
            S(rectE);
            S(rectE2);
            S(rectE3);
        }
    }

    /* JADX WARN: Code duplicated, block: B:46:0x00ca  */
    final void L(int i10) {
        int i11;
        Behavior behaviorF;
        boolean zOnDependentViewChanged;
        int iW = h0.w(this);
        int size = this.f2097a.size();
        Rect rectE = e();
        Rect rectE2 = e();
        Rect rectE3 = e();
        for (int i12 = 0; i12 < size; i12++) {
            View view = this.f2097a.get(i12);
            e eVar = (e) view.getLayoutParams();
            if (i10 != 0 || view.getVisibility() != 8) {
                for (int i13 = 0; i13 < i12; i13++) {
                    if (eVar.f2131l == this.f2097a.get(i13)) {
                        K(view, iW);
                    }
                }
                u(view, true, rectE2);
                if (eVar.f2126g != 0 && !rectE2.isEmpty()) {
                    int iB = i.b(eVar.f2126g, iW);
                    int i14 = iB & 112;
                    if (i14 == 48) {
                        rectE.top = Math.max(rectE.top, rectE2.bottom);
                    } else if (i14 == 80) {
                        rectE.bottom = Math.max(rectE.bottom, getHeight() - rectE2.top);
                    }
                    int i15 = iB & 7;
                    if (i15 == 3) {
                        rectE.left = Math.max(rectE.left, rectE2.right);
                    } else if (i15 == 5) {
                        rectE.right = Math.max(rectE.right, getWidth() - rectE2.left);
                    }
                }
                if (eVar.f2127h != 0 && view.getVisibility() == 0) {
                    J(view, rectE, iW);
                }
                if (i10 != 2) {
                    B(view, rectE3);
                    if (!rectE3.equals(rectE2)) {
                        R(view, rectE2);
                        for (i11 = i12 + 1; i11 < size; i11++) {
                            View view2 = this.f2097a.get(i11);
                            e eVar2 = (e) view2.getLayoutParams();
                            behaviorF = eVar2.f();
                            if (behaviorF == null && behaviorF.layoutDependsOn(this, view2, view)) {
                                if (i10 == 0 && eVar2.g()) {
                                    eVar2.k();
                                } else {
                                    if (i10 != 2) {
                                        zOnDependentViewChanged = behaviorF.onDependentViewChanged(this, view2, view);
                                    } else {
                                        behaviorF.onDependentViewRemoved(this, view2, view);
                                        zOnDependentViewChanged = true;
                                    }
                                    if (i10 == 1) {
                                        eVar2.p(zOnDependentViewChanged);
                                    }
                                }
                            }
                        }
                    }
                } else {
                    while (i11 < size) {
                        View view3 = this.f2097a.get(i11);
                        e eVar3 = (e) view3.getLayoutParams();
                        behaviorF = eVar3.f();
                        if (behaviorF == null) {
                        }
                    }
                }
            }
        }
        S(rectE);
        S(rectE2);
        S(rectE3);
    }

    public void M(View view, int i10) {
        e eVar = (e) view.getLayoutParams();
        if (eVar.a()) {
            throw new IllegalStateException("An anchor may not be changed after CoordinatorLayout measurement begins before layout is complete.");
        }
        View view2 = eVar.f2130k;
        if (view2 != null) {
            H(view, view2, i10);
            return;
        }
        int i11 = eVar.f2124e;
        if (i11 >= 0) {
            I(view, i11, i10);
        } else {
            G(view, i10);
        }
    }

    public void N(View view, int i10, int i11, int i12, int i13) {
        measureChildWithMargins(view, i10, i11, i12, i13);
    }

    void R(View view, Rect rect) {
        ((e) view.getLayoutParams()).q(rect);
    }

    void T() {
        if (this.f2105l && this.f2109p != null) {
            getViewTreeObserver().removeOnPreDrawListener(this.f2109p);
        }
        this.f2110q = false;
    }

    final t0 a0(t0 t0Var) {
        if (a0.c.a(this.f2111r, t0Var)) {
            return t0Var;
        }
        this.f2111r = t0Var;
        boolean z10 = false;
        boolean z11 = t0Var != null && t0Var.l() > 0;
        this.f2112s = z11;
        if (!z11 && getBackground() == null) {
            z10 = true;
        }
        setWillNotDraw(z10);
        t0 t0VarL = l(t0Var);
        requestLayout();
        return t0VarL;
    }

    @Override // android.view.ViewGroup
    protected boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return (layoutParams instanceof e) && super.checkLayoutParams(layoutParams);
    }

    @Override // android.view.ViewGroup
    protected boolean drawChild(Canvas canvas, View view, long j10) {
        e eVar = (e) view.getLayoutParams();
        Behavior behavior = eVar.f2120a;
        if (behavior != null) {
            float scrimOpacity = behavior.getScrimOpacity(this, view);
            if (scrimOpacity > 0.0f) {
                if (this.f2101h == null) {
                    this.f2101h = new Paint();
                }
                this.f2101h.setColor(eVar.f2120a.getScrimColor(this, view));
                this.f2101h.setAlpha(g(Math.round(scrimOpacity * 255.0f), 0, 255));
                int iSave = canvas.save();
                if (view.isOpaque()) {
                    canvas.clipRect(view.getLeft(), view.getTop(), view.getRight(), view.getBottom(), Region.Op.DIFFERENCE);
                }
                canvas.drawRect(getPaddingLeft(), getPaddingTop(), getWidth() - getPaddingRight(), getHeight() - getPaddingBottom(), this.f2101h);
                canvas.restoreToCount(iSave);
            }
        }
        return super.drawChild(canvas, view, j10);
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void drawableStateChanged() {
        super.drawableStateChanged();
        int[] drawableState = getDrawableState();
        Drawable drawable = this.f2113t;
        if ((drawable == null || !drawable.isStateful()) ? false : drawable.setState(drawableState)) {
            invalidate();
        }
    }

    void f() {
        if (this.f2105l) {
            if (this.f2109p == null) {
                this.f2109p = new f();
            }
            getViewTreeObserver().addOnPreDrawListener(this.f2109p);
        }
        this.f2110q = true;
    }

    final List<View> getDependencySortedChildren() {
        Q();
        return Collections.unmodifiableList(this.f2097a);
    }

    public final t0 getLastWindowInsets() {
        return this.f2111r;
    }

    @Override // android.view.ViewGroup
    public int getNestedScrollAxes() {
        return this.f2116w.a();
    }

    public Drawable getStatusBarBackground() {
        return this.f2113t;
    }

    @Override // android.view.View
    protected int getSuggestedMinimumHeight() {
        return Math.max(super.getSuggestedMinimumHeight(), getPaddingTop() + getPaddingBottom());
    }

    @Override // android.view.View
    protected int getSuggestedMinimumWidth() {
        return Math.max(super.getSuggestedMinimumWidth(), getPaddingLeft() + getPaddingRight());
    }

    @Override // androidx.core.view.u
    public void h(View view, View view2, int i10, int i11) {
        Behavior behaviorF;
        this.f2116w.c(view, view2, i10, i11);
        this.f2108o = view2;
        int childCount = getChildCount();
        for (int i12 = 0; i12 < childCount; i12++) {
            View childAt = getChildAt(i12);
            e eVar = (e) childAt.getLayoutParams();
            if (eVar.j(i11) && (behaviorF = eVar.f()) != null) {
                behaviorF.onNestedScrollAccepted(this, childAt, view, view2, i10, i11);
            }
        }
    }

    @Override // androidx.core.view.u
    public void i(View view, int i10) {
        this.f2116w.d(view, i10);
        int childCount = getChildCount();
        for (int i11 = 0; i11 < childCount; i11++) {
            View childAt = getChildAt(i11);
            e eVar = (e) childAt.getLayoutParams();
            if (eVar.j(i10)) {
                Behavior behaviorF = eVar.f();
                if (behaviorF != null) {
                    behaviorF.onStopNestedScroll(this, childAt, view, i10);
                }
                eVar.l(i10);
                eVar.k();
            }
        }
        this.f2108o = null;
    }

    @Override // androidx.core.view.u
    public void j(View view, int i10, int i11, int[] iArr, int i12) {
        Behavior behaviorF;
        int childCount = getChildCount();
        boolean z10 = false;
        int iMax = 0;
        int iMax2 = 0;
        for (int i13 = 0; i13 < childCount; i13++) {
            View childAt = getChildAt(i13);
            if (childAt.getVisibility() != 8) {
                e eVar = (e) childAt.getLayoutParams();
                if (eVar.j(i12) && (behaviorF = eVar.f()) != null) {
                    int[] iArr2 = this.f2102i;
                    iArr2[0] = 0;
                    iArr2[1] = 0;
                    behaviorF.onNestedPreScroll(this, childAt, view, i10, i11, iArr2, i12);
                    int[] iArr3 = this.f2102i;
                    iMax = i10 > 0 ? Math.max(iMax, iArr3[0]) : Math.min(iMax, iArr3[0]);
                    int[] iArr4 = this.f2102i;
                    iMax2 = i11 > 0 ? Math.max(iMax2, iArr4[1]) : Math.min(iMax2, iArr4[1]);
                    z10 = true;
                }
            }
        }
        iArr[0] = iMax;
        iArr[1] = iMax2;
        if (z10) {
            L(1);
        }
    }

    @Override // androidx.core.view.v
    public void m(View view, int i10, int i11, int i12, int i13, int i14, int[] iArr) {
        Behavior behaviorF;
        boolean z10;
        int iMin;
        int childCount = getChildCount();
        boolean z11 = false;
        int iMax = 0;
        int i15 = 0;
        for (int i16 = 0; i16 < childCount; i16++) {
            View childAt = getChildAt(i16);
            if (childAt.getVisibility() != 8) {
                e eVar = (e) childAt.getLayoutParams();
                if (eVar.j(i14) && (behaviorF = eVar.f()) != null) {
                    int[] iArr2 = this.f2102i;
                    iArr2[0] = 0;
                    iArr2[1] = 0;
                    behaviorF.onNestedScroll(this, childAt, view, i10, i11, i12, i13, i14, iArr2);
                    int[] iArr3 = this.f2102i;
                    iMax = i12 > 0 ? Math.max(iMax, iArr3[0]) : Math.min(iMax, iArr3[0]);
                    if (i13 > 0) {
                        z10 = true;
                        iMin = Math.max(i15, this.f2102i[1]);
                    } else {
                        z10 = true;
                        iMin = Math.min(i15, this.f2102i[1]);
                    }
                    i15 = iMin;
                    z11 = z10;
                }
            }
        }
        iArr[0] = iArr[0] + iMax;
        iArr[1] = iArr[1] + i15;
        if (z11) {
            L(1);
        }
    }

    @Override // androidx.core.view.u
    public void n(View view, int i10, int i11, int i12, int i13, int i14) {
        m(view, i10, i11, i12, i13, 0, this.f2103j);
    }

    @Override // androidx.core.view.u
    public boolean o(View view, View view2, int i10, int i11) {
        int childCount = getChildCount();
        boolean z10 = false;
        for (int i12 = 0; i12 < childCount; i12++) {
            View childAt = getChildAt(i12);
            if (childAt.getVisibility() != 8) {
                e eVar = (e) childAt.getLayoutParams();
                Behavior behaviorF = eVar.f();
                if (behaviorF != null) {
                    boolean zOnStartNestedScroll = behaviorF.onStartNestedScroll(this, childAt, view, view2, i10, i11);
                    z10 |= zOnStartNestedScroll;
                    eVar.r(i11, zOnStartNestedScroll);
                } else {
                    eVar.r(i11, false);
                }
            }
        }
        return z10;
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        U(false);
        if (this.f2110q) {
            if (this.f2109p == null) {
                this.f2109p = new f();
            }
            getViewTreeObserver().addOnPreDrawListener(this.f2109p);
        }
        if (this.f2111r == null && h0.t(this)) {
            h0.h0(this);
        }
        this.f2105l = true;
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        U(false);
        if (this.f2110q && this.f2109p != null) {
            getViewTreeObserver().removeOnPreDrawListener(this.f2109p);
        }
        View view = this.f2108o;
        if (view != null) {
            onStopNestedScroll(view);
        }
        this.f2105l = false;
    }

    @Override // android.view.View
    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (!this.f2112s || this.f2113t == null) {
            return;
        }
        t0 t0Var = this.f2111r;
        int iL = t0Var != null ? t0Var.l() : 0;
        if (iL > 0) {
            this.f2113t.setBounds(0, 0, getWidth(), iL);
            this.f2113t.draw(canvas);
        }
    }

    @Override // android.view.ViewGroup
    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            U(true);
        }
        boolean zP = P(motionEvent, 0);
        if (actionMasked == 1 || actionMasked == 3) {
            U(true);
        }
        return zP;
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onLayout(boolean z10, int i10, int i11, int i12, int i13) {
        Behavior behaviorF;
        int iW = h0.w(this);
        int size = this.f2097a.size();
        for (int i14 = 0; i14 < size; i14++) {
            View view = this.f2097a.get(i14);
            if (view.getVisibility() != 8 && ((behaviorF = ((e) view.getLayoutParams()).f()) == null || !behaviorF.onLayoutChild(this, view, iW))) {
                M(view, iW);
            }
        }
    }

    /* JADX WARN: Code duplicated, block: B:40:0x00f3  */
    /* JADX WARN: Code duplicated, block: B:43:0x00fd  */
    /* JADX WARN: Code duplicated, block: B:46:0x011f  */
    @Override // android.view.View
    protected void onMeasure(int i10, int i11) {
        int i12;
        int iMax;
        int iMakeMeasureSpec;
        int iMakeMeasureSpec2;
        Behavior behaviorF;
        e eVar;
        int i13;
        int i14;
        int i15;
        int i16;
        int i17;
        int i18;
        Q();
        q();
        int paddingLeft = getPaddingLeft();
        int paddingTop = getPaddingTop();
        int paddingRight = getPaddingRight();
        int paddingBottom = getPaddingBottom();
        int iW = h0.w(this);
        boolean z10 = iW == 1;
        int mode = View.MeasureSpec.getMode(i10);
        int size = View.MeasureSpec.getSize(i10);
        int mode2 = View.MeasureSpec.getMode(i11);
        int size2 = View.MeasureSpec.getSize(i11);
        int i19 = paddingLeft + paddingRight;
        int i20 = paddingTop + paddingBottom;
        int suggestedMinimumWidth = getSuggestedMinimumWidth();
        int suggestedMinimumHeight = getSuggestedMinimumHeight();
        boolean z11 = this.f2111r != null && h0.t(this);
        int size3 = this.f2097a.size();
        int i21 = suggestedMinimumWidth;
        int i22 = suggestedMinimumHeight;
        int iCombineMeasuredStates = 0;
        int i23 = 0;
        while (i23 < size3) {
            View view = this.f2097a.get(i23);
            if (view.getVisibility() == 8) {
                i17 = i23;
                i14 = size3;
                i15 = paddingLeft;
            } else {
                e eVar2 = (e) view.getLayoutParams();
                int i24 = eVar2.f2124e;
                if (i24 < 0 || mode == 0) {
                    i12 = iCombineMeasuredStates;
                } else {
                    int iA = A(i24);
                    int iB = i.b(X(eVar2.f2122c), iW) & 7;
                    i12 = iCombineMeasuredStates;
                    if ((iB == 3 && !z10) || (iB == 5 && z10)) {
                        iMax = Math.max(0, (size - paddingRight) - iA);
                    } else if ((iB == 5 && !z10) || (iB == 3 && z10)) {
                        iMax = Math.max(0, iA - paddingLeft);
                    }
                    if (z11 || h0.t(view)) {
                        iMakeMeasureSpec = i10;
                        iMakeMeasureSpec2 = i11;
                    } else {
                        int iJ = this.f2111r.j() + this.f2111r.k();
                        int iL = this.f2111r.l() + this.f2111r.i();
                        iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(size - iJ, mode);
                        iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(size2 - iL, mode2);
                    }
                    behaviorF = eVar2.f();
                    if (behaviorF != null) {
                        eVar = eVar2;
                        i16 = i12;
                        i17 = i23;
                        i13 = i22;
                        i15 = paddingLeft;
                        i18 = i21;
                        i14 = size3;
                        if (!behaviorF.onMeasureChild(this, view, iMakeMeasureSpec, iMax, iMakeMeasureSpec2, 0)) {
                        }
                        e eVar3 = eVar;
                        int iMax2 = Math.max(i18, i19 + view.getMeasuredWidth() + ((ViewGroup.MarginLayoutParams) eVar3).leftMargin + ((ViewGroup.MarginLayoutParams) eVar3).rightMargin);
                        int iMax3 = Math.max(i13, i20 + view.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) eVar3).topMargin + ((ViewGroup.MarginLayoutParams) eVar3).bottomMargin);
                        iCombineMeasuredStates = View.combineMeasuredStates(i16, view.getMeasuredState());
                        i21 = iMax2;
                        i22 = iMax3;
                    } else {
                        eVar = eVar2;
                        i13 = i22;
                        i14 = size3;
                        i15 = paddingLeft;
                        i16 = i12;
                        i17 = i23;
                        i18 = i21;
                    }
                    N(view, iMakeMeasureSpec, iMax, iMakeMeasureSpec2, 0);
                    e eVar4 = eVar;
                    int iMax4 = Math.max(i18, i19 + view.getMeasuredWidth() + ((ViewGroup.MarginLayoutParams) eVar4).leftMargin + ((ViewGroup.MarginLayoutParams) eVar4).rightMargin);
                    int iMax5 = Math.max(i13, i20 + view.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) eVar4).topMargin + ((ViewGroup.MarginLayoutParams) eVar4).bottomMargin);
                    iCombineMeasuredStates = View.combineMeasuredStates(i16, view.getMeasuredState());
                    i21 = iMax4;
                    i22 = iMax5;
                }
                iMax = 0;
                if (z11) {
                    iMakeMeasureSpec = i10;
                    iMakeMeasureSpec2 = i11;
                } else {
                    iMakeMeasureSpec = i10;
                    iMakeMeasureSpec2 = i11;
                }
                behaviorF = eVar2.f();
                if (behaviorF != null) {
                    eVar = eVar2;
                    i16 = i12;
                    i17 = i23;
                    i13 = i22;
                    i15 = paddingLeft;
                    i18 = i21;
                    i14 = size3;
                    if (!behaviorF.onMeasureChild(this, view, iMakeMeasureSpec, iMax, iMakeMeasureSpec2, 0)) {
                    }
                    e eVar5 = eVar;
                    int iMax6 = Math.max(i18, i19 + view.getMeasuredWidth() + ((ViewGroup.MarginLayoutParams) eVar5).leftMargin + ((ViewGroup.MarginLayoutParams) eVar5).rightMargin);
                    int iMax7 = Math.max(i13, i20 + view.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) eVar5).topMargin + ((ViewGroup.MarginLayoutParams) eVar5).bottomMargin);
                    iCombineMeasuredStates = View.combineMeasuredStates(i16, view.getMeasuredState());
                    i21 = iMax6;
                    i22 = iMax7;
                } else {
                    eVar = eVar2;
                    i13 = i22;
                    i14 = size3;
                    i15 = paddingLeft;
                    i16 = i12;
                    i17 = i23;
                    i18 = i21;
                }
                N(view, iMakeMeasureSpec, iMax, iMakeMeasureSpec2, 0);
                e eVar6 = eVar;
                int iMax8 = Math.max(i18, i19 + view.getMeasuredWidth() + ((ViewGroup.MarginLayoutParams) eVar6).leftMargin + ((ViewGroup.MarginLayoutParams) eVar6).rightMargin);
                int iMax9 = Math.max(i13, i20 + view.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) eVar6).topMargin + ((ViewGroup.MarginLayoutParams) eVar6).bottomMargin);
                iCombineMeasuredStates = View.combineMeasuredStates(i16, view.getMeasuredState());
                i21 = iMax8;
                i22 = iMax9;
            }
            i23 = i17 + 1;
            paddingLeft = i15;
            size3 = i14;
        }
        int i25 = iCombineMeasuredStates;
        setMeasuredDimension(View.resolveSizeAndState(i21, i10, (-16777216) & i25), View.resolveSizeAndState(i22, i11, i25 << 16));
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public boolean onNestedFling(View view, float f10, float f11, boolean z10) {
        Behavior behaviorF;
        int childCount = getChildCount();
        boolean zOnNestedFling = false;
        for (int i10 = 0; i10 < childCount; i10++) {
            View childAt = getChildAt(i10);
            if (childAt.getVisibility() != 8) {
                e eVar = (e) childAt.getLayoutParams();
                if (eVar.j(0) && (behaviorF = eVar.f()) != null) {
                    zOnNestedFling |= behaviorF.onNestedFling(this, childAt, view, f10, f11, z10);
                }
            }
        }
        if (zOnNestedFling) {
            L(1);
        }
        return zOnNestedFling;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public boolean onNestedPreFling(View view, float f10, float f11) {
        Behavior behaviorF;
        int childCount = getChildCount();
        boolean zOnNestedPreFling = false;
        for (int i10 = 0; i10 < childCount; i10++) {
            View childAt = getChildAt(i10);
            if (childAt.getVisibility() != 8) {
                e eVar = (e) childAt.getLayoutParams();
                if (eVar.j(0) && (behaviorF = eVar.f()) != null) {
                    zOnNestedPreFling |= behaviorF.onNestedPreFling(this, childAt, view, f10, f11);
                }
            }
        }
        return zOnNestedPreFling;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void onNestedPreScroll(View view, int i10, int i11, int[] iArr) {
        j(view, i10, i11, iArr, 0);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void onNestedScroll(View view, int i10, int i11, int i12, int i13) {
        n(view, i10, i11, i12, i13, 0);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void onNestedScrollAccepted(View view, View view2, int i10) {
        h(view, view2, i10, 0);
    }

    @Override // android.view.View
    protected void onRestoreInstanceState(Parcelable parcelable) {
        Parcelable parcelable2;
        if (!(parcelable instanceof SavedState)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        SavedState savedState = (SavedState) parcelable;
        super.onRestoreInstanceState(savedState.getSuperState());
        SparseArray<Parcelable> sparseArray = savedState.f2117a;
        int childCount = getChildCount();
        for (int i10 = 0; i10 < childCount; i10++) {
            View childAt = getChildAt(i10);
            int id = childAt.getId();
            Behavior behaviorF = C(childAt).f();
            if (id != -1 && behaviorF != null && (parcelable2 = sparseArray.get(id)) != null) {
                behaviorF.onRestoreInstanceState(this, childAt, parcelable2);
            }
        }
    }

    @Override // android.view.View
    protected Parcelable onSaveInstanceState() {
        Parcelable parcelableOnSaveInstanceState;
        SavedState savedState = new SavedState(super.onSaveInstanceState());
        SparseArray<Parcelable> sparseArray = new SparseArray<>();
        int childCount = getChildCount();
        for (int i10 = 0; i10 < childCount; i10++) {
            View childAt = getChildAt(i10);
            int id = childAt.getId();
            Behavior behaviorF = ((e) childAt.getLayoutParams()).f();
            if (id != -1 && behaviorF != null && (parcelableOnSaveInstanceState = behaviorF.onSaveInstanceState(this, childAt)) != null) {
                sparseArray.append(id, parcelableOnSaveInstanceState);
            }
        }
        savedState.f2117a = sparseArray;
        return savedState;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public boolean onStartNestedScroll(View view, View view2, int i10) {
        return o(view, view2, i10, 0);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void onStopNestedScroll(View view) {
        i(view, 0);
    }

    /* JADX WARN: Code duplicated, block: B:14:0x0031  */
    /* JADX WARN: Code duplicated, block: B:15:0x0037 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:16:0x0039  */
    /* JADX WARN: Code duplicated, block: B:18:0x004c  */
    /* JADX WARN: Code duplicated, block: B:22:0x0054  */
    /* JADX WARN: Code duplicated, block: B:7:0x0015 A[PHI: r3
      0x0015: PHI (r3v4 boolean) = (r3v2 boolean), (r3v5 boolean) binds: [B:10:0x0024, B:5:0x0012] A[DONT_GENERATE, DONT_INLINE]] */
    @Override // android.view.View
    public boolean onTouchEvent(MotionEvent motionEvent) {
        boolean zP;
        boolean zOnTouchEvent;
        MotionEvent motionEventObtain;
        int actionMasked = motionEvent.getActionMasked();
        if (this.f2107n == null) {
            zP = P(motionEvent, 1);
            if (!zP) {
                zOnTouchEvent = false;
            }
            motionEventObtain = null;
            if (this.f2107n == null) {
                zOnTouchEvent |= super.onTouchEvent(motionEvent);
            } else if (zP) {
                long jUptimeMillis = SystemClock.uptimeMillis();
                motionEventObtain = MotionEvent.obtain(jUptimeMillis, jUptimeMillis, 3, 0.0f, 0.0f, 0);
                super.onTouchEvent(motionEventObtain);
            }
            if (motionEventObtain != null) {
                motionEventObtain.recycle();
            }
            if (actionMasked != 1 || actionMasked == 3) {
                U(false);
            }
            return zOnTouchEvent;
        }
        zP = false;
        Behavior behaviorF = ((e) this.f2107n.getLayoutParams()).f();
        if (behaviorF != null) {
            zOnTouchEvent = behaviorF.onTouchEvent(this, this.f2107n, motionEvent);
        } else {
            zOnTouchEvent = false;
        }
        motionEventObtain = null;
        if (this.f2107n == null) {
            zOnTouchEvent |= super.onTouchEvent(motionEvent);
        } else if (zP) {
            long jUptimeMillis2 = SystemClock.uptimeMillis();
            motionEventObtain = MotionEvent.obtain(jUptimeMillis2, jUptimeMillis2, 3, 0.0f, 0.0f, 0);
            super.onTouchEvent(motionEventObtain);
        }
        if (motionEventObtain != null) {
            motionEventObtain.recycle();
        }
        if (actionMasked != 1) {
            U(false);
        } else {
            U(false);
        }
        return zOnTouchEvent;
    }

    public void p(View view) {
        List listG = this.f2098b.g(view);
        if (listG == null || listG.isEmpty()) {
            return;
        }
        for (int i10 = 0; i10 < listG.size(); i10++) {
            View view2 = (View) listG.get(i10);
            Behavior behaviorF = ((e) view2.getLayoutParams()).f();
            if (behaviorF != null) {
                behaviorF.onDependentViewChanged(this, view2, view);
            }
        }
    }

    void q() {
        int childCount = getChildCount();
        boolean z10 = false;
        for (int i10 = 0; i10 < childCount; i10++) {
            if (E(getChildAt(i10))) {
                z10 = true;
                break;
            }
        }
        if (z10 != this.f2110q) {
            if (z10) {
                f();
            } else {
                T();
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.view.ViewGroup
    /* JADX INFO: renamed from: r, reason: merged with bridge method [inline-methods] */
    public e generateDefaultLayoutParams() {
        return new e(-2, -2);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public boolean requestChildRectangleOnScreen(View view, Rect rect, boolean z10) {
        Behavior behaviorF = ((e) view.getLayoutParams()).f();
        if (behaviorF == null || !behaviorF.onRequestChildRectangleOnScreen(this, view, rect, z10)) {
            return super.requestChildRectangleOnScreen(view, rect, z10);
        }
        return true;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void requestDisallowInterceptTouchEvent(boolean z10) {
        super.requestDisallowInterceptTouchEvent(z10);
        if (!z10 || this.f2104k) {
            return;
        }
        U(false);
        this.f2104k = true;
    }

    @Override // android.view.ViewGroup
    /* JADX INFO: renamed from: s, reason: merged with bridge method [inline-methods] */
    public e generateLayoutParams(AttributeSet attributeSet) {
        return new e(getContext(), attributeSet);
    }

    @Override // android.view.View
    public void setFitsSystemWindows(boolean z10) {
        super.setFitsSystemWindows(z10);
        b0();
    }

    @Override // android.view.ViewGroup
    public void setOnHierarchyChangeListener(ViewGroup.OnHierarchyChangeListener onHierarchyChangeListener) {
        this.f2114u = onHierarchyChangeListener;
    }

    public void setStatusBarBackground(Drawable drawable) {
        Drawable drawable2 = this.f2113t;
        if (drawable2 != drawable) {
            if (drawable2 != null) {
                drawable2.setCallback(null);
            }
            Drawable drawableMutate = drawable != null ? drawable.mutate() : null;
            this.f2113t = drawableMutate;
            if (drawableMutate != null) {
                if (drawableMutate.isStateful()) {
                    this.f2113t.setState(getDrawableState());
                }
                androidx.core.graphics.drawable.a.m(this.f2113t, h0.w(this));
                this.f2113t.setVisible(getVisibility() == 0, false);
                this.f2113t.setCallback(this);
            }
            h0.b0(this);
        }
    }

    public void setStatusBarBackgroundColor(int i10) {
        setStatusBarBackground(new ColorDrawable(i10));
    }

    public void setStatusBarBackgroundResource(int i10) {
        setStatusBarBackground(i10 != 0 ? androidx.core.content.a.e(getContext(), i10) : null);
    }

    @Override // android.view.View
    public void setVisibility(int i10) {
        super.setVisibility(i10);
        boolean z10 = i10 == 0;
        Drawable drawable = this.f2113t;
        if (drawable == null || drawable.isVisible() == z10) {
            return;
        }
        this.f2113t.setVisible(z10, false);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.view.ViewGroup
    /* JADX INFO: renamed from: t, reason: merged with bridge method [inline-methods] */
    public e generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        if (layoutParams instanceof e) {
            return new e((e) layoutParams);
        }
        return layoutParams instanceof ViewGroup.MarginLayoutParams ? new e((ViewGroup.MarginLayoutParams) layoutParams) : new e(layoutParams);
    }

    void u(View view, boolean z10, Rect rect) {
        if (view.isLayoutRequested() || view.getVisibility() == 8) {
            rect.setEmpty();
        } else if (z10) {
            x(view, rect);
        } else {
            rect.set(view.getLeft(), view.getTop(), view.getRight(), view.getBottom());
        }
    }

    public List<View> v(View view) {
        List<View> listH = this.f2098b.h(view);
        this.f2100g.clear();
        if (listH != null) {
            this.f2100g.addAll(listH);
        }
        return this.f2100g;
    }

    @Override // android.view.View
    protected boolean verifyDrawable(Drawable drawable) {
        return super.verifyDrawable(drawable) || drawable == this.f2113t;
    }

    public List<View> w(View view) {
        List listG = this.f2098b.g(view);
        this.f2100g.clear();
        if (listG != null) {
            this.f2100g.addAll(listG);
        }
        return this.f2100g;
    }

    void x(View view, Rect rect) {
        androidx.coordinatorlayout.widget.b.a(this, view, rect);
    }

    void y(View view, int i10, Rect rect, Rect rect2) {
        e eVar = (e) view.getLayoutParams();
        int measuredWidth = view.getMeasuredWidth();
        int measuredHeight = view.getMeasuredHeight();
        z(view, i10, rect, rect2, eVar, measuredWidth, measuredHeight);
        k(eVar, rect2, measuredWidth, measuredHeight);
    }

    public CoordinatorLayout(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R$attr.coordinatorLayoutStyle);
    }

    public CoordinatorLayout(Context context, AttributeSet attributeSet, int i10) {
        TypedArray typedArrayObtainStyledAttributes;
        super(context, attributeSet, i10);
        this.f2097a = new ArrayList();
        this.f2098b = new androidx.coordinatorlayout.widget.a<>();
        this.f2099c = new ArrayList();
        this.f2100g = new ArrayList();
        this.f2102i = new int[2];
        this.f2103j = new int[2];
        this.f2116w = new w(this);
        if (i10 == 0) {
            typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R$styleable.CoordinatorLayout, 0, R$style.Widget_Support_CoordinatorLayout);
        } else {
            typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R$styleable.CoordinatorLayout, i10, 0);
        }
        if (i10 == 0) {
            saveAttributeDataForStyleable(context, R$styleable.CoordinatorLayout, attributeSet, typedArrayObtainStyledAttributes, 0, R$style.Widget_Support_CoordinatorLayout);
        } else {
            saveAttributeDataForStyleable(context, R$styleable.CoordinatorLayout, attributeSet, typedArrayObtainStyledAttributes, i10, 0);
        }
        int resourceId = typedArrayObtainStyledAttributes.getResourceId(R$styleable.CoordinatorLayout_keylines, 0);
        if (resourceId != 0) {
            Resources resources = context.getResources();
            this.f2106m = resources.getIntArray(resourceId);
            float f10 = resources.getDisplayMetrics().density;
            int length = this.f2106m.length;
            for (int i11 = 0; i11 < length; i11++) {
                int[] iArr = this.f2106m;
                iArr[i11] = (int) (iArr[i11] * f10);
            }
        }
        this.f2113t = typedArrayObtainStyledAttributes.getDrawable(R$styleable.CoordinatorLayout_statusBarBackground);
        typedArrayObtainStyledAttributes.recycle();
        b0();
        super.setOnHierarchyChangeListener(new d());
        if (h0.u(this) == 0) {
            h0.w0(this, 1);
        }
    }

    protected static class SavedState extends AbsSavedState {
        public static final Parcelable.Creator<SavedState> CREATOR = new a();

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        SparseArray<Parcelable> f2117a;

        static class a implements Parcelable.ClassLoaderCreator<SavedState> {
            a() {
            }

            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public SavedState createFromParcel(Parcel parcel) {
                return new SavedState(parcel, null);
            }

            @Override // android.os.Parcelable.ClassLoaderCreator
            /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
            public SavedState createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new SavedState(parcel, classLoader);
            }

            @Override // android.os.Parcelable.Creator
            /* JADX INFO: renamed from: c, reason: merged with bridge method [inline-methods] */
            public SavedState[] newArray(int i10) {
                return new SavedState[i10];
            }
        }

        public SavedState(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            int i10 = parcel.readInt();
            int[] iArr = new int[i10];
            parcel.readIntArray(iArr);
            Parcelable[] parcelableArray = parcel.readParcelableArray(classLoader);
            this.f2117a = new SparseArray<>(i10);
            for (int i11 = 0; i11 < i10; i11++) {
                this.f2117a.append(iArr[i11], parcelableArray[i11]);
            }
        }

        @Override // androidx.customview.view.AbsSavedState, android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i10) {
            super.writeToParcel(parcel, i10);
            SparseArray<Parcelable> sparseArray = this.f2117a;
            int size = sparseArray != null ? sparseArray.size() : 0;
            parcel.writeInt(size);
            int[] iArr = new int[size];
            Parcelable[] parcelableArr = new Parcelable[size];
            for (int i11 = 0; i11 < size; i11++) {
                iArr[i11] = this.f2117a.keyAt(i11);
                parcelableArr[i11] = this.f2117a.valueAt(i11);
            }
            parcel.writeIntArray(iArr);
            parcel.writeParcelableArray(parcelableArr, i10);
        }

        public SavedState(Parcelable parcelable) {
            super(parcelable);
        }
    }

    public static class e extends ViewGroup.MarginLayoutParams {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        Behavior f2120a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        boolean f2121b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        public int f2122c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        public int f2123d;

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        public int f2124e;

        /* JADX INFO: renamed from: f, reason: collision with root package name */
        int f2125f;

        /* JADX INFO: renamed from: g, reason: collision with root package name */
        public int f2126g;

        /* JADX INFO: renamed from: h, reason: collision with root package name */
        public int f2127h;

        /* JADX INFO: renamed from: i, reason: collision with root package name */
        int f2128i;

        /* JADX INFO: renamed from: j, reason: collision with root package name */
        int f2129j;

        /* JADX INFO: renamed from: k, reason: collision with root package name */
        View f2130k;

        /* JADX INFO: renamed from: l, reason: collision with root package name */
        View f2131l;

        /* JADX INFO: renamed from: m, reason: collision with root package name */
        private boolean f2132m;

        /* JADX INFO: renamed from: n, reason: collision with root package name */
        private boolean f2133n;

        /* JADX INFO: renamed from: o, reason: collision with root package name */
        private boolean f2134o;

        /* JADX INFO: renamed from: p, reason: collision with root package name */
        private boolean f2135p;

        /* JADX INFO: renamed from: q, reason: collision with root package name */
        final Rect f2136q;

        /* JADX INFO: renamed from: r, reason: collision with root package name */
        Object f2137r;

        public e(int i10, int i11) {
            super(i10, i11);
            this.f2121b = false;
            this.f2122c = 0;
            this.f2123d = 0;
            this.f2124e = -1;
            this.f2125f = -1;
            this.f2126g = 0;
            this.f2127h = 0;
            this.f2136q = new Rect();
        }

        private void n(View view, CoordinatorLayout coordinatorLayout) {
            View viewFindViewById = coordinatorLayout.findViewById(this.f2125f);
            this.f2130k = viewFindViewById;
            if (viewFindViewById == null) {
                if (coordinatorLayout.isInEditMode()) {
                    this.f2131l = null;
                    this.f2130k = null;
                    return;
                }
                throw new IllegalStateException("Could not find CoordinatorLayout descendant view with id " + coordinatorLayout.getResources().getResourceName(this.f2125f) + " to anchor view " + view);
            }
            if (viewFindViewById == coordinatorLayout) {
                if (!coordinatorLayout.isInEditMode()) {
                    throw new IllegalStateException("View can not be anchored to the the parent CoordinatorLayout");
                }
                this.f2131l = null;
                this.f2130k = null;
                return;
            }
            for (ViewParent parent = viewFindViewById.getParent(); parent != coordinatorLayout && parent != null; parent = parent.getParent()) {
                if (parent == view) {
                    if (!coordinatorLayout.isInEditMode()) {
                        throw new IllegalStateException("Anchor must not be a descendant of the anchored view");
                    }
                    this.f2131l = null;
                    this.f2130k = null;
                    return;
                }
                if (parent instanceof View) {
                    viewFindViewById = parent;
                }
            }
            this.f2131l = viewFindViewById;
        }

        private boolean s(View view, int i10) {
            int iB = i.b(((e) view.getLayoutParams()).f2126g, i10);
            return iB != 0 && (i.b(this.f2127h, i10) & iB) == iB;
        }

        private boolean t(View view, CoordinatorLayout coordinatorLayout) {
            if (this.f2130k.getId() != this.f2125f) {
                return false;
            }
            View view2 = this.f2130k;
            for (ViewParent parent = view2.getParent(); parent != coordinatorLayout; parent = parent.getParent()) {
                if (parent == null || parent == view) {
                    this.f2131l = null;
                    this.f2130k = null;
                    return false;
                }
                if (parent instanceof View) {
                    view2 = parent;
                }
            }
            this.f2131l = view2;
            return true;
        }

        boolean a() {
            return this.f2130k == null && this.f2125f != -1;
        }

        boolean b(CoordinatorLayout coordinatorLayout, View view, View view2) {
            Behavior behavior;
            return view2 == this.f2131l || s(view2, h0.w(coordinatorLayout)) || ((behavior = this.f2120a) != null && behavior.layoutDependsOn(coordinatorLayout, view, view2));
        }

        boolean c() {
            if (this.f2120a == null) {
                this.f2132m = false;
            }
            return this.f2132m;
        }

        View d(CoordinatorLayout coordinatorLayout, View view) {
            if (this.f2125f == -1) {
                this.f2131l = null;
                this.f2130k = null;
                return null;
            }
            if (this.f2130k == null || !t(view, coordinatorLayout)) {
                n(view, coordinatorLayout);
            }
            return this.f2130k;
        }

        public int e() {
            return this.f2125f;
        }

        public Behavior f() {
            return this.f2120a;
        }

        boolean g() {
            return this.f2135p;
        }

        Rect h() {
            return this.f2136q;
        }

        boolean i(CoordinatorLayout coordinatorLayout, View view) {
            boolean z10 = this.f2132m;
            if (z10) {
                return true;
            }
            Behavior behavior = this.f2120a;
            boolean zBlocksInteractionBelow = (behavior != null ? behavior.blocksInteractionBelow(coordinatorLayout, view) : false) | z10;
            this.f2132m = zBlocksInteractionBelow;
            return zBlocksInteractionBelow;
        }

        boolean j(int i10) {
            if (i10 == 0) {
                return this.f2133n;
            }
            if (i10 != 1) {
                return false;
            }
            return this.f2134o;
        }

        void k() {
            this.f2135p = false;
        }

        void l(int i10) {
            r(i10, false);
        }

        void m() {
            this.f2132m = false;
        }

        public void o(Behavior behavior) {
            Behavior behavior2 = this.f2120a;
            if (behavior2 != behavior) {
                if (behavior2 != null) {
                    behavior2.onDetachedFromLayoutParams();
                }
                this.f2120a = behavior;
                this.f2137r = null;
                this.f2121b = true;
                if (behavior != null) {
                    behavior.onAttachedToLayoutParams(this);
                }
            }
        }

        void p(boolean z10) {
            this.f2135p = z10;
        }

        void q(Rect rect) {
            this.f2136q.set(rect);
        }

        void r(int i10, boolean z10) {
            if (i10 == 0) {
                this.f2133n = z10;
            } else {
                if (i10 != 1) {
                    return;
                }
                this.f2134o = z10;
            }
        }

        e(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            this.f2121b = false;
            this.f2122c = 0;
            this.f2123d = 0;
            this.f2124e = -1;
            this.f2125f = -1;
            this.f2126g = 0;
            this.f2127h = 0;
            this.f2136q = new Rect();
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R$styleable.CoordinatorLayout_Layout);
            this.f2122c = typedArrayObtainStyledAttributes.getInteger(R$styleable.CoordinatorLayout_Layout_android_layout_gravity, 0);
            this.f2125f = typedArrayObtainStyledAttributes.getResourceId(R$styleable.CoordinatorLayout_Layout_layout_anchor, -1);
            this.f2123d = typedArrayObtainStyledAttributes.getInteger(R$styleable.CoordinatorLayout_Layout_layout_anchorGravity, 0);
            this.f2124e = typedArrayObtainStyledAttributes.getInteger(R$styleable.CoordinatorLayout_Layout_layout_keyline, -1);
            this.f2126g = typedArrayObtainStyledAttributes.getInt(R$styleable.CoordinatorLayout_Layout_layout_insetEdge, 0);
            this.f2127h = typedArrayObtainStyledAttributes.getInt(R$styleable.CoordinatorLayout_Layout_layout_dodgeInsetEdges, 0);
            int i10 = R$styleable.CoordinatorLayout_Layout_layout_behavior;
            boolean zHasValue = typedArrayObtainStyledAttributes.hasValue(i10);
            this.f2121b = zHasValue;
            if (zHasValue) {
                this.f2120a = CoordinatorLayout.O(context, attributeSet, typedArrayObtainStyledAttributes.getString(i10));
            }
            typedArrayObtainStyledAttributes.recycle();
            Behavior behavior = this.f2120a;
            if (behavior != null) {
                behavior.onAttachedToLayoutParams(this);
            }
        }

        public e(e eVar) {
            super((ViewGroup.MarginLayoutParams) eVar);
            this.f2121b = false;
            this.f2122c = 0;
            this.f2123d = 0;
            this.f2124e = -1;
            this.f2125f = -1;
            this.f2126g = 0;
            this.f2127h = 0;
            this.f2136q = new Rect();
        }

        public e(ViewGroup.MarginLayoutParams marginLayoutParams) {
            super(marginLayoutParams);
            this.f2121b = false;
            this.f2122c = 0;
            this.f2123d = 0;
            this.f2124e = -1;
            this.f2125f = -1;
            this.f2126g = 0;
            this.f2127h = 0;
            this.f2136q = new Rect();
        }

        public e(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
            this.f2121b = false;
            this.f2122c = 0;
            this.f2123d = 0;
            this.f2124e = -1;
            this.f2125f = -1;
            this.f2126g = 0;
            this.f2127h = 0;
            this.f2136q = new Rect();
        }
    }
}
