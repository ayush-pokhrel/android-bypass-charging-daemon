package androidx.coordinatorlayout;

/* JADX INFO: loaded from: classes.dex */
public final class R$drawable {
    public static final int notification_action_background = 2131231659;
    public static final int notification_bg = 2131231660;
    public static final int notification_bg_low = 2131231661;
    public static final int notification_bg_low_normal = 2131231662;
    public static final int notification_bg_low_pressed = 2131231663;
    public static final int notification_bg_normal = 2131231664;
    public static final int notification_bg_normal_pressed = 2131231665;
    public static final int notification_icon_background = 2131231666;
    public static final int notification_template_icon_bg = 2131231669;
    public static final int notification_template_icon_low_bg = 2131231670;
    public static final int notification_tile_bg = 2131231671;
    public static final int notify_panel_notification_icon_bg = 2131231672;

    private R$drawable() {
    }
}
