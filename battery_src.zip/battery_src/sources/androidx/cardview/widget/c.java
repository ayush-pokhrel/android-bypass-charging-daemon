package androidx.cardview.widget;

import android.content.Context;
import android.content.res.ColorStateList;

/* JADX INFO: compiled from: CardViewImpl.java */
/* JADX INFO: loaded from: classes.dex */
interface c {
    void a();

    float b(b bVar);

    ColorStateList c(b bVar);

    void d(b bVar, Context context, ColorStateList colorStateList, float f10, float f11, float f12);

    void e(b bVar, float f10);

    float f(b bVar);

    void g(b bVar);

    float h(b bVar);

    float i(b bVar);

    float j(b bVar);

    void k(b bVar);

    void l(b bVar, float f10);

    void m(b bVar);

    void n(b bVar, ColorStateList colorStateList);

    void o(b bVar, float f10);
}
