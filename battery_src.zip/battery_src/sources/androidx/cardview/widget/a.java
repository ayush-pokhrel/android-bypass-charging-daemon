package androidx.cardview.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.view.View;

/* JADX INFO: compiled from: CardViewApi21Impl.java */
/* JADX INFO: loaded from: classes.dex */
class a implements c {
    a() {
    }

    private d p(b bVar) {
        return (d) bVar.f();
    }

    @Override // androidx.cardview.widget.c
    public float b(b bVar) {
        return p(bVar).c();
    }

    @Override // androidx.cardview.widget.c
    public ColorStateList c(b bVar) {
        return p(bVar).b();
    }

    @Override // androidx.cardview.widget.c
    public void d(b bVar, Context context, ColorStateList colorStateList, float f10, float f11, float f12) {
        bVar.c(new d(colorStateList, f10));
        View viewB = bVar.b();
        viewB.setClipToOutline(true);
        viewB.setElevation(f11);
        o(bVar, f12);
    }

    @Override // androidx.cardview.widget.c
    public void e(b bVar, float f10) {
        p(bVar).h(f10);
    }

    @Override // androidx.cardview.widget.c
    public float f(b bVar) {
        return bVar.b().getElevation();
    }

    @Override // androidx.cardview.widget.c
    public void g(b bVar) {
        if (!bVar.e()) {
            bVar.a(0, 0, 0, 0);
            return;
        }
        float fB = b(bVar);
        float fH = h(bVar);
        int iCeil = (int) Math.ceil(e.a(fB, fH, bVar.d()));
        int iCeil2 = (int) Math.ceil(e.b(fB, fH, bVar.d()));
        bVar.a(iCeil, iCeil2, iCeil, iCeil2);
    }

    @Override // androidx.cardview.widget.c
    public float h(b bVar) {
        return p(bVar).d();
    }

    @Override // androidx.cardview.widget.c
    public float i(b bVar) {
        return h(bVar) * 2.0f;
    }

    @Override // androidx.cardview.widget.c
    public float j(b bVar) {
        return h(bVar) * 2.0f;
    }

    @Override // androidx.cardview.widget.c
    public void k(b bVar) {
        o(bVar, b(bVar));
    }

    @Override // androidx.cardview.widget.c
    public void l(b bVar, float f10) {
        bVar.b().setElevation(f10);
    }

    @Override // androidx.cardview.widget.c
    public void m(b bVar) {
        o(bVar, b(bVar));
    }

    @Override // androidx.cardview.widget.c
    public void n(b bVar, ColorStateList colorStateList) {
        p(bVar).f(colorStateList);
    }

    @Override // androidx.cardview.widget.c
    public void o(b bVar, float f10) {
        p(bVar).g(f10, bVar.e(), bVar.d());
        g(bVar);
    }

    @Override // androidx.cardview.widget.c
    public void a() {
    }
}
