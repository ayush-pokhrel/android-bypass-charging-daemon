package androidx.cardview;

/* JADX INFO: loaded from: classes.dex */
public final class R$color {
    public static final int cardview_dark_background = 2131099856;
    public static final int cardview_light_background = 2131099857;
    public static final int cardview_shadow_end_color = 2131099858;
    public static final int cardview_shadow_start_color = 2131099859;

    private R$color() {
    }
}
