package androidx.cardview;

/* JADX INFO: loaded from: classes.dex */
public final class R$dimen {
    public static final int cardview_compat_inset_shadow = 2131165324;
    public static final int cardview_default_elevation = 2131165325;
    public static final int cardview_default_radius = 2131165326;

    private R$dimen() {
    }
}
