package androidx.cardview;

/* JADX INFO: loaded from: classes.dex */
public final class R$style {
    public static final int Base_CardView = 2131886138;
    public static final int CardView = 2131886590;
    public static final int CardView_Dark = 2131886591;
    public static final int CardView_Light = 2131886592;

    private R$style() {
    }
}
