package androidx.cardview;

/* JADX INFO: loaded from: classes.dex */
public final class R$attr {
    public static final int cardBackgroundColor = 2130968783;
    public static final int cardCornerRadius = 2130968784;
    public static final int cardElevation = 2130968785;
    public static final int cardMaxElevation = 2130968791;
    public static final int cardPreventCornerOverlap = 2130968794;
    public static final int cardUseCompatPadding = 2130968795;
    public static final int cardViewStyle = 2130968796;
    public static final int contentPadding = 2130968956;
    public static final int contentPaddingBottom = 2130968957;
    public static final int contentPaddingLeft = 2130968959;
    public static final int contentPaddingRight = 2130968960;
    public static final int contentPaddingTop = 2130968962;

    private R$attr() {
    }
}
