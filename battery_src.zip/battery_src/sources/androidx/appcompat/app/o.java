package androidx.appcompat.app;

import android.annotation.SuppressLint;
import android.content.Context;
import android.location.Location;
import android.location.LocationManager;
import android.util.Log;
import java.util.Calendar;

/* JADX INFO: compiled from: TwilightManager.java */
/* JADX INFO: loaded from: classes.dex */
class o {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private static o f493d;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final Context f494a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private final LocationManager f495b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private final a f496c = new a();

    /* JADX INFO: compiled from: TwilightManager.java */
    private static class a {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        boolean f497a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        long f498b;

        a() {
        }
    }

    o(Context context, LocationManager locationManager) {
        this.f494a = context;
        this.f495b = locationManager;
    }

    static o a(Context context) {
        if (f493d == null) {
            Context applicationContext = context.getApplicationContext();
            f493d = new o(applicationContext, (LocationManager) applicationContext.getSystemService("location"));
        }
        return f493d;
    }

    @SuppressLint({"MissingPermission"})
    private Location b() {
        Location locationC = androidx.core.content.b.b(this.f494a, "android.permission.ACCESS_COARSE_LOCATION") == 0 ? c("network") : null;
        Location locationC2 = androidx.core.content.b.b(this.f494a, "android.permission.ACCESS_FINE_LOCATION") == 0 ? c("gps") : null;
        if (locationC2 == null || locationC == null) {
            return locationC2 != null ? locationC2 : locationC;
        }
        return locationC2.getTime() > locationC.getTime() ? locationC2 : locationC;
    }

    private Location c(String str) {
        try {
            if (this.f495b.isProviderEnabled(str)) {
                return this.f495b.getLastKnownLocation(str);
            }
            return null;
        } catch (Exception e10) {
            Log.d("TwilightManager", "Failed to get last known location", e10);
            return null;
        }
    }

    private boolean e() {
        return this.f496c.f498b > System.currentTimeMillis();
    }

    private void f(Location location) {
        long j10;
        a aVar = this.f496c;
        long jCurrentTimeMillis = System.currentTimeMillis();
        n nVarB = n.b();
        nVarB.a(jCurrentTimeMillis - 86400000, location.getLatitude(), location.getLongitude());
        nVarB.a(jCurrentTimeMillis, location.getLatitude(), location.getLongitude());
        boolean z10 = nVarB.f492c == 1;
        long j11 = nVarB.f491b;
        long j12 = nVarB.f490a;
        nVarB.a(jCurrentTimeMillis + 86400000, location.getLatitude(), location.getLongitude());
        long j13 = nVarB.f491b;
        if (j11 == -1 || j12 == -1) {
            j10 = jCurrentTimeMillis + 43200000;
        } else {
            if (jCurrentTimeMillis > j12) {
                j11 = j13;
            } else if (jCurrentTimeMillis > j11) {
                j11 = j12;
            }
            j10 = j11 + 60000;
        }
        aVar.f497a = z10;
        aVar.f498b = j10;
    }

    boolean d() {
        a aVar = this.f496c;
        if (e()) {
            return aVar.f497a;
        }
        Location locationB = b();
        if (locationB != null) {
            f(locationB);
            return aVar.f497a;
        }
        Log.i("TwilightManager", "Could not get last known location. This is probably because the app does not have any location permissions. Falling back to hardcoded sunrise/sunset values.");
        int i10 = Calendar.getInstance().get(11);
        return i10 < 6 || i10 >= 22;
    }
}
