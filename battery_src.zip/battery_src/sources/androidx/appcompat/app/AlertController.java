package androidx.appcompat.app;

import android.R;
import android.content.Context;
import android.content.DialogInterface;
import android.content.res.TypedArray;
import android.database.Cursor;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.ViewStub;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckedTextView;
import android.widget.CursorAdapter;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;
import androidx.appcompat.R$attr;
import androidx.appcompat.R$id;
import androidx.appcompat.R$styleable;
import androidx.appcompat.widget.LinearLayoutCompat;
import androidx.core.view.h0;
import androidx.core.widget.NestedScrollView;
import java.lang.ref.WeakReference;

/* JADX INFO: loaded from: classes.dex */
class AlertController {
    NestedScrollView A;
    private Drawable C;
    private ImageView D;
    private TextView E;
    private TextView F;
    private View G;
    ListAdapter H;
    private int J;
    private int K;
    int L;
    int M;
    int N;
    int O;
    private boolean P;
    Handler R;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final Context f298a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    final h f299b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private final Window f300c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private final int f301d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private CharSequence f302e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private CharSequence f303f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    ListView f304g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private View f305h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private int f306i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private int f307j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    private int f308k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private int f309l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    private int f310m;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    Button f312o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    private CharSequence f313p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    Message f314q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    private Drawable f315r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    Button f316s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    private CharSequence f317t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    Message f318u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    private Drawable f319v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    Button f320w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    private CharSequence f321x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    Message f322y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    private Drawable f323z;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    private boolean f311n = false;
    private int B = 0;
    int I = -1;
    private int Q = 0;
    private final View.OnClickListener S = new a();

    public static class RecycleListView extends ListView {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private final int f324a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private final int f325b;

        public RecycleListView(Context context) {
            this(context, null);
        }

        public void a(boolean z10, boolean z11) {
            if (z11 && z10) {
                return;
            }
            setPadding(getPaddingLeft(), z10 ? getPaddingTop() : this.f324a, getPaddingRight(), z11 ? getPaddingBottom() : this.f325b);
        }

        public RecycleListView(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R$styleable.RecycleListView);
            this.f325b = typedArrayObtainStyledAttributes.getDimensionPixelOffset(R$styleable.RecycleListView_paddingBottomNoButtons, -1);
            this.f324a = typedArrayObtainStyledAttributes.getDimensionPixelOffset(R$styleable.RecycleListView_paddingTopNoTitle, -1);
        }
    }

    class a implements View.OnClickListener {
        a() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            Message messageObtain;
            Message message;
            Message message2;
            Message message3;
            AlertController alertController = AlertController.this;
            if (view == alertController.f312o && (message3 = alertController.f314q) != null) {
                messageObtain = Message.obtain(message3);
            } else if (view != alertController.f316s || (message2 = alertController.f318u) == null) {
                messageObtain = (view != alertController.f320w || (message = alertController.f322y) == null) ? null : Message.obtain(message);
            } else {
                messageObtain = Message.obtain(message2);
            }
            if (messageObtain != null) {
                messageObtain.sendToTarget();
            }
            AlertController alertController2 = AlertController.this;
            alertController2.R.obtainMessage(1, alertController2.f299b).sendToTarget();
        }
    }

    public static class b {
        public int A;
        public int B;
        public int C;
        public int D;
        public boolean[] F;
        public boolean G;
        public boolean H;
        public DialogInterface.OnMultiChoiceClickListener J;
        public Cursor K;
        public String L;
        public String M;
        public AdapterView.OnItemSelectedListener N;

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final Context f327a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public final LayoutInflater f328b;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        public Drawable f330d;

        /* JADX INFO: renamed from: f, reason: collision with root package name */
        public CharSequence f332f;

        /* JADX INFO: renamed from: g, reason: collision with root package name */
        public View f333g;

        /* JADX INFO: renamed from: h, reason: collision with root package name */
        public CharSequence f334h;

        /* JADX INFO: renamed from: i, reason: collision with root package name */
        public CharSequence f335i;

        /* JADX INFO: renamed from: j, reason: collision with root package name */
        public Drawable f336j;

        /* JADX INFO: renamed from: k, reason: collision with root package name */
        public DialogInterface.OnClickListener f337k;

        /* JADX INFO: renamed from: l, reason: collision with root package name */
        public CharSequence f338l;

        /* JADX INFO: renamed from: m, reason: collision with root package name */
        public Drawable f339m;

        /* JADX INFO: renamed from: n, reason: collision with root package name */
        public DialogInterface.OnClickListener f340n;

        /* JADX INFO: renamed from: o, reason: collision with root package name */
        public CharSequence f341o;

        /* JADX INFO: renamed from: p, reason: collision with root package name */
        public Drawable f342p;

        /* JADX INFO: renamed from: q, reason: collision with root package name */
        public DialogInterface.OnClickListener f343q;

        /* JADX INFO: renamed from: s, reason: collision with root package name */
        public DialogInterface.OnCancelListener f345s;

        /* JADX INFO: renamed from: t, reason: collision with root package name */
        public DialogInterface.OnDismissListener f346t;

        /* JADX INFO: renamed from: u, reason: collision with root package name */
        public DialogInterface.OnKeyListener f347u;

        /* JADX INFO: renamed from: v, reason: collision with root package name */
        public CharSequence[] f348v;

        /* JADX INFO: renamed from: w, reason: collision with root package name */
        public ListAdapter f349w;

        /* JADX INFO: renamed from: x, reason: collision with root package name */
        public DialogInterface.OnClickListener f350x;

        /* JADX INFO: renamed from: y, reason: collision with root package name */
        public int f351y;

        /* JADX INFO: renamed from: z, reason: collision with root package name */
        public View f352z;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        public int f329c = 0;

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        public int f331e = 0;
        public boolean E = false;
        public int I = -1;
        public boolean O = true;

        /* JADX INFO: renamed from: r, reason: collision with root package name */
        public boolean f344r = true;

        class a extends ArrayAdapter<CharSequence> {

            /* JADX INFO: renamed from: a, reason: collision with root package name */
            final /* synthetic */ RecycleListView f353a;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            a(Context context, int i10, int i11, CharSequence[] charSequenceArr, RecycleListView recycleListView) {
                super(context, i10, i11, charSequenceArr);
                this.f353a = recycleListView;
            }

            @Override // android.widget.ArrayAdapter, android.widget.Adapter
            public View getView(int i10, View view, ViewGroup viewGroup) {
                View view2 = super.getView(i10, view, viewGroup);
                boolean[] zArr = b.this.F;
                if (zArr != null && zArr[i10]) {
                    this.f353a.setItemChecked(i10, true);
                }
                return view2;
            }
        }

        /* JADX INFO: renamed from: androidx.appcompat.app.AlertController$b$b, reason: collision with other inner class name */
        class C0004b extends CursorAdapter {

            /* JADX INFO: renamed from: a, reason: collision with root package name */
            private final int f355a;

            /* JADX INFO: renamed from: b, reason: collision with root package name */
            private final int f356b;

            /* JADX INFO: renamed from: c, reason: collision with root package name */
            final /* synthetic */ RecycleListView f357c;

            /* JADX INFO: renamed from: g, reason: collision with root package name */
            final /* synthetic */ AlertController f358g;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            C0004b(Context context, Cursor cursor, boolean z10, RecycleListView recycleListView, AlertController alertController) {
                super(context, cursor, z10);
                this.f357c = recycleListView;
                this.f358g = alertController;
                Cursor cursor2 = getCursor();
                this.f355a = cursor2.getColumnIndexOrThrow(b.this.L);
                this.f356b = cursor2.getColumnIndexOrThrow(b.this.M);
            }

            @Override // android.widget.CursorAdapter
            public void bindView(View view, Context context, Cursor cursor) {
                ((CheckedTextView) view.findViewById(R.id.text1)).setText(cursor.getString(this.f355a));
                this.f357c.setItemChecked(cursor.getPosition(), cursor.getInt(this.f356b) == 1);
            }

            @Override // android.widget.CursorAdapter
            public View newView(Context context, Cursor cursor, ViewGroup viewGroup) {
                return b.this.f328b.inflate(this.f358g.M, viewGroup, false);
            }
        }

        class c implements AdapterView.OnItemClickListener {

            /* JADX INFO: renamed from: a, reason: collision with root package name */
            final /* synthetic */ AlertController f360a;

            c(AlertController alertController) {
                this.f360a = alertController;
            }

            @Override // android.widget.AdapterView.OnItemClickListener
            public void onItemClick(AdapterView<?> adapterView, View view, int i10, long j10) {
                b.this.f350x.onClick(this.f360a.f299b, i10);
                if (b.this.H) {
                    return;
                }
                this.f360a.f299b.dismiss();
            }
        }

        class d implements AdapterView.OnItemClickListener {

            /* JADX INFO: renamed from: a, reason: collision with root package name */
            final /* synthetic */ RecycleListView f362a;

            /* JADX INFO: renamed from: b, reason: collision with root package name */
            final /* synthetic */ AlertController f363b;

            d(RecycleListView recycleListView, AlertController alertController) {
                this.f362a = recycleListView;
                this.f363b = alertController;
            }

            @Override // android.widget.AdapterView.OnItemClickListener
            public void onItemClick(AdapterView<?> adapterView, View view, int i10, long j10) {
                boolean[] zArr = b.this.F;
                if (zArr != null) {
                    zArr[i10] = this.f362a.isItemChecked(i10);
                }
                b.this.J.onClick(this.f363b.f299b, i10, this.f362a.isItemChecked(i10));
            }
        }

        public b(Context context) {
            this.f327a = context;
            this.f328b = (LayoutInflater) context.getSystemService("layout_inflater");
        }

        private void b(AlertController alertController) {
            ListAdapter dVar;
            RecycleListView recycleListView = (RecycleListView) this.f328b.inflate(alertController.L, (ViewGroup) null);
            if (this.G) {
                dVar = this.K == null ? new a(this.f327a, alertController.M, R.id.text1, this.f348v, recycleListView) : new C0004b(this.f327a, this.K, false, recycleListView, alertController);
            } else {
                int i10 = this.H ? alertController.N : alertController.O;
                if (this.K != null) {
                    dVar = new SimpleCursorAdapter(this.f327a, i10, this.K, new String[]{this.L}, new int[]{R.id.text1});
                } else {
                    dVar = this.f349w;
                    if (dVar == null) {
                        dVar = new d(this.f327a, i10, R.id.text1, this.f348v);
                    }
                }
            }
            alertController.H = dVar;
            alertController.I = this.I;
            if (this.f350x != null) {
                recycleListView.setOnItemClickListener(new c(alertController));
            } else if (this.J != null) {
                recycleListView.setOnItemClickListener(new d(recycleListView, alertController));
            }
            AdapterView.OnItemSelectedListener onItemSelectedListener = this.N;
            if (onItemSelectedListener != null) {
                recycleListView.setOnItemSelectedListener(onItemSelectedListener);
            }
            if (this.H) {
                recycleListView.setChoiceMode(1);
            } else if (this.G) {
                recycleListView.setChoiceMode(2);
            }
            alertController.f304g = recycleListView;
        }

        public void a(AlertController alertController) {
            View view = this.f333g;
            if (view != null) {
                alertController.l(view);
            } else {
                CharSequence charSequence = this.f332f;
                if (charSequence != null) {
                    alertController.q(charSequence);
                }
                Drawable drawable = this.f330d;
                if (drawable != null) {
                    alertController.n(drawable);
                }
                int i10 = this.f329c;
                if (i10 != 0) {
                    alertController.m(i10);
                }
                int i11 = this.f331e;
                if (i11 != 0) {
                    alertController.m(alertController.d(i11));
                }
            }
            CharSequence charSequence2 = this.f334h;
            if (charSequence2 != null) {
                alertController.o(charSequence2);
            }
            CharSequence charSequence3 = this.f335i;
            if (charSequence3 != null || this.f336j != null) {
                alertController.k(-1, charSequence3, this.f337k, null, this.f336j);
            }
            CharSequence charSequence4 = this.f338l;
            if (charSequence4 != null || this.f339m != null) {
                alertController.k(-2, charSequence4, this.f340n, null, this.f339m);
            }
            CharSequence charSequence5 = this.f341o;
            if (charSequence5 != null || this.f342p != null) {
                alertController.k(-3, charSequence5, this.f343q, null, this.f342p);
            }
            if (this.f348v != null || this.K != null || this.f349w != null) {
                b(alertController);
            }
            View view2 = this.f352z;
            if (view2 != null) {
                if (this.E) {
                    alertController.t(view2, this.A, this.B, this.C, this.D);
                    return;
                } else {
                    alertController.s(view2);
                    return;
                }
            }
            int i12 = this.f351y;
            if (i12 != 0) {
                alertController.r(i12);
            }
        }
    }

    private static final class c extends Handler {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private WeakReference<DialogInterface> f365a;

        public c(DialogInterface dialogInterface) {
            this.f365a = new WeakReference<>(dialogInterface);
        }

        @Override // android.os.Handler
        public void handleMessage(Message message) {
            int i10 = message.what;
            if (i10 == -3 || i10 == -2 || i10 == -1) {
                ((DialogInterface.OnClickListener) message.obj).onClick(this.f365a.get(), message.what);
            } else {
                if (i10 != 1) {
                    return;
                }
                ((DialogInterface) message.obj).dismiss();
            }
        }
    }

    private static class d extends ArrayAdapter<CharSequence> {
        public d(Context context, int i10, int i11, CharSequence[] charSequenceArr) {
            super(context, i10, i11, charSequenceArr);
        }

        @Override // android.widget.ArrayAdapter, android.widget.Adapter
        public long getItemId(int i10) {
            return i10;
        }

        @Override // android.widget.BaseAdapter, android.widget.Adapter
        public boolean hasStableIds() {
            return true;
        }
    }

    public AlertController(Context context, h hVar, Window window) {
        this.f298a = context;
        this.f299b = hVar;
        this.f300c = window;
        this.R = new c(hVar);
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(null, R$styleable.AlertDialog, R$attr.alertDialogStyle, 0);
        this.J = typedArrayObtainStyledAttributes.getResourceId(R$styleable.AlertDialog_android_layout, 0);
        this.K = typedArrayObtainStyledAttributes.getResourceId(R$styleable.AlertDialog_buttonPanelSideLayout, 0);
        this.L = typedArrayObtainStyledAttributes.getResourceId(R$styleable.AlertDialog_listLayout, 0);
        this.M = typedArrayObtainStyledAttributes.getResourceId(R$styleable.AlertDialog_multiChoiceItemLayout, 0);
        this.N = typedArrayObtainStyledAttributes.getResourceId(R$styleable.AlertDialog_singleChoiceItemLayout, 0);
        this.O = typedArrayObtainStyledAttributes.getResourceId(R$styleable.AlertDialog_listItemLayout, 0);
        this.P = typedArrayObtainStyledAttributes.getBoolean(R$styleable.AlertDialog_showTitle, true);
        this.f301d = typedArrayObtainStyledAttributes.getDimensionPixelSize(R$styleable.AlertDialog_buttonIconDimen, 0);
        typedArrayObtainStyledAttributes.recycle();
        hVar.i(1);
    }

    static boolean a(View view) {
        if (view.onCheckIsTextEditor()) {
            return true;
        }
        if (!(view instanceof ViewGroup)) {
            return false;
        }
        ViewGroup viewGroup = (ViewGroup) view;
        int childCount = viewGroup.getChildCount();
        while (childCount > 0) {
            childCount--;
            if (a(viewGroup.getChildAt(childCount))) {
                return true;
            }
        }
        return false;
    }

    private void b(Button button) {
        LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) button.getLayoutParams();
        layoutParams.gravity = 1;
        layoutParams.weight = 0.5f;
        button.setLayoutParams(layoutParams);
    }

    private ViewGroup i(View view, View view2) {
        if (view == null) {
            if (view2 instanceof ViewStub) {
                view2 = ((ViewStub) view2).inflate();
            }
            return (ViewGroup) view2;
        }
        if (view2 != null) {
            ViewParent parent = view2.getParent();
            if (parent instanceof ViewGroup) {
                ((ViewGroup) parent).removeView(view2);
            }
        }
        if (view instanceof ViewStub) {
            view = ((ViewStub) view).inflate();
        }
        return (ViewGroup) view;
    }

    private int j() {
        int i10 = this.K;
        if (i10 == 0) {
            return this.J;
        }
        return this.Q == 1 ? i10 : this.J;
    }

    private void p(ViewGroup viewGroup, View view, int i10, int i11) {
        View viewFindViewById = this.f300c.findViewById(R$id.scrollIndicatorUp);
        View viewFindViewById2 = this.f300c.findViewById(R$id.scrollIndicatorDown);
        h0.E0(view, i10, i11);
        if (viewFindViewById != null) {
            viewGroup.removeView(viewFindViewById);
        }
        if (viewFindViewById2 != null) {
            viewGroup.removeView(viewFindViewById2);
        }
    }

    private void u(ViewGroup viewGroup) {
        int i10;
        Button button = (Button) viewGroup.findViewById(R.id.button1);
        this.f312o = button;
        button.setOnClickListener(this.S);
        if (TextUtils.isEmpty(this.f313p) && this.f315r == null) {
            this.f312o.setVisibility(8);
            i10 = 0;
        } else {
            this.f312o.setText(this.f313p);
            Drawable drawable = this.f315r;
            if (drawable != null) {
                int i11 = this.f301d;
                drawable.setBounds(0, 0, i11, i11);
                this.f312o.setCompoundDrawables(this.f315r, null, null, null);
            }
            this.f312o.setVisibility(0);
            i10 = 1;
        }
        Button button2 = (Button) viewGroup.findViewById(R.id.button2);
        this.f316s = button2;
        button2.setOnClickListener(this.S);
        if (TextUtils.isEmpty(this.f317t) && this.f319v == null) {
            this.f316s.setVisibility(8);
        } else {
            this.f316s.setText(this.f317t);
            Drawable drawable2 = this.f319v;
            if (drawable2 != null) {
                int i12 = this.f301d;
                drawable2.setBounds(0, 0, i12, i12);
                this.f316s.setCompoundDrawables(this.f319v, null, null, null);
            }
            this.f316s.setVisibility(0);
            i10 |= 2;
        }
        Button button3 = (Button) viewGroup.findViewById(R.id.button3);
        this.f320w = button3;
        button3.setOnClickListener(this.S);
        if (TextUtils.isEmpty(this.f321x) && this.f323z == null) {
            this.f320w.setVisibility(8);
        } else {
            this.f320w.setText(this.f321x);
            Drawable drawable3 = this.f323z;
            if (drawable3 != null) {
                int i13 = this.f301d;
                drawable3.setBounds(0, 0, i13, i13);
                this.f320w.setCompoundDrawables(this.f323z, null, null, null);
            }
            this.f320w.setVisibility(0);
            i10 |= 4;
        }
        if (z(this.f298a)) {
            if (i10 == 1) {
                b(this.f312o);
            } else if (i10 == 2) {
                b(this.f316s);
            } else if (i10 == 4) {
                b(this.f320w);
            }
        }
        if (i10 != 0) {
            return;
        }
        viewGroup.setVisibility(8);
    }

    private void v(ViewGroup viewGroup) {
        NestedScrollView nestedScrollView = (NestedScrollView) this.f300c.findViewById(R$id.scrollView);
        this.A = nestedScrollView;
        nestedScrollView.setFocusable(false);
        this.A.setNestedScrollingEnabled(false);
        TextView textView = (TextView) viewGroup.findViewById(R.id.message);
        this.F = textView;
        if (textView == null) {
            return;
        }
        CharSequence charSequence = this.f303f;
        if (charSequence != null) {
            textView.setText(charSequence);
            return;
        }
        textView.setVisibility(8);
        this.A.removeView(this.F);
        if (this.f304g == null) {
            viewGroup.setVisibility(8);
            return;
        }
        ViewGroup viewGroup2 = (ViewGroup) this.A.getParent();
        int iIndexOfChild = viewGroup2.indexOfChild(this.A);
        viewGroup2.removeViewAt(iIndexOfChild);
        viewGroup2.addView(this.f304g, iIndexOfChild, new ViewGroup.LayoutParams(-1, -1));
    }

    private void w(ViewGroup viewGroup) {
        View viewInflate = this.f305h;
        if (viewInflate == null) {
            viewInflate = this.f306i != 0 ? LayoutInflater.from(this.f298a).inflate(this.f306i, viewGroup, false) : null;
        }
        boolean z10 = viewInflate != null;
        if (!z10 || !a(viewInflate)) {
            this.f300c.setFlags(131072, 131072);
        }
        if (!z10) {
            viewGroup.setVisibility(8);
            return;
        }
        FrameLayout frameLayout = (FrameLayout) this.f300c.findViewById(R$id.custom);
        frameLayout.addView(viewInflate, new ViewGroup.LayoutParams(-1, -1));
        if (this.f311n) {
            frameLayout.setPadding(this.f307j, this.f308k, this.f309l, this.f310m);
        }
        if (this.f304g != null) {
            ((LinearLayout.LayoutParams) ((LinearLayoutCompat.LayoutParams) viewGroup.getLayoutParams())).weight = 0.0f;
        }
    }

    private void x(ViewGroup viewGroup) {
        if (this.G != null) {
            viewGroup.addView(this.G, 0, new ViewGroup.LayoutParams(-1, -2));
            this.f300c.findViewById(R$id.title_template).setVisibility(8);
            return;
        }
        this.D = (ImageView) this.f300c.findViewById(R.id.icon);
        if (TextUtils.isEmpty(this.f302e) || !this.P) {
            this.f300c.findViewById(R$id.title_template).setVisibility(8);
            this.D.setVisibility(8);
            viewGroup.setVisibility(8);
            return;
        }
        TextView textView = (TextView) this.f300c.findViewById(R$id.alertTitle);
        this.E = textView;
        textView.setText(this.f302e);
        int i10 = this.B;
        if (i10 != 0) {
            this.D.setImageResource(i10);
            return;
        }
        Drawable drawable = this.C;
        if (drawable != null) {
            this.D.setImageDrawable(drawable);
        } else {
            this.E.setPadding(this.D.getPaddingLeft(), this.D.getPaddingTop(), this.D.getPaddingRight(), this.D.getPaddingBottom());
            this.D.setVisibility(8);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void y() {
        View viewFindViewById;
        ListAdapter listAdapter;
        View viewFindViewById2;
        View viewFindViewById3 = this.f300c.findViewById(R$id.parentPanel);
        int i10 = R$id.topPanel;
        View viewFindViewById4 = viewFindViewById3.findViewById(i10);
        int i11 = R$id.contentPanel;
        View viewFindViewById5 = viewFindViewById3.findViewById(i11);
        int i12 = R$id.buttonPanel;
        View viewFindViewById6 = viewFindViewById3.findViewById(i12);
        ViewGroup viewGroup = (ViewGroup) viewFindViewById3.findViewById(R$id.customPanel);
        w(viewGroup);
        View viewFindViewById7 = viewGroup.findViewById(i10);
        View viewFindViewById8 = viewGroup.findViewById(i11);
        View viewFindViewById9 = viewGroup.findViewById(i12);
        ViewGroup viewGroupI = i(viewFindViewById7, viewFindViewById4);
        ViewGroup viewGroupI2 = i(viewFindViewById8, viewFindViewById5);
        ViewGroup viewGroupI3 = i(viewFindViewById9, viewFindViewById6);
        v(viewGroupI2);
        u(viewGroupI3);
        x(viewGroupI);
        boolean z10 = viewGroup.getVisibility() != 8;
        boolean z11 = (viewGroupI == null || viewGroupI.getVisibility() == 8) ? 0 : 1;
        boolean z12 = (viewGroupI3 == null || viewGroupI3.getVisibility() == 8) ? false : true;
        if (!z12 && viewGroupI2 != null && (viewFindViewById2 = viewGroupI2.findViewById(R$id.textSpacerNoButtons)) != null) {
            viewFindViewById2.setVisibility(0);
        }
        if (z11 != 0) {
            NestedScrollView nestedScrollView = this.A;
            if (nestedScrollView != null) {
                nestedScrollView.setClipToPadding(true);
            }
            View viewFindViewById10 = (this.f303f == null && this.f304g == null) ? null : viewGroupI.findViewById(R$id.titleDividerNoCustom);
            if (viewFindViewById10 != null) {
                viewFindViewById10.setVisibility(0);
            }
        } else if (viewGroupI2 != null && (viewFindViewById = viewGroupI2.findViewById(R$id.textSpacerNoTitle)) != null) {
            viewFindViewById.setVisibility(0);
        }
        ListView listView = this.f304g;
        if (listView instanceof RecycleListView) {
            ((RecycleListView) listView).a(z11, z12);
        }
        if (!z10) {
            View view = this.f304g;
            if (view == null) {
                view = this.A;
            }
            if (view != null) {
                p(viewGroupI2, view, z11 | (z12 ? 2 : 0), 3);
            }
        }
        ListView listView2 = this.f304g;
        if (listView2 == null || (listAdapter = this.H) == null) {
            return;
        }
        listView2.setAdapter(listAdapter);
        int i13 = this.I;
        if (i13 > -1) {
            listView2.setItemChecked(i13, true);
            listView2.setSelection(i13);
        }
    }

    private static boolean z(Context context) {
        TypedValue typedValue = new TypedValue();
        context.getTheme().resolveAttribute(R$attr.alertDialogCenterButtons, typedValue, true);
        return typedValue.data != 0;
    }

    public Button c(int i10) {
        if (i10 == -3) {
            return this.f320w;
        }
        if (i10 == -2) {
            return this.f316s;
        }
        if (i10 != -1) {
            return null;
        }
        return this.f312o;
    }

    public int d(int i10) {
        TypedValue typedValue = new TypedValue();
        this.f298a.getTheme().resolveAttribute(i10, typedValue, true);
        return typedValue.resourceId;
    }

    public ListView e() {
        return this.f304g;
    }

    public void f() {
        this.f299b.setContentView(j());
        y();
    }

    public boolean g(int i10, KeyEvent keyEvent) {
        NestedScrollView nestedScrollView = this.A;
        return nestedScrollView != null && nestedScrollView.t(keyEvent);
    }

    public boolean h(int i10, KeyEvent keyEvent) {
        NestedScrollView nestedScrollView = this.A;
        return nestedScrollView != null && nestedScrollView.t(keyEvent);
    }

    public void k(int i10, CharSequence charSequence, DialogInterface.OnClickListener onClickListener, Message message, Drawable drawable) {
        if (message == null && onClickListener != null) {
            message = this.R.obtainMessage(i10, onClickListener);
        }
        if (i10 == -3) {
            this.f321x = charSequence;
            this.f322y = message;
            this.f323z = drawable;
        } else if (i10 == -2) {
            this.f317t = charSequence;
            this.f318u = message;
            this.f319v = drawable;
        } else {
            if (i10 != -1) {
                throw new IllegalArgumentException("Button does not exist");
            }
            this.f313p = charSequence;
            this.f314q = message;
            this.f315r = drawable;
        }
    }

    public void l(View view) {
        this.G = view;
    }

    public void m(int i10) {
        this.C = null;
        this.B = i10;
        ImageView imageView = this.D;
        if (imageView != null) {
            if (i10 == 0) {
                imageView.setVisibility(8);
            } else {
                imageView.setVisibility(0);
                this.D.setImageResource(this.B);
            }
        }
    }

    public void n(Drawable drawable) {
        this.C = drawable;
        this.B = 0;
        ImageView imageView = this.D;
        if (imageView != null) {
            if (drawable == null) {
                imageView.setVisibility(8);
            } else {
                imageView.setVisibility(0);
                this.D.setImageDrawable(drawable);
            }
        }
    }

    public void o(CharSequence charSequence) {
        this.f303f = charSequence;
        TextView textView = this.F;
        if (textView != null) {
            textView.setText(charSequence);
        }
    }

    public void q(CharSequence charSequence) {
        this.f302e = charSequence;
        TextView textView = this.E;
        if (textView != null) {
            textView.setText(charSequence);
        }
    }

    public void r(int i10) {
        this.f305h = null;
        this.f306i = i10;
        this.f311n = false;
    }

    public void s(View view) {
        this.f305h = view;
        this.f306i = 0;
        this.f311n = false;
    }

    public void t(View view, int i10, int i11, int i12, int i13) {
        this.f305h = view;
        this.f306i = 0;
        this.f311n = true;
        this.f307j = i10;
        this.f308k = i11;
        this.f309l = i12;
        this.f310m = i13;
    }
}
