package androidx.appcompat.app;

import android.content.Context;
import android.content.res.Configuration;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import androidx.appcompat.view.menu.MenuBuilder;
import androidx.appcompat.view.menu.MenuPresenter;
import androidx.appcompat.widget.Toolbar;
import androidx.appcompat.widget.l0;
import androidx.appcompat.widget.s;
import androidx.core.view.h0;
import java.util.ArrayList;

/* JADX INFO: compiled from: ToolbarActionBar.java */
/* JADX INFO: loaded from: classes.dex */
class m extends ActionBar {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    final s f474a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    final Window.Callback f475b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    final AppCompatDelegateImpl.g f476c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    boolean f477d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private boolean f478e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private boolean f479f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private ArrayList<ActionBar.a> f480g = new ArrayList<>();

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private final Runnable f481h = new a();

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private final Toolbar.g f482i;

    /* JADX INFO: compiled from: ToolbarActionBar.java */
    class a implements Runnable {
        a() {
        }

        @Override // java.lang.Runnable
        public void run() {
            m.this.x();
        }
    }

    /* JADX INFO: compiled from: ToolbarActionBar.java */
    class b implements Toolbar.g {
        b() {
        }

        @Override // androidx.appcompat.widget.Toolbar.g
        public boolean onMenuItemClick(MenuItem menuItem) {
            return m.this.f475b.onMenuItemSelected(0, menuItem);
        }
    }

    /* JADX INFO: compiled from: ToolbarActionBar.java */
    private final class c implements MenuPresenter.Callback {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private boolean f485a;

        c() {
        }

        @Override // androidx.appcompat.view.menu.MenuPresenter.Callback
        public void onCloseMenu(MenuBuilder menuBuilder, boolean z10) {
            if (this.f485a) {
                return;
            }
            this.f485a = true;
            m.this.f474a.h();
            m.this.f475b.onPanelClosed(108, menuBuilder);
            this.f485a = false;
        }

        @Override // androidx.appcompat.view.menu.MenuPresenter.Callback
        public boolean onOpenSubMenu(MenuBuilder menuBuilder) {
            m.this.f475b.onMenuOpened(108, menuBuilder);
            return true;
        }
    }

    /* JADX INFO: compiled from: ToolbarActionBar.java */
    private final class d implements MenuBuilder.Callback {
        d() {
        }

        @Override // androidx.appcompat.view.menu.MenuBuilder.Callback
        public boolean onMenuItemSelected(MenuBuilder menuBuilder, MenuItem menuItem) {
            return false;
        }

        @Override // androidx.appcompat.view.menu.MenuBuilder.Callback
        public void onMenuModeChange(MenuBuilder menuBuilder) {
            if (m.this.f474a.b()) {
                m.this.f475b.onPanelClosed(108, menuBuilder);
            } else if (m.this.f475b.onPreparePanel(0, null, menuBuilder)) {
                m.this.f475b.onMenuOpened(108, menuBuilder);
            }
        }
    }

    /* JADX INFO: compiled from: ToolbarActionBar.java */
    private class e implements AppCompatDelegateImpl.g {
        e() {
        }

        @Override // androidx.appcompat.app.AppCompatDelegateImpl.g
        public boolean a(int i10) {
            if (i10 != 0) {
                return false;
            }
            m mVar = m.this;
            if (mVar.f477d) {
                return false;
            }
            mVar.f474a.c();
            m.this.f477d = true;
            return false;
        }

        @Override // androidx.appcompat.app.AppCompatDelegateImpl.g
        public View onCreatePanelView(int i10) {
            if (i10 == 0) {
                return new View(m.this.f474a.getContext());
            }
            return null;
        }
    }

    m(Toolbar toolbar, CharSequence charSequence, Window.Callback callback) {
        b bVar = new b();
        this.f482i = bVar;
        a0.h.e(toolbar);
        l0 l0Var = new l0(toolbar, false);
        this.f474a = l0Var;
        this.f475b = (Window.Callback) a0.h.e(callback);
        l0Var.setWindowCallback(callback);
        toolbar.setOnMenuItemClickListener(bVar);
        l0Var.setWindowTitle(charSequence);
        this.f476c = new e();
    }

    private Menu w() {
        if (!this.f478e) {
            this.f474a.i(new c(), new d());
            this.f478e = true;
        }
        return this.f474a.p();
    }

    @Override // androidx.appcompat.app.ActionBar
    public boolean g() {
        return this.f474a.e();
    }

    @Override // androidx.appcompat.app.ActionBar
    public boolean h() {
        if (!this.f474a.m()) {
            return false;
        }
        this.f474a.collapseActionView();
        return true;
    }

    @Override // androidx.appcompat.app.ActionBar
    public void i(boolean z10) {
        if (z10 == this.f479f) {
            return;
        }
        this.f479f = z10;
        int size = this.f480g.size();
        for (int i10 = 0; i10 < size; i10++) {
            this.f480g.get(i10).a(z10);
        }
    }

    @Override // androidx.appcompat.app.ActionBar
    public int j() {
        return this.f474a.o();
    }

    @Override // androidx.appcompat.app.ActionBar
    public Context k() {
        return this.f474a.getContext();
    }

    @Override // androidx.appcompat.app.ActionBar
    public boolean l() {
        this.f474a.k().removeCallbacks(this.f481h);
        h0.c0(this.f474a.k(), this.f481h);
        return true;
    }

    @Override // androidx.appcompat.app.ActionBar
    public void m(Configuration configuration) {
        super.m(configuration);
    }

    @Override // androidx.appcompat.app.ActionBar
    void n() {
        this.f474a.k().removeCallbacks(this.f481h);
    }

    @Override // androidx.appcompat.app.ActionBar
    public boolean o(int i10, KeyEvent keyEvent) {
        Menu menuW = w();
        if (menuW == null) {
            return false;
        }
        menuW.setQwertyMode(KeyCharacterMap.load(keyEvent != null ? keyEvent.getDeviceId() : -1).getKeyboardType() != 1);
        return menuW.performShortcut(i10, keyEvent, 0);
    }

    @Override // androidx.appcompat.app.ActionBar
    public boolean p(KeyEvent keyEvent) {
        if (keyEvent.getAction() == 1) {
            q();
        }
        return true;
    }

    @Override // androidx.appcompat.app.ActionBar
    public boolean q() {
        return this.f474a.f();
    }

    @Override // androidx.appcompat.app.ActionBar
    public void s(boolean z10) {
        y(z10 ? 4 : 0, 4);
    }

    @Override // androidx.appcompat.app.ActionBar
    public void u(CharSequence charSequence) {
        this.f474a.setWindowTitle(charSequence);
    }

    void x() {
        Menu menuW = w();
        MenuBuilder menuBuilder = menuW instanceof MenuBuilder ? (MenuBuilder) menuW : null;
        if (menuBuilder != null) {
            menuBuilder.stopDispatchingItemsChanged();
        }
        try {
            menuW.clear();
            if (!this.f475b.onCreatePanelMenu(0, menuW) || !this.f475b.onPreparePanel(0, null, menuW)) {
                menuW.clear();
            }
        } finally {
            if (menuBuilder != null) {
                menuBuilder.startDispatchingItemsChanged();
            }
        }
    }

    public void y(int i10, int i11) {
        this.f474a.n((i10 & i11) | ((~i11) & this.f474a.o()));
    }

    @Override // androidx.appcompat.app.ActionBar
    public void r(boolean z10) {
    }

    @Override // androidx.appcompat.app.ActionBar
    public void t(boolean z10) {
    }
}
