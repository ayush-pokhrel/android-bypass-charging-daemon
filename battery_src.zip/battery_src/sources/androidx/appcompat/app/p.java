package androidx.appcompat.app;

import android.R;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import androidx.appcompat.R$attr;
import androidx.appcompat.R$id;
import androidx.appcompat.R$styleable;
import androidx.appcompat.view.menu.MenuBuilder;
import androidx.appcompat.widget.ActionBarContainer;
import androidx.appcompat.widget.ActionBarContextView;
import androidx.appcompat.widget.ActionBarOverlayLayout;
import androidx.appcompat.widget.ScrollingTabContainerView;
import androidx.appcompat.widget.Toolbar;
import androidx.appcompat.widget.s;
import androidx.core.view.h0;
import androidx.core.view.n0;
import androidx.core.view.o0;
import androidx.core.view.p0;
import androidx.core.view.q0;
import java.lang.ref.WeakReference;
import java.util.ArrayList;

/* JADX INFO: compiled from: WindowDecorActionBar.java */
/* JADX INFO: loaded from: classes.dex */
public class p extends ActionBar implements ActionBarOverlayLayout.d {
    private static final Interpolator E = new AccelerateInterpolator();
    private static final Interpolator F = new DecelerateInterpolator();
    boolean A;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    Context f499a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private Context f500b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private Activity f501c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    ActionBarOverlayLayout f502d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    ActionBarContainer f503e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    s f504f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    ActionBarContextView f505g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    View f506h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    ScrollingTabContainerView f507i;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private boolean f510l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    d f511m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    androidx.appcompat.view.b f512n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    androidx.appcompat.view.b.a f513o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    private boolean f514p;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    private boolean f516r;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    boolean f519u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    boolean f520v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    private boolean f521w;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    androidx.appcompat.view.h f523y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    private boolean f524z;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private ArrayList<Object> f508j = new ArrayList<>();

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    private int f509k = -1;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    private ArrayList<ActionBar.a> f515q = new ArrayList<>();

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    private int f517s = 0;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    boolean f518t = true;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    private boolean f522x = true;
    final o0 B = new a();
    final o0 C = new b();
    final q0 D = new c();

    /* JADX INFO: compiled from: WindowDecorActionBar.java */
    class a extends p0 {
        a() {
        }

        @Override // androidx.core.view.o0
        public void b(View view) {
            View view2;
            p pVar = p.this;
            if (pVar.f518t && (view2 = pVar.f506h) != null) {
                view2.setTranslationY(0.0f);
                p.this.f503e.setTranslationY(0.0f);
            }
            p.this.f503e.setVisibility(8);
            p.this.f503e.setTransitioning(false);
            p pVar2 = p.this;
            pVar2.f523y = null;
            pVar2.y();
            ActionBarOverlayLayout actionBarOverlayLayout = p.this.f502d;
            if (actionBarOverlayLayout != null) {
                h0.h0(actionBarOverlayLayout);
            }
        }
    }

    /* JADX INFO: compiled from: WindowDecorActionBar.java */
    class b extends p0 {
        b() {
        }

        @Override // androidx.core.view.o0
        public void b(View view) {
            p pVar = p.this;
            pVar.f523y = null;
            pVar.f503e.requestLayout();
        }
    }

    /* JADX INFO: compiled from: WindowDecorActionBar.java */
    class c implements q0 {
        c() {
        }

        @Override // androidx.core.view.q0
        public void a(View view) {
            ((View) p.this.f503e.getParent()).invalidate();
        }
    }

    /* JADX INFO: compiled from: WindowDecorActionBar.java */
    public class d extends androidx.appcompat.view.b implements MenuBuilder.Callback {

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        private final Context f528c;

        /* JADX INFO: renamed from: g, reason: collision with root package name */
        private final MenuBuilder f529g;

        /* JADX INFO: renamed from: h, reason: collision with root package name */
        private androidx.appcompat.view.b.a f530h;

        /* JADX INFO: renamed from: i, reason: collision with root package name */
        private WeakReference<View> f531i;

        public d(Context context, androidx.appcompat.view.b.a aVar) {
            this.f528c = context;
            this.f530h = aVar;
            MenuBuilder defaultShowAsAction = new MenuBuilder(context).setDefaultShowAsAction(1);
            this.f529g = defaultShowAsAction;
            defaultShowAsAction.setCallback(this);
        }

        @Override // androidx.appcompat.view.b
        public void a() {
            p pVar = p.this;
            if (pVar.f511m != this) {
                return;
            }
            if (p.x(pVar.f519u, pVar.f520v, false)) {
                this.f530h.b(this);
            } else {
                p pVar2 = p.this;
                pVar2.f512n = this;
                pVar2.f513o = this.f530h;
            }
            this.f530h = null;
            p.this.w(false);
            p.this.f505g.g();
            p pVar3 = p.this;
            pVar3.f502d.setHideOnContentScrollEnabled(pVar3.A);
            p.this.f511m = null;
        }

        @Override // androidx.appcompat.view.b
        public View b() {
            WeakReference<View> weakReference = this.f531i;
            if (weakReference != null) {
                return weakReference.get();
            }
            return null;
        }

        @Override // androidx.appcompat.view.b
        public Menu c() {
            return this.f529g;
        }

        @Override // androidx.appcompat.view.b
        public MenuInflater d() {
            return new androidx.appcompat.view.g(this.f528c);
        }

        @Override // androidx.appcompat.view.b
        public CharSequence e() {
            return p.this.f505g.getSubtitle();
        }

        @Override // androidx.appcompat.view.b
        public CharSequence g() {
            return p.this.f505g.getTitle();
        }

        @Override // androidx.appcompat.view.b
        public void i() {
            if (p.this.f511m != this) {
                return;
            }
            this.f529g.stopDispatchingItemsChanged();
            try {
                this.f530h.a(this, this.f529g);
            } finally {
                this.f529g.startDispatchingItemsChanged();
            }
        }

        @Override // androidx.appcompat.view.b
        public boolean j() {
            return p.this.f505g.j();
        }

        @Override // androidx.appcompat.view.b
        public void k(View view) {
            p.this.f505g.setCustomView(view);
            this.f531i = new WeakReference<>(view);
        }

        @Override // androidx.appcompat.view.b
        public void l(int i10) {
            m(p.this.f499a.getResources().getString(i10));
        }

        @Override // androidx.appcompat.view.b
        public void m(CharSequence charSequence) {
            p.this.f505g.setSubtitle(charSequence);
        }

        @Override // androidx.appcompat.view.b
        public void o(int i10) {
            p(p.this.f499a.getResources().getString(i10));
        }

        @Override // androidx.appcompat.view.menu.MenuBuilder.Callback
        public boolean onMenuItemSelected(MenuBuilder menuBuilder, MenuItem menuItem) {
            androidx.appcompat.view.b.a aVar = this.f530h;
            if (aVar != null) {
                return aVar.c(this, menuItem);
            }
            return false;
        }

        @Override // androidx.appcompat.view.menu.MenuBuilder.Callback
        public void onMenuModeChange(MenuBuilder menuBuilder) {
            if (this.f530h == null) {
                return;
            }
            i();
            p.this.f505g.l();
        }

        @Override // androidx.appcompat.view.b
        public void p(CharSequence charSequence) {
            p.this.f505g.setTitle(charSequence);
        }

        @Override // androidx.appcompat.view.b
        public void q(boolean z10) {
            super.q(z10);
            p.this.f505g.setTitleOptional(z10);
        }

        public boolean r() {
            this.f529g.stopDispatchingItemsChanged();
            try {
                return this.f530h.d(this, this.f529g);
            } finally {
                this.f529g.startDispatchingItemsChanged();
            }
        }
    }

    public p(Activity activity, boolean z10) {
        this.f501c = activity;
        View decorView = activity.getWindow().getDecorView();
        E(decorView);
        if (z10) {
            return;
        }
        this.f506h = decorView.findViewById(R.id.content);
    }

    /* JADX WARN: Multi-variable type inference failed */
    private s B(View view) {
        if (view instanceof s) {
            return (s) view;
        }
        if (view instanceof Toolbar) {
            return ((Toolbar) view).getWrapper();
        }
        StringBuilder sb2 = new StringBuilder();
        sb2.append("Can't make a decor toolbar out of ");
        sb2.append(view != 0 ? view.getClass().getSimpleName() : "null");
        throw new IllegalStateException(sb2.toString());
    }

    private void D() {
        if (this.f521w) {
            this.f521w = false;
            ActionBarOverlayLayout actionBarOverlayLayout = this.f502d;
            if (actionBarOverlayLayout != null) {
                actionBarOverlayLayout.setShowingForActionMode(false);
            }
            M(false);
        }
    }

    private void E(View view) {
        ActionBarOverlayLayout actionBarOverlayLayout = (ActionBarOverlayLayout) view.findViewById(R$id.decor_content_parent);
        this.f502d = actionBarOverlayLayout;
        if (actionBarOverlayLayout != null) {
            actionBarOverlayLayout.setActionBarVisibilityCallback(this);
        }
        this.f504f = B(view.findViewById(R$id.action_bar));
        this.f505g = (ActionBarContextView) view.findViewById(R$id.action_context_bar);
        ActionBarContainer actionBarContainer = (ActionBarContainer) view.findViewById(R$id.action_bar_container);
        this.f503e = actionBarContainer;
        s sVar = this.f504f;
        if (sVar == null || this.f505g == null || actionBarContainer == null) {
            throw new IllegalStateException(getClass().getSimpleName() + " can only be used with a compatible window decor layout");
        }
        this.f499a = sVar.getContext();
        boolean z10 = (this.f504f.o() & 4) != 0;
        if (z10) {
            this.f510l = true;
        }
        androidx.appcompat.view.a aVarB = androidx.appcompat.view.a.b(this.f499a);
        J(aVarB.a() || z10);
        H(aVarB.g());
        TypedArray typedArrayObtainStyledAttributes = this.f499a.obtainStyledAttributes(null, R$styleable.ActionBar, R$attr.actionBarStyle, 0);
        if (typedArrayObtainStyledAttributes.getBoolean(R$styleable.ActionBar_hideOnContentScroll, false)) {
            I(true);
        }
        int dimensionPixelSize = typedArrayObtainStyledAttributes.getDimensionPixelSize(R$styleable.ActionBar_elevation, 0);
        if (dimensionPixelSize != 0) {
            G(dimensionPixelSize);
        }
        typedArrayObtainStyledAttributes.recycle();
    }

    private void H(boolean z10) {
        this.f516r = z10;
        if (z10) {
            this.f503e.setTabContainer(null);
            this.f504f.j(this.f507i);
        } else {
            this.f504f.j(null);
            this.f503e.setTabContainer(this.f507i);
        }
        boolean z11 = C() == 2;
        ScrollingTabContainerView scrollingTabContainerView = this.f507i;
        if (scrollingTabContainerView != null) {
            if (z11) {
                scrollingTabContainerView.setVisibility(0);
                ActionBarOverlayLayout actionBarOverlayLayout = this.f502d;
                if (actionBarOverlayLayout != null) {
                    h0.h0(actionBarOverlayLayout);
                }
            } else {
                scrollingTabContainerView.setVisibility(8);
            }
        }
        this.f504f.v(!this.f516r && z11);
        this.f502d.setHasNonEmbeddedTabs(!this.f516r && z11);
    }

    private boolean K() {
        return h0.Q(this.f503e);
    }

    private void L() {
        if (this.f521w) {
            return;
        }
        this.f521w = true;
        ActionBarOverlayLayout actionBarOverlayLayout = this.f502d;
        if (actionBarOverlayLayout != null) {
            actionBarOverlayLayout.setShowingForActionMode(true);
        }
        M(false);
    }

    private void M(boolean z10) {
        if (x(this.f519u, this.f520v, this.f521w)) {
            if (this.f522x) {
                return;
            }
            this.f522x = true;
            A(z10);
            return;
        }
        if (this.f522x) {
            this.f522x = false;
            z(z10);
        }
    }

    static boolean x(boolean z10, boolean z11, boolean z12) {
        if (z12) {
            return true;
        }
        return (z10 || z11) ? false : true;
    }

    public void A(boolean z10) {
        View view;
        View view2;
        androidx.appcompat.view.h hVar = this.f523y;
        if (hVar != null) {
            hVar.a();
        }
        this.f503e.setVisibility(0);
        if (this.f517s == 0 && (this.f524z || z10)) {
            this.f503e.setTranslationY(0.0f);
            float f10 = -this.f503e.getHeight();
            if (z10) {
                int[] iArr = {0, 0};
                this.f503e.getLocationInWindow(iArr);
                f10 -= iArr[1];
            }
            this.f503e.setTranslationY(f10);
            androidx.appcompat.view.h hVar2 = new androidx.appcompat.view.h();
            n0 n0VarM = h0.d(this.f503e).m(0.0f);
            n0VarM.k(this.D);
            hVar2.c(n0VarM);
            if (this.f518t && (view2 = this.f506h) != null) {
                view2.setTranslationY(f10);
                hVar2.c(h0.d(this.f506h).m(0.0f));
            }
            hVar2.f(F);
            hVar2.e(250L);
            hVar2.g(this.C);
            this.f523y = hVar2;
            hVar2.h();
        } else {
            this.f503e.setAlpha(1.0f);
            this.f503e.setTranslationY(0.0f);
            if (this.f518t && (view = this.f506h) != null) {
                view.setTranslationY(0.0f);
            }
            this.C.b(null);
        }
        ActionBarOverlayLayout actionBarOverlayLayout = this.f502d;
        if (actionBarOverlayLayout != null) {
            h0.h0(actionBarOverlayLayout);
        }
    }

    public int C() {
        return this.f504f.r();
    }

    public void F(int i10, int i11) {
        int iO = this.f504f.o();
        if ((i11 & 4) != 0) {
            this.f510l = true;
        }
        this.f504f.n((i10 & i11) | ((~i11) & iO));
    }

    public void G(float f10) {
        h0.t0(this.f503e, f10);
    }

    public void I(boolean z10) {
        if (z10 && !this.f502d.w()) {
            throw new IllegalStateException("Action bar must be in overlay mode (Window.FEATURE_OVERLAY_ACTION_BAR) to enable hide on content scroll");
        }
        this.A = z10;
        this.f502d.setHideOnContentScrollEnabled(z10);
    }

    public void J(boolean z10) {
        this.f504f.l(z10);
    }

    @Override // androidx.appcompat.widget.ActionBarOverlayLayout.d
    public void a() {
        if (this.f520v) {
            this.f520v = false;
            M(true);
        }
    }

    @Override // androidx.appcompat.widget.ActionBarOverlayLayout.d
    public void b() {
        androidx.appcompat.view.h hVar = this.f523y;
        if (hVar != null) {
            hVar.a();
            this.f523y = null;
        }
    }

    @Override // androidx.appcompat.widget.ActionBarOverlayLayout.d
    public void c(int i10) {
        this.f517s = i10;
    }

    @Override // androidx.appcompat.widget.ActionBarOverlayLayout.d
    public void e(boolean z10) {
        this.f518t = z10;
    }

    @Override // androidx.appcompat.widget.ActionBarOverlayLayout.d
    public void f() {
        if (this.f520v) {
            return;
        }
        this.f520v = true;
        M(true);
    }

    @Override // androidx.appcompat.app.ActionBar
    public boolean h() {
        s sVar = this.f504f;
        if (sVar == null || !sVar.m()) {
            return false;
        }
        this.f504f.collapseActionView();
        return true;
    }

    @Override // androidx.appcompat.app.ActionBar
    public void i(boolean z10) {
        if (z10 == this.f514p) {
            return;
        }
        this.f514p = z10;
        int size = this.f515q.size();
        for (int i10 = 0; i10 < size; i10++) {
            this.f515q.get(i10).a(z10);
        }
    }

    @Override // androidx.appcompat.app.ActionBar
    public int j() {
        return this.f504f.o();
    }

    @Override // androidx.appcompat.app.ActionBar
    public Context k() {
        if (this.f500b == null) {
            TypedValue typedValue = new TypedValue();
            this.f499a.getTheme().resolveAttribute(R$attr.actionBarWidgetTheme, typedValue, true);
            int i10 = typedValue.resourceId;
            if (i10 != 0) {
                this.f500b = new ContextThemeWrapper(this.f499a, i10);
            } else {
                this.f500b = this.f499a;
            }
        }
        return this.f500b;
    }

    @Override // androidx.appcompat.app.ActionBar
    public void m(Configuration configuration) {
        H(androidx.appcompat.view.a.b(this.f499a).g());
    }

    @Override // androidx.appcompat.app.ActionBar
    public boolean o(int i10, KeyEvent keyEvent) {
        Menu menuC;
        d dVar = this.f511m;
        if (dVar == null || (menuC = dVar.c()) == null) {
            return false;
        }
        menuC.setQwertyMode(KeyCharacterMap.load(keyEvent != null ? keyEvent.getDeviceId() : -1).getKeyboardType() != 1);
        return menuC.performShortcut(i10, keyEvent, 0);
    }

    @Override // androidx.appcompat.app.ActionBar
    public void r(boolean z10) {
        if (this.f510l) {
            return;
        }
        s(z10);
    }

    @Override // androidx.appcompat.app.ActionBar
    public void s(boolean z10) {
        F(z10 ? 4 : 0, 4);
    }

    @Override // androidx.appcompat.app.ActionBar
    public void t(boolean z10) {
        androidx.appcompat.view.h hVar;
        this.f524z = z10;
        if (z10 || (hVar = this.f523y) == null) {
            return;
        }
        hVar.a();
    }

    @Override // androidx.appcompat.app.ActionBar
    public void u(CharSequence charSequence) {
        this.f504f.setWindowTitle(charSequence);
    }

    @Override // androidx.appcompat.app.ActionBar
    public androidx.appcompat.view.b v(androidx.appcompat.view.b.a aVar) {
        d dVar = this.f511m;
        if (dVar != null) {
            dVar.a();
        }
        this.f502d.setHideOnContentScrollEnabled(false);
        this.f505g.k();
        d dVar2 = new d(this.f505g.getContext(), aVar);
        if (!dVar2.r()) {
            return null;
        }
        this.f511m = dVar2;
        dVar2.i();
        this.f505g.h(dVar2);
        w(true);
        return dVar2;
    }

    public void w(boolean z10) {
        n0 n0VarF;
        n0 n0VarF2;
        if (z10) {
            L();
        } else {
            D();
        }
        if (!K()) {
            if (z10) {
                this.f504f.setVisibility(4);
                this.f505g.setVisibility(0);
                return;
            } else {
                this.f504f.setVisibility(0);
                this.f505g.setVisibility(8);
                return;
            }
        }
        if (z10) {
            n0VarF = this.f504f.s(4, 100L);
            n0VarF2 = this.f505g.f(0, 200L);
        } else {
            n0 n0VarS = this.f504f.s(0, 200L);
            n0VarF = this.f505g.f(8, 100L);
            n0VarF2 = n0VarS;
        }
        androidx.appcompat.view.h hVar = new androidx.appcompat.view.h();
        hVar.d(n0VarF, n0VarF2);
        hVar.h();
    }

    void y() {
        androidx.appcompat.view.b.a aVar = this.f513o;
        if (aVar != null) {
            aVar.b(this.f512n);
            this.f512n = null;
            this.f513o = null;
        }
    }

    public void z(boolean z10) {
        View view;
        androidx.appcompat.view.h hVar = this.f523y;
        if (hVar != null) {
            hVar.a();
        }
        if (this.f517s != 0 || (!this.f524z && !z10)) {
            this.B.b(null);
            return;
        }
        this.f503e.setAlpha(1.0f);
        this.f503e.setTransitioning(true);
        androidx.appcompat.view.h hVar2 = new androidx.appcompat.view.h();
        float f10 = -this.f503e.getHeight();
        if (z10) {
            int[] iArr = {0, 0};
            this.f503e.getLocationInWindow(iArr);
            f10 -= iArr[1];
        }
        n0 n0VarM = h0.d(this.f503e).m(f10);
        n0VarM.k(this.D);
        hVar2.c(n0VarM);
        if (this.f518t && (view = this.f506h) != null) {
            hVar2.c(h0.d(view).m(f10));
        }
        hVar2.f(E);
        hVar2.e(250L);
        hVar2.g(this.B);
        this.f523y = hVar2;
        hVar2.h();
    }

    public p(Dialog dialog) {
        E(dialog.getWindow().getDecorView());
    }

    @Override // androidx.appcompat.widget.ActionBarOverlayLayout.d
    public void d() {
    }
}
