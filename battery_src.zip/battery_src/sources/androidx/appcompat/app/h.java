package androidx.appcompat.app;

import android.content.Context;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import androidx.appcompat.R$attr;

/* JADX INFO: compiled from: AppCompatDialog.java */
/* JADX INFO: loaded from: classes.dex */
public class h extends androidx.activity.j implements c {

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private e f461g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private final androidx.core.view.j.a f462h;

    public h(Context context, int i10) {
        super(context, g(context, i10));
        this.f462h = new androidx.core.view.j.a() { // from class: androidx.appcompat.app.g
            @Override // androidx.core.view.j.a
            public final boolean superDispatchKeyEvent(KeyEvent keyEvent) {
                return this.f460a.h(keyEvent);
            }
        };
        e eVarF = f();
        eVarF.L(g(context, i10));
        eVarF.v(null);
    }

    private static int g(Context context, int i10) {
        if (i10 != 0) {
            return i10;
        }
        TypedValue typedValue = new TypedValue();
        context.getTheme().resolveAttribute(R$attr.dialogTheme, typedValue, true);
        return typedValue.resourceId;
    }

    @Override // android.app.Dialog
    public void addContentView(View view, ViewGroup.LayoutParams layoutParams) {
        f().c(view, layoutParams);
    }

    @Override // android.app.Dialog, android.content.DialogInterface
    public void dismiss() {
        super.dismiss();
        f().w();
    }

    @Override // android.app.Dialog, android.view.Window.Callback
    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        return androidx.core.view.j.b(this.f462h, getWindow().getDecorView(), this, keyEvent);
    }

    public e f() {
        if (this.f461g == null) {
            this.f461g = e.g(this, this);
        }
        return this.f461g;
    }

    @Override // android.app.Dialog
    public <T extends View> T findViewById(int i10) {
        return (T) f().h(i10);
    }

    boolean h(KeyEvent keyEvent) {
        return super.dispatchKeyEvent(keyEvent);
    }

    public boolean i(int i10) {
        return f().E(i10);
    }

    @Override // android.app.Dialog
    public void invalidateOptionsMenu() {
        f().r();
    }

    @Override // androidx.activity.j, android.app.Dialog
    protected void onCreate(Bundle bundle) {
        f().q();
        super.onCreate(bundle);
        f().v(bundle);
    }

    @Override // androidx.activity.j, android.app.Dialog
    protected void onStop() {
        super.onStop();
        f().B();
    }

    @Override // androidx.appcompat.app.c
    public androidx.appcompat.view.b onWindowStartingSupportActionMode(androidx.appcompat.view.b.a aVar) {
        return null;
    }

    @Override // android.app.Dialog
    public void setContentView(int i10) {
        f().F(i10);
    }

    @Override // android.app.Dialog
    public void setTitle(CharSequence charSequence) {
        super.setTitle(charSequence);
        f().M(charSequence);
    }

    @Override // android.app.Dialog
    public void setContentView(View view) {
        f().G(view);
    }

    @Override // android.app.Dialog
    public void setContentView(View view, ViewGroup.LayoutParams layoutParams) {
        f().H(view, layoutParams);
    }

    @Override // android.app.Dialog
    public void setTitle(int i10) {
        super.setTitle(i10);
        f().M(getContext().getString(i10));
    }

    @Override // androidx.appcompat.app.c
    public void onSupportActionModeFinished(androidx.appcompat.view.b bVar) {
    }

    @Override // androidx.appcompat.app.c
    public void onSupportActionModeStarted(androidx.appcompat.view.b bVar) {
    }
}
