package androidx.appcompat.app;

import android.app.Activity;
import android.app.Dialog;
import android.app.LocaleManager;
import android.content.Context;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.LocaleList;
import android.util.Log;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import android.window.OnBackInvokedDispatcher;
import androidx.appcompat.widget.Toolbar;
import java.lang.ref.WeakReference;
import java.util.Iterator;

/* JADX INFO: compiled from: AppCompatDelegate.java */
/* JADX INFO: loaded from: classes.dex */
public abstract class e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    static k.a f450a = new k.a(new k.b());

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private static int f451b = -100;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private static androidx.core.os.e f452c = null;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private static androidx.core.os.e f453g = null;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private static Boolean f454h = null;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private static boolean f455i = false;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private static final r.b<WeakReference<e>> f456j = new r.b<>();

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    private static final Object f457k = new Object();

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private static final Object f458l = new Object();

    /* JADX INFO: compiled from: AppCompatDelegate.java */
    static class a {
        static LocaleList a(String str) {
            return LocaleList.forLanguageTags(str);
        }
    }

    /* JADX INFO: compiled from: AppCompatDelegate.java */
    static class b {
        static LocaleList a(Object obj) {
            return ((LocaleManager) obj).getApplicationLocales();
        }

        static void b(Object obj, LocaleList localeList) {
            ((LocaleManager) obj).setApplicationLocales(localeList);
        }
    }

    e() {
    }

    static void C(e eVar) {
        synchronized (f457k) {
            D(eVar);
        }
    }

    private static void D(e eVar) {
        synchronized (f457k) {
            try {
                Iterator<WeakReference<e>> it = f456j.iterator();
                while (it.hasNext()) {
                    e eVar2 = it.next().get();
                    if (eVar2 == eVar || eVar2 == null) {
                        it.remove();
                    }
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    static void O(final Context context) {
        if (s(context)) {
            if (androidx.core.os.a.a()) {
                if (f455i) {
                    return;
                }
                f450a.execute(new Runnable() { // from class: androidx.appcompat.app.d
                    @Override // java.lang.Runnable
                    public final void run() {
                        e.t(context);
                    }
                });
                return;
            }
            synchronized (f458l) {
                try {
                    androidx.core.os.e eVar = f452c;
                    if (eVar == null) {
                        if (f453g == null) {
                            f453g = androidx.core.os.e.b(k.b(context));
                        }
                        if (f453g.d()) {
                        } else {
                            f452c = f453g;
                        }
                    } else if (!eVar.equals(f453g)) {
                        androidx.core.os.e eVar2 = f452c;
                        f453g = eVar2;
                        k.a(context, eVar2.e());
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
        }
    }

    static void b(e eVar) {
        synchronized (f457k) {
            D(eVar);
            f456j.add(new WeakReference<>(eVar));
        }
    }

    public static e f(Activity activity, c cVar) {
        return new AppCompatDelegateImpl(activity, cVar);
    }

    public static e g(Dialog dialog, c cVar) {
        return new AppCompatDelegateImpl(dialog, cVar);
    }

    public static androidx.core.os.e i() {
        if (androidx.core.os.a.a()) {
            Object objN = n();
            if (objN != null) {
                return androidx.core.os.e.f(b.a(objN));
            }
        } else {
            androidx.core.os.e eVar = f452c;
            if (eVar != null) {
                return eVar;
            }
        }
        return androidx.core.os.e.c();
    }

    public static int k() {
        return f451b;
    }

    static Object n() {
        Context contextJ;
        Iterator<WeakReference<e>> it = f456j.iterator();
        while (it.hasNext()) {
            e eVar = it.next().get();
            if (eVar != null && (contextJ = eVar.j()) != null) {
                return contextJ.getSystemService("locale");
            }
        }
        return null;
    }

    static boolean s(Context context) {
        if (f454h == null) {
            try {
                Bundle bundle = AppLocalesMetadataHolderService.a(context).metaData;
                if (bundle != null) {
                    f454h = Boolean.valueOf(bundle.getBoolean("autoStoreLocales"));
                }
            } catch (PackageManager.NameNotFoundException unused) {
                Log.d("AppCompatDelegate", "Checking for metadata for AppLocalesMetadataHolderService : Service not found");
                f454h = Boolean.FALSE;
            }
        }
        return f454h.booleanValue();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static /* synthetic */ void t(Context context) {
        k.c(context);
        f455i = true;
    }

    public abstract void A();

    public abstract void B();

    public abstract boolean E(int i10);

    public abstract void F(int i10);

    public abstract void G(View view);

    public abstract void H(View view, ViewGroup.LayoutParams layoutParams);

    public abstract void I(int i10);

    public abstract void K(Toolbar toolbar);

    public abstract void M(CharSequence charSequence);

    public abstract androidx.appcompat.view.b N(androidx.appcompat.view.b.a aVar);

    public abstract void c(View view, ViewGroup.LayoutParams layoutParams);

    public Context e(Context context) {
        d(context);
        return context;
    }

    public abstract <T extends View> T h(int i10);

    public Context j() {
        return null;
    }

    public abstract androidx.appcompat.app.a l();

    public int m() {
        return -100;
    }

    public abstract MenuInflater o();

    public abstract ActionBar p();

    public abstract void q();

    public abstract void r();

    public abstract void u(Configuration configuration);

    public abstract void v(Bundle bundle);

    public abstract void w();

    public abstract void x(Bundle bundle);

    public abstract void y();

    public abstract void z(Bundle bundle);

    public void J(OnBackInvokedDispatcher onBackInvokedDispatcher) {
    }

    public void L(int i10) {
    }

    @Deprecated
    public void d(Context context) {
    }
}
