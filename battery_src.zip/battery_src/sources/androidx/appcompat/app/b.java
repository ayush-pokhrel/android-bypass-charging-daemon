package androidx.appcompat.app;

import android.content.Context;
import android.content.DialogInterface;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import androidx.appcompat.R$attr;

/* JADX INFO: compiled from: AlertDialog.java */
/* JADX INFO: loaded from: classes.dex */
public class b extends h implements DialogInterface {

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    final AlertController f446i;

    /* JADX INFO: compiled from: AlertDialog.java */
    public static class a {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private final AlertController.b f447a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private final int f448b;

        public a(Context context) {
            this(context, b.l(context, 0));
        }

        public b a() {
            b bVar = new b(this.f447a.f327a, this.f448b);
            this.f447a.a(bVar.f446i);
            bVar.setCancelable(this.f447a.f344r);
            if (this.f447a.f344r) {
                bVar.setCanceledOnTouchOutside(true);
            }
            bVar.setOnCancelListener(this.f447a.f345s);
            bVar.setOnDismissListener(this.f447a.f346t);
            DialogInterface.OnKeyListener onKeyListener = this.f447a.f347u;
            if (onKeyListener != null) {
                bVar.setOnKeyListener(onKeyListener);
            }
            return bVar;
        }

        public Context b() {
            return this.f447a.f327a;
        }

        public a c(ListAdapter listAdapter, DialogInterface.OnClickListener onClickListener) {
            AlertController.b bVar = this.f447a;
            bVar.f349w = listAdapter;
            bVar.f350x = onClickListener;
            return this;
        }

        public a d(boolean z10) {
            this.f447a.f344r = z10;
            return this;
        }

        public a e(View view) {
            this.f447a.f333g = view;
            return this;
        }

        public a f(Drawable drawable) {
            this.f447a.f330d = drawable;
            return this;
        }

        public a g(int i10) {
            AlertController.b bVar = this.f447a;
            bVar.f334h = bVar.f327a.getText(i10);
            return this;
        }

        public a h(CharSequence charSequence) {
            this.f447a.f334h = charSequence;
            return this;
        }

        public a i(CharSequence[] charSequenceArr, boolean[] zArr, DialogInterface.OnMultiChoiceClickListener onMultiChoiceClickListener) {
            AlertController.b bVar = this.f447a;
            bVar.f348v = charSequenceArr;
            bVar.J = onMultiChoiceClickListener;
            bVar.F = zArr;
            bVar.G = true;
            return this;
        }

        public a j(int i10, DialogInterface.OnClickListener onClickListener) {
            AlertController.b bVar = this.f447a;
            bVar.f338l = bVar.f327a.getText(i10);
            this.f447a.f340n = onClickListener;
            return this;
        }

        public a k(CharSequence charSequence, DialogInterface.OnClickListener onClickListener) {
            AlertController.b bVar = this.f447a;
            bVar.f338l = charSequence;
            bVar.f340n = onClickListener;
            return this;
        }

        public a l(int i10, DialogInterface.OnClickListener onClickListener) {
            AlertController.b bVar = this.f447a;
            bVar.f341o = bVar.f327a.getText(i10);
            this.f447a.f343q = onClickListener;
            return this;
        }

        public a m(CharSequence charSequence, DialogInterface.OnClickListener onClickListener) {
            AlertController.b bVar = this.f447a;
            bVar.f341o = charSequence;
            bVar.f343q = onClickListener;
            return this;
        }

        public a n(DialogInterface.OnCancelListener onCancelListener) {
            this.f447a.f345s = onCancelListener;
            return this;
        }

        public a o(DialogInterface.OnDismissListener onDismissListener) {
            this.f447a.f346t = onDismissListener;
            return this;
        }

        public a p(DialogInterface.OnKeyListener onKeyListener) {
            this.f447a.f347u = onKeyListener;
            return this;
        }

        public a q(int i10, DialogInterface.OnClickListener onClickListener) {
            AlertController.b bVar = this.f447a;
            bVar.f335i = bVar.f327a.getText(i10);
            this.f447a.f337k = onClickListener;
            return this;
        }

        public a r(CharSequence charSequence, DialogInterface.OnClickListener onClickListener) {
            AlertController.b bVar = this.f447a;
            bVar.f335i = charSequence;
            bVar.f337k = onClickListener;
            return this;
        }

        public a s(ListAdapter listAdapter, int i10, DialogInterface.OnClickListener onClickListener) {
            AlertController.b bVar = this.f447a;
            bVar.f349w = listAdapter;
            bVar.f350x = onClickListener;
            bVar.I = i10;
            bVar.H = true;
            return this;
        }

        public a t(CharSequence[] charSequenceArr, int i10, DialogInterface.OnClickListener onClickListener) {
            AlertController.b bVar = this.f447a;
            bVar.f348v = charSequenceArr;
            bVar.f350x = onClickListener;
            bVar.I = i10;
            bVar.H = true;
            return this;
        }

        public a u(int i10) {
            AlertController.b bVar = this.f447a;
            bVar.f332f = bVar.f327a.getText(i10);
            return this;
        }

        public a v(CharSequence charSequence) {
            this.f447a.f332f = charSequence;
            return this;
        }

        public a w(int i10) {
            AlertController.b bVar = this.f447a;
            bVar.f352z = null;
            bVar.f351y = i10;
            bVar.E = false;
            return this;
        }

        public a x(View view) {
            AlertController.b bVar = this.f447a;
            bVar.f352z = view;
            bVar.f351y = 0;
            bVar.E = false;
            return this;
        }

        public b y() {
            b bVarA = a();
            bVarA.show();
            return bVarA;
        }

        public a(Context context, int i10) {
            this.f447a = new AlertController.b(new ContextThemeWrapper(context, b.l(context, i10)));
            this.f448b = i10;
        }
    }

    protected b(Context context, int i10) {
        super(context, l(context, i10));
        this.f446i = new AlertController(getContext(), this, getWindow());
    }

    static int l(Context context, int i10) {
        if (((i10 >>> 24) & 255) >= 1) {
            return i10;
        }
        TypedValue typedValue = new TypedValue();
        context.getTheme().resolveAttribute(R$attr.alertDialogTheme, typedValue, true);
        return typedValue.resourceId;
    }

    public Button j(int i10) {
        return this.f446i.c(i10);
    }

    public ListView k() {
        return this.f446i.e();
    }

    public void m(CharSequence charSequence) {
        this.f446i.o(charSequence);
    }

    @Override // androidx.appcompat.app.h, androidx.activity.j, android.app.Dialog
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.f446i.f();
    }

    @Override // android.app.Dialog, android.view.KeyEvent.Callback
    public boolean onKeyDown(int i10, KeyEvent keyEvent) {
        if (this.f446i.g(i10, keyEvent)) {
            return true;
        }
        return super.onKeyDown(i10, keyEvent);
    }

    @Override // android.app.Dialog, android.view.KeyEvent.Callback
    public boolean onKeyUp(int i10, KeyEvent keyEvent) {
        if (this.f446i.h(i10, keyEvent)) {
            return true;
        }
        return super.onKeyUp(i10, keyEvent);
    }

    @Override // androidx.appcompat.app.h, android.app.Dialog
    public void setTitle(CharSequence charSequence) {
        super.setTitle(charSequence);
        this.f446i.q(charSequence);
    }
}
