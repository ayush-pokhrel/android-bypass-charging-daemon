package androidx.appcompat.app;

import android.R;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.app.UiModeManager;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.media.AudioManager;
import android.os.Build;
import android.os.Bundle;
import android.os.LocaleList;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.PowerManager;
import android.text.TextUtils;
import android.util.AndroidRuntimeException;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.ActionMode;
import android.view.ContextThemeWrapper;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.KeyboardShortcutGroup;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;
import androidx.appcompat.R$attr;
import androidx.appcompat.R$color;
import androidx.appcompat.R$id;
import androidx.appcompat.R$layout;
import androidx.appcompat.R$style;
import androidx.appcompat.R$styleable;
import androidx.appcompat.view.menu.ListMenuPresenter;
import androidx.appcompat.view.menu.MenuBuilder;
import androidx.appcompat.view.menu.MenuPresenter;
import androidx.appcompat.view.menu.MenuView;
import androidx.appcompat.widget.ActionBarContextView;
import androidx.appcompat.widget.ContentFrameLayout;
import androidx.appcompat.widget.Toolbar;
import androidx.appcompat.widget.ViewStubCompat;
import androidx.appcompat.widget.o0;
import androidx.core.view.h0;
import androidx.core.view.n0;
import androidx.core.view.p0;
import androidx.core.view.t0;
import androidx.core.view.x;
import androidx.lifecycle.Lifecycle;
import com.google.android.material.internal.ViewUtils;
import com.oplus.deepthinker.sdk.app.DataLinkConstants;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import org.xmlpull.v1.XmlPullParser;

/* JADX INFO: loaded from: classes.dex */
class AppCompatDelegateImpl extends androidx.appcompat.app.e implements MenuBuilder.Callback, LayoutInflater.Factory2 {

    /* JADX INFO: renamed from: m0, reason: collision with root package name */
    private static final r.g<String, Integer> f368m0 = new r.g<>();

    /* JADX INFO: renamed from: n0, reason: collision with root package name */
    private static final boolean f369n0 = false;

    /* JADX INFO: renamed from: o0, reason: collision with root package name */
    private static final int[] f370o0 = {R.attr.windowBackground};

    /* JADX INFO: renamed from: p0, reason: collision with root package name */
    private static final boolean f371p0 = !"robolectric".equals(Build.FINGERPRINT);

    /* JADX INFO: renamed from: q0, reason: collision with root package name */
    private static final boolean f372q0 = true;
    Runnable A;
    n0 B;
    private boolean C;
    private boolean D;
    ViewGroup E;
    private TextView F;
    private View G;
    private boolean H;
    private boolean I;
    boolean J;
    boolean K;
    boolean L;
    boolean M;
    boolean N;
    private boolean O;
    private PanelFeatureState[] P;
    private PanelFeatureState Q;
    private boolean R;
    private boolean S;
    private boolean T;
    boolean U;
    private Configuration V;
    private int W;
    private int X;
    private int Y;
    private boolean Z;

    /* JADX INFO: renamed from: a0, reason: collision with root package name */
    private q f373a0;

    /* JADX INFO: renamed from: b0, reason: collision with root package name */
    private q f374b0;

    /* JADX INFO: renamed from: c0, reason: collision with root package name */
    boolean f375c0;

    /* JADX INFO: renamed from: d0, reason: collision with root package name */
    int f376d0;

    /* JADX INFO: renamed from: e0, reason: collision with root package name */
    private final Runnable f377e0;

    /* JADX INFO: renamed from: f0, reason: collision with root package name */
    private boolean f378f0;

    /* JADX INFO: renamed from: g0, reason: collision with root package name */
    private Rect f379g0;

    /* JADX INFO: renamed from: h0, reason: collision with root package name */
    private Rect f380h0;

    /* JADX INFO: renamed from: i0, reason: collision with root package name */
    private androidx.appcompat.app.i f381i0;

    /* JADX INFO: renamed from: j0, reason: collision with root package name */
    private androidx.appcompat.app.l f382j0;

    /* JADX INFO: renamed from: k0, reason: collision with root package name */
    private OnBackInvokedDispatcher f383k0;

    /* JADX INFO: renamed from: l0, reason: collision with root package name */
    private OnBackInvokedCallback f384l0;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    final Object f385m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    final Context f386n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    Window f387o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    private o f388p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    final androidx.appcompat.app.c f389q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    ActionBar f390r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    MenuInflater f391s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    private CharSequence f392t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    private androidx.appcompat.widget.r f393u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    private h f394v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    private u f395w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    androidx.appcompat.view.b f396x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    ActionBarContextView f397y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    PopupWindow f398z;

    protected static final class PanelFeatureState {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        int f399a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        int f400b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        int f401c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        int f402d;

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        int f403e;

        /* JADX INFO: renamed from: f, reason: collision with root package name */
        int f404f;

        /* JADX INFO: renamed from: g, reason: collision with root package name */
        ViewGroup f405g;

        /* JADX INFO: renamed from: h, reason: collision with root package name */
        View f406h;

        /* JADX INFO: renamed from: i, reason: collision with root package name */
        View f407i;

        /* JADX INFO: renamed from: j, reason: collision with root package name */
        MenuBuilder f408j;

        /* JADX INFO: renamed from: k, reason: collision with root package name */
        ListMenuPresenter f409k;

        /* JADX INFO: renamed from: l, reason: collision with root package name */
        Context f410l;

        /* JADX INFO: renamed from: m, reason: collision with root package name */
        boolean f411m;

        /* JADX INFO: renamed from: n, reason: collision with root package name */
        boolean f412n;

        /* JADX INFO: renamed from: o, reason: collision with root package name */
        boolean f413o;

        /* JADX INFO: renamed from: p, reason: collision with root package name */
        public boolean f414p;

        /* JADX INFO: renamed from: q, reason: collision with root package name */
        boolean f415q = false;

        /* JADX INFO: renamed from: r, reason: collision with root package name */
        boolean f416r;

        /* JADX INFO: renamed from: s, reason: collision with root package name */
        Bundle f417s;

        @SuppressLint({"BanParcelableUsage"})
        private static class SavedState implements Parcelable {
            public static final Parcelable.Creator<SavedState> CREATOR = new a();

            /* JADX INFO: renamed from: a, reason: collision with root package name */
            int f418a;

            /* JADX INFO: renamed from: b, reason: collision with root package name */
            boolean f419b;

            /* JADX INFO: renamed from: c, reason: collision with root package name */
            Bundle f420c;

            class a implements Parcelable.ClassLoaderCreator<SavedState> {
                a() {
                }

                @Override // android.os.Parcelable.Creator
                /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
                public SavedState createFromParcel(Parcel parcel) {
                    return SavedState.p(parcel, null);
                }

                @Override // android.os.Parcelable.ClassLoaderCreator
                /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
                public SavedState createFromParcel(Parcel parcel, ClassLoader classLoader) {
                    return SavedState.p(parcel, classLoader);
                }

                @Override // android.os.Parcelable.Creator
                /* JADX INFO: renamed from: c, reason: merged with bridge method [inline-methods] */
                public SavedState[] newArray(int i10) {
                    return new SavedState[i10];
                }
            }

            SavedState() {
            }

            static SavedState p(Parcel parcel, ClassLoader classLoader) {
                SavedState savedState = new SavedState();
                savedState.f418a = parcel.readInt();
                boolean z10 = parcel.readInt() == 1;
                savedState.f419b = z10;
                if (z10) {
                    savedState.f420c = parcel.readBundle(classLoader);
                }
                return savedState;
            }

            @Override // android.os.Parcelable
            public int describeContents() {
                return 0;
            }

            @Override // android.os.Parcelable
            public void writeToParcel(Parcel parcel, int i10) {
                parcel.writeInt(this.f418a);
                parcel.writeInt(this.f419b ? 1 : 0);
                if (this.f419b) {
                    parcel.writeBundle(this.f420c);
                }
            }
        }

        PanelFeatureState(int i10) {
            this.f399a = i10;
        }

        MenuView a(MenuPresenter.Callback callback) {
            if (this.f408j == null) {
                return null;
            }
            if (this.f409k == null) {
                ListMenuPresenter listMenuPresenter = new ListMenuPresenter(this.f410l, R$layout.abc_list_menu_item_layout);
                this.f409k = listMenuPresenter;
                listMenuPresenter.setCallback(callback);
                this.f408j.addMenuPresenter(this.f409k);
            }
            return this.f409k.getMenuView(this.f405g);
        }

        public boolean b() {
            if (this.f406h == null) {
                return false;
            }
            return this.f407i != null || this.f409k.getAdapter().getCount() > 0;
        }

        void c(MenuBuilder menuBuilder) {
            ListMenuPresenter listMenuPresenter;
            MenuBuilder menuBuilder2 = this.f408j;
            if (menuBuilder == menuBuilder2) {
                return;
            }
            if (menuBuilder2 != null) {
                menuBuilder2.removeMenuPresenter(this.f409k);
            }
            this.f408j = menuBuilder;
            if (menuBuilder == null || (listMenuPresenter = this.f409k) == null) {
                return;
            }
            menuBuilder.addMenuPresenter(listMenuPresenter);
        }

        void d(Context context) {
            TypedValue typedValue = new TypedValue();
            Resources.Theme themeNewTheme = context.getResources().newTheme();
            themeNewTheme.setTo(context.getTheme());
            themeNewTheme.resolveAttribute(R$attr.actionBarPopupTheme, typedValue, true);
            int i10 = typedValue.resourceId;
            if (i10 != 0) {
                themeNewTheme.applyStyle(i10, true);
            }
            themeNewTheme.resolveAttribute(R$attr.panelMenuListTheme, typedValue, true);
            int i11 = typedValue.resourceId;
            if (i11 != 0) {
                themeNewTheme.applyStyle(i11, true);
            } else {
                themeNewTheme.applyStyle(R$style.Theme_AppCompat_CompactMenu, true);
            }
            androidx.appcompat.view.d dVar = new androidx.appcompat.view.d(context, 0);
            dVar.getTheme().setTo(themeNewTheme);
            this.f410l = dVar;
            TypedArray typedArrayObtainStyledAttributes = dVar.obtainStyledAttributes(R$styleable.AppCompatTheme);
            this.f400b = typedArrayObtainStyledAttributes.getResourceId(R$styleable.AppCompatTheme_panelBackground, 0);
            this.f404f = typedArrayObtainStyledAttributes.getResourceId(R$styleable.AppCompatTheme_android_windowAnimationStyle, 0);
            typedArrayObtainStyledAttributes.recycle();
        }
    }

    class a implements Runnable {
        a() {
        }

        @Override // java.lang.Runnable
        public void run() {
            AppCompatDelegateImpl appCompatDelegateImpl = AppCompatDelegateImpl.this;
            if ((appCompatDelegateImpl.f376d0 & 1) != 0) {
                appCompatDelegateImpl.g0(0);
            }
            AppCompatDelegateImpl appCompatDelegateImpl2 = AppCompatDelegateImpl.this;
            if ((appCompatDelegateImpl2.f376d0 & 4096) != 0) {
                appCompatDelegateImpl2.g0(108);
            }
            AppCompatDelegateImpl appCompatDelegateImpl3 = AppCompatDelegateImpl.this;
            appCompatDelegateImpl3.f375c0 = false;
            appCompatDelegateImpl3.f376d0 = 0;
        }
    }

    class b implements x {
        b() {
        }

        @Override // androidx.core.view.x
        public t0 onApplyWindowInsets(View view, t0 t0Var) {
            int iL = t0Var.l();
            int iC1 = AppCompatDelegateImpl.this.c1(t0Var, null);
            if (iL != iC1) {
                t0Var = t0Var.q(t0Var.j(), iC1, t0Var.k(), t0Var.i());
            }
            return h0.X(view, t0Var);
        }
    }

    class d implements Runnable {

        class a extends p0 {
            a() {
            }

            @Override // androidx.core.view.o0
            public void b(View view) {
                AppCompatDelegateImpl.this.f397y.setAlpha(1.0f);
                AppCompatDelegateImpl.this.B.h(null);
                AppCompatDelegateImpl.this.B = null;
            }

            @Override // androidx.core.view.p0, androidx.core.view.o0
            public void c(View view) {
                AppCompatDelegateImpl.this.f397y.setVisibility(0);
            }
        }

        d() {
        }

        @Override // java.lang.Runnable
        public void run() {
            AppCompatDelegateImpl appCompatDelegateImpl = AppCompatDelegateImpl.this;
            appCompatDelegateImpl.f398z.showAtLocation(appCompatDelegateImpl.f397y, 55, 0, 0);
            AppCompatDelegateImpl.this.h0();
            if (!AppCompatDelegateImpl.this.S0()) {
                AppCompatDelegateImpl.this.f397y.setAlpha(1.0f);
                AppCompatDelegateImpl.this.f397y.setVisibility(0);
            } else {
                AppCompatDelegateImpl.this.f397y.setAlpha(0.0f);
                AppCompatDelegateImpl appCompatDelegateImpl2 = AppCompatDelegateImpl.this;
                appCompatDelegateImpl2.B = h0.d(appCompatDelegateImpl2.f397y).b(1.0f);
                AppCompatDelegateImpl.this.B.h(new a());
            }
        }
    }

    class e extends p0 {
        e() {
        }

        @Override // androidx.core.view.o0
        public void b(View view) {
            AppCompatDelegateImpl.this.f397y.setAlpha(1.0f);
            AppCompatDelegateImpl.this.B.h(null);
            AppCompatDelegateImpl.this.B = null;
        }

        @Override // androidx.core.view.p0, androidx.core.view.o0
        public void c(View view) {
            AppCompatDelegateImpl.this.f397y.setVisibility(0);
            if (AppCompatDelegateImpl.this.f397y.getParent() instanceof View) {
                h0.h0((View) AppCompatDelegateImpl.this.f397y.getParent());
            }
        }
    }

    private class f implements androidx.appcompat.app.a {
        f() {
        }
    }

    interface g {
        boolean a(int i10);

        View onCreatePanelView(int i10);
    }

    private final class h implements MenuPresenter.Callback {
        h() {
        }

        @Override // androidx.appcompat.view.menu.MenuPresenter.Callback
        public void onCloseMenu(MenuBuilder menuBuilder, boolean z10) {
            AppCompatDelegateImpl.this.X(menuBuilder);
        }

        @Override // androidx.appcompat.view.menu.MenuPresenter.Callback
        public boolean onOpenSubMenu(MenuBuilder menuBuilder) {
            Window.Callback callbackT0 = AppCompatDelegateImpl.this.t0();
            if (callbackT0 == null) {
                return true;
            }
            callbackT0.onMenuOpened(108, menuBuilder);
            return true;
        }
    }

    class i implements androidx.appcompat.view.b.a {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private androidx.appcompat.view.b.a f429a;

        class a extends p0 {
            a() {
            }

            @Override // androidx.core.view.o0
            public void b(View view) {
                AppCompatDelegateImpl.this.f397y.setVisibility(8);
                AppCompatDelegateImpl appCompatDelegateImpl = AppCompatDelegateImpl.this;
                PopupWindow popupWindow = appCompatDelegateImpl.f398z;
                if (popupWindow != null) {
                    popupWindow.dismiss();
                } else if (appCompatDelegateImpl.f397y.getParent() instanceof View) {
                    h0.h0((View) AppCompatDelegateImpl.this.f397y.getParent());
                }
                AppCompatDelegateImpl.this.f397y.k();
                AppCompatDelegateImpl.this.B.h(null);
                AppCompatDelegateImpl appCompatDelegateImpl2 = AppCompatDelegateImpl.this;
                appCompatDelegateImpl2.B = null;
                h0.h0(appCompatDelegateImpl2.E);
            }
        }

        public i(androidx.appcompat.view.b.a aVar) {
            this.f429a = aVar;
        }

        @Override // androidx.appcompat.view.b.a
        public boolean a(androidx.appcompat.view.b bVar, Menu menu) {
            h0.h0(AppCompatDelegateImpl.this.E);
            return this.f429a.a(bVar, menu);
        }

        @Override // androidx.appcompat.view.b.a
        public void b(androidx.appcompat.view.b bVar) {
            this.f429a.b(bVar);
            AppCompatDelegateImpl appCompatDelegateImpl = AppCompatDelegateImpl.this;
            if (appCompatDelegateImpl.f398z != null) {
                appCompatDelegateImpl.f387o.getDecorView().removeCallbacks(AppCompatDelegateImpl.this.A);
            }
            AppCompatDelegateImpl appCompatDelegateImpl2 = AppCompatDelegateImpl.this;
            if (appCompatDelegateImpl2.f397y != null) {
                appCompatDelegateImpl2.h0();
                AppCompatDelegateImpl appCompatDelegateImpl3 = AppCompatDelegateImpl.this;
                appCompatDelegateImpl3.B = h0.d(appCompatDelegateImpl3.f397y).b(0.0f);
                AppCompatDelegateImpl.this.B.h(new a());
            }
            AppCompatDelegateImpl appCompatDelegateImpl4 = AppCompatDelegateImpl.this;
            androidx.appcompat.app.c cVar = appCompatDelegateImpl4.f389q;
            if (cVar != null) {
                cVar.onSupportActionModeFinished(appCompatDelegateImpl4.f396x);
            }
            AppCompatDelegateImpl appCompatDelegateImpl5 = AppCompatDelegateImpl.this;
            appCompatDelegateImpl5.f396x = null;
            h0.h0(appCompatDelegateImpl5.E);
            AppCompatDelegateImpl.this.a1();
        }

        @Override // androidx.appcompat.view.b.a
        public boolean c(androidx.appcompat.view.b bVar, MenuItem menuItem) {
            return this.f429a.c(bVar, menuItem);
        }

        @Override // androidx.appcompat.view.b.a
        public boolean d(androidx.appcompat.view.b bVar, Menu menu) {
            return this.f429a.d(bVar, menu);
        }
    }

    static class j {
        static Context a(Context context, Configuration configuration) {
            return context.createConfigurationContext(configuration);
        }

        static void b(Configuration configuration, Configuration configuration2, Configuration configuration3) {
            int i10 = configuration.densityDpi;
            int i11 = configuration2.densityDpi;
            if (i10 != i11) {
                configuration3.densityDpi = i11;
            }
        }

        static void c(Configuration configuration, Locale locale) {
            configuration.setLayoutDirection(locale);
        }

        static void d(Configuration configuration, Locale locale) {
            configuration.setLocale(locale);
        }
    }

    static class k {
        static boolean a(PowerManager powerManager) {
            return powerManager.isPowerSaveMode();
        }

        static String b(Locale locale) {
            return locale.toLanguageTag();
        }
    }

    static class l {
        static void a(Configuration configuration, Configuration configuration2, Configuration configuration3) {
            LocaleList locales = configuration.getLocales();
            LocaleList locales2 = configuration2.getLocales();
            if (locales.equals(locales2)) {
                return;
            }
            configuration3.setLocales(locales2);
            configuration3.locale = configuration2.locale;
        }

        static androidx.core.os.e b(Configuration configuration) {
            return androidx.core.os.e.b(configuration.getLocales().toLanguageTags());
        }

        public static void c(androidx.core.os.e eVar) {
            LocaleList.setDefault(LocaleList.forLanguageTags(eVar.e()));
        }

        static void d(Configuration configuration, androidx.core.os.e eVar) {
            configuration.setLocales(LocaleList.forLanguageTags(eVar.e()));
        }
    }

    static class m {
        static void a(Configuration configuration, Configuration configuration2, Configuration configuration3) {
            int i10 = configuration.colorMode & 3;
            int i11 = configuration2.colorMode;
            if (i10 != (i11 & 3)) {
                configuration3.colorMode |= i11 & 3;
            }
            int i12 = configuration.colorMode & 12;
            int i13 = configuration2.colorMode;
            if (i12 != (i13 & 12)) {
                configuration3.colorMode |= i13 & 12;
            }
        }
    }

    static class n {
        static OnBackInvokedDispatcher a(Activity activity) {
            return activity.getOnBackInvokedDispatcher();
        }

        static OnBackInvokedCallback b(Object obj, final AppCompatDelegateImpl appCompatDelegateImpl) {
            Objects.requireNonNull(appCompatDelegateImpl);
            OnBackInvokedCallback onBackInvokedCallback = new OnBackInvokedCallback() { // from class: androidx.appcompat.app.f
                @Override // android.window.OnBackInvokedCallback
                public final void onBackInvoked() {
                    appCompatDelegateImpl.B0();
                }
            };
            ((OnBackInvokedDispatcher) obj).registerOnBackInvokedCallback(1000000, onBackInvokedCallback);
            return onBackInvokedCallback;
        }

        static void c(Object obj, Object obj2) {
            ((OnBackInvokedDispatcher) obj).unregisterOnBackInvokedCallback((OnBackInvokedCallback) obj2);
        }
    }

    class o extends androidx.appcompat.view.i {

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private g f432b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        private boolean f433c;

        /* JADX INFO: renamed from: g, reason: collision with root package name */
        private boolean f434g;

        /* JADX INFO: renamed from: h, reason: collision with root package name */
        private boolean f435h;

        o(Window.Callback callback) {
            super(callback);
        }

        public boolean b(Window.Callback callback, KeyEvent keyEvent) {
            try {
                this.f434g = true;
                return callback.dispatchKeyEvent(keyEvent);
            } finally {
                this.f434g = false;
            }
        }

        public void c(Window.Callback callback) {
            try {
                this.f433c = true;
                callback.onContentChanged();
            } finally {
                this.f433c = false;
            }
        }

        public void d(Window.Callback callback, int i10, Menu menu) {
            try {
                this.f435h = true;
                callback.onPanelClosed(i10, menu);
            } finally {
                this.f435h = false;
            }
        }

        @Override // androidx.appcompat.view.i, android.view.Window.Callback
        public boolean dispatchKeyEvent(KeyEvent keyEvent) {
            if (this.f434g) {
                return a().dispatchKeyEvent(keyEvent);
            }
            return AppCompatDelegateImpl.this.f0(keyEvent) || super.dispatchKeyEvent(keyEvent);
        }

        @Override // androidx.appcompat.view.i, android.view.Window.Callback
        public boolean dispatchKeyShortcutEvent(KeyEvent keyEvent) {
            return super.dispatchKeyShortcutEvent(keyEvent) || AppCompatDelegateImpl.this.E0(keyEvent.getKeyCode(), keyEvent);
        }

        void e(g gVar) {
            this.f432b = gVar;
        }

        final ActionMode f(ActionMode.Callback callback) {
            androidx.appcompat.view.f.a aVar = new androidx.appcompat.view.f.a(AppCompatDelegateImpl.this.f386n, callback);
            androidx.appcompat.view.b bVarN = AppCompatDelegateImpl.this.N(aVar);
            if (bVarN != null) {
                return aVar.e(bVarN);
            }
            return null;
        }

        @Override // android.view.Window.Callback
        public void onContentChanged() {
            if (this.f433c) {
                a().onContentChanged();
            }
        }

        @Override // androidx.appcompat.view.i, android.view.Window.Callback
        public boolean onCreatePanelMenu(int i10, Menu menu) {
            if (i10 != 0 || (menu instanceof MenuBuilder)) {
                return super.onCreatePanelMenu(i10, menu);
            }
            return false;
        }

        @Override // androidx.appcompat.view.i, android.view.Window.Callback
        public View onCreatePanelView(int i10) {
            View viewOnCreatePanelView;
            g gVar = this.f432b;
            return (gVar == null || (viewOnCreatePanelView = gVar.onCreatePanelView(i10)) == null) ? super.onCreatePanelView(i10) : viewOnCreatePanelView;
        }

        @Override // androidx.appcompat.view.i, android.view.Window.Callback
        public boolean onMenuOpened(int i10, Menu menu) {
            super.onMenuOpened(i10, menu);
            AppCompatDelegateImpl.this.H0(i10);
            return true;
        }

        @Override // androidx.appcompat.view.i, android.view.Window.Callback
        public void onPanelClosed(int i10, Menu menu) {
            if (this.f435h) {
                a().onPanelClosed(i10, menu);
            } else {
                super.onPanelClosed(i10, menu);
                AppCompatDelegateImpl.this.I0(i10);
            }
        }

        @Override // androidx.appcompat.view.i, android.view.Window.Callback
        public boolean onPreparePanel(int i10, View view, Menu menu) {
            MenuBuilder menuBuilder = menu instanceof MenuBuilder ? (MenuBuilder) menu : null;
            if (i10 == 0 && menuBuilder == null) {
                return false;
            }
            if (menuBuilder != null) {
                menuBuilder.setOverrideVisibleItems(true);
            }
            g gVar = this.f432b;
            boolean zOnPreparePanel = gVar != null && gVar.a(i10);
            if (!zOnPreparePanel) {
                zOnPreparePanel = super.onPreparePanel(i10, view, menu);
            }
            if (menuBuilder != null) {
                menuBuilder.setOverrideVisibleItems(false);
            }
            return zOnPreparePanel;
        }

        @Override // androidx.appcompat.view.i, android.view.Window.Callback
        public void onProvideKeyboardShortcuts(List<KeyboardShortcutGroup> list, Menu menu, int i10) {
            MenuBuilder menuBuilder;
            PanelFeatureState panelFeatureStateR0 = AppCompatDelegateImpl.this.r0(0, true);
            if (panelFeatureStateR0 == null || (menuBuilder = panelFeatureStateR0.f408j) == null) {
                super.onProvideKeyboardShortcuts(list, menu, i10);
            } else {
                super.onProvideKeyboardShortcuts(list, menuBuilder, i10);
            }
        }

        @Override // android.view.Window.Callback
        public ActionMode onWindowStartingActionMode(ActionMode.Callback callback) {
            return null;
        }

        @Override // androidx.appcompat.view.i, android.view.Window.Callback
        public ActionMode onWindowStartingActionMode(ActionMode.Callback callback, int i10) {
            return (AppCompatDelegateImpl.this.z0() && i10 == 0) ? f(callback) : super.onWindowStartingActionMode(callback, i10);
        }
    }

    private class p extends q {

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        private final PowerManager f437c;

        p(Context context) {
            super();
            this.f437c = (PowerManager) context.getApplicationContext().getSystemService("power");
        }

        @Override // androidx.appcompat.app.AppCompatDelegateImpl.q
        IntentFilter b() {
            IntentFilter intentFilter = new IntentFilter();
            intentFilter.addAction("android.os.action.POWER_SAVE_MODE_CHANGED");
            return intentFilter;
        }

        @Override // androidx.appcompat.app.AppCompatDelegateImpl.q
        public int c() {
            return k.a(this.f437c) ? 2 : 1;
        }

        @Override // androidx.appcompat.app.AppCompatDelegateImpl.q
        public void d() {
            AppCompatDelegateImpl.this.R();
        }
    }

    abstract class q {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private BroadcastReceiver f439a;

        class a extends BroadcastReceiver {
            a() {
            }

            @Override // android.content.BroadcastReceiver
            public void onReceive(Context context, Intent intent) {
                q.this.d();
            }
        }

        q() {
        }

        void a() {
            BroadcastReceiver broadcastReceiver = this.f439a;
            if (broadcastReceiver != null) {
                try {
                    AppCompatDelegateImpl.this.f386n.unregisterReceiver(broadcastReceiver);
                } catch (IllegalArgumentException unused) {
                }
                this.f439a = null;
            }
        }

        abstract IntentFilter b();

        abstract int c();

        abstract void d();

        void e() {
            a();
            IntentFilter intentFilterB = b();
            if (intentFilterB == null || intentFilterB.countActions() == 0) {
                return;
            }
            if (this.f439a == null) {
                this.f439a = new a();
            }
            AppCompatDelegateImpl.this.f386n.registerReceiver(this.f439a, intentFilterB);
        }
    }

    private class r extends q {

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        private final androidx.appcompat.app.o f442c;

        r(androidx.appcompat.app.o oVar) {
            super();
            this.f442c = oVar;
        }

        @Override // androidx.appcompat.app.AppCompatDelegateImpl.q
        IntentFilter b() {
            IntentFilter intentFilter = new IntentFilter();
            intentFilter.addAction("android.intent.action.TIME_SET");
            intentFilter.addAction("android.intent.action.TIMEZONE_CHANGED");
            intentFilter.addAction("android.intent.action.TIME_TICK");
            return intentFilter;
        }

        @Override // androidx.appcompat.app.AppCompatDelegateImpl.q
        public int c() {
            return this.f442c.d() ? 2 : 1;
        }

        @Override // androidx.appcompat.app.AppCompatDelegateImpl.q
        public void d() {
            AppCompatDelegateImpl.this.R();
        }
    }

    private static class s {
        static void a(ContextThemeWrapper contextThemeWrapper, Configuration configuration) {
            contextThemeWrapper.applyOverrideConfiguration(configuration);
        }
    }

    private class t extends ContentFrameLayout {
        public t(Context context) {
            super(context);
        }

        private boolean b(int i10, int i11) {
            return i10 < -5 || i11 < -5 || i10 > getWidth() + 5 || i11 > getHeight() + 5;
        }

        @Override // android.view.ViewGroup, android.view.View
        public boolean dispatchKeyEvent(KeyEvent keyEvent) {
            return AppCompatDelegateImpl.this.f0(keyEvent) || super.dispatchKeyEvent(keyEvent);
        }

        @Override // android.view.ViewGroup
        public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
            if (motionEvent.getAction() != 0 || !b((int) motionEvent.getX(), (int) motionEvent.getY())) {
                return super.onInterceptTouchEvent(motionEvent);
            }
            AppCompatDelegateImpl.this.Z(0);
            return true;
        }

        @Override // android.view.View
        public void setBackgroundResource(int i10) {
            setBackgroundDrawable(h.a.b(getContext(), i10));
        }
    }

    private final class u implements MenuPresenter.Callback {
        u() {
        }

        @Override // androidx.appcompat.view.menu.MenuPresenter.Callback
        public void onCloseMenu(MenuBuilder menuBuilder, boolean z10) {
            MenuBuilder rootMenu = menuBuilder.getRootMenu();
            boolean z11 = rootMenu != menuBuilder;
            AppCompatDelegateImpl appCompatDelegateImpl = AppCompatDelegateImpl.this;
            if (z11) {
                menuBuilder = rootMenu;
            }
            PanelFeatureState panelFeatureStateK0 = appCompatDelegateImpl.k0(menuBuilder);
            if (panelFeatureStateK0 != null) {
                if (!z11) {
                    AppCompatDelegateImpl.this.a0(panelFeatureStateK0, z10);
                } else {
                    AppCompatDelegateImpl.this.W(panelFeatureStateK0.f399a, panelFeatureStateK0, rootMenu);
                    AppCompatDelegateImpl.this.a0(panelFeatureStateK0, true);
                }
            }
        }

        @Override // androidx.appcompat.view.menu.MenuPresenter.Callback
        public boolean onOpenSubMenu(MenuBuilder menuBuilder) {
            Window.Callback callbackT0;
            if (menuBuilder != menuBuilder.getRootMenu()) {
                return true;
            }
            AppCompatDelegateImpl appCompatDelegateImpl = AppCompatDelegateImpl.this;
            if (!appCompatDelegateImpl.J || (callbackT0 = appCompatDelegateImpl.t0()) == null || AppCompatDelegateImpl.this.U) {
                return true;
            }
            callbackT0.onMenuOpened(108, menuBuilder);
            return true;
        }
    }

    AppCompatDelegateImpl(Activity activity, androidx.appcompat.app.c cVar) {
        this(activity, null, cVar, activity);
    }

    private boolean D0(int i10, KeyEvent keyEvent) {
        if (keyEvent.getRepeatCount() != 0) {
            return false;
        }
        PanelFeatureState panelFeatureStateR0 = r0(i10, true);
        if (panelFeatureStateR0.f413o) {
            return false;
        }
        return N0(panelFeatureStateR0, keyEvent);
    }

    /* JADX WARN: Code duplicated, block: B:34:0x0062  */
    private boolean G0(int i10, KeyEvent keyEvent) {
        boolean zN0;
        androidx.appcompat.widget.r rVar;
        if (this.f396x != null) {
            return false;
        }
        boolean zE = true;
        PanelFeatureState panelFeatureStateR0 = r0(i10, true);
        if (i10 != 0 || (rVar = this.f393u) == null || !rVar.g() || ViewConfiguration.get(this.f386n).hasPermanentMenuKey()) {
            boolean z10 = panelFeatureStateR0.f413o;
            if (z10 || panelFeatureStateR0.f412n) {
                a0(panelFeatureStateR0, true);
                zE = z10;
            } else if (panelFeatureStateR0.f411m) {
                if (panelFeatureStateR0.f416r) {
                    panelFeatureStateR0.f411m = false;
                    zN0 = N0(panelFeatureStateR0, keyEvent);
                } else {
                    zN0 = true;
                }
                if (zN0) {
                    K0(panelFeatureStateR0, keyEvent);
                } else {
                    zE = false;
                }
            } else {
                zE = false;
            }
        } else if (this.f393u.b()) {
            zE = this.f393u.e();
        } else if (this.U || !N0(panelFeatureStateR0, keyEvent)) {
            zE = false;
        } else {
            zE = this.f393u.f();
        }
        if (zE) {
            AudioManager audioManager = (AudioManager) this.f386n.getApplicationContext().getSystemService("audio");
            if (audioManager != null) {
                audioManager.playSoundEffect(0);
            } else {
                Log.w("AppCompatDelegate", "Couldn't get audio manager");
            }
        }
        return zE;
    }

    /* JADX WARN: Code duplicated, block: B:64:0x00ed  */
    /* JADX WARN: Code duplicated, block: B:69:? A[RETURN, SYNTHETIC] */
    private void K0(PanelFeatureState panelFeatureState, KeyEvent keyEvent) {
        int i10;
        ViewGroup.LayoutParams layoutParams;
        if (panelFeatureState.f413o || this.U) {
            return;
        }
        if (panelFeatureState.f399a == 0 && (this.f386n.getResources().getConfiguration().screenLayout & 15) == 4) {
            return;
        }
        Window.Callback callbackT0 = t0();
        if (callbackT0 != null && !callbackT0.onMenuOpened(panelFeatureState.f399a, panelFeatureState.f408j)) {
            a0(panelFeatureState, true);
            return;
        }
        WindowManager windowManager = (WindowManager) this.f386n.getSystemService("window");
        if (windowManager != null && N0(panelFeatureState, keyEvent)) {
            ViewGroup viewGroup = panelFeatureState.f405g;
            if (viewGroup != null && !panelFeatureState.f415q) {
                View view = panelFeatureState.f407i;
                if (view != null && (layoutParams = view.getLayoutParams()) != null && layoutParams.width == -1) {
                    i10 = -1;
                }
                panelFeatureState.f412n = false;
                WindowManager.LayoutParams layoutParams2 = new WindowManager.LayoutParams(i10, -2, panelFeatureState.f402d, panelFeatureState.f403e, 1002, 8519680, -3);
                layoutParams2.gravity = panelFeatureState.f401c;
                layoutParams2.windowAnimations = panelFeatureState.f404f;
                windowManager.addView(panelFeatureState.f405g, layoutParams2);
                panelFeatureState.f413o = true;
                if (panelFeatureState.f399a == 0) {
                    a1();
                }
            }
            if (viewGroup == null) {
                if (!w0(panelFeatureState) || panelFeatureState.f405g == null) {
                    return;
                }
            } else if (panelFeatureState.f415q && viewGroup.getChildCount() > 0) {
                panelFeatureState.f405g.removeAllViews();
            }
            if (!v0(panelFeatureState) || !panelFeatureState.b()) {
                panelFeatureState.f415q = true;
                return;
            }
            ViewGroup.LayoutParams layoutParams3 = panelFeatureState.f406h.getLayoutParams();
            if (layoutParams3 == null) {
                layoutParams3 = new ViewGroup.LayoutParams(-2, -2);
            }
            panelFeatureState.f405g.setBackgroundResource(panelFeatureState.f400b);
            ViewParent parent = panelFeatureState.f406h.getParent();
            if (parent instanceof ViewGroup) {
                ((ViewGroup) parent).removeView(panelFeatureState.f406h);
            }
            panelFeatureState.f405g.addView(panelFeatureState.f406h, layoutParams3);
            if (!panelFeatureState.f406h.hasFocus()) {
                panelFeatureState.f406h.requestFocus();
            }
            i10 = -2;
            panelFeatureState.f412n = false;
            WindowManager.LayoutParams layoutParams4 = new WindowManager.LayoutParams(i10, -2, panelFeatureState.f402d, panelFeatureState.f403e, 1002, 8519680, -3);
            layoutParams4.gravity = panelFeatureState.f401c;
            layoutParams4.windowAnimations = panelFeatureState.f404f;
            windowManager.addView(panelFeatureState.f405g, layoutParams4);
            panelFeatureState.f413o = true;
            if (panelFeatureState.f399a == 0) {
                a1();
            }
        }
    }

    private boolean M0(PanelFeatureState panelFeatureState, int i10, KeyEvent keyEvent, int i11) {
        MenuBuilder menuBuilder;
        boolean zPerformShortcut = false;
        if (keyEvent.isSystem()) {
            return false;
        }
        if ((panelFeatureState.f411m || N0(panelFeatureState, keyEvent)) && (menuBuilder = panelFeatureState.f408j) != null) {
            zPerformShortcut = menuBuilder.performShortcut(i10, keyEvent, i11);
        }
        if (zPerformShortcut && (i11 & 1) == 0 && this.f393u == null) {
            a0(panelFeatureState, true);
        }
        return zPerformShortcut;
    }

    private boolean N0(PanelFeatureState panelFeatureState, KeyEvent keyEvent) {
        androidx.appcompat.widget.r rVar;
        androidx.appcompat.widget.r rVar2;
        androidx.appcompat.widget.r rVar3;
        if (this.U) {
            return false;
        }
        if (panelFeatureState.f411m) {
            return true;
        }
        PanelFeatureState panelFeatureState2 = this.Q;
        if (panelFeatureState2 != null && panelFeatureState2 != panelFeatureState) {
            a0(panelFeatureState2, false);
        }
        Window.Callback callbackT0 = t0();
        if (callbackT0 != null) {
            panelFeatureState.f407i = callbackT0.onCreatePanelView(panelFeatureState.f399a);
        }
        int i10 = panelFeatureState.f399a;
        boolean z10 = i10 == 0 || i10 == 108;
        if (z10 && (rVar3 = this.f393u) != null) {
            rVar3.c();
        }
        if (panelFeatureState.f407i == null && (!z10 || !(L0() instanceof androidx.appcompat.app.m))) {
            MenuBuilder menuBuilder = panelFeatureState.f408j;
            if (menuBuilder == null || panelFeatureState.f416r) {
                if (menuBuilder == null && (!x0(panelFeatureState) || panelFeatureState.f408j == null)) {
                    return false;
                }
                if (z10 && this.f393u != null) {
                    if (this.f394v == null) {
                        this.f394v = new h();
                    }
                    this.f393u.a(panelFeatureState.f408j, this.f394v);
                }
                panelFeatureState.f408j.stopDispatchingItemsChanged();
                if (!callbackT0.onCreatePanelMenu(panelFeatureState.f399a, panelFeatureState.f408j)) {
                    panelFeatureState.c(null);
                    if (z10 && (rVar = this.f393u) != null) {
                        rVar.a(null, this.f394v);
                    }
                    return false;
                }
                panelFeatureState.f416r = false;
            }
            panelFeatureState.f408j.stopDispatchingItemsChanged();
            Bundle bundle = panelFeatureState.f417s;
            if (bundle != null) {
                panelFeatureState.f408j.restoreActionViewStates(bundle);
                panelFeatureState.f417s = null;
            }
            if (!callbackT0.onPreparePanel(0, panelFeatureState.f407i, panelFeatureState.f408j)) {
                if (z10 && (rVar2 = this.f393u) != null) {
                    rVar2.a(null, this.f394v);
                }
                panelFeatureState.f408j.startDispatchingItemsChanged();
                return false;
            }
            boolean z11 = KeyCharacterMap.load(keyEvent != null ? keyEvent.getDeviceId() : -1).getKeyboardType() != 1;
            panelFeatureState.f414p = z11;
            panelFeatureState.f408j.setQwertyMode(z11);
            panelFeatureState.f408j.startDispatchingItemsChanged();
        }
        panelFeatureState.f411m = true;
        panelFeatureState.f412n = false;
        this.Q = panelFeatureState;
        return true;
    }

    private void O0(boolean z10) {
        androidx.appcompat.widget.r rVar = this.f393u;
        if (rVar == null || !rVar.g() || (ViewConfiguration.get(this.f386n).hasPermanentMenuKey() && !this.f393u.d())) {
            PanelFeatureState panelFeatureStateR0 = r0(0, true);
            panelFeatureStateR0.f415q = true;
            a0(panelFeatureStateR0, false);
            K0(panelFeatureStateR0, null);
            return;
        }
        Window.Callback callbackT0 = t0();
        if (this.f393u.b() && z10) {
            this.f393u.e();
            if (this.U) {
                return;
            }
            callbackT0.onPanelClosed(108, r0(0, true).f408j);
            return;
        }
        if (callbackT0 == null || this.U) {
            return;
        }
        if (this.f375c0 && (this.f376d0 & 1) != 0) {
            this.f387o.getDecorView().removeCallbacks(this.f377e0);
            this.f377e0.run();
        }
        PanelFeatureState panelFeatureStateR1 = r0(0, true);
        MenuBuilder menuBuilder = panelFeatureStateR1.f408j;
        if (menuBuilder == null || panelFeatureStateR1.f416r || !callbackT0.onPreparePanel(0, panelFeatureStateR1.f407i, menuBuilder)) {
            return;
        }
        callbackT0.onMenuOpened(108, panelFeatureStateR1.f408j);
        this.f393u.f();
    }

    private boolean P(boolean z10) {
        return Q(z10, true);
    }

    private int P0(int i10) {
        if (i10 == 8) {
            Log.i("AppCompatDelegate", "You should now use the AppCompatDelegate.FEATURE_SUPPORT_ACTION_BAR id when requesting this feature.");
            return 108;
        }
        if (i10 != 9) {
            return i10;
        }
        Log.i("AppCompatDelegate", "You should now use the AppCompatDelegate.FEATURE_SUPPORT_ACTION_BAR_OVERLAY id when requesting this feature.");
        return 109;
    }

    private boolean Q(boolean z10, boolean z11) {
        if (this.U) {
            return false;
        }
        int iV = V();
        boolean zZ0 = Z0(A0(this.f386n, iV), null, z10);
        if (iV == 0) {
            p0(this.f386n).e();
        } else {
            q qVar = this.f373a0;
            if (qVar != null) {
                qVar.a();
            }
        }
        if (iV == 3) {
            o0(this.f386n).e();
        } else {
            q qVar2 = this.f374b0;
            if (qVar2 != null) {
                qVar2.a();
            }
        }
        return zZ0;
    }

    private void S() {
        ContentFrameLayout contentFrameLayout = (ContentFrameLayout) this.E.findViewById(R.id.content);
        View decorView = this.f387o.getDecorView();
        contentFrameLayout.a(decorView.getPaddingLeft(), decorView.getPaddingTop(), decorView.getPaddingRight(), decorView.getPaddingBottom());
        TypedArray typedArrayObtainStyledAttributes = this.f386n.obtainStyledAttributes(R$styleable.AppCompatTheme);
        typedArrayObtainStyledAttributes.getValue(R$styleable.AppCompatTheme_windowMinWidthMajor, contentFrameLayout.getMinWidthMajor());
        typedArrayObtainStyledAttributes.getValue(R$styleable.AppCompatTheme_windowMinWidthMinor, contentFrameLayout.getMinWidthMinor());
        int i10 = R$styleable.AppCompatTheme_windowFixedWidthMajor;
        if (typedArrayObtainStyledAttributes.hasValue(i10)) {
            typedArrayObtainStyledAttributes.getValue(i10, contentFrameLayout.getFixedWidthMajor());
        }
        int i11 = R$styleable.AppCompatTheme_windowFixedWidthMinor;
        if (typedArrayObtainStyledAttributes.hasValue(i11)) {
            typedArrayObtainStyledAttributes.getValue(i11, contentFrameLayout.getFixedWidthMinor());
        }
        int i12 = R$styleable.AppCompatTheme_windowFixedHeightMajor;
        if (typedArrayObtainStyledAttributes.hasValue(i12)) {
            typedArrayObtainStyledAttributes.getValue(i12, contentFrameLayout.getFixedHeightMajor());
        }
        int i13 = R$styleable.AppCompatTheme_windowFixedHeightMinor;
        if (typedArrayObtainStyledAttributes.hasValue(i13)) {
            typedArrayObtainStyledAttributes.getValue(i13, contentFrameLayout.getFixedHeightMinor());
        }
        typedArrayObtainStyledAttributes.recycle();
        contentFrameLayout.requestLayout();
    }

    private void T(Window window) {
        if (this.f387o != null) {
            throw new IllegalStateException("AppCompat has already installed itself into the Window");
        }
        Window.Callback callback = window.getCallback();
        if (callback instanceof o) {
            throw new IllegalStateException("AppCompat has already installed itself into the Window");
        }
        o oVar = new o(callback);
        this.f388p = oVar;
        window.setCallback(oVar);
        androidx.appcompat.widget.h0 h0VarV = androidx.appcompat.widget.h0.v(this.f386n, null, f370o0);
        Drawable drawableH = h0VarV.h(0);
        if (drawableH != null) {
            window.setBackgroundDrawable(drawableH);
        }
        h0VarV.x();
        this.f387o = window;
        if (this.f383k0 == null) {
            J(null);
        }
    }

    private boolean T0(ViewParent viewParent) {
        if (viewParent == null) {
            return false;
        }
        View decorView = this.f387o.getDecorView();
        while (viewParent != null) {
            if (viewParent == decorView || !(viewParent instanceof View) || h0.P((View) viewParent)) {
                return false;
            }
            viewParent = viewParent.getParent();
        }
        return true;
    }

    private int V() {
        int i10 = this.W;
        return i10 != -100 ? i10 : androidx.appcompat.app.e.k();
    }

    private void W0() {
        if (this.D) {
            throw new AndroidRuntimeException("Window feature must be requested before adding content");
        }
    }

    private AppCompatActivity X0() {
        for (Context baseContext = this.f386n; baseContext != null; baseContext = ((ContextWrapper) baseContext).getBaseContext()) {
            if (baseContext instanceof AppCompatActivity) {
                return (AppCompatActivity) baseContext;
            }
            if (!(baseContext instanceof ContextWrapper)) {
                break;
            }
        }
        return null;
    }

    private void Y() {
        q qVar = this.f373a0;
        if (qVar != null) {
            qVar.a();
        }
        q qVar2 = this.f374b0;
        if (qVar2 != null) {
            qVar2.a();
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    private void Y0(Configuration configuration) {
        Activity activity = (Activity) this.f385m;
        if (activity instanceof androidx.lifecycle.l) {
            if (((androidx.lifecycle.l) activity).getLifecycle().b().b(Lifecycle.State.CREATED)) {
                activity.onConfigurationChanged(configuration);
            }
        } else {
            if (!this.T || this.U) {
                return;
            }
            activity.onConfigurationChanged(configuration);
        }
    }

    /* JADX WARN: Code duplicated, block: B:31:0x006f  */
    private boolean Z0(int i10, androidx.core.os.e eVar, boolean z10) {
        boolean z11;
        Configuration configurationB0 = b0(this.f386n, i10, eVar, null, false);
        int iN0 = n0(this.f386n);
        Configuration configuration = this.V;
        if (configuration == null) {
            configuration = this.f386n.getResources().getConfiguration();
        }
        int i11 = configuration.uiMode & 48;
        int i12 = configurationB0.uiMode & 48;
        androidx.core.os.e eVarQ0 = q0(configuration);
        androidx.core.os.e eVarQ1 = eVar == null ? null : q0(configurationB0);
        int i13 = i11 != i12 ? DataLinkConstants.DATA_UPLOAD : 0;
        if (eVarQ1 != null && !eVarQ0.equals(eVarQ1)) {
            i13 |= 8196;
        }
        boolean z12 = true;
        if (((~iN0) & i13) != 0 && z10 && this.S && (f371p0 || this.T)) {
            Object obj = this.f385m;
            if (!(obj instanceof Activity) || ((Activity) obj).isChild()) {
                z11 = false;
            } else {
                androidx.core.app.a.o((Activity) this.f385m);
                z11 = true;
            }
        } else {
            z11 = false;
        }
        if (z11 || i13 == 0) {
            z12 = z11;
        } else {
            b1(i12, eVarQ1, (i13 & iN0) == i13, null);
        }
        if (z12) {
            Object obj2 = this.f385m;
            if (obj2 instanceof AppCompatActivity) {
                if ((i13 & DataLinkConstants.DATA_UPLOAD) != 0) {
                    ((AppCompatActivity) obj2).onNightModeChanged(i10);
                }
                if ((i13 & 4) != 0) {
                    ((AppCompatActivity) this.f385m).onLocalesChanged(eVar);
                }
            }
        }
        if (z12 && eVarQ1 != null) {
            R0(q0(this.f386n.getResources().getConfiguration()));
        }
        return z12;
    }

    private Configuration b0(Context context, int i10, androidx.core.os.e eVar, Configuration configuration, boolean z10) {
        int i11;
        if (i10 == 1) {
            i11 = 16;
        } else if (i10 != 2) {
            i11 = z10 ? 0 : context.getApplicationContext().getResources().getConfiguration().uiMode & 48;
        } else {
            i11 = 32;
        }
        Configuration configuration2 = new Configuration();
        configuration2.fontScale = 0.0f;
        if (configuration != null) {
            configuration2.setTo(configuration);
        }
        configuration2.uiMode = i11 | (configuration2.uiMode & (-49));
        if (eVar != null) {
            Q0(configuration2, eVar);
        }
        return configuration2;
    }

    private void b1(int i10, androidx.core.os.e eVar, boolean z10, Configuration configuration) {
        Resources resources = this.f386n.getResources();
        Configuration configuration2 = new Configuration(resources.getConfiguration());
        if (configuration != null) {
            configuration2.updateFrom(configuration);
        }
        configuration2.uiMode = i10 | (resources.getConfiguration().uiMode & (-49));
        if (eVar != null) {
            Q0(configuration2, eVar);
        }
        resources.updateConfiguration(configuration2, null);
        int i11 = this.X;
        if (i11 != 0) {
            this.f386n.setTheme(i11);
            this.f386n.getTheme().applyStyle(this.X, true);
        }
        if (z10 && (this.f385m instanceof Activity)) {
            Y0(configuration2);
        }
    }

    private ViewGroup c0() {
        ViewGroup viewGroup;
        TypedArray typedArrayObtainStyledAttributes = this.f386n.obtainStyledAttributes(R$styleable.AppCompatTheme);
        int i10 = R$styleable.AppCompatTheme_windowActionBar;
        if (!typedArrayObtainStyledAttributes.hasValue(i10)) {
            typedArrayObtainStyledAttributes.recycle();
            throw new IllegalStateException("You need to use a Theme.AppCompat theme (or descendant) with this activity.");
        }
        if (typedArrayObtainStyledAttributes.getBoolean(R$styleable.AppCompatTheme_windowNoTitle, false)) {
            E(1);
        } else if (typedArrayObtainStyledAttributes.getBoolean(i10, false)) {
            E(108);
        }
        if (typedArrayObtainStyledAttributes.getBoolean(R$styleable.AppCompatTheme_windowActionBarOverlay, false)) {
            E(109);
        }
        if (typedArrayObtainStyledAttributes.getBoolean(R$styleable.AppCompatTheme_windowActionModeOverlay, false)) {
            E(10);
        }
        this.M = typedArrayObtainStyledAttributes.getBoolean(R$styleable.AppCompatTheme_android_windowIsFloating, false);
        typedArrayObtainStyledAttributes.recycle();
        j0();
        this.f387o.getDecorView();
        LayoutInflater layoutInflaterFrom = LayoutInflater.from(this.f386n);
        if (this.N) {
            viewGroup = this.L ? (ViewGroup) layoutInflaterFrom.inflate(R$layout.abc_screen_simple_overlay_action_mode, (ViewGroup) null) : (ViewGroup) layoutInflaterFrom.inflate(R$layout.abc_screen_simple, (ViewGroup) null);
        } else if (this.M) {
            viewGroup = (ViewGroup) layoutInflaterFrom.inflate(R$layout.abc_dialog_title_material, (ViewGroup) null);
            this.K = false;
            this.J = false;
        } else if (this.J) {
            TypedValue typedValue = new TypedValue();
            this.f386n.getTheme().resolveAttribute(R$attr.actionBarTheme, typedValue, true);
            viewGroup = (ViewGroup) LayoutInflater.from(typedValue.resourceId != 0 ? new androidx.appcompat.view.d(this.f386n, typedValue.resourceId) : this.f386n).inflate(R$layout.abc_screen_toolbar, (ViewGroup) null);
            androidx.appcompat.widget.r rVar = (androidx.appcompat.widget.r) viewGroup.findViewById(R$id.decor_content_parent);
            this.f393u = rVar;
            rVar.setWindowCallback(t0());
            if (this.K) {
                this.f393u.k(109);
            }
            if (this.H) {
                this.f393u.k(2);
            }
            if (this.I) {
                this.f393u.k(5);
            }
        } else {
            viewGroup = null;
        }
        if (viewGroup == null) {
            throw new IllegalArgumentException("AppCompat does not support the current theme features: { windowActionBar: " + this.J + ", windowActionBarOverlay: " + this.K + ", android:windowIsFloating: " + this.M + ", windowActionModeOverlay: " + this.L + ", windowNoTitle: " + this.N + " }");
        }
        h0.B0(viewGroup, new b());
        if (this.f393u == null) {
            this.F = (TextView) viewGroup.findViewById(R$id.title);
        }
        o0.c(viewGroup);
        ContentFrameLayout contentFrameLayout = (ContentFrameLayout) viewGroup.findViewById(R$id.action_bar_activity_content);
        ViewGroup viewGroup2 = (ViewGroup) this.f387o.findViewById(R.id.content);
        if (viewGroup2 != null) {
            while (viewGroup2.getChildCount() > 0) {
                View childAt = viewGroup2.getChildAt(0);
                viewGroup2.removeViewAt(0);
                contentFrameLayout.addView(childAt);
            }
            viewGroup2.setId(-1);
            contentFrameLayout.setId(R.id.content);
            if (viewGroup2 instanceof FrameLayout) {
                ((FrameLayout) viewGroup2).setForeground(null);
            }
        }
        this.f387o.setContentView(viewGroup);
        contentFrameLayout.setAttachListener(new c());
        return viewGroup;
    }

    private void d1(View view) {
        view.setBackgroundColor((h0.I(view) & 8192) != 0 ? androidx.core.content.a.c(this.f386n, R$color.abc_decor_view_status_guard_light) : androidx.core.content.a.c(this.f386n, R$color.abc_decor_view_status_guard));
    }

    private void i0() {
        if (this.D) {
            return;
        }
        this.E = c0();
        CharSequence charSequenceS0 = s0();
        if (!TextUtils.isEmpty(charSequenceS0)) {
            androidx.appcompat.widget.r rVar = this.f393u;
            if (rVar != null) {
                rVar.setWindowTitle(charSequenceS0);
            } else if (L0() != null) {
                L0().u(charSequenceS0);
            } else {
                TextView textView = this.F;
                if (textView != null) {
                    textView.setText(charSequenceS0);
                }
            }
        }
        S();
        J0(this.E);
        this.D = true;
        PanelFeatureState panelFeatureStateR0 = r0(0, false);
        if (this.U) {
            return;
        }
        if (panelFeatureStateR0 == null || panelFeatureStateR0.f408j == null) {
            y0(108);
        }
    }

    private void j0() {
        if (this.f387o == null) {
            Object obj = this.f385m;
            if (obj instanceof Activity) {
                T(((Activity) obj).getWindow());
            }
        }
        if (this.f387o == null) {
            throw new IllegalStateException("We have not been given a Window");
        }
    }

    private static Configuration l0(Configuration configuration, Configuration configuration2) {
        Configuration configuration3 = new Configuration();
        configuration3.fontScale = 0.0f;
        if (configuration2 != null && configuration.diff(configuration2) != 0) {
            float f10 = configuration.fontScale;
            float f11 = configuration2.fontScale;
            if (f10 != f11) {
                configuration3.fontScale = f11;
            }
            int i10 = configuration.mcc;
            int i11 = configuration2.mcc;
            if (i10 != i11) {
                configuration3.mcc = i11;
            }
            int i12 = configuration.mnc;
            int i13 = configuration2.mnc;
            if (i12 != i13) {
                configuration3.mnc = i13;
            }
            l.a(configuration, configuration2, configuration3);
            int i14 = configuration.touchscreen;
            int i15 = configuration2.touchscreen;
            if (i14 != i15) {
                configuration3.touchscreen = i15;
            }
            int i16 = configuration.keyboard;
            int i17 = configuration2.keyboard;
            if (i16 != i17) {
                configuration3.keyboard = i17;
            }
            int i18 = configuration.keyboardHidden;
            int i19 = configuration2.keyboardHidden;
            if (i18 != i19) {
                configuration3.keyboardHidden = i19;
            }
            int i20 = configuration.navigation;
            int i21 = configuration2.navigation;
            if (i20 != i21) {
                configuration3.navigation = i21;
            }
            int i22 = configuration.navigationHidden;
            int i23 = configuration2.navigationHidden;
            if (i22 != i23) {
                configuration3.navigationHidden = i23;
            }
            int i24 = configuration.orientation;
            int i25 = configuration2.orientation;
            if (i24 != i25) {
                configuration3.orientation = i25;
            }
            int i26 = configuration.screenLayout & 15;
            int i27 = configuration2.screenLayout;
            if (i26 != (i27 & 15)) {
                configuration3.screenLayout |= i27 & 15;
            }
            int i28 = configuration.screenLayout & 192;
            int i29 = configuration2.screenLayout;
            if (i28 != (i29 & 192)) {
                configuration3.screenLayout |= i29 & 192;
            }
            int i30 = configuration.screenLayout & 48;
            int i31 = configuration2.screenLayout;
            if (i30 != (i31 & 48)) {
                configuration3.screenLayout |= i31 & 48;
            }
            int i32 = configuration.screenLayout & ViewUtils.EDGE_TO_EDGE_FLAGS;
            int i33 = configuration2.screenLayout;
            if (i32 != (i33 & ViewUtils.EDGE_TO_EDGE_FLAGS)) {
                configuration3.screenLayout |= i33 & ViewUtils.EDGE_TO_EDGE_FLAGS;
            }
            m.a(configuration, configuration2, configuration3);
            int i34 = configuration.uiMode & 15;
            int i35 = configuration2.uiMode;
            if (i34 != (i35 & 15)) {
                configuration3.uiMode |= i35 & 15;
            }
            int i36 = configuration.uiMode & 48;
            int i37 = configuration2.uiMode;
            if (i36 != (i37 & 48)) {
                configuration3.uiMode |= i37 & 48;
            }
            int i38 = configuration.screenWidthDp;
            int i39 = configuration2.screenWidthDp;
            if (i38 != i39) {
                configuration3.screenWidthDp = i39;
            }
            int i40 = configuration.screenHeightDp;
            int i41 = configuration2.screenHeightDp;
            if (i40 != i41) {
                configuration3.screenHeightDp = i41;
            }
            int i42 = configuration.smallestScreenWidthDp;
            int i43 = configuration2.smallestScreenWidthDp;
            if (i42 != i43) {
                configuration3.smallestScreenWidthDp = i43;
            }
            j.b(configuration, configuration2, configuration3);
        }
        return configuration3;
    }

    private int n0(Context context) {
        if (!this.Z && (this.f385m instanceof Activity)) {
            PackageManager packageManager = context.getPackageManager();
            if (packageManager == null) {
                return 0;
            }
            try {
                ActivityInfo activityInfo = packageManager.getActivityInfo(new ComponentName(context, this.f385m.getClass()), 269221888);
                if (activityInfo != null) {
                    this.Y = activityInfo.configChanges;
                }
            } catch (PackageManager.NameNotFoundException e10) {
                Log.d("AppCompatDelegate", "Exception while getting ActivityInfo", e10);
                this.Y = 0;
            }
        }
        this.Z = true;
        return this.Y;
    }

    private q o0(Context context) {
        if (this.f374b0 == null) {
            this.f374b0 = new p(context);
        }
        return this.f374b0;
    }

    private q p0(Context context) {
        if (this.f373a0 == null) {
            this.f373a0 = new r(androidx.appcompat.app.o.a(context));
        }
        return this.f373a0;
    }

    private void u0() {
        i0();
        if (this.J && this.f390r == null) {
            Object obj = this.f385m;
            if (obj instanceof Activity) {
                this.f390r = new androidx.appcompat.app.p((Activity) this.f385m, this.K);
            } else if (obj instanceof Dialog) {
                this.f390r = new androidx.appcompat.app.p((Dialog) this.f385m);
            }
            ActionBar actionBar = this.f390r;
            if (actionBar != null) {
                actionBar.r(this.f378f0);
            }
        }
    }

    private boolean v0(PanelFeatureState panelFeatureState) {
        View view = panelFeatureState.f407i;
        if (view != null) {
            panelFeatureState.f406h = view;
            return true;
        }
        if (panelFeatureState.f408j == null) {
            return false;
        }
        if (this.f395w == null) {
            this.f395w = new u();
        }
        View view2 = (View) panelFeatureState.a(this.f395w);
        panelFeatureState.f406h = view2;
        return view2 != null;
    }

    private boolean w0(PanelFeatureState panelFeatureState) {
        panelFeatureState.d(m0());
        panelFeatureState.f405g = new t(panelFeatureState.f410l);
        panelFeatureState.f401c = 81;
        return true;
    }

    private boolean x0(PanelFeatureState panelFeatureState) {
        Resources.Theme themeNewTheme;
        Context context = this.f386n;
        int i10 = panelFeatureState.f399a;
        if ((i10 == 0 || i10 == 108) && this.f393u != null) {
            TypedValue typedValue = new TypedValue();
            Resources.Theme theme = context.getTheme();
            theme.resolveAttribute(R$attr.actionBarTheme, typedValue, true);
            if (typedValue.resourceId != 0) {
                themeNewTheme = context.getResources().newTheme();
                themeNewTheme.setTo(theme);
                themeNewTheme.applyStyle(typedValue.resourceId, true);
                themeNewTheme.resolveAttribute(R$attr.actionBarWidgetTheme, typedValue, true);
            } else {
                theme.resolveAttribute(R$attr.actionBarWidgetTheme, typedValue, true);
                themeNewTheme = null;
            }
            if (typedValue.resourceId != 0) {
                if (themeNewTheme == null) {
                    themeNewTheme = context.getResources().newTheme();
                    themeNewTheme.setTo(theme);
                }
                themeNewTheme.applyStyle(typedValue.resourceId, true);
            }
            if (themeNewTheme != null) {
                androidx.appcompat.view.d dVar = new androidx.appcompat.view.d(context, 0);
                dVar.getTheme().setTo(themeNewTheme);
                context = dVar;
            }
        }
        MenuBuilder menuBuilder = new MenuBuilder(context);
        menuBuilder.setCallback(this);
        panelFeatureState.c(menuBuilder);
        return true;
    }

    private void y0(int i10) {
        this.f376d0 = (1 << i10) | this.f376d0;
        if (this.f375c0) {
            return;
        }
        h0.c0(this.f387o.getDecorView(), this.f377e0);
        this.f375c0 = true;
    }

    @Override // androidx.appcompat.app.e
    public void A() {
        Q(true, false);
    }

    int A0(Context context, int i10) {
        if (i10 == -100) {
            return -1;
        }
        if (i10 != -1) {
            if (i10 == 0) {
                if (((UiModeManager) context.getApplicationContext().getSystemService("uimode")).getNightMode() == 0) {
                    return -1;
                }
                return p0(context).c();
            }
            if (i10 != 1 && i10 != 2) {
                if (i10 == 3) {
                    return o0(context).c();
                }
                throw new IllegalStateException("Unknown value set for night mode. Please use one of the MODE_NIGHT values from AppCompatDelegate.");
            }
        }
        return i10;
    }

    @Override // androidx.appcompat.app.e
    public void B() {
        ActionBar actionBarP = p();
        if (actionBarP != null) {
            actionBarP.t(false);
        }
    }

    boolean B0() {
        boolean z10 = this.R;
        this.R = false;
        PanelFeatureState panelFeatureStateR0 = r0(0, false);
        if (panelFeatureStateR0 != null && panelFeatureStateR0.f413o) {
            if (!z10) {
                a0(panelFeatureStateR0, true);
            }
            return true;
        }
        androidx.appcompat.view.b bVar = this.f396x;
        if (bVar != null) {
            bVar.a();
            return true;
        }
        ActionBar actionBarP = p();
        return actionBarP != null && actionBarP.h();
    }

    boolean C0(int i10, KeyEvent keyEvent) {
        if (i10 == 4) {
            this.R = (keyEvent.getFlags() & 128) != 0;
        } else if (i10 == 82) {
            D0(0, keyEvent);
            return true;
        }
        return false;
    }

    @Override // androidx.appcompat.app.e
    public boolean E(int i10) {
        int iP0 = P0(i10);
        if (this.N && iP0 == 108) {
            return false;
        }
        if (this.J && iP0 == 1) {
            this.J = false;
        }
        if (iP0 == 1) {
            W0();
            this.N = true;
            return true;
        }
        if (iP0 == 2) {
            W0();
            this.H = true;
            return true;
        }
        if (iP0 == 5) {
            W0();
            this.I = true;
            return true;
        }
        if (iP0 == 10) {
            W0();
            this.L = true;
            return true;
        }
        if (iP0 == 108) {
            W0();
            this.J = true;
            return true;
        }
        if (iP0 != 109) {
            return this.f387o.requestFeature(iP0);
        }
        W0();
        this.K = true;
        return true;
    }

    boolean E0(int i10, KeyEvent keyEvent) {
        ActionBar actionBarP = p();
        if (actionBarP != null && actionBarP.o(i10, keyEvent)) {
            return true;
        }
        PanelFeatureState panelFeatureState = this.Q;
        if (panelFeatureState != null && M0(panelFeatureState, keyEvent.getKeyCode(), keyEvent, 1)) {
            PanelFeatureState panelFeatureState2 = this.Q;
            if (panelFeatureState2 != null) {
                panelFeatureState2.f412n = true;
            }
            return true;
        }
        if (this.Q == null) {
            PanelFeatureState panelFeatureStateR0 = r0(0, true);
            N0(panelFeatureStateR0, keyEvent);
            boolean zM0 = M0(panelFeatureStateR0, keyEvent.getKeyCode(), keyEvent, 1);
            panelFeatureStateR0.f411m = false;
            if (zM0) {
                return true;
            }
        }
        return false;
    }

    @Override // androidx.appcompat.app.e
    public void F(int i10) {
        i0();
        ViewGroup viewGroup = (ViewGroup) this.E.findViewById(R.id.content);
        viewGroup.removeAllViews();
        LayoutInflater.from(this.f386n).inflate(i10, viewGroup);
        this.f388p.c(this.f387o.getCallback());
    }

    boolean F0(int i10, KeyEvent keyEvent) {
        if (i10 != 4) {
            if (i10 == 82) {
                G0(0, keyEvent);
                return true;
            }
        } else if (B0()) {
            return true;
        }
        return false;
    }

    @Override // androidx.appcompat.app.e
    public void G(View view) {
        i0();
        ViewGroup viewGroup = (ViewGroup) this.E.findViewById(R.id.content);
        viewGroup.removeAllViews();
        viewGroup.addView(view);
        this.f388p.c(this.f387o.getCallback());
    }

    @Override // androidx.appcompat.app.e
    public void H(View view, ViewGroup.LayoutParams layoutParams) {
        i0();
        ViewGroup viewGroup = (ViewGroup) this.E.findViewById(R.id.content);
        viewGroup.removeAllViews();
        viewGroup.addView(view, layoutParams);
        this.f388p.c(this.f387o.getCallback());
    }

    void H0(int i10) {
        ActionBar actionBarP;
        if (i10 != 108 || (actionBarP = p()) == null) {
            return;
        }
        actionBarP.i(true);
    }

    @Override // androidx.appcompat.app.e
    public void I(int i10) {
        if (this.W != i10) {
            this.W = i10;
            if (this.S) {
                R();
            }
        }
    }

    void I0(int i10) {
        if (i10 == 108) {
            ActionBar actionBarP = p();
            if (actionBarP != null) {
                actionBarP.i(false);
                return;
            }
            return;
        }
        if (i10 == 0) {
            PanelFeatureState panelFeatureStateR0 = r0(i10, true);
            if (panelFeatureStateR0.f413o) {
                a0(panelFeatureStateR0, false);
            }
        }
    }

    /* JADX WARN: Code duplicated, block: B:13:0x002c  */
    @Override // androidx.appcompat.app.e
    public void J(OnBackInvokedDispatcher onBackInvokedDispatcher) {
        OnBackInvokedCallback onBackInvokedCallback;
        super.J(onBackInvokedDispatcher);
        OnBackInvokedDispatcher onBackInvokedDispatcher2 = this.f383k0;
        if (onBackInvokedDispatcher2 != null && (onBackInvokedCallback = this.f384l0) != null) {
            n.c(onBackInvokedDispatcher2, onBackInvokedCallback);
            this.f384l0 = null;
        }
        if (onBackInvokedDispatcher == null) {
            Object obj = this.f385m;
            if (!(obj instanceof Activity) || ((Activity) obj).getWindow() == null) {
                this.f383k0 = onBackInvokedDispatcher;
            } else {
                this.f383k0 = n.a((Activity) this.f385m);
            }
        } else {
            this.f383k0 = onBackInvokedDispatcher;
        }
        a1();
    }

    @Override // androidx.appcompat.app.e
    public void K(Toolbar toolbar) {
        if (this.f385m instanceof Activity) {
            ActionBar actionBarP = p();
            if (actionBarP instanceof androidx.appcompat.app.p) {
                throw new IllegalStateException("This Activity already has an action bar supplied by the window decor. Do not request Window.FEATURE_SUPPORT_ACTION_BAR and set windowActionBar to false in your theme to use a Toolbar instead.");
            }
            this.f391s = null;
            if (actionBarP != null) {
                actionBarP.n();
            }
            this.f390r = null;
            if (toolbar != null) {
                androidx.appcompat.app.m mVar = new androidx.appcompat.app.m(toolbar, s0(), this.f388p);
                this.f390r = mVar;
                this.f388p.e(mVar.f476c);
                toolbar.setBackInvokedCallbackEnabled(true);
            } else {
                this.f388p.e(null);
            }
            r();
        }
    }

    @Override // androidx.appcompat.app.e
    public void L(int i10) {
        this.X = i10;
    }

    final ActionBar L0() {
        return this.f390r;
    }

    @Override // androidx.appcompat.app.e
    public final void M(CharSequence charSequence) {
        this.f392t = charSequence;
        androidx.appcompat.widget.r rVar = this.f393u;
        if (rVar != null) {
            rVar.setWindowTitle(charSequence);
            return;
        }
        if (L0() != null) {
            L0().u(charSequence);
            return;
        }
        TextView textView = this.F;
        if (textView != null) {
            textView.setText(charSequence);
        }
    }

    @Override // androidx.appcompat.app.e
    public androidx.appcompat.view.b N(androidx.appcompat.view.b.a aVar) {
        androidx.appcompat.app.c cVar;
        if (aVar == null) {
            throw new IllegalArgumentException("ActionMode callback can not be null.");
        }
        androidx.appcompat.view.b bVar = this.f396x;
        if (bVar != null) {
            bVar.a();
        }
        i iVar = new i(aVar);
        ActionBar actionBarP = p();
        if (actionBarP != null) {
            androidx.appcompat.view.b bVarV = actionBarP.v(iVar);
            this.f396x = bVarV;
            if (bVarV != null && (cVar = this.f389q) != null) {
                cVar.onSupportActionModeStarted(bVarV);
            }
        }
        if (this.f396x == null) {
            this.f396x = V0(iVar);
        }
        a1();
        return this.f396x;
    }

    void Q0(Configuration configuration, androidx.core.os.e eVar) {
        l.d(configuration, eVar);
    }

    public boolean R() {
        return P(true);
    }

    void R0(androidx.core.os.e eVar) {
        l.c(eVar);
    }

    final boolean S0() {
        ViewGroup viewGroup;
        return this.D && (viewGroup = this.E) != null && h0.Q(viewGroup);
    }

    androidx.core.os.e U(Context context) {
        return null;
    }

    boolean U0() {
        if (this.f383k0 == null) {
            return false;
        }
        PanelFeatureState panelFeatureStateR0 = r0(0, false);
        return (panelFeatureStateR0 != null && panelFeatureStateR0.f413o) || this.f396x != null;
    }

    androidx.appcompat.view.b V0(androidx.appcompat.view.b.a aVar) {
        androidx.appcompat.view.b bVarOnWindowStartingSupportActionMode;
        Context dVar;
        androidx.appcompat.app.c cVar;
        h0();
        androidx.appcompat.view.b bVar = this.f396x;
        if (bVar != null) {
            bVar.a();
        }
        if (!(aVar instanceof i)) {
            aVar = new i(aVar);
        }
        androidx.appcompat.app.c cVar2 = this.f389q;
        if (cVar2 == null || this.U) {
            bVarOnWindowStartingSupportActionMode = null;
        } else {
            try {
                bVarOnWindowStartingSupportActionMode = cVar2.onWindowStartingSupportActionMode(aVar);
            } catch (AbstractMethodError unused) {
                bVarOnWindowStartingSupportActionMode = null;
            }
        }
        if (bVarOnWindowStartingSupportActionMode != null) {
            this.f396x = bVarOnWindowStartingSupportActionMode;
        } else {
            if (this.f397y == null) {
                if (this.M) {
                    TypedValue typedValue = new TypedValue();
                    Resources.Theme theme = this.f386n.getTheme();
                    theme.resolveAttribute(R$attr.actionBarTheme, typedValue, true);
                    if (typedValue.resourceId != 0) {
                        Resources.Theme themeNewTheme = this.f386n.getResources().newTheme();
                        themeNewTheme.setTo(theme);
                        themeNewTheme.applyStyle(typedValue.resourceId, true);
                        dVar = new androidx.appcompat.view.d(this.f386n, 0);
                        dVar.getTheme().setTo(themeNewTheme);
                    } else {
                        dVar = this.f386n;
                    }
                    this.f397y = new ActionBarContextView(dVar);
                    PopupWindow popupWindow = new PopupWindow(dVar, (AttributeSet) null, R$attr.actionModePopupWindowStyle);
                    this.f398z = popupWindow;
                    androidx.core.widget.i.b(popupWindow, 2);
                    this.f398z.setContentView(this.f397y);
                    this.f398z.setWidth(-1);
                    dVar.getTheme().resolveAttribute(R$attr.actionBarSize, typedValue, true);
                    this.f397y.setContentHeight(TypedValue.complexToDimensionPixelSize(typedValue.data, dVar.getResources().getDisplayMetrics()));
                    this.f398z.setHeight(-2);
                    this.A = new d();
                } else {
                    ViewStubCompat viewStubCompat = (ViewStubCompat) this.E.findViewById(R$id.action_mode_bar_stub);
                    if (viewStubCompat != null) {
                        viewStubCompat.setLayoutInflater(LayoutInflater.from(m0()));
                        this.f397y = (ActionBarContextView) viewStubCompat.a();
                    }
                }
            }
            if (this.f397y != null) {
                h0();
                this.f397y.k();
                androidx.appcompat.view.e eVar = new androidx.appcompat.view.e(this.f397y.getContext(), this.f397y, aVar, this.f398z == null);
                if (aVar.d(eVar, eVar.c())) {
                    eVar.i();
                    this.f397y.h(eVar);
                    this.f396x = eVar;
                    if (S0()) {
                        this.f397y.setAlpha(0.0f);
                        n0 n0VarB = h0.d(this.f397y).b(1.0f);
                        this.B = n0VarB;
                        n0VarB.h(new e());
                    } else {
                        this.f397y.setAlpha(1.0f);
                        this.f397y.setVisibility(0);
                        if (this.f397y.getParent() instanceof View) {
                            h0.h0((View) this.f397y.getParent());
                        }
                    }
                    if (this.f398z != null) {
                        this.f387o.getDecorView().post(this.A);
                    }
                } else {
                    this.f396x = null;
                }
            }
        }
        androidx.appcompat.view.b bVar2 = this.f396x;
        if (bVar2 != null && (cVar = this.f389q) != null) {
            cVar.onSupportActionModeStarted(bVar2);
        }
        a1();
        return this.f396x;
    }

    void W(int i10, PanelFeatureState panelFeatureState, Menu menu) {
        if (menu == null) {
            if (panelFeatureState == null && i10 >= 0) {
                PanelFeatureState[] panelFeatureStateArr = this.P;
                if (i10 < panelFeatureStateArr.length) {
                    panelFeatureState = panelFeatureStateArr[i10];
                }
            }
            if (panelFeatureState != null) {
                menu = panelFeatureState.f408j;
            }
        }
        if ((panelFeatureState == null || panelFeatureState.f413o) && !this.U) {
            this.f388p.d(this.f387o.getCallback(), i10, menu);
        }
    }

    void X(MenuBuilder menuBuilder) {
        if (this.O) {
            return;
        }
        this.O = true;
        this.f393u.l();
        Window.Callback callbackT0 = t0();
        if (callbackT0 != null && !this.U) {
            callbackT0.onPanelClosed(108, menuBuilder);
        }
        this.O = false;
    }

    void Z(int i10) {
        a0(r0(i10, true), true);
    }

    void a0(PanelFeatureState panelFeatureState, boolean z10) {
        ViewGroup viewGroup;
        androidx.appcompat.widget.r rVar;
        if (z10 && panelFeatureState.f399a == 0 && (rVar = this.f393u) != null && rVar.b()) {
            X(panelFeatureState.f408j);
            return;
        }
        WindowManager windowManager = (WindowManager) this.f386n.getSystemService("window");
        if (windowManager != null && panelFeatureState.f413o && (viewGroup = panelFeatureState.f405g) != null) {
            windowManager.removeView(viewGroup);
            if (z10) {
                W(panelFeatureState.f399a, panelFeatureState, null);
            }
        }
        panelFeatureState.f411m = false;
        panelFeatureState.f412n = false;
        panelFeatureState.f413o = false;
        panelFeatureState.f406h = null;
        panelFeatureState.f415q = true;
        if (this.Q == panelFeatureState) {
            this.Q = null;
        }
        if (panelFeatureState.f399a == 0) {
            a1();
        }
    }

    void a1() {
        OnBackInvokedCallback onBackInvokedCallback;
        boolean zU0 = U0();
        if (zU0 && this.f384l0 == null) {
            this.f384l0 = n.b(this.f383k0, this);
        } else {
            if (zU0 || (onBackInvokedCallback = this.f384l0) == null) {
                return;
            }
            n.c(this.f383k0, onBackInvokedCallback);
        }
    }

    @Override // androidx.appcompat.app.e
    public void c(View view, ViewGroup.LayoutParams layoutParams) {
        i0();
        ((ViewGroup) this.E.findViewById(R.id.content)).addView(view, layoutParams);
        this.f388p.c(this.f387o.getCallback());
    }

    final int c1(t0 t0Var, Rect rect) {
        int iL;
        boolean z10;
        boolean z11;
        if (t0Var != null) {
            iL = t0Var.l();
        } else {
            iL = rect != null ? rect.top : 0;
        }
        ActionBarContextView actionBarContextView = this.f397y;
        if (actionBarContextView == null || !(actionBarContextView.getLayoutParams() instanceof ViewGroup.MarginLayoutParams)) {
            z10 = false;
        } else {
            ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) this.f397y.getLayoutParams();
            boolean z12 = true;
            if (this.f397y.isShown()) {
                if (this.f379g0 == null) {
                    this.f379g0 = new Rect();
                    this.f380h0 = new Rect();
                }
                Rect rect2 = this.f379g0;
                Rect rect3 = this.f380h0;
                if (t0Var == null) {
                    rect2.set(rect);
                } else {
                    rect2.set(t0Var.j(), t0Var.l(), t0Var.k(), t0Var.i());
                }
                o0.a(this.E, rect2, rect3);
                int i10 = rect2.top;
                int i11 = rect2.left;
                int i12 = rect2.right;
                t0 t0VarD = h0.D(this.E);
                int iJ = t0VarD == null ? 0 : t0VarD.j();
                int iK = t0VarD == null ? 0 : t0VarD.k();
                if (marginLayoutParams.topMargin == i10 && marginLayoutParams.leftMargin == i11 && marginLayoutParams.rightMargin == i12) {
                    z11 = false;
                } else {
                    marginLayoutParams.topMargin = i10;
                    marginLayoutParams.leftMargin = i11;
                    marginLayoutParams.rightMargin = i12;
                    z11 = true;
                }
                if (i10 <= 0 || this.G != null) {
                    View view = this.G;
                    if (view != null) {
                        ViewGroup.MarginLayoutParams marginLayoutParams2 = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
                        int i13 = marginLayoutParams2.height;
                        int i14 = marginLayoutParams.topMargin;
                        if (i13 != i14 || marginLayoutParams2.leftMargin != iJ || marginLayoutParams2.rightMargin != iK) {
                            marginLayoutParams2.height = i14;
                            marginLayoutParams2.leftMargin = iJ;
                            marginLayoutParams2.rightMargin = iK;
                            this.G.setLayoutParams(marginLayoutParams2);
                        }
                    }
                } else {
                    View view2 = new View(this.f386n);
                    this.G = view2;
                    view2.setVisibility(8);
                    FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(-1, marginLayoutParams.topMargin, 51);
                    layoutParams.leftMargin = iJ;
                    layoutParams.rightMargin = iK;
                    this.E.addView(this.G, -1, layoutParams);
                }
                View view3 = this.G;
                z12 = view3 != null;
                if (z12 && view3.getVisibility() != 0) {
                    d1(this.G);
                }
                if (!this.L && z12) {
                    iL = 0;
                }
                z10 = z12;
                z12 = z11;
            } else if (marginLayoutParams.topMargin != 0) {
                marginLayoutParams.topMargin = 0;
                z10 = false;
            } else {
                z10 = false;
                z12 = false;
            }
            if (z12) {
                this.f397y.setLayoutParams(marginLayoutParams);
            }
        }
        View view4 = this.G;
        if (view4 != null) {
            view4.setVisibility(z10 ? 0 : 8);
        }
        return iL;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public View d0(View view, String str, Context context, AttributeSet attributeSet) {
        boolean z10;
        if (this.f381i0 == null) {
            String string = this.f386n.obtainStyledAttributes(R$styleable.AppCompatTheme).getString(R$styleable.AppCompatTheme_viewInflaterClass);
            if (string == null) {
                this.f381i0 = new androidx.appcompat.app.i();
            } else {
                try {
                    this.f381i0 = (androidx.appcompat.app.i) this.f386n.getClassLoader().loadClass(string).getDeclaredConstructor(null).newInstance(null);
                } catch (Throwable th) {
                    Log.i("AppCompatDelegate", "Failed to instantiate custom view inflater " + string + ". Falling back to default.", th);
                    this.f381i0 = new androidx.appcompat.app.i();
                }
            }
        }
        boolean z11 = f369n0;
        boolean zT0 = false;
        if (z11) {
            if (this.f382j0 == null) {
                this.f382j0 = new androidx.appcompat.app.l();
            }
            if (this.f382j0.a(attributeSet)) {
                z10 = true;
            } else {
                if (!(attributeSet instanceof XmlPullParser)) {
                    zT0 = T0((ViewParent) view);
                } else if (((XmlPullParser) attributeSet).getDepth() > 1) {
                    zT0 = true;
                }
                z10 = zT0;
            }
        } else {
            z10 = zT0;
        }
        return this.f381i0.createView(view, str, context, attributeSet, z10, z11, true, androidx.appcompat.widget.n0.c());
    }

    @Override // androidx.appcompat.app.e
    public Context e(Context context) {
        this.S = true;
        int iA0 = A0(context, V());
        if (androidx.appcompat.app.e.s(context)) {
            androidx.appcompat.app.e.O(context);
        }
        androidx.core.os.e eVarU = U(context);
        if (f372q0 && (context instanceof ContextThemeWrapper)) {
            try {
                s.a((ContextThemeWrapper) context, b0(context, iA0, eVarU, null, false));
                return context;
            } catch (IllegalStateException unused) {
            }
        }
        if (context instanceof androidx.appcompat.view.d) {
            try {
                ((androidx.appcompat.view.d) context).a(b0(context, iA0, eVarU, null, false));
                return context;
            } catch (IllegalStateException unused2) {
            }
        }
        if (!f371p0) {
            return super.e(context);
        }
        Configuration configuration = new Configuration();
        configuration.uiMode = -1;
        configuration.fontScale = 0.0f;
        Configuration configuration2 = j.a(context, configuration).getResources().getConfiguration();
        Configuration configuration3 = context.getResources().getConfiguration();
        configuration2.uiMode = configuration3.uiMode;
        Configuration configurationB0 = b0(context, iA0, eVarU, !configuration2.equals(configuration3) ? l0(configuration2, configuration3) : null, true);
        androidx.appcompat.view.d dVar = new androidx.appcompat.view.d(context, R$style.Theme_AppCompat_Empty);
        dVar.a(configurationB0);
        try {
            if (context.getTheme() != null) {
                androidx.core.content.res.h.f.a(dVar.getTheme());
            }
        } catch (NullPointerException unused3) {
        }
        return super.e(dVar);
    }

    void e0() {
        MenuBuilder menuBuilder;
        androidx.appcompat.widget.r rVar = this.f393u;
        if (rVar != null) {
            rVar.l();
        }
        if (this.f398z != null) {
            this.f387o.getDecorView().removeCallbacks(this.A);
            if (this.f398z.isShowing()) {
                try {
                    this.f398z.dismiss();
                } catch (IllegalArgumentException unused) {
                }
            }
            this.f398z = null;
        }
        h0();
        PanelFeatureState panelFeatureStateR0 = r0(0, false);
        if (panelFeatureStateR0 == null || (menuBuilder = panelFeatureStateR0.f408j) == null) {
            return;
        }
        menuBuilder.close();
    }

    boolean f0(KeyEvent keyEvent) {
        View decorView;
        Object obj = this.f385m;
        if (((obj instanceof androidx.core.view.j.a) || (obj instanceof androidx.appcompat.app.h)) && (decorView = this.f387o.getDecorView()) != null && androidx.core.view.j.a(decorView, keyEvent)) {
            return true;
        }
        if (keyEvent.getKeyCode() == 82 && this.f388p.b(this.f387o.getCallback(), keyEvent)) {
            return true;
        }
        int keyCode = keyEvent.getKeyCode();
        return keyEvent.getAction() == 0 ? C0(keyCode, keyEvent) : F0(keyCode, keyEvent);
    }

    void g0(int i10) {
        PanelFeatureState panelFeatureStateR0;
        PanelFeatureState panelFeatureStateR1 = r0(i10, true);
        if (panelFeatureStateR1.f408j != null) {
            Bundle bundle = new Bundle();
            panelFeatureStateR1.f408j.saveActionViewStates(bundle);
            if (bundle.size() > 0) {
                panelFeatureStateR1.f417s = bundle;
            }
            panelFeatureStateR1.f408j.stopDispatchingItemsChanged();
            panelFeatureStateR1.f408j.clear();
        }
        panelFeatureStateR1.f416r = true;
        panelFeatureStateR1.f415q = true;
        if ((i10 != 108 && i10 != 0) || this.f393u == null || (panelFeatureStateR0 = r0(0, false)) == null) {
            return;
        }
        panelFeatureStateR0.f411m = false;
        N0(panelFeatureStateR0, null);
    }

    @Override // androidx.appcompat.app.e
    public <T extends View> T h(int i10) {
        i0();
        return (T) this.f387o.findViewById(i10);
    }

    void h0() {
        n0 n0Var = this.B;
        if (n0Var != null) {
            n0Var.c();
        }
    }

    @Override // androidx.appcompat.app.e
    public Context j() {
        return this.f386n;
    }

    PanelFeatureState k0(Menu menu) {
        PanelFeatureState[] panelFeatureStateArr = this.P;
        int length = panelFeatureStateArr != null ? panelFeatureStateArr.length : 0;
        for (int i10 = 0; i10 < length; i10++) {
            PanelFeatureState panelFeatureState = panelFeatureStateArr[i10];
            if (panelFeatureState != null && panelFeatureState.f408j == menu) {
                return panelFeatureState;
            }
        }
        return null;
    }

    @Override // androidx.appcompat.app.e
    public final androidx.appcompat.app.a l() {
        return new f();
    }

    @Override // androidx.appcompat.app.e
    public int m() {
        return this.W;
    }

    final Context m0() {
        ActionBar actionBarP = p();
        Context contextK = actionBarP != null ? actionBarP.k() : null;
        return contextK == null ? this.f386n : contextK;
    }

    @Override // androidx.appcompat.app.e
    public MenuInflater o() {
        if (this.f391s == null) {
            u0();
            ActionBar actionBar = this.f390r;
            this.f391s = new androidx.appcompat.view.g(actionBar != null ? actionBar.k() : this.f386n);
        }
        return this.f391s;
    }

    @Override // android.view.LayoutInflater.Factory2
    public final View onCreateView(View view, String str, Context context, AttributeSet attributeSet) {
        return d0(view, str, context, attributeSet);
    }

    @Override // androidx.appcompat.view.menu.MenuBuilder.Callback
    public boolean onMenuItemSelected(MenuBuilder menuBuilder, MenuItem menuItem) {
        PanelFeatureState panelFeatureStateK0;
        Window.Callback callbackT0 = t0();
        if (callbackT0 == null || this.U || (panelFeatureStateK0 = k0(menuBuilder.getRootMenu())) == null) {
            return false;
        }
        return callbackT0.onMenuItemSelected(panelFeatureStateK0.f399a, menuItem);
    }

    @Override // androidx.appcompat.view.menu.MenuBuilder.Callback
    public void onMenuModeChange(MenuBuilder menuBuilder) {
        O0(true);
    }

    @Override // androidx.appcompat.app.e
    public ActionBar p() {
        u0();
        return this.f390r;
    }

    @Override // androidx.appcompat.app.e
    public void q() {
        LayoutInflater layoutInflaterFrom = LayoutInflater.from(this.f386n);
        if (layoutInflaterFrom.getFactory() == null) {
            androidx.core.view.k.a(layoutInflaterFrom, this);
        } else {
            if (layoutInflaterFrom.getFactory2() instanceof AppCompatDelegateImpl) {
                return;
            }
            Log.i("AppCompatDelegate", "The Activity's LayoutInflater already has a Factory installed so we can not install AppCompat's");
        }
    }

    androidx.core.os.e q0(Configuration configuration) {
        return l.b(configuration);
    }

    @Override // androidx.appcompat.app.e
    public void r() {
        if (L0() == null || p().l()) {
            return;
        }
        y0(0);
    }

    protected PanelFeatureState r0(int i10, boolean z10) {
        PanelFeatureState[] panelFeatureStateArr = this.P;
        if (panelFeatureStateArr == null || panelFeatureStateArr.length <= i10) {
            PanelFeatureState[] panelFeatureStateArr2 = new PanelFeatureState[i10 + 1];
            if (panelFeatureStateArr != null) {
                System.arraycopy(panelFeatureStateArr, 0, panelFeatureStateArr2, 0, panelFeatureStateArr.length);
            }
            this.P = panelFeatureStateArr2;
            panelFeatureStateArr = panelFeatureStateArr2;
        }
        PanelFeatureState panelFeatureState = panelFeatureStateArr[i10];
        if (panelFeatureState != null) {
            return panelFeatureState;
        }
        PanelFeatureState panelFeatureState2 = new PanelFeatureState(i10);
        panelFeatureStateArr[i10] = panelFeatureState2;
        return panelFeatureState2;
    }

    final CharSequence s0() {
        Object obj = this.f385m;
        return obj instanceof Activity ? ((Activity) obj).getTitle() : this.f392t;
    }

    final Window.Callback t0() {
        return this.f387o.getCallback();
    }

    @Override // androidx.appcompat.app.e
    public void u(Configuration configuration) {
        ActionBar actionBarP;
        if (this.J && this.D && (actionBarP = p()) != null) {
            actionBarP.m(configuration);
        }
        androidx.appcompat.widget.g.b().g(this.f386n);
        this.V = new Configuration(this.f386n.getResources().getConfiguration());
        Q(false, false);
    }

    @Override // androidx.appcompat.app.e
    public void v(Bundle bundle) {
        String strC;
        this.S = true;
        P(false);
        j0();
        Object obj = this.f385m;
        if (obj instanceof Activity) {
            try {
                strC = androidx.core.app.f.c((Activity) obj);
            } catch (IllegalArgumentException unused) {
                strC = null;
            }
            if (strC != null) {
                ActionBar actionBarL0 = L0();
                if (actionBarL0 == null) {
                    this.f378f0 = true;
                } else {
                    actionBarL0.r(true);
                }
            }
            androidx.appcompat.app.e.b(this);
        }
        this.V = new Configuration(this.f386n.getResources().getConfiguration());
        this.T = true;
    }

    /* JADX WARN: Code duplicated, block: B:15:0x0045  */
    @Override // androidx.appcompat.app.e
    public void w() {
        if (this.f385m instanceof Activity) {
            androidx.appcompat.app.e.C(this);
        }
        if (this.f375c0) {
            this.f387o.getDecorView().removeCallbacks(this.f377e0);
        }
        this.U = true;
        if (this.W != -100) {
            Object obj = this.f385m;
            if ((obj instanceof Activity) && ((Activity) obj).isChangingConfigurations()) {
                f368m0.put(this.f385m.getClass().getName(), Integer.valueOf(this.W));
            } else {
                f368m0.remove(this.f385m.getClass().getName());
            }
        } else {
            f368m0.remove(this.f385m.getClass().getName());
        }
        ActionBar actionBar = this.f390r;
        if (actionBar != null) {
            actionBar.n();
        }
        Y();
    }

    @Override // androidx.appcompat.app.e
    public void x(Bundle bundle) {
        i0();
    }

    @Override // androidx.appcompat.app.e
    public void y() {
        ActionBar actionBarP = p();
        if (actionBarP != null) {
            actionBarP.t(true);
        }
    }

    public boolean z0() {
        return this.C;
    }

    AppCompatDelegateImpl(Dialog dialog, androidx.appcompat.app.c cVar) {
        this(dialog.getContext(), dialog.getWindow(), cVar, dialog);
    }

    @Override // android.view.LayoutInflater.Factory
    public View onCreateView(String str, Context context, AttributeSet attributeSet) {
        return onCreateView(null, str, context, attributeSet);
    }

    private AppCompatDelegateImpl(Context context, Window window, androidx.appcompat.app.c cVar, Object obj) {
        r.g<String, Integer> gVar;
        Integer num;
        AppCompatActivity appCompatActivityX0;
        this.B = null;
        this.C = true;
        this.W = -100;
        this.f377e0 = new a();
        this.f386n = context;
        this.f389q = cVar;
        this.f385m = obj;
        if (this.W == -100 && (obj instanceof Dialog) && (appCompatActivityX0 = X0()) != null) {
            this.W = appCompatActivityX0.getDelegate().m();
        }
        if (this.W == -100 && (num = (gVar = f368m0).get(obj.getClass().getName())) != null) {
            this.W = num.intValue();
            gVar.remove(obj.getClass().getName());
        }
        if (window != null) {
            T(window);
        }
        androidx.appcompat.widget.g.h();
    }

    class c implements ContentFrameLayout.a {
        c() {
        }

        @Override // androidx.appcompat.widget.ContentFrameLayout.a
        public void onDetachedFromWindow() {
            AppCompatDelegateImpl.this.e0();
        }

        @Override // androidx.appcompat.widget.ContentFrameLayout.a
        public void a() {
        }
    }

    void J0(ViewGroup viewGroup) {
    }

    @Override // androidx.appcompat.app.e
    public void z(Bundle bundle) {
    }
}
