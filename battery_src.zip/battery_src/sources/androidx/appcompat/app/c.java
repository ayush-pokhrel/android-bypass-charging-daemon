package androidx.appcompat.app;

/* JADX INFO: compiled from: AppCompatCallback.java */
/* JADX INFO: loaded from: classes.dex */
public interface c {
    void onSupportActionModeFinished(androidx.appcompat.view.b bVar);

    void onSupportActionModeStarted(androidx.appcompat.view.b bVar);

    androidx.appcompat.view.b onWindowStartingSupportActionMode(androidx.appcompat.view.b.a aVar);
}
