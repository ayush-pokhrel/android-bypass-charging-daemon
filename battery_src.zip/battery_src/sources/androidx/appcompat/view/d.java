package androidx.appcompat.view;

import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.AssetManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.view.LayoutInflater;
import androidx.appcompat.R$style;

/* JADX INFO: compiled from: ContextThemeWrapper.java */
/* JADX INFO: loaded from: classes.dex */
public class d extends ContextWrapper {

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private static Configuration f536f;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private int f537a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private Resources.Theme f538b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private LayoutInflater f539c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private Configuration f540d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private Resources f541e;

    /* JADX INFO: compiled from: ContextThemeWrapper.java */
    static class a {
        static Context a(d dVar, Configuration configuration) {
            return dVar.createConfigurationContext(configuration);
        }
    }

    public d() {
        super(null);
    }

    private Resources b() {
        if (this.f541e == null) {
            Configuration configuration = this.f540d;
            if (configuration == null || d(configuration)) {
                this.f541e = super.getResources();
            } else {
                this.f541e = a.a(this, this.f540d).getResources();
            }
        }
        return this.f541e;
    }

    private void c() {
        boolean z10 = this.f538b == null;
        if (z10) {
            this.f538b = getResources().newTheme();
            Resources.Theme theme = getBaseContext().getTheme();
            if (theme != null) {
                this.f538b.setTo(theme);
            }
        }
        e(this.f538b, this.f537a, z10);
    }

    private static boolean d(Configuration configuration) {
        if (configuration == null) {
            return true;
        }
        if (f536f == null) {
            Configuration configuration2 = new Configuration();
            configuration2.fontScale = 0.0f;
            f536f = configuration2;
        }
        return configuration.equals(f536f);
    }

    public void a(Configuration configuration) {
        if (this.f541e != null) {
            throw new IllegalStateException("getResources() or getAssets() has already been called");
        }
        if (this.f540d != null) {
            throw new IllegalStateException("Override configuration has already been set");
        }
        this.f540d = new Configuration(configuration);
    }

    @Override // android.content.ContextWrapper
    protected void attachBaseContext(Context context) {
        super.attachBaseContext(context);
    }

    protected void e(Resources.Theme theme, int i10, boolean z10) {
        theme.applyStyle(i10, true);
    }

    @Override // android.content.ContextWrapper, android.content.Context
    public AssetManager getAssets() {
        return getResources().getAssets();
    }

    @Override // android.content.ContextWrapper, android.content.Context
    public Resources getResources() {
        return b();
    }

    @Override // android.content.ContextWrapper, android.content.Context
    public Object getSystemService(String str) {
        if (!"layout_inflater".equals(str)) {
            return getBaseContext().getSystemService(str);
        }
        if (this.f539c == null) {
            this.f539c = LayoutInflater.from(getBaseContext()).cloneInContext(this);
        }
        return this.f539c;
    }

    @Override // android.content.ContextWrapper, android.content.Context
    public Resources.Theme getTheme() {
        Resources.Theme theme = this.f538b;
        if (theme != null) {
            return theme;
        }
        if (this.f537a == 0) {
            this.f537a = R$style.Theme_AppCompat_Light;
        }
        c();
        return this.f538b;
    }

    public int getThemeResId() {
        return this.f537a;
    }

    @Override // android.content.ContextWrapper, android.content.Context
    public void setTheme(int i10) {
        if (this.f537a != i10) {
            this.f537a = i10;
            c();
        }
    }

    public d(Context context, int i10) {
        super(context);
        this.f537a = i10;
    }

    public d(Context context, Resources.Theme theme) {
        super(context);
        this.f538b = theme;
    }
}
