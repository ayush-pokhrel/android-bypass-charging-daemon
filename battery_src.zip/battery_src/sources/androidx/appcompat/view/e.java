package androidx.appcompat.view;

import android.content.Context;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import androidx.appcompat.view.menu.MenuBuilder;
import androidx.appcompat.widget.ActionBarContextView;
import java.lang.ref.WeakReference;

/* JADX INFO: compiled from: StandaloneActionMode.java */
/* JADX INFO: loaded from: classes.dex */
public class e extends b implements MenuBuilder.Callback {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private Context f542c;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private ActionBarContextView f543g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private b.a f544h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private WeakReference<View> f545i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private boolean f546j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    private boolean f547k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private MenuBuilder f548l;

    public e(Context context, ActionBarContextView actionBarContextView, b.a aVar, boolean z10) {
        this.f542c = context;
        this.f543g = actionBarContextView;
        this.f544h = aVar;
        MenuBuilder defaultShowAsAction = new MenuBuilder(actionBarContextView.getContext()).setDefaultShowAsAction(1);
        this.f548l = defaultShowAsAction;
        defaultShowAsAction.setCallback(this);
        this.f547k = z10;
    }

    @Override // androidx.appcompat.view.b
    public void a() {
        if (this.f546j) {
            return;
        }
        this.f546j = true;
        this.f544h.b(this);
    }

    @Override // androidx.appcompat.view.b
    public View b() {
        WeakReference<View> weakReference = this.f545i;
        if (weakReference != null) {
            return weakReference.get();
        }
        return null;
    }

    @Override // androidx.appcompat.view.b
    public Menu c() {
        return this.f548l;
    }

    @Override // androidx.appcompat.view.b
    public MenuInflater d() {
        return new g(this.f543g.getContext());
    }

    @Override // androidx.appcompat.view.b
    public CharSequence e() {
        return this.f543g.getSubtitle();
    }

    @Override // androidx.appcompat.view.b
    public CharSequence g() {
        return this.f543g.getTitle();
    }

    @Override // androidx.appcompat.view.b
    public void i() {
        this.f544h.a(this, this.f548l);
    }

    @Override // androidx.appcompat.view.b
    public boolean j() {
        return this.f543g.j();
    }

    @Override // androidx.appcompat.view.b
    public void k(View view) {
        this.f543g.setCustomView(view);
        this.f545i = view != null ? new WeakReference<>(view) : null;
    }

    @Override // androidx.appcompat.view.b
    public void l(int i10) {
        m(this.f542c.getString(i10));
    }

    @Override // androidx.appcompat.view.b
    public void m(CharSequence charSequence) {
        this.f543g.setSubtitle(charSequence);
    }

    @Override // androidx.appcompat.view.b
    public void o(int i10) {
        p(this.f542c.getString(i10));
    }

    @Override // androidx.appcompat.view.menu.MenuBuilder.Callback
    public boolean onMenuItemSelected(MenuBuilder menuBuilder, MenuItem menuItem) {
        return this.f544h.c(this, menuItem);
    }

    @Override // androidx.appcompat.view.menu.MenuBuilder.Callback
    public void onMenuModeChange(MenuBuilder menuBuilder) {
        i();
        this.f543g.l();
    }

    @Override // androidx.appcompat.view.b
    public void p(CharSequence charSequence) {
        this.f543g.setTitle(charSequence);
    }

    @Override // androidx.appcompat.view.b
    public void q(boolean z10) {
        super.q(z10);
        this.f543g.setTitleOptional(z10);
    }
}
