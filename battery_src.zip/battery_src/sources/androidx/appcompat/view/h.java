package androidx.appcompat.view;

import android.view.View;
import android.view.animation.Interpolator;
import androidx.core.view.n0;
import androidx.core.view.o0;
import androidx.core.view.p0;
import java.util.ArrayList;
import java.util.Iterator;

/* JADX INFO: compiled from: ViewPropertyAnimatorCompatSet.java */
/* JADX INFO: loaded from: classes.dex */
public class h {

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private Interpolator f592c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    o0 f593d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private boolean f594e;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private long f591b = -1;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private final p0 f595f = new a();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    final ArrayList<n0> f590a = new ArrayList<>();

    /* JADX INFO: compiled from: ViewPropertyAnimatorCompatSet.java */
    class a extends p0 {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private boolean f596a = false;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private int f597b = 0;

        a() {
        }

        @Override // androidx.core.view.o0
        public void b(View view) {
            int i10 = this.f597b + 1;
            this.f597b = i10;
            if (i10 == h.this.f590a.size()) {
                o0 o0Var = h.this.f593d;
                if (o0Var != null) {
                    o0Var.b(null);
                }
                d();
            }
        }

        @Override // androidx.core.view.p0, androidx.core.view.o0
        public void c(View view) {
            if (this.f596a) {
                return;
            }
            this.f596a = true;
            o0 o0Var = h.this.f593d;
            if (o0Var != null) {
                o0Var.c(null);
            }
        }

        void d() {
            this.f597b = 0;
            this.f596a = false;
            h.this.b();
        }
    }

    public void a() {
        if (this.f594e) {
            Iterator<n0> it = this.f590a.iterator();
            while (it.hasNext()) {
                it.next().c();
            }
            this.f594e = false;
        }
    }

    void b() {
        this.f594e = false;
    }

    public h c(n0 n0Var) {
        if (!this.f594e) {
            this.f590a.add(n0Var);
        }
        return this;
    }

    public h d(n0 n0Var, n0 n0Var2) {
        this.f590a.add(n0Var);
        n0Var2.j(n0Var.d());
        this.f590a.add(n0Var2);
        return this;
    }

    public h e(long j10) {
        if (!this.f594e) {
            this.f591b = j10;
        }
        return this;
    }

    public h f(Interpolator interpolator) {
        if (!this.f594e) {
            this.f592c = interpolator;
        }
        return this;
    }

    public h g(o0 o0Var) {
        if (!this.f594e) {
            this.f593d = o0Var;
        }
        return this;
    }

    public void h() {
        if (this.f594e) {
            return;
        }
        for (n0 n0Var : this.f590a) {
            long j10 = this.f591b;
            if (j10 >= 0) {
                n0Var.f(j10);
            }
            Interpolator interpolator = this.f592c;
            if (interpolator != null) {
                n0Var.g(interpolator);
            }
            if (this.f593d != null) {
                n0Var.h(this.f595f);
            }
            n0Var.l();
        }
        this.f594e = true;
    }
}
