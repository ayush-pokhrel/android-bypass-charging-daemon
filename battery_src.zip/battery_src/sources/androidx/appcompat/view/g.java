package androidx.appcompat.view;

import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.graphics.PorterDuff;
import android.util.AttributeSet;
import android.util.Log;
import android.util.Xml;
import android.view.InflateException;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import androidx.appcompat.R$styleable;
import androidx.appcompat.view.menu.MenuItemImpl;
import androidx.appcompat.view.menu.MenuItemWrapperICS;
import androidx.appcompat.widget.h0;
import androidx.appcompat.widget.t;
import androidx.core.view.p;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

/* JADX INFO: compiled from: SupportMenuInflater.java */
/* JADX INFO: loaded from: classes.dex */
public class g extends MenuInflater {

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    static final Class<?>[] f555e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    static final Class<?>[] f556f;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    final Object[] f557a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    final Object[] f558b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    Context f559c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private Object f560d;

    /* JADX INFO: compiled from: SupportMenuInflater.java */
    private static class a implements MenuItem.OnMenuItemClickListener {

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        private static final Class<?>[] f561c = {MenuItem.class};

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private Object f562a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private Method f563b;

        public a(Object obj, String str) {
            this.f562a = obj;
            Class<?> cls = obj.getClass();
            try {
                this.f563b = cls.getMethod(str, f561c);
            } catch (Exception e10) {
                InflateException inflateException = new InflateException("Couldn't resolve menu item onClick handler " + str + " in class " + cls.getName());
                inflateException.initCause(e10);
                throw inflateException;
            }
        }

        @Override // android.view.MenuItem.OnMenuItemClickListener
        public boolean onMenuItemClick(MenuItem menuItem) {
            try {
                if (this.f563b.getReturnType() == Boolean.TYPE) {
                    return ((Boolean) this.f563b.invoke(this.f562a, menuItem)).booleanValue();
                }
                this.f563b.invoke(this.f562a, menuItem);
                return true;
            } catch (Exception e10) {
                throw new RuntimeException(e10);
            }
        }
    }

    /* JADX INFO: compiled from: SupportMenuInflater.java */
    private class b {
        androidx.core.view.b A;
        private CharSequence B;
        private CharSequence C;
        private ColorStateList D = null;
        private PorterDuff.Mode E = null;

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private Menu f564a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private int f565b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        private int f566c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        private int f567d;

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        private int f568e;

        /* JADX INFO: renamed from: f, reason: collision with root package name */
        private boolean f569f;

        /* JADX INFO: renamed from: g, reason: collision with root package name */
        private boolean f570g;

        /* JADX INFO: renamed from: h, reason: collision with root package name */
        private boolean f571h;

        /* JADX INFO: renamed from: i, reason: collision with root package name */
        private int f572i;

        /* JADX INFO: renamed from: j, reason: collision with root package name */
        private int f573j;

        /* JADX INFO: renamed from: k, reason: collision with root package name */
        private CharSequence f574k;

        /* JADX INFO: renamed from: l, reason: collision with root package name */
        private CharSequence f575l;

        /* JADX INFO: renamed from: m, reason: collision with root package name */
        private int f576m;

        /* JADX INFO: renamed from: n, reason: collision with root package name */
        private char f577n;

        /* JADX INFO: renamed from: o, reason: collision with root package name */
        private int f578o;

        /* JADX INFO: renamed from: p, reason: collision with root package name */
        private char f579p;

        /* JADX INFO: renamed from: q, reason: collision with root package name */
        private int f580q;

        /* JADX INFO: renamed from: r, reason: collision with root package name */
        private int f581r;

        /* JADX INFO: renamed from: s, reason: collision with root package name */
        private boolean f582s;

        /* JADX INFO: renamed from: t, reason: collision with root package name */
        private boolean f583t;

        /* JADX INFO: renamed from: u, reason: collision with root package name */
        private boolean f584u;

        /* JADX INFO: renamed from: v, reason: collision with root package name */
        private int f585v;

        /* JADX INFO: renamed from: w, reason: collision with root package name */
        private int f586w;

        /* JADX INFO: renamed from: x, reason: collision with root package name */
        private String f587x;

        /* JADX INFO: renamed from: y, reason: collision with root package name */
        private String f588y;

        /* JADX INFO: renamed from: z, reason: collision with root package name */
        private String f589z;

        public b(Menu menu) {
            this.f564a = menu;
            h();
        }

        private char c(String str) {
            if (str == null) {
                return (char) 0;
            }
            return str.charAt(0);
        }

        private <T> T e(String str, Class<?>[] clsArr, Object[] objArr) {
            try {
                Constructor<?> constructor = Class.forName(str, false, g.this.f559c.getClassLoader()).getConstructor(clsArr);
                constructor.setAccessible(true);
                return (T) constructor.newInstance(objArr);
            } catch (Exception e10) {
                Log.w("SupportMenuInflater", "Cannot instantiate class: " + str, e10);
                return null;
            }
        }

        private void i(MenuItem menuItem) {
            boolean z10 = false;
            menuItem.setChecked(this.f582s).setVisible(this.f583t).setEnabled(this.f584u).setCheckable(this.f581r >= 1).setTitleCondensed(this.f575l).setIcon(this.f576m);
            int i10 = this.f585v;
            if (i10 >= 0) {
                menuItem.setShowAsAction(i10);
            }
            if (this.f589z != null) {
                if (g.this.f559c.isRestricted()) {
                    throw new IllegalStateException("The android:onClick attribute cannot be used within a restricted context");
                }
                menuItem.setOnMenuItemClickListener(new a(g.this.b(), this.f589z));
            }
            if (this.f581r >= 2) {
                if (menuItem instanceof MenuItemImpl) {
                    ((MenuItemImpl) menuItem).setExclusiveCheckable(true);
                } else if (menuItem instanceof MenuItemWrapperICS) {
                    ((MenuItemWrapperICS) menuItem).setExclusiveCheckable(true);
                }
            }
            String str = this.f587x;
            if (str != null) {
                menuItem.setActionView((View) e(str, g.f555e, g.this.f557a));
                z10 = true;
            }
            int i11 = this.f586w;
            if (i11 > 0) {
                if (z10) {
                    Log.w("SupportMenuInflater", "Ignoring attribute 'itemActionViewLayout'. Action view already specified.");
                } else {
                    menuItem.setActionView(i11);
                }
            }
            androidx.core.view.b bVar = this.A;
            if (bVar != null) {
                p.a(menuItem, bVar);
            }
            p.c(menuItem, this.B);
            p.g(menuItem, this.C);
            p.b(menuItem, this.f577n, this.f578o);
            p.f(menuItem, this.f579p, this.f580q);
            PorterDuff.Mode mode = this.E;
            if (mode != null) {
                p.e(menuItem, mode);
            }
            ColorStateList colorStateList = this.D;
            if (colorStateList != null) {
                p.d(menuItem, colorStateList);
            }
        }

        public void a() {
            this.f571h = true;
            i(this.f564a.add(this.f565b, this.f572i, this.f573j, this.f574k));
        }

        public SubMenu b() {
            this.f571h = true;
            SubMenu subMenuAddSubMenu = this.f564a.addSubMenu(this.f565b, this.f572i, this.f573j, this.f574k);
            i(subMenuAddSubMenu.getItem());
            return subMenuAddSubMenu;
        }

        public boolean d() {
            return this.f571h;
        }

        public void f(AttributeSet attributeSet) {
            TypedArray typedArrayObtainStyledAttributes = g.this.f559c.obtainStyledAttributes(attributeSet, R$styleable.MenuGroup);
            this.f565b = typedArrayObtainStyledAttributes.getResourceId(R$styleable.MenuGroup_android_id, 0);
            this.f566c = typedArrayObtainStyledAttributes.getInt(R$styleable.MenuGroup_android_menuCategory, 0);
            this.f567d = typedArrayObtainStyledAttributes.getInt(R$styleable.MenuGroup_android_orderInCategory, 0);
            this.f568e = typedArrayObtainStyledAttributes.getInt(R$styleable.MenuGroup_android_checkableBehavior, 0);
            this.f569f = typedArrayObtainStyledAttributes.getBoolean(R$styleable.MenuGroup_android_visible, true);
            this.f570g = typedArrayObtainStyledAttributes.getBoolean(R$styleable.MenuGroup_android_enabled, true);
            typedArrayObtainStyledAttributes.recycle();
        }

        public void g(AttributeSet attributeSet) {
            h0 h0VarV = h0.v(g.this.f559c, attributeSet, R$styleable.MenuItem);
            this.f572i = h0VarV.n(R$styleable.MenuItem_android_id, 0);
            this.f573j = (h0VarV.k(R$styleable.MenuItem_android_menuCategory, this.f566c) & (-65536)) | (h0VarV.k(R$styleable.MenuItem_android_orderInCategory, this.f567d) & 65535);
            this.f574k = h0VarV.p(R$styleable.MenuItem_android_title);
            this.f575l = h0VarV.p(R$styleable.MenuItem_android_titleCondensed);
            this.f576m = h0VarV.n(R$styleable.MenuItem_android_icon, 0);
            this.f577n = c(h0VarV.o(R$styleable.MenuItem_android_alphabeticShortcut));
            this.f578o = h0VarV.k(R$styleable.MenuItem_alphabeticModifiers, 4096);
            this.f579p = c(h0VarV.o(R$styleable.MenuItem_android_numericShortcut));
            this.f580q = h0VarV.k(R$styleable.MenuItem_numericModifiers, 4096);
            int i10 = R$styleable.MenuItem_android_checkable;
            if (h0VarV.s(i10)) {
                this.f581r = h0VarV.a(i10, false) ? 1 : 0;
            } else {
                this.f581r = this.f568e;
            }
            this.f582s = h0VarV.a(R$styleable.MenuItem_android_checked, false);
            this.f583t = h0VarV.a(R$styleable.MenuItem_android_visible, this.f569f);
            this.f584u = h0VarV.a(R$styleable.MenuItem_android_enabled, this.f570g);
            this.f585v = h0VarV.k(R$styleable.MenuItem_showAsAction, -1);
            this.f589z = h0VarV.o(R$styleable.MenuItem_android_onClick);
            this.f586w = h0VarV.n(R$styleable.MenuItem_actionLayout, 0);
            this.f587x = h0VarV.o(R$styleable.MenuItem_actionViewClass);
            String strO = h0VarV.o(R$styleable.MenuItem_actionProviderClass);
            this.f588y = strO;
            boolean z10 = strO != null;
            if (z10 && this.f586w == 0 && this.f587x == null) {
                this.A = (androidx.core.view.b) e(strO, g.f556f, g.this.f558b);
            } else {
                if (z10) {
                    Log.w("SupportMenuInflater", "Ignoring attribute 'actionProviderClass'. Action view already specified.");
                }
                this.A = null;
            }
            this.B = h0VarV.p(R$styleable.MenuItem_contentDescription);
            this.C = h0VarV.p(R$styleable.MenuItem_tooltipText);
            int i11 = R$styleable.MenuItem_iconTintMode;
            if (h0VarV.s(i11)) {
                this.E = t.d(h0VarV.k(i11, -1), this.E);
            } else {
                this.E = null;
            }
            int i12 = R$styleable.MenuItem_iconTint;
            if (h0VarV.s(i12)) {
                this.D = h0VarV.c(i12);
            } else {
                this.D = null;
            }
            h0VarV.x();
            this.f571h = false;
        }

        public void h() {
            this.f565b = 0;
            this.f566c = 0;
            this.f567d = 0;
            this.f568e = 0;
            this.f569f = true;
            this.f570g = true;
        }
    }

    static {
        Class<?>[] clsArr = {Context.class};
        f555e = clsArr;
        f556f = clsArr;
    }

    public g(Context context) {
        super(context);
        this.f559c = context;
        Object[] objArr = {context};
        this.f557a = objArr;
        this.f558b = objArr;
    }

    private Object a(Object obj) {
        return (!(obj instanceof Activity) && (obj instanceof ContextWrapper)) ? a(((ContextWrapper) obj).getBaseContext()) : obj;
    }

    private void c(XmlPullParser xmlPullParser, AttributeSet attributeSet, Menu menu) throws XmlPullParserException, IOException {
        b bVar = new b(menu);
        int eventType = xmlPullParser.getEventType();
        do {
            if (eventType == 2) {
                String name = xmlPullParser.getName();
                if (name.equals("menu")) {
                    eventType = xmlPullParser.next();
                    break;
                }
                throw new RuntimeException("Expecting menu, got " + name);
            }
            eventType = xmlPullParser.next();
        } while (eventType != 1);
        boolean z10 = false;
        boolean z11 = false;
        String str = null;
        while (!z10) {
            if (eventType == 1) {
                throw new RuntimeException("Unexpected end of document");
            }
            if (eventType != 2) {
                if (eventType == 3) {
                    String name2 = xmlPullParser.getName();
                    if (z11 && name2.equals(str)) {
                        z11 = false;
                        str = null;
                    } else if (name2.equals("group")) {
                        bVar.h();
                    } else if (name2.equals("item")) {
                        if (!bVar.d()) {
                            androidx.core.view.b bVar2 = bVar.A;
                            if (bVar2 == null || !bVar2.hasSubMenu()) {
                                bVar.a();
                            } else {
                                bVar.b();
                            }
                        }
                    } else if (name2.equals("menu")) {
                        z10 = true;
                    }
                }
            } else if (!z11) {
                String name3 = xmlPullParser.getName();
                if (name3.equals("group")) {
                    bVar.f(attributeSet);
                } else if (name3.equals("item")) {
                    bVar.g(attributeSet);
                } else if (name3.equals("menu")) {
                    c(xmlPullParser, attributeSet, bVar.b());
                } else {
                    str = name3;
                    z11 = true;
                }
            }
            eventType = xmlPullParser.next();
        }
    }

    Object b() {
        if (this.f560d == null) {
            this.f560d = a(this.f559c);
        }
        return this.f560d;
    }

    @Override // android.view.MenuInflater
    public void inflate(int i10, Menu menu) {
        if (!(menu instanceof x.a)) {
            super.inflate(i10, menu);
            return;
        }
        XmlResourceParser layout = null;
        try {
            try {
                try {
                    layout = this.f559c.getResources().getLayout(i10);
                    c(layout, Xml.asAttributeSet(layout), menu);
                    if (layout != null) {
                        layout.close();
                    }
                } catch (IOException e10) {
                    throw new InflateException("Error inflating menu XML", e10);
                }
            } catch (XmlPullParserException e11) {
                throw new InflateException("Error inflating menu XML", e11);
            }
        } catch (Throwable th) {
            if (layout != null) {
                layout.close();
            }
            throw th;
        }
    }
}
