package androidx.appcompat.view.menu;

import android.content.Context;
import android.view.MenuItem;
import android.view.SubMenu;
import r.g;
import x.b;
import x.c;

/* JADX INFO: loaded from: classes.dex */
abstract class BaseMenuWrapper {
    final Context mContext;
    private g<b, MenuItem> mMenuItems;
    private g<c, SubMenu> mSubMenus;

    BaseMenuWrapper(Context context) {
        this.mContext = context;
    }

    final MenuItem getMenuItemWrapper(MenuItem menuItem) {
        if (!(menuItem instanceof b)) {
            return menuItem;
        }
        b bVar = (b) menuItem;
        if (this.mMenuItems == null) {
            this.mMenuItems = new g<>();
        }
        MenuItem menuItem2 = this.mMenuItems.get(bVar);
        if (menuItem2 != null) {
            return menuItem2;
        }
        MenuItemWrapperICS menuItemWrapperICS = new MenuItemWrapperICS(this.mContext, bVar);
        this.mMenuItems.put(bVar, menuItemWrapperICS);
        return menuItemWrapperICS;
    }

    final SubMenu getSubMenuWrapper(SubMenu subMenu) {
        if (!(subMenu instanceof c)) {
            return subMenu;
        }
        c cVar = (c) subMenu;
        if (this.mSubMenus == null) {
            this.mSubMenus = new g<>();
        }
        SubMenu subMenu2 = this.mSubMenus.get(cVar);
        if (subMenu2 != null) {
            return subMenu2;
        }
        SubMenuWrapperICS subMenuWrapperICS = new SubMenuWrapperICS(this.mContext, cVar);
        this.mSubMenus.put(cVar, subMenuWrapperICS);
        return subMenuWrapperICS;
    }

    final void internalClear() {
        g<b, MenuItem> gVar = this.mMenuItems;
        if (gVar != null) {
            gVar.clear();
        }
        g<c, SubMenu> gVar2 = this.mSubMenus;
        if (gVar2 != null) {
            gVar2.clear();
        }
    }

    final void internalRemoveGroup(int i10) {
        if (this.mMenuItems == null) {
            return;
        }
        int i11 = 0;
        while (i11 < this.mMenuItems.size()) {
            if (this.mMenuItems.i(i11).getGroupId() == i10) {
                this.mMenuItems.k(i11);
                i11--;
            }
            i11++;
        }
    }

    final void internalRemoveItem(int i10) {
        if (this.mMenuItems == null) {
            return;
        }
        for (int i11 = 0; i11 < this.mMenuItems.size(); i11++) {
            if (this.mMenuItems.i(i11).getItemId() == i10) {
                this.mMenuItems.k(i11);
                return;
            }
        }
    }
}
