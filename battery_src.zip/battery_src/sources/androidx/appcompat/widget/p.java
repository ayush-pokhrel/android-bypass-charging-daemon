package androidx.appcompat.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.LocaleList;
import android.text.method.PasswordTransformationMethod;
import android.util.AttributeSet;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.TextView;
import androidx.appcompat.R$styleable;
import java.lang.ref.WeakReference;
import java.util.Locale;

/* JADX INFO: compiled from: AppCompatTextHelper.java */
/* JADX INFO: loaded from: classes.dex */
class p {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final TextView f1048a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private f0 f1049b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private f0 f1050c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private f0 f1051d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private f0 f1052e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private f0 f1053f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private f0 f1054g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private f0 f1055h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private final q f1056i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private int f1057j = 0;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    private int f1058k = -1;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private Typeface f1059l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    private boolean f1060m;

    /* JADX INFO: compiled from: AppCompatTextHelper.java */
    class b implements Runnable {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        final /* synthetic */ TextView f1065a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        final /* synthetic */ Typeface f1066b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        final /* synthetic */ int f1067c;

        b(TextView textView, Typeface typeface, int i10) {
            this.f1065a = textView;
            this.f1066b = typeface;
            this.f1067c = i10;
        }

        @Override // java.lang.Runnable
        public void run() {
            this.f1065a.setTypeface(this.f1066b, this.f1067c);
        }
    }

    /* JADX INFO: compiled from: AppCompatTextHelper.java */
    static class c {
        static Drawable[] a(TextView textView) {
            return textView.getCompoundDrawablesRelative();
        }

        static void b(TextView textView, Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
            textView.setCompoundDrawablesRelativeWithIntrinsicBounds(drawable, drawable2, drawable3, drawable4);
        }

        static void c(TextView textView, Locale locale) {
            textView.setTextLocale(locale);
        }
    }

    /* JADX INFO: compiled from: AppCompatTextHelper.java */
    static class d {
        static LocaleList a(String str) {
            return LocaleList.forLanguageTags(str);
        }

        static void b(TextView textView, LocaleList localeList) {
            textView.setTextLocales(localeList);
        }
    }

    /* JADX INFO: compiled from: AppCompatTextHelper.java */
    static class e {
        static int a(TextView textView) {
            return textView.getAutoSizeStepGranularity();
        }

        static void b(TextView textView, int i10, int i11, int i12, int i13) {
            textView.setAutoSizeTextTypeUniformWithConfiguration(i10, i11, i12, i13);
        }

        static void c(TextView textView, int[] iArr, int i10) {
            textView.setAutoSizeTextTypeUniformWithPresetSizes(iArr, i10);
        }

        static boolean d(TextView textView, String str) {
            return textView.setFontVariationSettings(str);
        }
    }

    /* JADX INFO: compiled from: AppCompatTextHelper.java */
    static class f {
        static Typeface a(Typeface typeface, int i10, boolean z10) {
            return Typeface.create(typeface, i10, z10);
        }
    }

    p(TextView textView) {
        this.f1048a = textView;
        this.f1056i = new q(textView);
    }

    private void B(int i10, float f10) {
        this.f1056i.t(i10, f10);
    }

    private void C(Context context, h0 h0Var) {
        String strO;
        this.f1057j = h0Var.k(R$styleable.TextAppearance_android_textStyle, this.f1057j);
        int iK = h0Var.k(R$styleable.TextAppearance_android_textFontWeight, -1);
        this.f1058k = iK;
        if (iK != -1) {
            this.f1057j &= 2;
        }
        int i10 = R$styleable.TextAppearance_android_fontFamily;
        if (!h0Var.s(i10) && !h0Var.s(R$styleable.TextAppearance_fontFamily)) {
            int i11 = R$styleable.TextAppearance_android_typeface;
            if (h0Var.s(i11)) {
                this.f1060m = false;
                int iK2 = h0Var.k(i11, 1);
                if (iK2 == 1) {
                    this.f1059l = Typeface.SANS_SERIF;
                    return;
                } else if (iK2 == 2) {
                    this.f1059l = Typeface.SERIF;
                    return;
                } else {
                    if (iK2 != 3) {
                        return;
                    }
                    this.f1059l = Typeface.MONOSPACE;
                    return;
                }
            }
            return;
        }
        this.f1059l = null;
        int i12 = R$styleable.TextAppearance_fontFamily;
        if (h0Var.s(i12)) {
            i10 = i12;
        }
        int i13 = this.f1058k;
        int i14 = this.f1057j;
        if (!context.isRestricted()) {
            try {
                Typeface typefaceJ = h0Var.j(i10, this.f1057j, new a(i13, i14, new WeakReference(this.f1048a)));
                if (typefaceJ != null) {
                    if (this.f1058k != -1) {
                        this.f1059l = f.a(Typeface.create(typefaceJ, 0), this.f1058k, (this.f1057j & 2) != 0);
                    } else {
                        this.f1059l = typefaceJ;
                    }
                }
                this.f1060m = this.f1059l == null;
            } catch (Resources.NotFoundException | UnsupportedOperationException unused) {
            }
        }
        if (this.f1059l != null || (strO = h0Var.o(i10)) == null) {
            return;
        }
        if (this.f1058k != -1) {
            this.f1059l = f.a(Typeface.create(strO, 0), this.f1058k, (this.f1057j & 2) != 0);
        } else {
            this.f1059l = Typeface.create(strO, this.f1057j);
        }
    }

    private void a(Drawable drawable, f0 f0Var) {
        if (drawable == null || f0Var == null) {
            return;
        }
        g.i(drawable, f0Var, this.f1048a.getDrawableState());
    }

    private static f0 d(Context context, g gVar, int i10) {
        ColorStateList colorStateListF = gVar.f(context, i10);
        if (colorStateListF == null) {
            return null;
        }
        f0 f0Var = new f0();
        f0Var.f986d = true;
        f0Var.f983a = colorStateListF;
        return f0Var;
    }

    private void y(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4, Drawable drawable5, Drawable drawable6) {
        if (drawable5 != null || drawable6 != null) {
            Drawable[] drawableArrA = c.a(this.f1048a);
            TextView textView = this.f1048a;
            if (drawable5 == null) {
                drawable5 = drawableArrA[0];
            }
            if (drawable2 == null) {
                drawable2 = drawableArrA[1];
            }
            if (drawable6 == null) {
                drawable6 = drawableArrA[2];
            }
            if (drawable4 == null) {
                drawable4 = drawableArrA[3];
            }
            c.b(textView, drawable5, drawable2, drawable6, drawable4);
            return;
        }
        if (drawable == null && drawable2 == null && drawable3 == null && drawable4 == null) {
            return;
        }
        Drawable[] drawableArrA2 = c.a(this.f1048a);
        Drawable drawable7 = drawableArrA2[0];
        if (drawable7 != null || drawableArrA2[2] != null) {
            TextView textView2 = this.f1048a;
            if (drawable2 == null) {
                drawable2 = drawableArrA2[1];
            }
            Drawable drawable8 = drawableArrA2[2];
            if (drawable4 == null) {
                drawable4 = drawableArrA2[3];
            }
            c.b(textView2, drawable7, drawable2, drawable8, drawable4);
            return;
        }
        Drawable[] compoundDrawables = this.f1048a.getCompoundDrawables();
        TextView textView3 = this.f1048a;
        if (drawable == null) {
            drawable = compoundDrawables[0];
        }
        if (drawable2 == null) {
            drawable2 = compoundDrawables[1];
        }
        if (drawable3 == null) {
            drawable3 = compoundDrawables[2];
        }
        if (drawable4 == null) {
            drawable4 = compoundDrawables[3];
        }
        textView3.setCompoundDrawablesWithIntrinsicBounds(drawable, drawable2, drawable3, drawable4);
    }

    private void z() {
        f0 f0Var = this.f1055h;
        this.f1049b = f0Var;
        this.f1050c = f0Var;
        this.f1051d = f0Var;
        this.f1052e = f0Var;
        this.f1053f = f0Var;
        this.f1054g = f0Var;
    }

    void A(int i10, float f10) {
        if (o0.f1047b || l()) {
            return;
        }
        B(i10, f10);
    }

    void b() {
        if (this.f1049b != null || this.f1050c != null || this.f1051d != null || this.f1052e != null) {
            Drawable[] compoundDrawables = this.f1048a.getCompoundDrawables();
            a(compoundDrawables[0], this.f1049b);
            a(compoundDrawables[1], this.f1050c);
            a(compoundDrawables[2], this.f1051d);
            a(compoundDrawables[3], this.f1052e);
        }
        if (this.f1053f == null && this.f1054g == null) {
            return;
        }
        Drawable[] drawableArrA = c.a(this.f1048a);
        a(drawableArrA[0], this.f1053f);
        a(drawableArrA[2], this.f1054g);
    }

    void c() {
        this.f1056i.a();
    }

    int e() {
        return this.f1056i.f();
    }

    int f() {
        return this.f1056i.g();
    }

    int g() {
        return this.f1056i.h();
    }

    int[] h() {
        return this.f1056i.i();
    }

    int i() {
        return this.f1056i.j();
    }

    ColorStateList j() {
        f0 f0Var = this.f1055h;
        if (f0Var != null) {
            return f0Var.f983a;
        }
        return null;
    }

    PorterDuff.Mode k() {
        f0 f0Var = this.f1055h;
        if (f0Var != null) {
            return f0Var.f984b;
        }
        return null;
    }

    boolean l() {
        return this.f1056i.n();
    }

    /* JADX WARN: Code duplicated, block: B:27:0x00c1  */
    /* JADX WARN: Code duplicated, block: B:43:0x00ff  */
    @SuppressLint({"NewApi"})
    void m(AttributeSet attributeSet, int i10) {
        boolean zA;
        boolean z10;
        String strO;
        String strO2;
        Context context = this.f1048a.getContext();
        g gVarB = g.b();
        int[] iArr = R$styleable.AppCompatTextHelper;
        h0 h0VarW = h0.w(context, attributeSet, iArr, i10, 0);
        TextView textView = this.f1048a;
        androidx.core.view.h0.j0(textView, textView.getContext(), iArr, attributeSet, h0VarW.r(), i10, 0);
        int iN = h0VarW.n(R$styleable.AppCompatTextHelper_android_textAppearance, -1);
        int i11 = R$styleable.AppCompatTextHelper_android_drawableLeft;
        if (h0VarW.s(i11)) {
            this.f1049b = d(context, gVarB, h0VarW.n(i11, 0));
        }
        int i12 = R$styleable.AppCompatTextHelper_android_drawableTop;
        if (h0VarW.s(i12)) {
            this.f1050c = d(context, gVarB, h0VarW.n(i12, 0));
        }
        int i13 = R$styleable.AppCompatTextHelper_android_drawableRight;
        if (h0VarW.s(i13)) {
            this.f1051d = d(context, gVarB, h0VarW.n(i13, 0));
        }
        int i14 = R$styleable.AppCompatTextHelper_android_drawableBottom;
        if (h0VarW.s(i14)) {
            this.f1052e = d(context, gVarB, h0VarW.n(i14, 0));
        }
        int i15 = R$styleable.AppCompatTextHelper_android_drawableStart;
        if (h0VarW.s(i15)) {
            this.f1053f = d(context, gVarB, h0VarW.n(i15, 0));
        }
        int i16 = R$styleable.AppCompatTextHelper_android_drawableEnd;
        if (h0VarW.s(i16)) {
            this.f1054g = d(context, gVarB, h0VarW.n(i16, 0));
        }
        h0VarW.x();
        boolean z11 = this.f1048a.getTransformationMethod() instanceof PasswordTransformationMethod;
        boolean z12 = true;
        if (iN != -1) {
            h0 h0VarU = h0.u(context, iN, R$styleable.TextAppearance);
            if (z11) {
                zA = false;
                z10 = false;
            } else {
                int i17 = R$styleable.TextAppearance_textAllCaps;
                if (h0VarU.s(i17)) {
                    zA = h0VarU.a(i17, false);
                    z10 = true;
                } else {
                    zA = false;
                    z10 = false;
                }
            }
            C(context, h0VarU);
            int i18 = R$styleable.TextAppearance_textLocale;
            strO = h0VarU.s(i18) ? h0VarU.o(i18) : null;
            int i19 = R$styleable.TextAppearance_fontVariationSettings;
            strO2 = h0VarU.s(i19) ? h0VarU.o(i19) : null;
            h0VarU.x();
        } else {
            zA = false;
            z10 = false;
            strO = null;
            strO2 = null;
        }
        h0 h0VarW2 = h0.w(context, attributeSet, R$styleable.TextAppearance, i10, 0);
        if (z11) {
            z12 = z10;
        } else {
            int i20 = R$styleable.TextAppearance_textAllCaps;
            if (h0VarW2.s(i20)) {
                zA = h0VarW2.a(i20, false);
            } else {
                z12 = z10;
            }
        }
        int i21 = R$styleable.TextAppearance_textLocale;
        if (h0VarW2.s(i21)) {
            strO = h0VarW2.o(i21);
        }
        int i22 = R$styleable.TextAppearance_fontVariationSettings;
        if (h0VarW2.s(i22)) {
            strO2 = h0VarW2.o(i22);
        }
        int i23 = R$styleable.TextAppearance_android_textSize;
        if (h0VarW2.s(i23) && h0VarW2.f(i23, -1) == 0) {
            this.f1048a.setTextSize(0, 0.0f);
        }
        C(context, h0VarW2);
        h0VarW2.x();
        if (!z11 && z12) {
            s(zA);
        }
        Typeface typeface = this.f1059l;
        if (typeface != null) {
            if (this.f1058k == -1) {
                this.f1048a.setTypeface(typeface, this.f1057j);
            } else {
                this.f1048a.setTypeface(typeface);
            }
        }
        if (strO2 != null) {
            e.d(this.f1048a, strO2);
        }
        if (strO != null) {
            d.b(this.f1048a, d.a(strO));
        }
        this.f1056i.o(attributeSet, i10);
        if (o0.f1047b && this.f1056i.j() != 0) {
            int[] iArrI = this.f1056i.i();
            if (iArrI.length > 0) {
                if (e.a(this.f1048a) != -1.0f) {
                    e.b(this.f1048a, this.f1056i.g(), this.f1056i.f(), this.f1056i.h(), 0);
                } else {
                    e.c(this.f1048a, iArrI, 0);
                }
            }
        }
        h0 h0VarV = h0.v(context, attributeSet, R$styleable.AppCompatTextView);
        int iN2 = h0VarV.n(R$styleable.AppCompatTextView_drawableLeftCompat, -1);
        Drawable drawableC = iN2 != -1 ? gVarB.c(context, iN2) : null;
        int iN3 = h0VarV.n(R$styleable.AppCompatTextView_drawableTopCompat, -1);
        Drawable drawableC2 = iN3 != -1 ? gVarB.c(context, iN3) : null;
        int iN4 = h0VarV.n(R$styleable.AppCompatTextView_drawableRightCompat, -1);
        Drawable drawableC3 = iN4 != -1 ? gVarB.c(context, iN4) : null;
        int iN5 = h0VarV.n(R$styleable.AppCompatTextView_drawableBottomCompat, -1);
        Drawable drawableC4 = iN5 != -1 ? gVarB.c(context, iN5) : null;
        int iN6 = h0VarV.n(R$styleable.AppCompatTextView_drawableStartCompat, -1);
        Drawable drawableC5 = iN6 != -1 ? gVarB.c(context, iN6) : null;
        int iN7 = h0VarV.n(R$styleable.AppCompatTextView_drawableEndCompat, -1);
        y(drawableC, drawableC2, drawableC3, drawableC4, drawableC5, iN7 != -1 ? gVarB.c(context, iN7) : null);
        int i24 = R$styleable.AppCompatTextView_drawableTint;
        if (h0VarV.s(i24)) {
            androidx.core.widget.j.g(this.f1048a, h0VarV.c(i24));
        }
        int i25 = R$styleable.AppCompatTextView_drawableTintMode;
        if (h0VarV.s(i25)) {
            androidx.core.widget.j.h(this.f1048a, t.d(h0VarV.k(i25, -1), null));
        }
        int iF = h0VarV.f(R$styleable.AppCompatTextView_firstBaselineToTopHeight, -1);
        int iF2 = h0VarV.f(R$styleable.AppCompatTextView_lastBaselineToBottomHeight, -1);
        int iF3 = h0VarV.f(R$styleable.AppCompatTextView_lineHeight, -1);
        h0VarV.x();
        if (iF != -1) {
            androidx.core.widget.j.j(this.f1048a, iF);
        }
        if (iF2 != -1) {
            androidx.core.widget.j.k(this.f1048a, iF2);
        }
        if (iF3 != -1) {
            androidx.core.widget.j.l(this.f1048a, iF3);
        }
    }

    void n(WeakReference<TextView> weakReference, Typeface typeface) {
        if (this.f1060m) {
            this.f1059l = typeface;
            TextView textView = weakReference.get();
            if (textView != null) {
                if (androidx.core.view.h0.P(textView)) {
                    textView.post(new b(textView, typeface, this.f1057j));
                } else {
                    textView.setTypeface(typeface, this.f1057j);
                }
            }
        }
    }

    void o(boolean z10, int i10, int i11, int i12, int i13) {
        if (o0.f1047b) {
            return;
        }
        c();
    }

    void p() {
        b();
    }

    void q(Context context, int i10) {
        String strO;
        h0 h0VarU = h0.u(context, i10, R$styleable.TextAppearance);
        int i11 = R$styleable.TextAppearance_textAllCaps;
        if (h0VarU.s(i11)) {
            s(h0VarU.a(i11, false));
        }
        int i12 = R$styleable.TextAppearance_android_textSize;
        if (h0VarU.s(i12) && h0VarU.f(i12, -1) == 0) {
            this.f1048a.setTextSize(0, 0.0f);
        }
        C(context, h0VarU);
        int i13 = R$styleable.TextAppearance_fontVariationSettings;
        if (h0VarU.s(i13) && (strO = h0VarU.o(i13)) != null) {
            e.d(this.f1048a, strO);
        }
        h0VarU.x();
        Typeface typeface = this.f1059l;
        if (typeface != null) {
            this.f1048a.setTypeface(typeface, this.f1057j);
        }
    }

    void s(boolean z10) {
        this.f1048a.setAllCaps(z10);
    }

    void t(int i10, int i11, int i12, int i13) throws IllegalArgumentException {
        this.f1056i.p(i10, i11, i12, i13);
    }

    void u(int[] iArr, int i10) throws IllegalArgumentException {
        this.f1056i.q(iArr, i10);
    }

    void v(int i10) {
        this.f1056i.r(i10);
    }

    void w(ColorStateList colorStateList) {
        if (this.f1055h == null) {
            this.f1055h = new f0();
        }
        f0 f0Var = this.f1055h;
        f0Var.f983a = colorStateList;
        f0Var.f986d = colorStateList != null;
        z();
    }

    void x(PorterDuff.Mode mode) {
        if (this.f1055h == null) {
            this.f1055h = new f0();
        }
        f0 f0Var = this.f1055h;
        f0Var.f984b = mode;
        f0Var.f985c = mode != null;
        z();
    }

    /* JADX INFO: compiled from: AppCompatTextHelper.java */
    class a extends androidx.core.content.res.h.e {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        final /* synthetic */ int f1061a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        final /* synthetic */ int f1062b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        final /* synthetic */ WeakReference f1063c;

        a(int i10, int i11, WeakReference weakReference) {
            this.f1061a = i10;
            this.f1062b = i11;
            this.f1063c = weakReference;
        }

        @Override // androidx.core.content.res.h.e
        /* JADX INFO: renamed from: i */
        public void g(Typeface typeface) {
            int i10 = this.f1061a;
            if (i10 != -1) {
                typeface = f.a(typeface, i10, (this.f1062b & 2) != 0);
            }
            p.this.n(this.f1063c, typeface);
        }

        @Override // androidx.core.content.res.h.e
        /* JADX INFO: renamed from: h */
        public void f(int i10) {
        }
    }

    void r(TextView textView, InputConnection inputConnection, EditorInfo editorInfo) {
    }
}
