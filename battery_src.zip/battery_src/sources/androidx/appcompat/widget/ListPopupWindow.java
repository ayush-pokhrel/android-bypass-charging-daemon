package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.database.DataSetObserver;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import androidx.appcompat.R$attr;
import androidx.appcompat.R$styleable;
import androidx.appcompat.view.menu.ShowableListMenu;

/* JADX INFO: loaded from: classes.dex */
public class ListPopupWindow implements ShowableListMenu {
    private final h A;
    private final g B;
    private final e C;
    private Runnable D;
    final Handler E;
    private final Rect F;
    private Rect G;
    private boolean H;
    PopupWindow I;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private Context f796a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private ListAdapter f797b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    u f798c;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private int f799g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private int f800h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private int f801i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private int f802j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    private int f803k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private boolean f804l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    private boolean f805m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    private boolean f806n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    private int f807o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    private boolean f808p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    private boolean f809q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    int f810r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    private View f811s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    private int f812t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    private DataSetObserver f813u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    private View f814v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    private Drawable f815w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    private AdapterView.OnItemClickListener f816x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    private AdapterView.OnItemSelectedListener f817y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    final i f818z;

    class a implements Runnable {
        a() {
        }

        @Override // java.lang.Runnable
        public void run() {
            View viewO = ListPopupWindow.this.o();
            if (viewO == null || viewO.getWindowToken() == null) {
                return;
            }
            ListPopupWindow.this.show();
        }
    }

    static class c {
        static int a(PopupWindow popupWindow, View view, int i10, boolean z10) {
            return popupWindow.getMaxAvailableHeight(view, i10, z10);
        }
    }

    static class d {
        static void a(PopupWindow popupWindow, Rect rect) {
            popupWindow.setEpicenterBounds(rect);
        }

        static void b(PopupWindow popupWindow, boolean z10) {
            popupWindow.setIsClippedToScreen(z10);
        }
    }

    private class e implements Runnable {
        e() {
        }

        @Override // java.lang.Runnable
        public void run() {
            ListPopupWindow.this.m();
        }
    }

    private class f extends DataSetObserver {
        f() {
        }

        @Override // android.database.DataSetObserver
        public void onChanged() {
            if (ListPopupWindow.this.isShowing()) {
                ListPopupWindow.this.show();
            }
        }

        @Override // android.database.DataSetObserver
        public void onInvalidated() {
            ListPopupWindow.this.dismiss();
        }
    }

    private class h implements View.OnTouchListener {
        h() {
        }

        @Override // android.view.View.OnTouchListener
        public boolean onTouch(View view, MotionEvent motionEvent) {
            PopupWindow popupWindow;
            int action = motionEvent.getAction();
            int x10 = (int) motionEvent.getX();
            int y10 = (int) motionEvent.getY();
            if (action == 0 && (popupWindow = ListPopupWindow.this.I) != null && popupWindow.isShowing() && x10 >= 0 && x10 < ListPopupWindow.this.I.getWidth() && y10 >= 0 && y10 < ListPopupWindow.this.I.getHeight()) {
                ListPopupWindow listPopupWindow = ListPopupWindow.this;
                listPopupWindow.E.postDelayed(listPopupWindow.f818z, 250L);
                return false;
            }
            if (action != 1) {
                return false;
            }
            ListPopupWindow listPopupWindow2 = ListPopupWindow.this;
            listPopupWindow2.E.removeCallbacks(listPopupWindow2.f818z);
            return false;
        }
    }

    private class i implements Runnable {
        i() {
        }

        @Override // java.lang.Runnable
        public void run() {
            u uVar = ListPopupWindow.this.f798c;
            if (uVar == null || !androidx.core.view.h0.P(uVar) || ListPopupWindow.this.f798c.getCount() <= ListPopupWindow.this.f798c.getChildCount()) {
                return;
            }
            int childCount = ListPopupWindow.this.f798c.getChildCount();
            ListPopupWindow listPopupWindow = ListPopupWindow.this;
            if (childCount <= listPopupWindow.f810r) {
                listPopupWindow.I.setInputMethodMode(2);
                ListPopupWindow.this.show();
            }
        }
    }

    public ListPopupWindow(Context context) {
        this(context, null, R$attr.listPopupWindowStyle);
    }

    private void J(boolean z10) {
        d.b(this.I, z10);
    }

    private int a() {
        int measuredHeight;
        int i10;
        int iMakeMeasureSpec;
        View view;
        int i11;
        if (this.f798c == null) {
            Context context = this.f796a;
            this.D = new a();
            u uVarN = n(context, !this.H);
            this.f798c = uVarN;
            Drawable drawable = this.f815w;
            if (drawable != null) {
                uVarN.setSelector(drawable);
            }
            this.f798c.setAdapter(this.f797b);
            this.f798c.setOnItemClickListener(this.f816x);
            this.f798c.setFocusable(true);
            this.f798c.setFocusableInTouchMode(true);
            this.f798c.setOnItemSelectedListener(new b());
            this.f798c.setOnScrollListener(this.B);
            AdapterView.OnItemSelectedListener onItemSelectedListener = this.f817y;
            if (onItemSelectedListener != null) {
                this.f798c.setOnItemSelectedListener(onItemSelectedListener);
            }
            u uVar = this.f798c;
            View view2 = this.f811s;
            if (view2 != null) {
                LinearLayout linearLayout = new LinearLayout(context);
                linearLayout.setOrientation(1);
                LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, 0, 1.0f);
                int i12 = this.f812t;
                if (i12 == 0) {
                    linearLayout.addView(view2);
                    linearLayout.addView(uVar, layoutParams);
                } else if (i12 != 1) {
                    Log.e("ListPopupWindow", "Invalid hint position " + this.f812t);
                } else {
                    linearLayout.addView(uVar, layoutParams);
                    linearLayout.addView(view2);
                }
                int i13 = this.f800h;
                if (i13 >= 0) {
                    i11 = Integer.MIN_VALUE;
                } else {
                    i13 = 0;
                    i11 = 0;
                }
                view2.measure(View.MeasureSpec.makeMeasureSpec(i13, i11), 0);
                LinearLayout.LayoutParams layoutParams2 = (LinearLayout.LayoutParams) view2.getLayoutParams();
                measuredHeight = view2.getMeasuredHeight() + layoutParams2.topMargin + layoutParams2.bottomMargin;
                view = linearLayout;
            } else {
                measuredHeight = 0;
                view = uVar;
            }
            this.I.setContentView(view);
        } else {
            View view3 = this.f811s;
            if (view3 != null) {
                LinearLayout.LayoutParams layoutParams3 = (LinearLayout.LayoutParams) view3.getLayoutParams();
                measuredHeight = view3.getMeasuredHeight() + layoutParams3.topMargin + layoutParams3.bottomMargin;
            } else {
                measuredHeight = 0;
            }
        }
        Drawable background = this.I.getBackground();
        if (background != null) {
            background.getPadding(this.F);
            Rect rect = this.F;
            int i14 = rect.top;
            i10 = rect.bottom + i14;
            if (!this.f804l) {
                this.f802j = -i14;
            }
        } else {
            this.F.setEmpty();
            i10 = 0;
        }
        int iP = p(o(), this.f802j, this.I.getInputMethodMode() == 2);
        if (this.f808p || this.f799g == -1) {
            return iP + i10;
        }
        int i15 = this.f800h;
        if (i15 == -2) {
            int i16 = this.f796a.getResources().getDisplayMetrics().widthPixels;
            Rect rect2 = this.F;
            iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(i16 - (rect2.left + rect2.right), Integer.MIN_VALUE);
        } else if (i15 != -1) {
            iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(i15, 1073741824);
        } else {
            int i17 = this.f796a.getResources().getDisplayMetrics().widthPixels;
            Rect rect3 = this.F;
            iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(i17 - (rect3.left + rect3.right), 1073741824);
        }
        int iD = this.f798c.d(iMakeMeasureSpec, 0, -1, iP - measuredHeight, -1);
        if (iD > 0) {
            measuredHeight += i10 + this.f798c.getPaddingTop() + this.f798c.getPaddingBottom();
        }
        return iD + measuredHeight;
    }

    private int p(View view, int i10, boolean z10) {
        return c.a(this.I, view, i10, z10);
    }

    private void x() {
        View view = this.f811s;
        if (view != null) {
            ViewParent parent = view.getParent();
            if (parent instanceof ViewGroup) {
                ((ViewGroup) parent).removeView(this.f811s);
            }
        }
    }

    public void A(int i10) {
        Drawable background = this.I.getBackground();
        if (background == null) {
            M(i10);
            return;
        }
        background.getPadding(this.F);
        Rect rect = this.F;
        this.f800h = rect.left + rect.right + i10;
    }

    public void B(int i10) {
        this.f807o = i10;
    }

    public void C(Rect rect) {
        this.G = rect != null ? new Rect(rect) : null;
    }

    public void D(int i10) {
        this.I.setInputMethodMode(i10);
    }

    public void E(boolean z10) {
        this.H = z10;
        this.I.setFocusable(z10);
    }

    public void F(PopupWindow.OnDismissListener onDismissListener) {
        this.I.setOnDismissListener(onDismissListener);
    }

    public void G(AdapterView.OnItemClickListener onItemClickListener) {
        this.f816x = onItemClickListener;
    }

    public void H(AdapterView.OnItemSelectedListener onItemSelectedListener) {
        this.f817y = onItemSelectedListener;
    }

    public void I(boolean z10) {
        this.f806n = true;
        this.f805m = z10;
    }

    public void K(int i10) {
        this.f812t = i10;
    }

    public void L(int i10) {
        u uVar = this.f798c;
        if (!isShowing() || uVar == null) {
            return;
        }
        uVar.setListSelectionHidden(false);
        uVar.setSelection(i10);
        if (uVar.getChoiceMode() != 0) {
            uVar.setItemChecked(i10, true);
        }
    }

    public void M(int i10) {
        this.f800h = i10;
    }

    public void b(Drawable drawable) {
        this.I.setBackgroundDrawable(drawable);
    }

    public int c() {
        return this.f801i;
    }

    public Drawable d() {
        return this.I.getBackground();
    }

    @Override // androidx.appcompat.view.menu.ShowableListMenu
    public void dismiss() {
        this.I.dismiss();
        x();
        this.I.setContentView(null);
        this.f798c = null;
        this.E.removeCallbacks(this.f818z);
    }

    public void f(int i10) {
        this.f802j = i10;
        this.f804l = true;
    }

    @Override // androidx.appcompat.view.menu.ShowableListMenu
    public ListView getListView() {
        return this.f798c;
    }

    public void h(int i10) {
        this.f801i = i10;
    }

    @Override // androidx.appcompat.view.menu.ShowableListMenu
    public boolean isShowing() {
        return this.I.isShowing();
    }

    public int j() {
        if (this.f804l) {
            return this.f802j;
        }
        return 0;
    }

    public void l(ListAdapter listAdapter) {
        DataSetObserver dataSetObserver = this.f813u;
        if (dataSetObserver == null) {
            this.f813u = new f();
        } else {
            ListAdapter listAdapter2 = this.f797b;
            if (listAdapter2 != null) {
                listAdapter2.unregisterDataSetObserver(dataSetObserver);
            }
        }
        this.f797b = listAdapter;
        if (listAdapter != null) {
            listAdapter.registerDataSetObserver(this.f813u);
        }
        u uVar = this.f798c;
        if (uVar != null) {
            uVar.setAdapter(this.f797b);
        }
    }

    public void m() {
        u uVar = this.f798c;
        if (uVar != null) {
            uVar.setListSelectionHidden(true);
            uVar.requestLayout();
        }
    }

    u n(Context context, boolean z10) {
        return new u(context, z10);
    }

    public View o() {
        return this.f814v;
    }

    public Object q() {
        if (isShowing()) {
            return this.f798c.getSelectedItem();
        }
        return null;
    }

    public long r() {
        if (isShowing()) {
            return this.f798c.getSelectedItemId();
        }
        return Long.MIN_VALUE;
    }

    public int s() {
        if (isShowing()) {
            return this.f798c.getSelectedItemPosition();
        }
        return -1;
    }

    @Override // androidx.appcompat.view.menu.ShowableListMenu
    public void show() {
        int iA = a();
        boolean zV = v();
        androidx.core.widget.i.b(this.I, this.f803k);
        if (this.I.isShowing()) {
            if (androidx.core.view.h0.P(o())) {
                int width = this.f800h;
                if (width == -1) {
                    width = -1;
                } else if (width == -2) {
                    width = o().getWidth();
                }
                int i10 = this.f799g;
                if (i10 == -1) {
                    if (!zV) {
                        iA = -1;
                    }
                    if (zV) {
                        this.I.setWidth(this.f800h == -1 ? -1 : 0);
                        this.I.setHeight(0);
                    } else {
                        this.I.setWidth(this.f800h == -1 ? -1 : 0);
                        this.I.setHeight(-1);
                    }
                } else if (i10 != -2) {
                    iA = i10;
                }
                this.I.setOutsideTouchable((this.f809q || this.f808p) ? false : true);
                this.I.update(o(), this.f801i, this.f802j, width < 0 ? -1 : width, iA < 0 ? -1 : iA);
                return;
            }
            return;
        }
        int width2 = this.f800h;
        if (width2 == -1) {
            width2 = -1;
        } else if (width2 == -2) {
            width2 = o().getWidth();
        }
        int i11 = this.f799g;
        if (i11 == -1) {
            iA = -1;
        } else if (i11 != -2) {
            iA = i11;
        }
        this.I.setWidth(width2);
        this.I.setHeight(iA);
        J(true);
        this.I.setOutsideTouchable((this.f809q || this.f808p) ? false : true);
        this.I.setTouchInterceptor(this.A);
        if (this.f806n) {
            androidx.core.widget.i.a(this.I, this.f805m);
        }
        d.a(this.I, this.G);
        androidx.core.widget.i.c(this.I, o(), this.f801i, this.f802j, this.f807o);
        this.f798c.setSelection(-1);
        if (!this.H || this.f798c.isInTouchMode()) {
            m();
        }
        if (this.H) {
            return;
        }
        this.E.post(this.C);
    }

    public View t() {
        if (isShowing()) {
            return this.f798c.getSelectedView();
        }
        return null;
    }

    public int u() {
        return this.f800h;
    }

    public boolean v() {
        return this.I.getInputMethodMode() == 2;
    }

    public boolean w() {
        return this.H;
    }

    public void y(View view) {
        this.f814v = view;
    }

    public void z(int i10) {
        this.I.setAnimationStyle(i10);
    }

    public ListPopupWindow(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R$attr.listPopupWindowStyle);
    }

    public ListPopupWindow(Context context, AttributeSet attributeSet, int i10) {
        this(context, attributeSet, i10, 0);
    }

    public ListPopupWindow(Context context, AttributeSet attributeSet, int i10, int i11) {
        this.f799g = -2;
        this.f800h = -2;
        this.f803k = 1002;
        this.f807o = 0;
        this.f808p = false;
        this.f809q = false;
        this.f810r = Integer.MAX_VALUE;
        this.f812t = 0;
        this.f818z = new i();
        this.A = new h();
        this.B = new g();
        this.C = new e();
        this.F = new Rect();
        this.f796a = context;
        this.E = new Handler(context.getMainLooper());
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R$styleable.ListPopupWindow, i10, i11);
        this.f801i = typedArrayObtainStyledAttributes.getDimensionPixelOffset(R$styleable.ListPopupWindow_android_dropDownHorizontalOffset, 0);
        int dimensionPixelOffset = typedArrayObtainStyledAttributes.getDimensionPixelOffset(R$styleable.ListPopupWindow_android_dropDownVerticalOffset, 0);
        this.f802j = dimensionPixelOffset;
        if (dimensionPixelOffset != 0) {
            this.f804l = true;
        }
        typedArrayObtainStyledAttributes.recycle();
        AppCompatPopupWindow appCompatPopupWindow = new AppCompatPopupWindow(context, attributeSet, i10, i11);
        this.I = appCompatPopupWindow;
        appCompatPopupWindow.setInputMethodMode(1);
    }

    class b implements AdapterView.OnItemSelectedListener {
        b() {
        }

        @Override // android.widget.AdapterView.OnItemSelectedListener
        public void onItemSelected(AdapterView<?> adapterView, View view, int i10, long j10) {
            u uVar;
            if (i10 == -1 || (uVar = ListPopupWindow.this.f798c) == null) {
                return;
            }
            uVar.setListSelectionHidden(false);
        }

        @Override // android.widget.AdapterView.OnItemSelectedListener
        public void onNothingSelected(AdapterView<?> adapterView) {
        }
    }

    private class g implements AbsListView.OnScrollListener {
        g() {
        }

        @Override // android.widget.AbsListView.OnScrollListener
        public void onScrollStateChanged(AbsListView absListView, int i10) {
            if (i10 != 1 || ListPopupWindow.this.v() || ListPopupWindow.this.I.getContentView() == null) {
                return;
            }
            ListPopupWindow listPopupWindow = ListPopupWindow.this;
            listPopupWindow.E.removeCallbacks(listPopupWindow.f818z);
            ListPopupWindow.this.f818z.run();
        }

        @Override // android.widget.AbsListView.OnScrollListener
        public void onScroll(AbsListView absListView, int i10, int i11, int i12) {
        }
    }
}
