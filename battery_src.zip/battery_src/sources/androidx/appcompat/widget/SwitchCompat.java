package androidx.appcompat.widget;

import android.R;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.Region;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.text.InputFilter;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.text.TextUtils;
import android.text.method.TransformationMethod;
import android.util.AttributeSet;
import android.util.Property;
import android.view.ActionMode;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.CompoundButton;
import androidx.appcompat.R$attr;
import androidx.appcompat.R$string;
import androidx.appcompat.R$styleable;
import java.lang.ref.Reference;
import java.lang.ref.WeakReference;

/* JADX INFO: loaded from: classes.dex */
public class SwitchCompat extends CompoundButton {
    private static final Property<SwitchCompat, Float> V = new a(Float.class, "thumbPos");
    private static final int[] W = {R.attr.state_checked};
    private VelocityTracker A;
    private int B;
    float C;
    private int D;
    private int E;
    private int F;
    private int G;
    private int H;
    private int I;
    private int J;
    private boolean K;
    private final TextPaint L;
    private ColorStateList M;
    private Layout N;
    private Layout O;
    private TransformationMethod P;
    ObjectAnimator Q;
    private final p R;
    private i S;
    private c T;
    private final Rect U;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private Drawable f877a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private ColorStateList f878b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private PorterDuff.Mode f879c;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private boolean f880g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private boolean f881h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private Drawable f882i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private ColorStateList f883j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    private PorterDuff.Mode f884k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private boolean f885l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    private boolean f886m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    private int f887n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    private int f888o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    private int f889p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    private boolean f890q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    private CharSequence f891r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    private CharSequence f892s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    private CharSequence f893t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    private CharSequence f894u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    private boolean f895v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    private int f896w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    private int f897x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    private float f898y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    private float f899z;

    class a extends Property<SwitchCompat, Float> {
        a(Class cls, String str) {
            super(cls, str);
        }

        @Override // android.util.Property
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public Float get(SwitchCompat switchCompat) {
            return Float.valueOf(switchCompat.C);
        }

        @Override // android.util.Property
        /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
        public void set(SwitchCompat switchCompat, Float f10) {
            switchCompat.setThumbPosition(f10.floatValue());
        }
    }

    static class b {
        static void a(ObjectAnimator objectAnimator, boolean z10) {
            objectAnimator.setAutoCancel(z10);
        }
    }

    static class c extends androidx.emoji2.text.e.AbstractC0023e {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private final Reference<SwitchCompat> f900a;

        c(SwitchCompat switchCompat) {
            this.f900a = new WeakReference(switchCompat);
        }

        @Override // androidx.emoji2.text.e.AbstractC0023e
        public void a(Throwable th) {
            SwitchCompat switchCompat = this.f900a.get();
            if (switchCompat != null) {
                switchCompat.j();
            }
        }

        @Override // androidx.emoji2.text.e.AbstractC0023e
        public void b() {
            SwitchCompat switchCompat = this.f900a.get();
            if (switchCompat != null) {
                switchCompat.j();
            }
        }
    }

    public SwitchCompat(Context context) {
        this(context, null);
    }

    private void a(boolean z10) {
        ObjectAnimator objectAnimatorOfFloat = ObjectAnimator.ofFloat(this, V, z10 ? 1.0f : 0.0f);
        this.Q = objectAnimatorOfFloat;
        objectAnimatorOfFloat.setDuration(250L);
        b.a(this.Q, true);
        this.Q.start();
    }

    private void b() {
        Drawable drawable = this.f877a;
        if (drawable != null) {
            if (this.f880g || this.f881h) {
                Drawable drawableMutate = androidx.core.graphics.drawable.a.r(drawable).mutate();
                this.f877a = drawableMutate;
                if (this.f880g) {
                    androidx.core.graphics.drawable.a.o(drawableMutate, this.f878b);
                }
                if (this.f881h) {
                    androidx.core.graphics.drawable.a.p(this.f877a, this.f879c);
                }
                if (this.f877a.isStateful()) {
                    this.f877a.setState(getDrawableState());
                }
            }
        }
    }

    private void c() {
        Drawable drawable = this.f882i;
        if (drawable != null) {
            if (this.f885l || this.f886m) {
                Drawable drawableMutate = androidx.core.graphics.drawable.a.r(drawable).mutate();
                this.f882i = drawableMutate;
                if (this.f885l) {
                    androidx.core.graphics.drawable.a.o(drawableMutate, this.f883j);
                }
                if (this.f886m) {
                    androidx.core.graphics.drawable.a.p(this.f882i, this.f884k);
                }
                if (this.f882i.isStateful()) {
                    this.f882i.setState(getDrawableState());
                }
            }
        }
    }

    private void d() {
        ObjectAnimator objectAnimator = this.Q;
        if (objectAnimator != null) {
            objectAnimator.cancel();
        }
    }

    private void e(MotionEvent motionEvent) {
        MotionEvent motionEventObtain = MotionEvent.obtain(motionEvent);
        motionEventObtain.setAction(3);
        super.onTouchEvent(motionEventObtain);
        motionEventObtain.recycle();
    }

    private static float f(float f10, float f11, float f12) {
        if (f10 < f11) {
            return f11;
        }
        return f10 > f12 ? f12 : f10;
    }

    private CharSequence g(CharSequence charSequence) {
        TransformationMethod transformationMethodF = getEmojiTextViewHelper().f(this.P);
        return transformationMethodF != null ? transformationMethodF.getTransformation(charSequence, this) : charSequence;
    }

    private i getEmojiTextViewHelper() {
        if (this.S == null) {
            this.S = new i(this);
        }
        return this.S;
    }

    private boolean getTargetCheckedState() {
        return this.C > 0.5f;
    }

    private int getThumbOffset() {
        return (int) (((o0.b(this) ? 1.0f - this.C : this.C) * getThumbScrollRange()) + 0.5f);
    }

    private int getThumbScrollRange() {
        Drawable drawable = this.f882i;
        if (drawable == null) {
            return 0;
        }
        Rect rect = this.U;
        drawable.getPadding(rect);
        Drawable drawable2 = this.f877a;
        Rect rectC = drawable2 != null ? t.c(drawable2) : t.f1085c;
        return ((((this.D - this.F) - rect.left) - rect.right) - rectC.left) - rectC.right;
    }

    private boolean h(float f10, float f11) {
        if (this.f877a == null) {
            return false;
        }
        int thumbOffset = getThumbOffset();
        this.f877a.getPadding(this.U);
        int i10 = this.H;
        int i11 = this.f897x;
        int i12 = i10 - i11;
        int i13 = (this.G + thumbOffset) - i11;
        int i14 = this.F + i13;
        Rect rect = this.U;
        return f10 > ((float) i13) && f10 < ((float) (((i14 + rect.left) + rect.right) + i11)) && f11 > ((float) i12) && f11 < ((float) (this.J + i11));
    }

    private Layout i(CharSequence charSequence) {
        TextPaint textPaint = this.L;
        return new StaticLayout(charSequence, textPaint, charSequence != null ? (int) Math.ceil(Layout.getDesiredWidth(charSequence, textPaint)) : 0, Layout.Alignment.ALIGN_NORMAL, 1.0f, 0.0f, true);
    }

    private void k() {
        CharSequence string = this.f893t;
        if (string == null) {
            string = getResources().getString(R$string.abc_capital_off);
        }
        androidx.core.view.h0.F0(this, string);
    }

    private void l() {
        CharSequence string = this.f891r;
        if (string == null) {
            string = getResources().getString(R$string.abc_capital_on);
        }
        androidx.core.view.h0.F0(this, string);
    }

    private void o(int i10, int i11) {
        Typeface typeface;
        if (i10 == 1) {
            typeface = Typeface.SANS_SERIF;
        } else if (i10 != 2) {
            typeface = i10 != 3 ? null : Typeface.MONOSPACE;
        } else {
            typeface = Typeface.SERIF;
        }
        n(typeface, i11);
    }

    private void p() {
        if (this.T == null && this.S.b() && androidx.emoji2.text.e.h()) {
            androidx.emoji2.text.e eVarB = androidx.emoji2.text.e.b();
            int iD = eVarB.d();
            if (iD == 3 || iD == 0) {
                c cVar = new c(this);
                this.T = cVar;
                eVarB.s(cVar);
            }
        }
    }

    private void q(MotionEvent motionEvent) {
        this.f896w = 0;
        boolean targetCheckedState = true;
        boolean z10 = motionEvent.getAction() == 1 && isEnabled();
        boolean zIsChecked = isChecked();
        if (z10) {
            this.A.computeCurrentVelocity(1000);
            float xVelocity = this.A.getXVelocity();
            if (Math.abs(xVelocity) <= this.B) {
                targetCheckedState = getTargetCheckedState();
            } else if (!o0.b(this) ? xVelocity <= 0.0f : xVelocity >= 0.0f) {
                targetCheckedState = false;
            }
        } else {
            targetCheckedState = zIsChecked;
        }
        if (targetCheckedState != zIsChecked) {
            playSoundEffect(0);
        }
        setChecked(targetCheckedState);
        e(motionEvent);
    }

    private void setTextOffInternal(CharSequence charSequence) {
        this.f893t = charSequence;
        this.f894u = g(charSequence);
        this.O = null;
        if (this.f895v) {
            p();
        }
    }

    private void setTextOnInternal(CharSequence charSequence) {
        this.f891r = charSequence;
        this.f892s = g(charSequence);
        this.N = null;
        if (this.f895v) {
            p();
        }
    }

    @Override // android.view.View
    public void draw(Canvas canvas) {
        int i10;
        int i11;
        Rect rect = this.U;
        int i12 = this.G;
        int i13 = this.H;
        int i14 = this.I;
        int i15 = this.J;
        int thumbOffset = getThumbOffset() + i12;
        Drawable drawable = this.f877a;
        Rect rectC = drawable != null ? t.c(drawable) : t.f1085c;
        Drawable drawable2 = this.f882i;
        if (drawable2 != null) {
            drawable2.getPadding(rect);
            int i16 = rect.left;
            thumbOffset += i16;
            if (rectC != null) {
                int i17 = rectC.left;
                if (i17 > i16) {
                    i12 += i17 - i16;
                }
                int i18 = rectC.top;
                int i19 = rect.top;
                i10 = i18 > i19 ? (i18 - i19) + i13 : i13;
                int i20 = rectC.right;
                int i21 = rect.right;
                if (i20 > i21) {
                    i14 -= i20 - i21;
                }
                int i22 = rectC.bottom;
                int i23 = rect.bottom;
                if (i22 > i23) {
                    i11 = i15 - (i22 - i23);
                }
                this.f882i.setBounds(i12, i10, i14, i11);
            } else {
                i10 = i13;
            }
            i11 = i15;
            this.f882i.setBounds(i12, i10, i14, i11);
        }
        Drawable drawable3 = this.f877a;
        if (drawable3 != null) {
            drawable3.getPadding(rect);
            int i24 = thumbOffset - rect.left;
            int i25 = thumbOffset + this.F + rect.right;
            this.f877a.setBounds(i24, i13, i25, i15);
            Drawable background = getBackground();
            if (background != null) {
                androidx.core.graphics.drawable.a.l(background, i24, i13, i25, i15);
            }
        }
        super.draw(canvas);
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    public void drawableHotspotChanged(float f10, float f11) {
        super.drawableHotspotChanged(f10, f11);
        Drawable drawable = this.f877a;
        if (drawable != null) {
            androidx.core.graphics.drawable.a.k(drawable, f10, f11);
        }
        Drawable drawable2 = this.f882i;
        if (drawable2 != null) {
            androidx.core.graphics.drawable.a.k(drawable2, f10, f11);
        }
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    protected void drawableStateChanged() {
        super.drawableStateChanged();
        int[] drawableState = getDrawableState();
        Drawable drawable = this.f877a;
        boolean state = (drawable == null || !drawable.isStateful()) ? false : drawable.setState(drawableState);
        Drawable drawable2 = this.f882i;
        if (drawable2 != null && drawable2.isStateful()) {
            state |= drawable2.setState(drawableState);
        }
        if (state) {
            invalidate();
        }
    }

    @Override // android.widget.CompoundButton, android.widget.TextView
    public int getCompoundPaddingLeft() {
        if (!o0.b(this)) {
            return super.getCompoundPaddingLeft();
        }
        int compoundPaddingLeft = super.getCompoundPaddingLeft() + this.D;
        return !TextUtils.isEmpty(getText()) ? compoundPaddingLeft + this.f889p : compoundPaddingLeft;
    }

    @Override // android.widget.CompoundButton, android.widget.TextView
    public int getCompoundPaddingRight() {
        if (o0.b(this)) {
            return super.getCompoundPaddingRight();
        }
        int compoundPaddingRight = super.getCompoundPaddingRight() + this.D;
        return !TextUtils.isEmpty(getText()) ? compoundPaddingRight + this.f889p : compoundPaddingRight;
    }

    @Override // android.widget.TextView
    public ActionMode.Callback getCustomSelectionActionModeCallback() {
        return androidx.core.widget.j.p(super.getCustomSelectionActionModeCallback());
    }

    public boolean getShowText() {
        return this.f895v;
    }

    public boolean getSplitTrack() {
        return this.f890q;
    }

    public int getSwitchMinWidth() {
        return this.f888o;
    }

    public int getSwitchPadding() {
        return this.f889p;
    }

    public CharSequence getTextOff() {
        return this.f893t;
    }

    public CharSequence getTextOn() {
        return this.f891r;
    }

    public Drawable getThumbDrawable() {
        return this.f877a;
    }

    protected final float getThumbPosition() {
        return this.C;
    }

    public int getThumbTextPadding() {
        return this.f887n;
    }

    public ColorStateList getThumbTintList() {
        return this.f878b;
    }

    public PorterDuff.Mode getThumbTintMode() {
        return this.f879c;
    }

    public Drawable getTrackDrawable() {
        return this.f882i;
    }

    public ColorStateList getTrackTintList() {
        return this.f883j;
    }

    public PorterDuff.Mode getTrackTintMode() {
        return this.f884k;
    }

    void j() {
        setTextOnInternal(this.f891r);
        setTextOffInternal(this.f893t);
        requestLayout();
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    public void jumpDrawablesToCurrentState() {
        super.jumpDrawablesToCurrentState();
        Drawable drawable = this.f877a;
        if (drawable != null) {
            drawable.jumpToCurrentState();
        }
        Drawable drawable2 = this.f882i;
        if (drawable2 != null) {
            drawable2.jumpToCurrentState();
        }
        ObjectAnimator objectAnimator = this.Q;
        if (objectAnimator == null || !objectAnimator.isStarted()) {
            return;
        }
        this.Q.end();
        this.Q = null;
    }

    public void m(Context context, int i10) {
        h0 h0VarU = h0.u(context, i10, R$styleable.TextAppearance);
        ColorStateList colorStateListC = h0VarU.c(R$styleable.TextAppearance_android_textColor);
        if (colorStateListC != null) {
            this.M = colorStateListC;
        } else {
            this.M = getTextColors();
        }
        int iF = h0VarU.f(R$styleable.TextAppearance_android_textSize, 0);
        if (iF != 0) {
            float f10 = iF;
            if (f10 != this.L.getTextSize()) {
                this.L.setTextSize(f10);
                requestLayout();
            }
        }
        o(h0VarU.k(R$styleable.TextAppearance_android_typeface, -1), h0VarU.k(R$styleable.TextAppearance_android_textStyle, -1));
        if (h0VarU.a(R$styleable.TextAppearance_textAllCaps, false)) {
            this.P = new m.a(getContext());
        } else {
            this.P = null;
        }
        setTextOnInternal(this.f891r);
        setTextOffInternal(this.f893t);
        h0VarU.x();
    }

    public void n(Typeface typeface, int i10) {
        if (i10 <= 0) {
            this.L.setFakeBoldText(false);
            this.L.setTextSkewX(0.0f);
            setSwitchTypeface(typeface);
        } else {
            Typeface typefaceDefaultFromStyle = typeface == null ? Typeface.defaultFromStyle(i10) : Typeface.create(typeface, i10);
            setSwitchTypeface(typefaceDefaultFromStyle);
            int i11 = (~(typefaceDefaultFromStyle != null ? typefaceDefaultFromStyle.getStyle() : 0)) & i10;
            this.L.setFakeBoldText((i11 & 1) != 0);
            this.L.setTextSkewX((i11 & 2) != 0 ? -0.25f : 0.0f);
        }
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    protected int[] onCreateDrawableState(int i10) {
        int[] iArrOnCreateDrawableState = super.onCreateDrawableState(i10 + 1);
        if (isChecked()) {
            View.mergeDrawableStates(iArrOnCreateDrawableState, W);
        }
        return iArrOnCreateDrawableState;
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    protected void onDraw(Canvas canvas) {
        int width;
        super.onDraw(canvas);
        Rect rect = this.U;
        Drawable drawable = this.f882i;
        if (drawable != null) {
            drawable.getPadding(rect);
        } else {
            rect.setEmpty();
        }
        int i10 = this.H;
        int i11 = this.J;
        int i12 = i10 + rect.top;
        int i13 = i11 - rect.bottom;
        Drawable drawable2 = this.f877a;
        if (drawable != null) {
            if (!this.f890q || drawable2 == null) {
                drawable.draw(canvas);
            } else {
                Rect rectC = t.c(drawable2);
                drawable2.copyBounds(rect);
                rect.left += rectC.left;
                rect.right -= rectC.right;
                int iSave = canvas.save();
                canvas.clipRect(rect, Region.Op.DIFFERENCE);
                drawable.draw(canvas);
                canvas.restoreToCount(iSave);
            }
        }
        int iSave2 = canvas.save();
        if (drawable2 != null) {
            drawable2.draw(canvas);
        }
        Layout layout = getTargetCheckedState() ? this.N : this.O;
        if (layout != null) {
            int[] drawableState = getDrawableState();
            ColorStateList colorStateList = this.M;
            if (colorStateList != null) {
                this.L.setColor(colorStateList.getColorForState(drawableState, 0));
            }
            this.L.drawableState = drawableState;
            if (drawable2 != null) {
                Rect bounds = drawable2.getBounds();
                width = bounds.left + bounds.right;
            } else {
                width = getWidth();
            }
            canvas.translate((width / 2) - (layout.getWidth() / 2), ((i12 + i13) / 2) - (layout.getHeight() / 2));
            layout.draw(canvas);
        }
        canvas.restoreToCount(iSave2);
    }

    @Override // android.view.View
    public void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        super.onInitializeAccessibilityEvent(accessibilityEvent);
        accessibilityEvent.setClassName("android.widget.Switch");
    }

    @Override // android.view.View
    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        accessibilityNodeInfo.setClassName("android.widget.Switch");
    }

    @Override // android.widget.TextView, android.view.View
    protected void onLayout(boolean z10, int i10, int i11, int i12, int i13) {
        int iMax;
        int width;
        int paddingLeft;
        int i14;
        int paddingTop;
        int height;
        super.onLayout(z10, i10, i11, i12, i13);
        int iMax2 = 0;
        if (this.f877a != null) {
            Rect rect = this.U;
            Drawable drawable = this.f882i;
            if (drawable != null) {
                drawable.getPadding(rect);
            } else {
                rect.setEmpty();
            }
            Rect rectC = t.c(this.f877a);
            iMax = Math.max(0, rectC.left - rect.left);
            iMax2 = Math.max(0, rectC.right - rect.right);
        } else {
            iMax = 0;
        }
        if (o0.b(this)) {
            paddingLeft = getPaddingLeft() + iMax;
            width = ((this.D + paddingLeft) - iMax) - iMax2;
        } else {
            width = (getWidth() - getPaddingRight()) - iMax2;
            paddingLeft = (width - this.D) + iMax + iMax2;
        }
        int gravity = getGravity() & 112;
        if (gravity != 16) {
            if (gravity != 80) {
                paddingTop = getPaddingTop();
                i14 = this.E;
            } else {
                height = getHeight() - getPaddingBottom();
                paddingTop = height - this.E;
            }
            this.G = paddingLeft;
            this.H = paddingTop;
            this.J = height;
            this.I = width;
        }
        int paddingTop2 = ((getPaddingTop() + getHeight()) - getPaddingBottom()) / 2;
        i14 = this.E;
        paddingTop = paddingTop2 - (i14 / 2);
        height = i14 + paddingTop;
        this.G = paddingLeft;
        this.H = paddingTop;
        this.J = height;
        this.I = width;
    }

    @Override // android.widget.TextView, android.view.View
    public void onMeasure(int i10, int i11) {
        int intrinsicWidth;
        int intrinsicHeight;
        if (this.f895v) {
            if (this.N == null) {
                this.N = i(this.f892s);
            }
            if (this.O == null) {
                this.O = i(this.f894u);
            }
        }
        Rect rect = this.U;
        Drawable drawable = this.f877a;
        int intrinsicHeight2 = 0;
        if (drawable != null) {
            drawable.getPadding(rect);
            intrinsicWidth = (this.f877a.getIntrinsicWidth() - rect.left) - rect.right;
            intrinsicHeight = this.f877a.getIntrinsicHeight();
        } else {
            intrinsicWidth = 0;
            intrinsicHeight = 0;
        }
        this.F = Math.max(this.f895v ? Math.max(this.N.getWidth(), this.O.getWidth()) + (this.f887n * 2) : 0, intrinsicWidth);
        Drawable drawable2 = this.f882i;
        if (drawable2 != null) {
            drawable2.getPadding(rect);
            intrinsicHeight2 = this.f882i.getIntrinsicHeight();
        } else {
            rect.setEmpty();
        }
        int iMax = rect.left;
        int iMax2 = rect.right;
        Drawable drawable3 = this.f877a;
        if (drawable3 != null) {
            Rect rectC = t.c(drawable3);
            iMax = Math.max(iMax, rectC.left);
            iMax2 = Math.max(iMax2, rectC.right);
        }
        int iMax3 = this.K ? Math.max(this.f888o, (this.F * 2) + iMax + iMax2) : this.f888o;
        int iMax4 = Math.max(intrinsicHeight2, intrinsicHeight);
        this.D = iMax3;
        this.E = iMax4;
        super.onMeasure(i10, i11);
        if (getMeasuredHeight() < iMax4) {
            setMeasuredDimension(getMeasuredWidthAndState(), iMax4);
        }
    }

    @Override // android.view.View
    public void onPopulateAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        super.onPopulateAccessibilityEvent(accessibilityEvent);
        CharSequence charSequence = isChecked() ? this.f891r : this.f893t;
        if (charSequence != null) {
            accessibilityEvent.getText().add(charSequence);
        }
    }

    /* JADX WARN: Code duplicated, block: B:34:0x0089  */
    /* JADX WARN: Code duplicated, block: B:36:0x008d  */
    /* JADX WARN: Code duplicated, block: B:38:0x0094  */
    @Override // android.widget.TextView, android.view.View
    public boolean onTouchEvent(MotionEvent motionEvent) {
        float f10;
        this.A.addMovement(motionEvent);
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            float x10 = motionEvent.getX();
            float y10 = motionEvent.getY();
            if (isEnabled() && h(x10, y10)) {
                this.f896w = 1;
                this.f898y = x10;
                this.f899z = y10;
            }
        } else if (actionMasked == 1) {
            if (this.f896w == 2) {
                q(motionEvent);
                super.onTouchEvent(motionEvent);
                return true;
            }
            this.f896w = 0;
            this.A.clear();
        } else if (actionMasked == 2) {
            int i10 = this.f896w;
            if (i10 == 1) {
                float x11 = motionEvent.getX();
                float y11 = motionEvent.getY();
                if (Math.abs(x11 - this.f898y) > this.f897x || Math.abs(y11 - this.f899z) > this.f897x) {
                    this.f896w = 2;
                    getParent().requestDisallowInterceptTouchEvent(true);
                    this.f898y = x11;
                    this.f899z = y11;
                    return true;
                }
            } else if (i10 == 2) {
                float x12 = motionEvent.getX();
                int thumbScrollRange = getThumbScrollRange();
                float f11 = x12 - this.f898y;
                if (thumbScrollRange != 0) {
                    f10 = f11 / thumbScrollRange;
                } else {
                    f10 = f11 > 0.0f ? 1.0f : -1.0f;
                }
                if (o0.b(this)) {
                    f10 = -f10;
                }
                float f12 = f(this.C + f10, 0.0f, 1.0f);
                if (f12 != this.C) {
                    this.f898y = x12;
                    setThumbPosition(f12);
                }
                return true;
            }
        } else if (actionMasked == 3) {
            if (this.f896w == 2) {
                q(motionEvent);
                super.onTouchEvent(motionEvent);
                return true;
            }
            this.f896w = 0;
            this.A.clear();
        }
        return super.onTouchEvent(motionEvent);
    }

    @Override // android.widget.TextView
    public void setAllCaps(boolean z10) {
        super.setAllCaps(z10);
        getEmojiTextViewHelper().d(z10);
    }

    @Override // android.widget.CompoundButton, android.widget.Checkable
    public void setChecked(boolean z10) {
        super.setChecked(z10);
        boolean zIsChecked = isChecked();
        if (zIsChecked) {
            l();
        } else {
            k();
        }
        if (getWindowToken() != null && androidx.core.view.h0.Q(this)) {
            a(zIsChecked);
        } else {
            d();
            setThumbPosition(zIsChecked ? 1.0f : 0.0f);
        }
    }

    @Override // android.widget.TextView
    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(androidx.core.widget.j.q(this, callback));
    }

    public void setEmojiCompatEnabled(boolean z10) {
        getEmojiTextViewHelper().e(z10);
        setTextOnInternal(this.f891r);
        setTextOffInternal(this.f893t);
        requestLayout();
    }

    protected final void setEnforceSwitchWidth(boolean z10) {
        this.K = z10;
        invalidate();
    }

    @Override // android.widget.TextView
    public void setFilters(InputFilter[] inputFilterArr) {
        super.setFilters(getEmojiTextViewHelper().a(inputFilterArr));
    }

    public void setShowText(boolean z10) {
        if (this.f895v != z10) {
            this.f895v = z10;
            requestLayout();
            if (z10) {
                p();
            }
        }
    }

    public void setSplitTrack(boolean z10) {
        this.f890q = z10;
        invalidate();
    }

    public void setSwitchMinWidth(int i10) {
        this.f888o = i10;
        requestLayout();
    }

    public void setSwitchPadding(int i10) {
        this.f889p = i10;
        requestLayout();
    }

    public void setSwitchTypeface(Typeface typeface) {
        if ((this.L.getTypeface() == null || this.L.getTypeface().equals(typeface)) && (this.L.getTypeface() != null || typeface == null)) {
            return;
        }
        this.L.setTypeface(typeface);
        requestLayout();
        invalidate();
    }

    public void setTextOff(CharSequence charSequence) {
        setTextOffInternal(charSequence);
        requestLayout();
        if (isChecked()) {
            return;
        }
        k();
    }

    public void setTextOn(CharSequence charSequence) {
        setTextOnInternal(charSequence);
        requestLayout();
        if (isChecked()) {
            l();
        }
    }

    public void setThumbDrawable(Drawable drawable) {
        Drawable drawable2 = this.f877a;
        if (drawable2 != null) {
            drawable2.setCallback(null);
        }
        this.f877a = drawable;
        if (drawable != null) {
            drawable.setCallback(this);
        }
        requestLayout();
    }

    void setThumbPosition(float f10) {
        this.C = f10;
        invalidate();
    }

    public void setThumbResource(int i10) {
        setThumbDrawable(h.a.b(getContext(), i10));
    }

    public void setThumbTextPadding(int i10) {
        this.f887n = i10;
        requestLayout();
    }

    public void setThumbTintList(ColorStateList colorStateList) {
        this.f878b = colorStateList;
        this.f880g = true;
        b();
    }

    public void setThumbTintMode(PorterDuff.Mode mode) {
        this.f879c = mode;
        this.f881h = true;
        b();
    }

    public void setTrackDrawable(Drawable drawable) {
        Drawable drawable2 = this.f882i;
        if (drawable2 != null) {
            drawable2.setCallback(null);
        }
        this.f882i = drawable;
        if (drawable != null) {
            drawable.setCallback(this);
        }
        requestLayout();
    }

    public void setTrackResource(int i10) {
        setTrackDrawable(h.a.b(getContext(), i10));
    }

    public void setTrackTintList(ColorStateList colorStateList) {
        this.f883j = colorStateList;
        this.f885l = true;
        c();
    }

    public void setTrackTintMode(PorterDuff.Mode mode) {
        this.f884k = mode;
        this.f886m = true;
        c();
    }

    @Override // android.widget.CompoundButton, android.widget.Checkable
    public void toggle() {
        setChecked(!isChecked());
    }

    @Override // android.widget.CompoundButton, android.widget.TextView, android.view.View
    protected boolean verifyDrawable(Drawable drawable) {
        return super.verifyDrawable(drawable) || drawable == this.f877a || drawable == this.f882i;
    }

    public SwitchCompat(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R$attr.switchStyle);
    }

    public SwitchCompat(Context context, AttributeSet attributeSet, int i10) {
        super(context, attributeSet, i10);
        this.f878b = null;
        this.f879c = null;
        this.f880g = false;
        this.f881h = false;
        this.f883j = null;
        this.f884k = null;
        this.f885l = false;
        this.f886m = false;
        this.A = VelocityTracker.obtain();
        this.K = true;
        this.U = new Rect();
        c0.a(this, getContext());
        TextPaint textPaint = new TextPaint(1);
        this.L = textPaint;
        textPaint.density = getResources().getDisplayMetrics().density;
        int[] iArr = R$styleable.SwitchCompat;
        h0 h0VarW = h0.w(context, attributeSet, iArr, i10, 0);
        androidx.core.view.h0.j0(this, context, iArr, attributeSet, h0VarW.r(), i10, 0);
        Drawable drawableG = h0VarW.g(R$styleable.SwitchCompat_android_thumb);
        this.f877a = drawableG;
        if (drawableG != null) {
            drawableG.setCallback(this);
        }
        Drawable drawableG2 = h0VarW.g(R$styleable.SwitchCompat_track);
        this.f882i = drawableG2;
        if (drawableG2 != null) {
            drawableG2.setCallback(this);
        }
        setTextOnInternal(h0VarW.p(R$styleable.SwitchCompat_android_textOn));
        setTextOffInternal(h0VarW.p(R$styleable.SwitchCompat_android_textOff));
        this.f895v = h0VarW.a(R$styleable.SwitchCompat_showText, true);
        this.f887n = h0VarW.f(R$styleable.SwitchCompat_thumbTextPadding, 0);
        this.f888o = h0VarW.f(R$styleable.SwitchCompat_switchMinWidth, 0);
        this.f889p = h0VarW.f(R$styleable.SwitchCompat_switchPadding, 0);
        this.f890q = h0VarW.a(R$styleable.SwitchCompat_splitTrack, false);
        ColorStateList colorStateListC = h0VarW.c(R$styleable.SwitchCompat_thumbTint);
        if (colorStateListC != null) {
            this.f878b = colorStateListC;
            this.f880g = true;
        }
        PorterDuff.Mode modeD = t.d(h0VarW.k(R$styleable.SwitchCompat_thumbTintMode, -1), null);
        if (this.f879c != modeD) {
            this.f879c = modeD;
            this.f881h = true;
        }
        if (this.f880g || this.f881h) {
            b();
        }
        ColorStateList colorStateListC2 = h0VarW.c(R$styleable.SwitchCompat_trackTint);
        if (colorStateListC2 != null) {
            this.f883j = colorStateListC2;
            this.f885l = true;
        }
        PorterDuff.Mode modeD2 = t.d(h0VarW.k(R$styleable.SwitchCompat_trackTintMode, -1), null);
        if (this.f884k != modeD2) {
            this.f884k = modeD2;
            this.f886m = true;
        }
        if (this.f885l || this.f886m) {
            c();
        }
        int iN = h0VarW.n(R$styleable.SwitchCompat_switchTextAppearance, 0);
        if (iN != 0) {
            m(context, iN);
        }
        p pVar = new p(this);
        this.R = pVar;
        pVar.m(attributeSet, i10);
        h0VarW.x();
        ViewConfiguration viewConfiguration = ViewConfiguration.get(context);
        this.f897x = viewConfiguration.getScaledTouchSlop();
        this.B = viewConfiguration.getScaledMinimumFlingVelocity();
        getEmojiTextViewHelper().c(attributeSet, i10);
        refreshDrawableState();
        setChecked(isChecked());
    }
}
