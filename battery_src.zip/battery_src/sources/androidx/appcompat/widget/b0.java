package androidx.appcompat.widget;

import android.R;
import android.app.SearchableInfo;
import android.content.ComponentName;
import android.content.Context;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.TextUtils;
import android.text.style.TextAppearanceSpan;
import android.util.Log;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.R$attr;
import androidx.appcompat.R$id;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.WeakHashMap;

/* JADX INFO: compiled from: SuggestionsAdapter.java */
/* JADX INFO: loaded from: classes.dex */
class b0 extends e0.c implements View.OnClickListener {
    private int A;
    private int B;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    private final SearchView f934o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    private final SearchableInfo f935p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    private final Context f936q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    private final WeakHashMap<String, Drawable.ConstantState> f937r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    private final int f938s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    private boolean f939t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    private int f940u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    private ColorStateList f941v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    private int f942w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    private int f943x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    private int f944y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    private int f945z;

    /* JADX INFO: compiled from: SuggestionsAdapter.java */
    private static final class a {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public final TextView f946a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public final TextView f947b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        public final ImageView f948c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        public final ImageView f949d;

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        public final ImageView f950e;

        public a(View view) {
            this.f946a = (TextView) view.findViewById(R.id.text1);
            this.f947b = (TextView) view.findViewById(R.id.text2);
            this.f948c = (ImageView) view.findViewById(R.id.icon1);
            this.f949d = (ImageView) view.findViewById(R.id.icon2);
            this.f950e = (ImageView) view.findViewById(R$id.edit_query);
        }
    }

    public b0(Context context, SearchView searchView, SearchableInfo searchableInfo, WeakHashMap<String, Drawable.ConstantState> weakHashMap) {
        super(context, searchView.getSuggestionRowLayout(), null, true);
        this.f939t = false;
        this.f940u = 1;
        this.f942w = -1;
        this.f943x = -1;
        this.f944y = -1;
        this.f945z = -1;
        this.A = -1;
        this.B = -1;
        this.f934o = searchView;
        this.f935p = searchableInfo;
        this.f938s = searchView.getSuggestionCommitIconResId();
        this.f936q = context;
        this.f937r = weakHashMap;
    }

    private Drawable g(String str) {
        Drawable.ConstantState constantState = this.f937r.get(str);
        if (constantState == null) {
            return null;
        }
        return constantState.newDrawable();
    }

    private CharSequence h(CharSequence charSequence) {
        if (this.f941v == null) {
            TypedValue typedValue = new TypedValue();
            this.f936q.getTheme().resolveAttribute(R$attr.textColorSearchUrl, typedValue, true);
            this.f941v = this.f936q.getResources().getColorStateList(typedValue.resourceId);
        }
        SpannableString spannableString = new SpannableString(charSequence);
        spannableString.setSpan(new TextAppearanceSpan(null, 0, 0, this.f941v, null), 0, charSequence.length(), 33);
        return spannableString;
    }

    private Drawable i(ComponentName componentName) {
        PackageManager packageManager = this.f936q.getPackageManager();
        try {
            ActivityInfo activityInfo = packageManager.getActivityInfo(componentName, 128);
            int iconResource = activityInfo.getIconResource();
            if (iconResource == 0) {
                return null;
            }
            Drawable drawable = packageManager.getDrawable(componentName.getPackageName(), iconResource, activityInfo.applicationInfo);
            if (drawable != null) {
                return drawable;
            }
            Log.w("SuggestionsAdapter", "Invalid icon resource " + iconResource + " for " + componentName.flattenToShortString());
            return null;
        } catch (PackageManager.NameNotFoundException e10) {
            Log.w("SuggestionsAdapter", e10.toString());
            return null;
        }
    }

    private Drawable j(ComponentName componentName) {
        String strFlattenToShortString = componentName.flattenToShortString();
        if (!this.f937r.containsKey(strFlattenToShortString)) {
            Drawable drawableI = i(componentName);
            this.f937r.put(strFlattenToShortString, drawableI != null ? drawableI.getConstantState() : null);
            return drawableI;
        }
        Drawable.ConstantState constantState = this.f937r.get(strFlattenToShortString);
        if (constantState == null) {
            return null;
        }
        return constantState.newDrawable(this.f936q.getResources());
    }

    public static String k(Cursor cursor, String str) {
        return s(cursor, cursor.getColumnIndex(str));
    }

    private Drawable l() {
        Drawable drawableJ = j(this.f935p.getSearchActivity());
        return drawableJ != null ? drawableJ : this.f936q.getPackageManager().getDefaultActivityIcon();
    }

    private Drawable m(Uri uri) {
        try {
            if ("android.resource".equals(uri.getScheme())) {
                try {
                    return n(uri);
                } catch (Resources.NotFoundException unused) {
                    throw new FileNotFoundException("Resource does not exist: " + uri);
                }
            }
            InputStream inputStreamOpenInputStream = this.f936q.getContentResolver().openInputStream(uri);
            if (inputStreamOpenInputStream == null) {
                throw new FileNotFoundException("Failed to open " + uri);
            }
            try {
                Drawable drawableCreateFromStream = Drawable.createFromStream(inputStreamOpenInputStream, null);
                try {
                    inputStreamOpenInputStream.close();
                } catch (IOException e10) {
                    Log.e("SuggestionsAdapter", "Error closing icon stream for " + uri, e10);
                }
                return drawableCreateFromStream;
            } catch (Throwable th) {
                try {
                    inputStreamOpenInputStream.close();
                } catch (IOException e11) {
                    Log.e("SuggestionsAdapter", "Error closing icon stream for " + uri, e11);
                }
                throw th;
            }
        } catch (FileNotFoundException e12) {
            Log.w("SuggestionsAdapter", "Icon not found: " + uri + ", " + e12.getMessage());
            return null;
        }
        Log.w("SuggestionsAdapter", "Icon not found: " + uri + ", " + e12.getMessage());
        return null;
    }

    private Drawable o(String str) {
        if (str == null || str.isEmpty() || "0".equals(str)) {
            return null;
        }
        try {
            int i10 = Integer.parseInt(str);
            String str2 = "android.resource://" + this.f936q.getPackageName() + "/" + i10;
            Drawable drawableG = g(str2);
            if (drawableG != null) {
                return drawableG;
            }
            Drawable drawableE = androidx.core.content.a.e(this.f936q, i10);
            w(str2, drawableE);
            return drawableE;
        } catch (Resources.NotFoundException unused) {
            Log.w("SuggestionsAdapter", "Icon resource not found: " + str);
            return null;
        } catch (NumberFormatException unused2) {
            Drawable drawableG2 = g(str);
            if (drawableG2 != null) {
                return drawableG2;
            }
            Drawable drawableM = m(Uri.parse(str));
            w(str, drawableM);
            return drawableM;
        }
    }

    private Drawable p(Cursor cursor) {
        int i10 = this.f945z;
        if (i10 == -1) {
            return null;
        }
        Drawable drawableO = o(cursor.getString(i10));
        return drawableO != null ? drawableO : l();
    }

    private Drawable q(Cursor cursor) {
        int i10 = this.A;
        if (i10 == -1) {
            return null;
        }
        return o(cursor.getString(i10));
    }

    private static String s(Cursor cursor, int i10) {
        if (i10 == -1) {
            return null;
        }
        try {
            return cursor.getString(i10);
        } catch (Exception e10) {
            Log.e("SuggestionsAdapter", "unexpected error retrieving valid column from cursor, did the remote process die?", e10);
            return null;
        }
    }

    private void u(ImageView imageView, Drawable drawable, int i10) {
        imageView.setImageDrawable(drawable);
        if (drawable == null) {
            imageView.setVisibility(i10);
            return;
        }
        imageView.setVisibility(0);
        drawable.setVisible(false, false);
        drawable.setVisible(true, false);
    }

    private void v(TextView textView, CharSequence charSequence) {
        textView.setText(charSequence);
        if (TextUtils.isEmpty(charSequence)) {
            textView.setVisibility(8);
        } else {
            textView.setVisibility(0);
        }
    }

    private void w(String str, Drawable drawable) {
        if (drawable != null) {
            this.f937r.put(str, drawable.getConstantState());
        }
    }

    private void x(Cursor cursor) {
        Bundle extras = cursor != null ? cursor.getExtras() : null;
        if (extras != null) {
            extras.getBoolean("in_progress");
        }
    }

    @Override // e0.a
    public void a(View view, Context context, Cursor cursor) {
        a aVar = (a) view.getTag();
        int i10 = this.B;
        int i11 = i10 != -1 ? cursor.getInt(i10) : 0;
        if (aVar.f946a != null) {
            v(aVar.f946a, s(cursor, this.f942w));
        }
        if (aVar.f947b != null) {
            String strS = s(cursor, this.f944y);
            CharSequence charSequenceH = strS != null ? h(strS) : s(cursor, this.f943x);
            if (TextUtils.isEmpty(charSequenceH)) {
                TextView textView = aVar.f946a;
                if (textView != null) {
                    textView.setSingleLine(false);
                    aVar.f946a.setMaxLines(2);
                }
            } else {
                TextView textView2 = aVar.f946a;
                if (textView2 != null) {
                    textView2.setSingleLine(true);
                    aVar.f946a.setMaxLines(1);
                }
            }
            v(aVar.f947b, charSequenceH);
        }
        ImageView imageView = aVar.f948c;
        if (imageView != null) {
            u(imageView, p(cursor), 4);
        }
        ImageView imageView2 = aVar.f949d;
        if (imageView2 != null) {
            u(imageView2, q(cursor), 8);
        }
        int i12 = this.f940u;
        if (i12 != 2 && (i12 != 1 || (i11 & 1) == 0)) {
            aVar.f950e.setVisibility(8);
            return;
        }
        aVar.f950e.setVisibility(0);
        aVar.f950e.setTag(aVar.f946a.getText());
        aVar.f950e.setOnClickListener(this);
    }

    @Override // e0.a, e0.b.a
    public void changeCursor(Cursor cursor) {
        if (this.f939t) {
            Log.w("SuggestionsAdapter", "Tried to change cursor after adapter was closed.");
            if (cursor != null) {
                cursor.close();
                return;
            }
            return;
        }
        try {
            super.changeCursor(cursor);
            if (cursor != null) {
                this.f942w = cursor.getColumnIndex("suggest_text_1");
                this.f943x = cursor.getColumnIndex("suggest_text_2");
                this.f944y = cursor.getColumnIndex("suggest_text_2_url");
                this.f945z = cursor.getColumnIndex("suggest_icon_1");
                this.A = cursor.getColumnIndex("suggest_icon_2");
                this.B = cursor.getColumnIndex("suggest_flags");
            }
        } catch (Exception e10) {
            Log.e("SuggestionsAdapter", "error changing cursor and caching columns", e10);
        }
    }

    @Override // e0.a, e0.b.a
    public CharSequence convertToString(Cursor cursor) {
        String strK;
        String strK2;
        if (cursor == null) {
            return null;
        }
        String strK3 = k(cursor, "suggest_intent_query");
        if (strK3 != null) {
            return strK3;
        }
        if (this.f935p.shouldRewriteQueryFromData() && (strK2 = k(cursor, "suggest_intent_data")) != null) {
            return strK2;
        }
        if (!this.f935p.shouldRewriteQueryFromText() || (strK = k(cursor, "suggest_text_1")) == null) {
            return null;
        }
        return strK;
    }

    @Override // e0.c, e0.a
    public View d(Context context, Cursor cursor, ViewGroup viewGroup) {
        View viewD = super.d(context, cursor, viewGroup);
        viewD.setTag(new a(viewD));
        ((ImageView) viewD.findViewById(R$id.edit_query)).setImageResource(this.f938s);
        return viewD;
    }

    @Override // e0.a, android.widget.BaseAdapter, android.widget.SpinnerAdapter
    public View getDropDownView(int i10, View view, ViewGroup viewGroup) {
        try {
            return super.getDropDownView(i10, view, viewGroup);
        } catch (RuntimeException e10) {
            Log.w("SuggestionsAdapter", "Search suggestions cursor threw exception.", e10);
            View viewC = c(this.f936q, getCursor(), viewGroup);
            if (viewC != null) {
                ((a) viewC.getTag()).f946a.setText(e10.toString());
            }
            return viewC;
        }
    }

    @Override // e0.a, android.widget.Adapter
    public View getView(int i10, View view, ViewGroup viewGroup) {
        try {
            return super.getView(i10, view, viewGroup);
        } catch (RuntimeException e10) {
            Log.w("SuggestionsAdapter", "Search suggestions cursor threw exception.", e10);
            View viewD = d(this.f936q, getCursor(), viewGroup);
            if (viewD != null) {
                ((a) viewD.getTag()).f946a.setText(e10.toString());
            }
            return viewD;
        }
    }

    @Override // android.widget.BaseAdapter, android.widget.Adapter
    public boolean hasStableIds() {
        return false;
    }

    Drawable n(Uri uri) throws FileNotFoundException {
        int identifier;
        String authority = uri.getAuthority();
        if (TextUtils.isEmpty(authority)) {
            throw new FileNotFoundException("No authority: " + uri);
        }
        try {
            Resources resourcesForApplication = this.f936q.getPackageManager().getResourcesForApplication(authority);
            List<String> pathSegments = uri.getPathSegments();
            if (pathSegments == null) {
                throw new FileNotFoundException("No path: " + uri);
            }
            int size = pathSegments.size();
            if (size == 1) {
                try {
                    identifier = Integer.parseInt(pathSegments.get(0));
                } catch (NumberFormatException unused) {
                    throw new FileNotFoundException("Single path segment is not a resource ID: " + uri);
                }
            } else {
                if (size != 2) {
                    throw new FileNotFoundException("More than two path segments: " + uri);
                }
                identifier = resourcesForApplication.getIdentifier(pathSegments.get(1), pathSegments.get(0), authority);
            }
            if (identifier != 0) {
                return resourcesForApplication.getDrawable(identifier);
            }
            throw new FileNotFoundException("No resource found for: " + uri);
        } catch (PackageManager.NameNotFoundException unused2) {
            throw new FileNotFoundException("No package found for authority: " + uri);
        }
    }

    @Override // android.widget.BaseAdapter
    public void notifyDataSetChanged() {
        super.notifyDataSetChanged();
        x(getCursor());
    }

    @Override // android.widget.BaseAdapter
    public void notifyDataSetInvalidated() {
        super.notifyDataSetInvalidated();
        x(getCursor());
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        Object tag = view.getTag();
        if (tag instanceof CharSequence) {
            this.f934o.onQueryRefine((CharSequence) tag);
        }
    }

    Cursor r(SearchableInfo searchableInfo, String str, int i10) {
        String suggestAuthority;
        String[] strArr = null;
        if (searchableInfo == null || (suggestAuthority = searchableInfo.getSuggestAuthority()) == null) {
            return null;
        }
        Uri.Builder builderFragment = new Uri.Builder().scheme("content").authority(suggestAuthority).query("").fragment("");
        String suggestPath = searchableInfo.getSuggestPath();
        if (suggestPath != null) {
            builderFragment.appendEncodedPath(suggestPath);
        }
        builderFragment.appendPath("search_suggest_query");
        String suggestSelection = searchableInfo.getSuggestSelection();
        if (suggestSelection != null) {
            strArr = new String[]{str};
        } else {
            builderFragment.appendPath(str);
        }
        String[] strArr2 = strArr;
        if (i10 > 0) {
            builderFragment.appendQueryParameter("limit", String.valueOf(i10));
        }
        return this.f936q.getContentResolver().query(builderFragment.build(), null, suggestSelection, strArr2, null);
    }

    @Override // e0.b.a
    public Cursor runQueryOnBackgroundThread(CharSequence charSequence) {
        String string = charSequence == null ? "" : charSequence.toString();
        if (this.f934o.getVisibility() == 0 && this.f934o.getWindowVisibility() == 0) {
            try {
                Cursor cursorR = r(this.f935p, string, 50);
                if (cursorR != null) {
                    cursorR.getCount();
                    return cursorR;
                }
            } catch (RuntimeException e10) {
                Log.w("SuggestionsAdapter", "Search suggestions query threw an exception.", e10);
            }
        }
        return null;
    }

    public void t(int i10) {
        this.f940u = i10;
    }
}
