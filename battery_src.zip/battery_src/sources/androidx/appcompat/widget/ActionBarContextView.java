package androidx.appcompat.widget;

import android.content.Context;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.R$attr;
import androidx.appcompat.R$id;
import androidx.appcompat.R$layout;
import androidx.appcompat.R$styleable;
import androidx.appcompat.view.menu.MenuBuilder;

/* JADX INFO: loaded from: classes.dex */
public class ActionBarContextView extends androidx.appcompat.widget.a {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private CharSequence f610l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    private CharSequence f611m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    private View f612n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    private View f613o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    private View f614p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    private LinearLayout f615q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    private TextView f616r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    private TextView f617s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    private int f618t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    private int f619u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    private boolean f620v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    private int f621w;

    class a implements View.OnClickListener {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        final /* synthetic */ androidx.appcompat.view.b f622a;

        a(androidx.appcompat.view.b bVar) {
            this.f622a = bVar;
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            this.f622a.a();
        }
    }

    public ActionBarContextView(Context context) {
        this(context, null);
    }

    private void i() {
        if (this.f615q == null) {
            LayoutInflater.from(getContext()).inflate(R$layout.abc_action_bar_title_item, this);
            LinearLayout linearLayout = (LinearLayout) getChildAt(getChildCount() - 1);
            this.f615q = linearLayout;
            this.f616r = (TextView) linearLayout.findViewById(R$id.action_bar_title);
            this.f617s = (TextView) this.f615q.findViewById(R$id.action_bar_subtitle);
            if (this.f618t != 0) {
                this.f616r.setTextAppearance(getContext(), this.f618t);
            }
            if (this.f619u != 0) {
                this.f617s.setTextAppearance(getContext(), this.f619u);
            }
        }
        this.f616r.setText(this.f610l);
        this.f617s.setText(this.f611m);
        boolean zIsEmpty = TextUtils.isEmpty(this.f610l);
        boolean zIsEmpty2 = TextUtils.isEmpty(this.f611m);
        this.f617s.setVisibility(!zIsEmpty2 ? 0 : 8);
        this.f615q.setVisibility((zIsEmpty && zIsEmpty2) ? 8 : 0);
        if (this.f615q.getParent() == null) {
            addView(this.f615q);
        }
    }

    @Override // androidx.appcompat.widget.a
    public /* bridge */ /* synthetic */ androidx.core.view.n0 f(int i10, long j10) {
        return super.f(i10, j10);
    }

    public void g() {
        if (this.f612n == null) {
            k();
        }
    }

    @Override // android.view.ViewGroup
    protected ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new ViewGroup.MarginLayoutParams(-1, -2);
    }

    @Override // android.view.ViewGroup
    public ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new ViewGroup.MarginLayoutParams(getContext(), attributeSet);
    }

    @Override // androidx.appcompat.widget.a
    public /* bridge */ /* synthetic */ int getAnimatedVisibility() {
        return super.getAnimatedVisibility();
    }

    @Override // androidx.appcompat.widget.a
    public /* bridge */ /* synthetic */ int getContentHeight() {
        return super.getContentHeight();
    }

    public CharSequence getSubtitle() {
        return this.f611m;
    }

    public CharSequence getTitle() {
        return this.f610l;
    }

    public void h(androidx.appcompat.view.b bVar) {
        View view = this.f612n;
        if (view == null) {
            View viewInflate = LayoutInflater.from(getContext()).inflate(this.f621w, (ViewGroup) this, false);
            this.f612n = viewInflate;
            addView(viewInflate);
        } else if (view.getParent() == null) {
            addView(this.f612n);
        }
        View viewFindViewById = this.f612n.findViewById(R$id.action_mode_close_button);
        this.f613o = viewFindViewById;
        viewFindViewById.setOnClickListener(new a(bVar));
        MenuBuilder menuBuilder = (MenuBuilder) bVar.c();
        ActionMenuPresenter actionMenuPresenter = this.f917g;
        if (actionMenuPresenter != null) {
            actionMenuPresenter.i();
        }
        ActionMenuPresenter actionMenuPresenter2 = new ActionMenuPresenter(getContext());
        this.f917g = actionMenuPresenter2;
        actionMenuPresenter2.t(true);
        ViewGroup.LayoutParams layoutParams = new ViewGroup.LayoutParams(-2, -1);
        menuBuilder.addMenuPresenter(this.f917g, this.f915b);
        ActionMenuView actionMenuView = (ActionMenuView) this.f917g.getMenuView(this);
        this.f916c = actionMenuView;
        androidx.core.view.h0.p0(actionMenuView, null);
        addView(this.f916c, layoutParams);
    }

    public boolean j() {
        return this.f620v;
    }

    public void k() {
        removeAllViews();
        this.f614p = null;
        this.f916c = null;
        this.f917g = null;
        View view = this.f613o;
        if (view != null) {
            view.setOnClickListener(null);
        }
    }

    public boolean l() {
        ActionMenuPresenter actionMenuPresenter = this.f917g;
        if (actionMenuPresenter != null) {
            return actionMenuPresenter.u();
        }
        return false;
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        ActionMenuPresenter actionMenuPresenter = this.f917g;
        if (actionMenuPresenter != null) {
            actionMenuPresenter.l();
            this.f917g.m();
        }
    }

    @Override // androidx.appcompat.widget.a, android.view.View
    public /* bridge */ /* synthetic */ boolean onHoverEvent(MotionEvent motionEvent) {
        return super.onHoverEvent(motionEvent);
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onLayout(boolean z10, int i10, int i11, int i12, int i13) {
        boolean zB = o0.b(this);
        int paddingRight = zB ? (i12 - i10) - getPaddingRight() : getPaddingLeft();
        int paddingTop = getPaddingTop();
        int paddingTop2 = ((i13 - i11) - getPaddingTop()) - getPaddingBottom();
        View view = this.f612n;
        if (view != null && view.getVisibility() != 8) {
            ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) this.f612n.getLayoutParams();
            int i14 = zB ? marginLayoutParams.rightMargin : marginLayoutParams.leftMargin;
            int i15 = zB ? marginLayoutParams.leftMargin : marginLayoutParams.rightMargin;
            int iD = androidx.appcompat.widget.a.d(paddingRight, i14, zB);
            paddingRight = androidx.appcompat.widget.a.d(iD + e(this.f612n, iD, paddingTop, paddingTop2, zB), i15, zB);
        }
        int iE = paddingRight;
        LinearLayout linearLayout = this.f615q;
        if (linearLayout != null && this.f614p == null && linearLayout.getVisibility() != 8) {
            iE += e(this.f615q, iE, paddingTop, paddingTop2, zB);
        }
        int i16 = iE;
        View view2 = this.f614p;
        if (view2 != null) {
            e(view2, i16, paddingTop, paddingTop2, zB);
        }
        int paddingLeft = zB ? getPaddingLeft() : (i12 - i10) - getPaddingRight();
        ActionMenuView actionMenuView = this.f916c;
        if (actionMenuView != null) {
            e(actionMenuView, paddingLeft, paddingTop, paddingTop2, !zB);
        }
    }

    @Override // android.view.View
    protected void onMeasure(int i10, int i11) {
        if (View.MeasureSpec.getMode(i10) != 1073741824) {
            throw new IllegalStateException(getClass().getSimpleName() + " can only be used with android:layout_width=\"match_parent\" (or fill_parent)");
        }
        if (View.MeasureSpec.getMode(i11) == 0) {
            throw new IllegalStateException(getClass().getSimpleName() + " can only be used with android:layout_height=\"wrap_content\"");
        }
        int size = View.MeasureSpec.getSize(i10);
        int size2 = this.f918h;
        if (size2 <= 0) {
            size2 = View.MeasureSpec.getSize(i11);
        }
        int paddingTop = getPaddingTop() + getPaddingBottom();
        int paddingLeft = (size - getPaddingLeft()) - getPaddingRight();
        int iMin = size2 - paddingTop;
        int iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(iMin, Integer.MIN_VALUE);
        View view = this.f612n;
        if (view != null) {
            int iC = c(view, paddingLeft, iMakeMeasureSpec, 0);
            ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) this.f612n.getLayoutParams();
            paddingLeft = iC - (marginLayoutParams.leftMargin + marginLayoutParams.rightMargin);
        }
        ActionMenuView actionMenuView = this.f916c;
        if (actionMenuView != null && actionMenuView.getParent() == this) {
            paddingLeft = c(this.f916c, paddingLeft, iMakeMeasureSpec, 0);
        }
        LinearLayout linearLayout = this.f615q;
        if (linearLayout != null && this.f614p == null) {
            if (this.f620v) {
                this.f615q.measure(View.MeasureSpec.makeMeasureSpec(0, 0), iMakeMeasureSpec);
                int measuredWidth = this.f615q.getMeasuredWidth();
                boolean z10 = measuredWidth <= paddingLeft;
                if (z10) {
                    paddingLeft -= measuredWidth;
                }
                this.f615q.setVisibility(z10 ? 0 : 8);
            } else {
                paddingLeft = c(linearLayout, paddingLeft, iMakeMeasureSpec, 0);
            }
        }
        View view2 = this.f614p;
        if (view2 != null) {
            ViewGroup.LayoutParams layoutParams = view2.getLayoutParams();
            int i12 = layoutParams.width;
            int i13 = i12 != -2 ? 1073741824 : Integer.MIN_VALUE;
            if (i12 >= 0) {
                paddingLeft = Math.min(i12, paddingLeft);
            }
            int i14 = layoutParams.height;
            int i15 = i14 == -2 ? Integer.MIN_VALUE : 1073741824;
            if (i14 >= 0) {
                iMin = Math.min(i14, iMin);
            }
            this.f614p.measure(View.MeasureSpec.makeMeasureSpec(paddingLeft, i13), View.MeasureSpec.makeMeasureSpec(iMin, i15));
        }
        if (this.f918h > 0) {
            setMeasuredDimension(size, size2);
            return;
        }
        int childCount = getChildCount();
        int i16 = 0;
        for (int i17 = 0; i17 < childCount; i17++) {
            int measuredHeight = getChildAt(i17).getMeasuredHeight() + paddingTop;
            if (measuredHeight > i16) {
                i16 = measuredHeight;
            }
        }
        setMeasuredDimension(size, i16);
    }

    @Override // androidx.appcompat.widget.a, android.view.View
    public /* bridge */ /* synthetic */ boolean onTouchEvent(MotionEvent motionEvent) {
        return super.onTouchEvent(motionEvent);
    }

    @Override // androidx.appcompat.widget.a
    public void setContentHeight(int i10) {
        this.f918h = i10;
    }

    public void setCustomView(View view) {
        LinearLayout linearLayout;
        View view2 = this.f614p;
        if (view2 != null) {
            removeView(view2);
        }
        this.f614p = view;
        if (view != null && (linearLayout = this.f615q) != null) {
            removeView(linearLayout);
            this.f615q = null;
        }
        if (view != null) {
            addView(view);
        }
        requestLayout();
    }

    public void setSubtitle(CharSequence charSequence) {
        this.f611m = charSequence;
        i();
    }

    public void setTitle(CharSequence charSequence) {
        this.f610l = charSequence;
        i();
        androidx.core.view.h0.o0(this, charSequence);
    }

    public void setTitleOptional(boolean z10) {
        if (z10 != this.f620v) {
            requestLayout();
        }
        this.f620v = z10;
    }

    @Override // androidx.appcompat.widget.a, android.view.View
    public /* bridge */ /* synthetic */ void setVisibility(int i10) {
        super.setVisibility(i10);
    }

    @Override // android.view.ViewGroup
    public boolean shouldDelayChildPressedState() {
        return false;
    }

    public ActionBarContextView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R$attr.actionModeStyle);
    }

    public ActionBarContextView(Context context, AttributeSet attributeSet, int i10) {
        super(context, attributeSet, i10);
        h0 h0VarW = h0.w(context, attributeSet, R$styleable.ActionMode, i10, 0);
        androidx.core.view.h0.p0(this, h0VarW.g(R$styleable.ActionMode_background));
        this.f618t = h0VarW.n(R$styleable.ActionMode_titleTextStyle, 0);
        this.f619u = h0VarW.n(R$styleable.ActionMode_subtitleTextStyle, 0);
        this.f918h = h0VarW.m(R$styleable.ActionMode_height, 0);
        this.f621w = h0VarW.n(R$styleable.ActionMode_closeItemLayout, R$layout.abc_action_mode_close_item_material);
        h0VarW.x();
    }
}
