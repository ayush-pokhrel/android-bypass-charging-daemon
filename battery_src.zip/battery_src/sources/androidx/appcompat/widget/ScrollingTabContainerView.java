package androidx.appcompat.widget;

import android.R;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.ViewPropertyAnimator;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TextView;
import androidx.appcompat.R$attr;
import androidx.appcompat.app.ActionBar;

/* JADX INFO: loaded from: classes.dex */
public class ScrollingTabContainerView extends HorizontalScrollView implements AdapterView.OnItemSelectedListener {

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    private static final Interpolator f830o = new DecelerateInterpolator();

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    Runnable f831a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private c f832b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    LinearLayoutCompat f833c;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private Spinner f834g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private boolean f835h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    int f836i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    int f837j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    private int f838k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private int f839l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    protected ViewPropertyAnimator f840m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    protected final e f841n;

    class a implements Runnable {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        final /* synthetic */ View f842a;

        a(View view) {
            this.f842a = view;
        }

        @Override // java.lang.Runnable
        public void run() {
            ScrollingTabContainerView.this.smoothScrollTo(this.f842a.getLeft() - ((ScrollingTabContainerView.this.getWidth() - this.f842a.getWidth()) / 2), 0);
            ScrollingTabContainerView.this.f831a = null;
        }
    }

    private class b extends BaseAdapter {
        b() {
        }

        @Override // android.widget.Adapter
        public int getCount() {
            return ScrollingTabContainerView.this.f833c.getChildCount();
        }

        @Override // android.widget.Adapter
        public Object getItem(int i10) {
            return ((d) ScrollingTabContainerView.this.f833c.getChildAt(i10)).b();
        }

        @Override // android.widget.Adapter
        public long getItemId(int i10) {
            return i10;
        }

        @Override // android.widget.Adapter
        public View getView(int i10, View view, ViewGroup viewGroup) {
            if (view == null) {
                return ScrollingTabContainerView.this.d((ActionBar.b) getItem(i10), true);
            }
            ((d) view).a((ActionBar.b) getItem(i10));
            return view;
        }
    }

    private class c implements View.OnClickListener {
        c() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            ((d) view).b().e();
            int childCount = ScrollingTabContainerView.this.f833c.getChildCount();
            for (int i10 = 0; i10 < childCount; i10++) {
                View childAt = ScrollingTabContainerView.this.f833c.getChildAt(i10);
                childAt.setSelected(childAt == view);
            }
        }
    }

    private class d extends LinearLayout {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private final int[] f846a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private ActionBar.b f847b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        private TextView f848c;

        /* JADX INFO: renamed from: g, reason: collision with root package name */
        private ImageView f849g;

        /* JADX INFO: renamed from: h, reason: collision with root package name */
        private View f850h;

        /* JADX WARN: Illegal instructions before constructor call */
        public d(Context context, ActionBar.b bVar, boolean z10) {
            int i10 = R$attr.actionBarTabStyle;
            super(context, null, i10);
            int[] iArr = {R.attr.background};
            this.f846a = iArr;
            this.f847b = bVar;
            h0 h0VarW = h0.w(context, null, iArr, i10, 0);
            if (h0VarW.s(0)) {
                setBackgroundDrawable(h0VarW.g(0));
            }
            h0VarW.x();
            if (z10) {
                setGravity(8388627);
            }
            c();
        }

        public void a(ActionBar.b bVar) {
            this.f847b = bVar;
            c();
        }

        public ActionBar.b b() {
            return this.f847b;
        }

        public void c() {
            ActionBar.b bVar = this.f847b;
            View viewB = bVar.b();
            if (viewB != null) {
                ViewParent parent = viewB.getParent();
                if (parent != this) {
                    if (parent != null) {
                        ((ViewGroup) parent).removeView(viewB);
                    }
                    addView(viewB);
                }
                this.f850h = viewB;
                TextView textView = this.f848c;
                if (textView != null) {
                    textView.setVisibility(8);
                }
                ImageView imageView = this.f849g;
                if (imageView != null) {
                    imageView.setVisibility(8);
                    this.f849g.setImageDrawable(null);
                    return;
                }
                return;
            }
            View view = this.f850h;
            if (view != null) {
                removeView(view);
                this.f850h = null;
            }
            Drawable drawableC = bVar.c();
            CharSequence charSequenceD = bVar.d();
            if (drawableC != null) {
                if (this.f849g == null) {
                    AppCompatImageView appCompatImageView = new AppCompatImageView(getContext());
                    LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -2);
                    layoutParams.gravity = 16;
                    appCompatImageView.setLayoutParams(layoutParams);
                    addView(appCompatImageView, 0);
                    this.f849g = appCompatImageView;
                }
                this.f849g.setImageDrawable(drawableC);
                this.f849g.setVisibility(0);
            } else {
                ImageView imageView2 = this.f849g;
                if (imageView2 != null) {
                    imageView2.setVisibility(8);
                    this.f849g.setImageDrawable(null);
                }
            }
            boolean zIsEmpty = TextUtils.isEmpty(charSequenceD);
            if (zIsEmpty) {
                TextView textView2 = this.f848c;
                if (textView2 != null) {
                    textView2.setVisibility(8);
                    this.f848c.setText((CharSequence) null);
                }
            } else {
                if (this.f848c == null) {
                    AppCompatTextView appCompatTextView = new AppCompatTextView(getContext(), null, R$attr.actionBarTabTextStyle);
                    appCompatTextView.setEllipsize(TextUtils.TruncateAt.END);
                    LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-2, -2);
                    layoutParams2.gravity = 16;
                    appCompatTextView.setLayoutParams(layoutParams2);
                    addView(appCompatTextView);
                    this.f848c = appCompatTextView;
                }
                this.f848c.setText(charSequenceD);
                this.f848c.setVisibility(0);
            }
            ImageView imageView3 = this.f849g;
            if (imageView3 != null) {
                imageView3.setContentDescription(bVar.a());
            }
            m0.a(this, zIsEmpty ? bVar.a() : null);
        }

        @Override // android.view.View
        public void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
            super.onInitializeAccessibilityEvent(accessibilityEvent);
            accessibilityEvent.setClassName("androidx.appcompat.app.ActionBar$Tab");
        }

        @Override // android.view.View
        public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
            super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
            accessibilityNodeInfo.setClassName("androidx.appcompat.app.ActionBar$Tab");
        }

        @Override // android.widget.LinearLayout, android.view.View
        public void onMeasure(int i10, int i11) {
            super.onMeasure(i10, i11);
            if (ScrollingTabContainerView.this.f836i > 0) {
                int measuredWidth = getMeasuredWidth();
                int i12 = ScrollingTabContainerView.this.f836i;
                if (measuredWidth > i12) {
                    super.onMeasure(View.MeasureSpec.makeMeasureSpec(i12, 1073741824), i11);
                }
            }
        }

        @Override // android.view.View
        public void setSelected(boolean z10) {
            boolean z11 = isSelected() != z10;
            super.setSelected(z10);
            if (z11 && z10) {
                sendAccessibilityEvent(4);
            }
        }
    }

    protected class e extends AnimatorListenerAdapter {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private boolean f852a = false;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private int f853b;

        protected e() {
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationCancel(Animator animator) {
            this.f852a = true;
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
            if (this.f852a) {
                return;
            }
            ScrollingTabContainerView scrollingTabContainerView = ScrollingTabContainerView.this;
            scrollingTabContainerView.f840m = null;
            scrollingTabContainerView.setVisibility(this.f853b);
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationStart(Animator animator) {
            ScrollingTabContainerView.this.setVisibility(0);
            this.f852a = false;
        }
    }

    public ScrollingTabContainerView(Context context) {
        super(context);
        this.f841n = new e();
        setHorizontalScrollBarEnabled(false);
        androidx.appcompat.view.a aVarB = androidx.appcompat.view.a.b(context);
        setContentHeight(aVarB.f());
        this.f837j = aVarB.e();
        LinearLayoutCompat linearLayoutCompatC = c();
        this.f833c = linearLayoutCompatC;
        addView(linearLayoutCompatC, new ViewGroup.LayoutParams(-2, -1));
    }

    private Spinner b() {
        AppCompatSpinner appCompatSpinner = new AppCompatSpinner(getContext(), null, R$attr.actionDropDownStyle);
        appCompatSpinner.setLayoutParams(new LinearLayoutCompat.LayoutParams(-2, -1));
        appCompatSpinner.setOnItemSelectedListener(this);
        return appCompatSpinner;
    }

    private LinearLayoutCompat c() {
        LinearLayoutCompat linearLayoutCompat = new LinearLayoutCompat(getContext(), null, R$attr.actionBarTabBarStyle);
        linearLayoutCompat.setMeasureWithLargestChildEnabled(true);
        linearLayoutCompat.setGravity(17);
        linearLayoutCompat.setLayoutParams(new LinearLayoutCompat.LayoutParams(-2, -1));
        return linearLayoutCompat;
    }

    private boolean e() {
        Spinner spinner = this.f834g;
        return spinner != null && spinner.getParent() == this;
    }

    private void f() {
        if (e()) {
            return;
        }
        if (this.f834g == null) {
            this.f834g = b();
        }
        removeView(this.f833c);
        addView(this.f834g, new ViewGroup.LayoutParams(-2, -1));
        if (this.f834g.getAdapter() == null) {
            this.f834g.setAdapter((SpinnerAdapter) new b());
        }
        Runnable runnable = this.f831a;
        if (runnable != null) {
            removeCallbacks(runnable);
            this.f831a = null;
        }
        this.f834g.setSelection(this.f839l);
    }

    private boolean g() {
        if (!e()) {
            return false;
        }
        removeView(this.f834g);
        addView(this.f833c, new ViewGroup.LayoutParams(-2, -1));
        setTabSelected(this.f834g.getSelectedItemPosition());
        return false;
    }

    public void a(int i10) {
        View childAt = this.f833c.getChildAt(i10);
        Runnable runnable = this.f831a;
        if (runnable != null) {
            removeCallbacks(runnable);
        }
        a aVar = new a(childAt);
        this.f831a = aVar;
        post(aVar);
    }

    d d(ActionBar.b bVar, boolean z10) {
        d dVar = new d(getContext(), bVar, z10);
        if (z10) {
            dVar.setBackgroundDrawable(null);
            dVar.setLayoutParams(new AbsListView.LayoutParams(-1, this.f838k));
        } else {
            dVar.setFocusable(true);
            if (this.f832b == null) {
                this.f832b = new c();
            }
            dVar.setOnClickListener(this.f832b);
        }
        return dVar;
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        Runnable runnable = this.f831a;
        if (runnable != null) {
            post(runnable);
        }
    }

    @Override // android.view.View
    protected void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        androidx.appcompat.view.a aVarB = androidx.appcompat.view.a.b(getContext());
        setContentHeight(aVarB.f());
        this.f837j = aVarB.e();
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        Runnable runnable = this.f831a;
        if (runnable != null) {
            removeCallbacks(runnable);
        }
    }

    @Override // android.widget.AdapterView.OnItemSelectedListener
    public void onItemSelected(AdapterView<?> adapterView, View view, int i10, long j10) {
        ((d) view).b().e();
    }

    @Override // android.widget.HorizontalScrollView, android.widget.FrameLayout, android.view.View
    public void onMeasure(int i10, int i11) {
        int mode = View.MeasureSpec.getMode(i10);
        boolean z10 = mode == 1073741824;
        setFillViewport(z10);
        int childCount = this.f833c.getChildCount();
        if (childCount <= 1 || !(mode == 1073741824 || mode == Integer.MIN_VALUE)) {
            this.f836i = -1;
        } else {
            if (childCount > 2) {
                this.f836i = (int) (View.MeasureSpec.getSize(i10) * 0.4f);
            } else {
                this.f836i = View.MeasureSpec.getSize(i10) / 2;
            }
            this.f836i = Math.min(this.f836i, this.f837j);
        }
        int iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(this.f838k, 1073741824);
        if (z10 || !this.f835h) {
            g();
        } else {
            this.f833c.measure(0, iMakeMeasureSpec);
            if (this.f833c.getMeasuredWidth() > View.MeasureSpec.getSize(i10)) {
                f();
            } else {
                g();
            }
        }
        int measuredWidth = getMeasuredWidth();
        super.onMeasure(i10, iMakeMeasureSpec);
        int measuredWidth2 = getMeasuredWidth();
        if (!z10 || measuredWidth == measuredWidth2) {
            return;
        }
        setTabSelected(this.f839l);
    }

    public void setAllowCollapse(boolean z10) {
        this.f835h = z10;
    }

    public void setContentHeight(int i10) {
        this.f838k = i10;
        requestLayout();
    }

    public void setTabSelected(int i10) {
        this.f839l = i10;
        int childCount = this.f833c.getChildCount();
        int i11 = 0;
        while (i11 < childCount) {
            View childAt = this.f833c.getChildAt(i11);
            boolean z10 = i11 == i10;
            childAt.setSelected(z10);
            if (z10) {
                a(i10);
            }
            i11++;
        }
        Spinner spinner = this.f834g;
        if (spinner == null || i10 < 0) {
            return;
        }
        spinner.setSelection(i10);
    }

    @Override // android.widget.AdapterView.OnItemSelectedListener
    public void onNothingSelected(AdapterView<?> adapterView) {
    }
}
