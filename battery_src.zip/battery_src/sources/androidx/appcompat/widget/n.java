package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.widget.SeekBar;
import androidx.appcompat.R$styleable;

/* JADX INFO: compiled from: AppCompatSeekBarHelper.java */
/* JADX INFO: loaded from: classes.dex */
class n extends l {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private final SeekBar f1037d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private Drawable f1038e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private ColorStateList f1039f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private PorterDuff.Mode f1040g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private boolean f1041h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private boolean f1042i;

    n(SeekBar seekBar) {
        super(seekBar);
        this.f1039f = null;
        this.f1040g = null;
        this.f1041h = false;
        this.f1042i = false;
        this.f1037d = seekBar;
    }

    private void f() {
        Drawable drawable = this.f1038e;
        if (drawable != null) {
            if (this.f1041h || this.f1042i) {
                Drawable drawableR = androidx.core.graphics.drawable.a.r(drawable.mutate());
                this.f1038e = drawableR;
                if (this.f1041h) {
                    androidx.core.graphics.drawable.a.o(drawableR, this.f1039f);
                }
                if (this.f1042i) {
                    androidx.core.graphics.drawable.a.p(this.f1038e, this.f1040g);
                }
                if (this.f1038e.isStateful()) {
                    this.f1038e.setState(this.f1037d.getDrawableState());
                }
            }
        }
    }

    @Override // androidx.appcompat.widget.l
    void c(AttributeSet attributeSet, int i10) {
        super.c(attributeSet, i10);
        Context context = this.f1037d.getContext();
        int[] iArr = R$styleable.AppCompatSeekBar;
        h0 h0VarW = h0.w(context, attributeSet, iArr, i10, 0);
        SeekBar seekBar = this.f1037d;
        androidx.core.view.h0.j0(seekBar, seekBar.getContext(), iArr, attributeSet, h0VarW.r(), i10, 0);
        Drawable drawableH = h0VarW.h(R$styleable.AppCompatSeekBar_android_thumb);
        if (drawableH != null) {
            this.f1037d.setThumb(drawableH);
        }
        j(h0VarW.g(R$styleable.AppCompatSeekBar_tickMark));
        int i11 = R$styleable.AppCompatSeekBar_tickMarkTintMode;
        if (h0VarW.s(i11)) {
            this.f1040g = t.d(h0VarW.k(i11, -1), this.f1040g);
            this.f1042i = true;
        }
        int i12 = R$styleable.AppCompatSeekBar_tickMarkTint;
        if (h0VarW.s(i12)) {
            this.f1039f = h0VarW.c(i12);
            this.f1041h = true;
        }
        h0VarW.x();
        f();
    }

    void g(Canvas canvas) {
        if (this.f1038e != null) {
            int max = this.f1037d.getMax();
            if (max > 1) {
                int intrinsicWidth = this.f1038e.getIntrinsicWidth();
                int intrinsicHeight = this.f1038e.getIntrinsicHeight();
                int i10 = intrinsicWidth >= 0 ? intrinsicWidth / 2 : 1;
                int i11 = intrinsicHeight >= 0 ? intrinsicHeight / 2 : 1;
                this.f1038e.setBounds(-i10, -i11, i10, i11);
                float width = ((this.f1037d.getWidth() - this.f1037d.getPaddingLeft()) - this.f1037d.getPaddingRight()) / max;
                int iSave = canvas.save();
                canvas.translate(this.f1037d.getPaddingLeft(), this.f1037d.getHeight() / 2);
                for (int i12 = 0; i12 <= max; i12++) {
                    this.f1038e.draw(canvas);
                    canvas.translate(width, 0.0f);
                }
                canvas.restoreToCount(iSave);
            }
        }
    }

    void h() {
        Drawable drawable = this.f1038e;
        if (drawable != null && drawable.isStateful() && drawable.setState(this.f1037d.getDrawableState())) {
            this.f1037d.invalidateDrawable(drawable);
        }
    }

    void i() {
        Drawable drawable = this.f1038e;
        if (drawable != null) {
            drawable.jumpToCurrentState();
        }
    }

    void j(Drawable drawable) {
        Drawable drawable2 = this.f1038e;
        if (drawable2 != null) {
            drawable2.setCallback(null);
        }
        this.f1038e = drawable;
        if (drawable != null) {
            drawable.setCallback(this.f1037d);
            androidx.core.graphics.drawable.a.m(drawable, androidx.core.view.h0.w(this.f1037d));
            if (drawable.isStateful()) {
                drawable.setState(this.f1037d.getDrawableState());
            }
            f();
        }
        this.f1037d.invalidate();
    }
}
