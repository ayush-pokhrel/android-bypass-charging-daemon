package androidx.appcompat.widget;

import android.view.DragEvent;
import android.view.View;
import android.widget.TextView;

/* JADX INFO: compiled from: AppCompatReceiveContentHelper.java */
/* JADX INFO: loaded from: classes.dex */
final class m {
    static boolean a(View view, DragEvent dragEvent) {
        return false;
    }

    static boolean b(TextView textView, int i10) {
        return false;
    }
}
