package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.widget.CompoundButton;
import androidx.appcompat.R$styleable;

/* JADX INFO: compiled from: AppCompatCompoundButtonHelper.java */
/* JADX INFO: loaded from: classes.dex */
class f {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final CompoundButton f977a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private ColorStateList f978b = null;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private PorterDuff.Mode f979c = null;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private boolean f980d = false;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private boolean f981e = false;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private boolean f982f;

    f(CompoundButton compoundButton) {
        this.f977a = compoundButton;
    }

    void a() {
        Drawable drawableA = androidx.core.widget.c.a(this.f977a);
        if (drawableA != null) {
            if (this.f980d || this.f981e) {
                Drawable drawableMutate = androidx.core.graphics.drawable.a.r(drawableA).mutate();
                if (this.f980d) {
                    androidx.core.graphics.drawable.a.o(drawableMutate, this.f978b);
                }
                if (this.f981e) {
                    androidx.core.graphics.drawable.a.p(drawableMutate, this.f979c);
                }
                if (drawableMutate.isStateful()) {
                    drawableMutate.setState(this.f977a.getDrawableState());
                }
                this.f977a.setButtonDrawable(drawableMutate);
            }
        }
    }

    ColorStateList c() {
        return this.f978b;
    }

    PorterDuff.Mode d() {
        return this.f979c;
    }

    void e(AttributeSet attributeSet, int i10) {
        int i11;
        int iN;
        int iN2;
        Context context = this.f977a.getContext();
        int[] iArr = R$styleable.CompoundButton;
        h0 h0VarW = h0.w(context, attributeSet, iArr, i10, 0);
        CompoundButton compoundButton = this.f977a;
        androidx.core.view.h0.j0(compoundButton, compoundButton.getContext(), iArr, attributeSet, h0VarW.r(), i10, 0);
        try {
            int i12 = R$styleable.CompoundButton_buttonCompat;
            if (!h0VarW.s(i12) || (iN2 = h0VarW.n(i12, 0)) == 0) {
                i11 = R$styleable.CompoundButton_android_button;
                if (h0VarW.s(i11) && (iN = h0VarW.n(i11, 0)) != 0) {
                    CompoundButton compoundButton2 = this.f977a;
                    compoundButton2.setButtonDrawable(h.a.b(compoundButton2.getContext(), iN));
                }
            } else {
                try {
                    CompoundButton compoundButton3 = this.f977a;
                    compoundButton3.setButtonDrawable(h.a.b(compoundButton3.getContext(), iN2));
                } catch (Resources.NotFoundException unused) {
                    i11 = R$styleable.CompoundButton_android_button;
                    if (h0VarW.s(i11)) {
                        CompoundButton compoundButton4 = this.f977a;
                        compoundButton4.setButtonDrawable(h.a.b(compoundButton4.getContext(), iN));
                    }
                }
            }
            int i13 = R$styleable.CompoundButton_buttonTint;
            if (h0VarW.s(i13)) {
                androidx.core.widget.c.d(this.f977a, h0VarW.c(i13));
            }
            int i14 = R$styleable.CompoundButton_buttonTintMode;
            if (h0VarW.s(i14)) {
                androidx.core.widget.c.e(this.f977a, t.d(h0VarW.k(i14, -1), null));
            }
        } finally {
            h0VarW.x();
        }
    }

    void f() {
        if (this.f982f) {
            this.f982f = false;
        } else {
            this.f982f = true;
            a();
        }
    }

    void g(ColorStateList colorStateList) {
        this.f978b = colorStateList;
        this.f980d = true;
        a();
    }

    void h(PorterDuff.Mode mode) {
        this.f979c = mode;
        this.f981e = true;
        a();
    }

    int b(int i10) {
        return i10;
    }
}
