package androidx.appcompat.widget;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;

/* JADX INFO: compiled from: TintInfo.java */
/* JADX INFO: loaded from: classes.dex */
public class f0 {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public ColorStateList f983a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public PorterDuff.Mode f984b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public boolean f985c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public boolean f986d;

    void a() {
        this.f983a = null;
        this.f986d = false;
        this.f984b = null;
        this.f985c = false;
    }
}
