package androidx.appcompat.widget;

import android.R;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Shader;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import androidx.appcompat.R$attr;
import androidx.appcompat.R$color;
import androidx.appcompat.R$dimen;
import androidx.appcompat.R$drawable;

/* JADX INFO: compiled from: AppCompatDrawableManager.java */
/* JADX INFO: loaded from: classes.dex */
public final class g {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private static final PorterDuff.Mode f987b = PorterDuff.Mode.SRC_IN;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private static g f988c;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private y f989a;

    /* JADX INFO: compiled from: AppCompatDrawableManager.java */
    class a implements y.c {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private final int[] f990a = {R$drawable.abc_textfield_search_default_mtrl_alpha, R$drawable.abc_textfield_default_mtrl_alpha, R$drawable.abc_ab_share_pack_mtrl_alpha};

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private final int[] f991b = {R$drawable.abc_ic_commit_search_api_mtrl_alpha, R$drawable.abc_seekbar_tick_mark_material, R$drawable.abc_ic_menu_share_mtrl_alpha, R$drawable.abc_ic_menu_copy_mtrl_am_alpha, R$drawable.abc_ic_menu_cut_mtrl_alpha, R$drawable.abc_ic_menu_selectall_mtrl_alpha, R$drawable.abc_ic_menu_paste_mtrl_am_alpha};

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        private final int[] f992c = {R$drawable.abc_textfield_activated_mtrl_alpha, R$drawable.abc_textfield_search_activated_mtrl_alpha, R$drawable.abc_cab_background_top_mtrl_alpha, R$drawable.abc_text_cursor_material, R$drawable.abc_text_select_handle_left_mtrl, R$drawable.abc_text_select_handle_middle_mtrl, R$drawable.abc_text_select_handle_right_mtrl};

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        private final int[] f993d = {R$drawable.abc_popup_background_mtrl_mult, R$drawable.abc_cab_background_internal_bg, R$drawable.abc_menu_hardkey_panel_mtrl_mult};

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        private final int[] f994e = {R$drawable.abc_tab_indicator_material, R$drawable.abc_textfield_search_material};

        /* JADX INFO: renamed from: f, reason: collision with root package name */
        private final int[] f995f = {R$drawable.abc_btn_check_material, R$drawable.abc_btn_radio_material, R$drawable.abc_btn_check_material_anim, R$drawable.abc_btn_radio_material_anim};

        a() {
        }

        private boolean f(int[] iArr, int i10) {
            for (int i11 : iArr) {
                if (i11 == i10) {
                    return true;
                }
            }
            return false;
        }

        private ColorStateList g(Context context) {
            return h(context, 0);
        }

        private ColorStateList h(Context context, int i10) {
            int iC = c0.c(context, R$attr.colorControlHighlight);
            return new ColorStateList(new int[][]{c0.f952b, c0.f955e, c0.f953c, c0.f959i}, new int[]{c0.b(context, R$attr.colorButtonNormal), androidx.core.graphics.a.j(iC, i10), androidx.core.graphics.a.j(iC, i10), i10});
        }

        private ColorStateList i(Context context) {
            return h(context, c0.c(context, R$attr.colorAccent));
        }

        private ColorStateList j(Context context) {
            return h(context, c0.c(context, R$attr.colorButtonNormal));
        }

        private ColorStateList k(Context context) {
            int[][] iArr = new int[3][];
            int[] iArr2 = new int[3];
            int i10 = R$attr.colorSwitchThumbNormal;
            ColorStateList colorStateListE = c0.e(context, i10);
            if (colorStateListE == null || !colorStateListE.isStateful()) {
                iArr[0] = c0.f952b;
                iArr2[0] = c0.b(context, i10);
                iArr[1] = c0.f956f;
                iArr2[1] = c0.c(context, R$attr.colorControlActivated);
                iArr[2] = c0.f959i;
                iArr2[2] = c0.c(context, i10);
            } else {
                int[] iArr3 = c0.f952b;
                iArr[0] = iArr3;
                iArr2[0] = colorStateListE.getColorForState(iArr3, 0);
                iArr[1] = c0.f956f;
                iArr2[1] = c0.c(context, R$attr.colorControlActivated);
                iArr[2] = c0.f959i;
                iArr2[2] = colorStateListE.getDefaultColor();
            }
            return new ColorStateList(iArr, iArr2);
        }

        private LayerDrawable l(y yVar, Context context, int i10) {
            BitmapDrawable bitmapDrawable;
            BitmapDrawable bitmapDrawable2;
            BitmapDrawable bitmapDrawable3;
            int dimensionPixelSize = context.getResources().getDimensionPixelSize(i10);
            Drawable drawableI = yVar.i(context, R$drawable.abc_star_black_48dp);
            Drawable drawableI2 = yVar.i(context, R$drawable.abc_star_half_black_48dp);
            if ((drawableI instanceof BitmapDrawable) && drawableI.getIntrinsicWidth() == dimensionPixelSize && drawableI.getIntrinsicHeight() == dimensionPixelSize) {
                bitmapDrawable = (BitmapDrawable) drawableI;
                bitmapDrawable2 = new BitmapDrawable(bitmapDrawable.getBitmap());
            } else {
                Bitmap bitmapCreateBitmap = Bitmap.createBitmap(dimensionPixelSize, dimensionPixelSize, Bitmap.Config.ARGB_8888);
                Canvas canvas = new Canvas(bitmapCreateBitmap);
                drawableI.setBounds(0, 0, dimensionPixelSize, dimensionPixelSize);
                drawableI.draw(canvas);
                bitmapDrawable = new BitmapDrawable(bitmapCreateBitmap);
                bitmapDrawable2 = new BitmapDrawable(bitmapCreateBitmap);
            }
            bitmapDrawable2.setTileModeX(Shader.TileMode.REPEAT);
            if ((drawableI2 instanceof BitmapDrawable) && drawableI2.getIntrinsicWidth() == dimensionPixelSize && drawableI2.getIntrinsicHeight() == dimensionPixelSize) {
                bitmapDrawable3 = (BitmapDrawable) drawableI2;
            } else {
                Bitmap bitmapCreateBitmap2 = Bitmap.createBitmap(dimensionPixelSize, dimensionPixelSize, Bitmap.Config.ARGB_8888);
                Canvas canvas2 = new Canvas(bitmapCreateBitmap2);
                drawableI2.setBounds(0, 0, dimensionPixelSize, dimensionPixelSize);
                drawableI2.draw(canvas2);
                bitmapDrawable3 = new BitmapDrawable(bitmapCreateBitmap2);
            }
            LayerDrawable layerDrawable = new LayerDrawable(new Drawable[]{bitmapDrawable, bitmapDrawable3, bitmapDrawable2});
            layerDrawable.setId(0, R.id.background);
            layerDrawable.setId(1, R.id.secondaryProgress);
            layerDrawable.setId(2, R.id.progress);
            return layerDrawable;
        }

        private void m(Drawable drawable, int i10, PorterDuff.Mode mode) {
            if (t.a(drawable)) {
                drawable = drawable.mutate();
            }
            if (mode == null) {
                mode = g.f987b;
            }
            drawable.setColorFilter(g.e(i10, mode));
        }

        /* JADX WARN: Code duplicated, block: B:22:0x004b  */
        /* JADX WARN: Code duplicated, block: B:24:0x0051  */
        /* JADX WARN: Code duplicated, block: B:27:0x0062  */
        /* JADX WARN: Code duplicated, block: B:29:0x0066 A[RETURN] */
        @Override // androidx.appcompat.widget.y.c
        public boolean a(Context context, int i10, Drawable drawable) {
            int i11;
            boolean z10;
            int iRound;
            PorterDuff.Mode mode = g.f987b;
            if (f(this.f990a, i10)) {
                i11 = R$attr.colorControlNormal;
            } else if (f(this.f992c, i10)) {
                i11 = R$attr.colorControlActivated;
            } else {
                if (!f(this.f993d, i10)) {
                    if (i10 == R$drawable.abc_list_divider_mtrl_alpha) {
                        z10 = true;
                        iRound = Math.round(40.8f);
                        i11 = 16842800;
                    } else {
                        if (i10 != R$drawable.abc_dialog_material_background) {
                            i11 = 0;
                            z10 = false;
                        }
                        iRound = -1;
                    }
                    if (z10) {
                        return false;
                    }
                    if (t.a(drawable)) {
                        drawable = drawable.mutate();
                    }
                    drawable.setColorFilter(g.e(c0.c(context, i11), mode));
                    if (iRound != -1) {
                        drawable.setAlpha(iRound);
                    }
                    return true;
                }
                mode = PorterDuff.Mode.MULTIPLY;
                i11 = 16842801;
            }
            z10 = true;
            iRound = -1;
            if (z10) {
                return false;
            }
            if (t.a(drawable)) {
                drawable = drawable.mutate();
            }
            drawable.setColorFilter(g.e(c0.c(context, i11), mode));
            if (iRound != -1) {
                drawable.setAlpha(iRound);
            }
            return true;
        }

        @Override // androidx.appcompat.widget.y.c
        public PorterDuff.Mode b(int i10) {
            if (i10 == R$drawable.abc_switch_thumb_material) {
                return PorterDuff.Mode.MULTIPLY;
            }
            return null;
        }

        @Override // androidx.appcompat.widget.y.c
        public Drawable c(y yVar, Context context, int i10) {
            if (i10 == R$drawable.abc_cab_background_top_material) {
                return new LayerDrawable(new Drawable[]{yVar.i(context, R$drawable.abc_cab_background_internal_bg), yVar.i(context, R$drawable.abc_cab_background_top_mtrl_alpha)});
            }
            if (i10 == R$drawable.abc_ratingbar_material) {
                return l(yVar, context, R$dimen.abc_star_big);
            }
            if (i10 == R$drawable.abc_ratingbar_indicator_material) {
                return l(yVar, context, R$dimen.abc_star_medium);
            }
            if (i10 == R$drawable.abc_ratingbar_small_material) {
                return l(yVar, context, R$dimen.abc_star_small);
            }
            return null;
        }

        @Override // androidx.appcompat.widget.y.c
        public ColorStateList d(Context context, int i10) {
            if (i10 == R$drawable.abc_edit_text_material) {
                return h.a.a(context, R$color.abc_tint_edittext);
            }
            if (i10 == R$drawable.abc_switch_track_mtrl_alpha) {
                return h.a.a(context, R$color.abc_tint_switch_track);
            }
            if (i10 == R$drawable.abc_switch_thumb_material) {
                return k(context);
            }
            if (i10 == R$drawable.abc_btn_default_mtrl_shape) {
                return j(context);
            }
            if (i10 == R$drawable.abc_btn_borderless_material) {
                return g(context);
            }
            if (i10 == R$drawable.abc_btn_colored_material) {
                return i(context);
            }
            if (i10 == R$drawable.abc_spinner_mtrl_am_alpha || i10 == R$drawable.abc_spinner_textfield_background_material) {
                return h.a.a(context, R$color.abc_tint_spinner);
            }
            if (f(this.f991b, i10)) {
                return c0.e(context, R$attr.colorControlNormal);
            }
            if (f(this.f994e, i10)) {
                return h.a.a(context, R$color.abc_tint_default);
            }
            if (f(this.f995f, i10)) {
                return h.a.a(context, R$color.abc_tint_btn_checkable);
            }
            if (i10 == R$drawable.abc_seekbar_thumb_material) {
                return h.a.a(context, R$color.abc_tint_seek_thumb);
            }
            return null;
        }

        @Override // androidx.appcompat.widget.y.c
        public boolean e(Context context, int i10, Drawable drawable) {
            if (i10 == R$drawable.abc_seekbar_track_material) {
                LayerDrawable layerDrawable = (LayerDrawable) drawable;
                Drawable drawableFindDrawableByLayerId = layerDrawable.findDrawableByLayerId(R.id.background);
                int i11 = R$attr.colorControlNormal;
                m(drawableFindDrawableByLayerId, c0.c(context, i11), g.f987b);
                m(layerDrawable.findDrawableByLayerId(R.id.secondaryProgress), c0.c(context, i11), g.f987b);
                m(layerDrawable.findDrawableByLayerId(R.id.progress), c0.c(context, R$attr.colorControlActivated), g.f987b);
                return true;
            }
            if (i10 != R$drawable.abc_ratingbar_material && i10 != R$drawable.abc_ratingbar_indicator_material && i10 != R$drawable.abc_ratingbar_small_material) {
                return false;
            }
            LayerDrawable layerDrawable2 = (LayerDrawable) drawable;
            m(layerDrawable2.findDrawableByLayerId(R.id.background), c0.b(context, R$attr.colorControlNormal), g.f987b);
            Drawable drawableFindDrawableByLayerId2 = layerDrawable2.findDrawableByLayerId(R.id.secondaryProgress);
            int i12 = R$attr.colorControlActivated;
            m(drawableFindDrawableByLayerId2, c0.c(context, i12), g.f987b);
            m(layerDrawable2.findDrawableByLayerId(R.id.progress), c0.c(context, i12), g.f987b);
            return true;
        }
    }

    public static synchronized g b() {
        try {
            if (f988c == null) {
                h();
            }
        } catch (Throwable th) {
            throw th;
        }
        return f988c;
    }

    public static synchronized PorterDuffColorFilter e(int i10, PorterDuff.Mode mode) {
        return y.k(i10, mode);
    }

    public static synchronized void h() {
        if (f988c == null) {
            g gVar = new g();
            f988c = gVar;
            gVar.f989a = y.g();
            f988c.f989a.t(new a());
        }
    }

    static void i(Drawable drawable, f0 f0Var, int[] iArr) {
        y.v(drawable, f0Var, iArr);
    }

    public synchronized Drawable c(Context context, int i10) {
        return this.f989a.i(context, i10);
    }

    synchronized Drawable d(Context context, int i10, boolean z10) {
        return this.f989a.j(context, i10, z10);
    }

    synchronized ColorStateList f(Context context, int i10) {
        return this.f989a.l(context, i10);
    }

    public synchronized void g(Context context) {
        this.f989a.r(context);
    }
}
