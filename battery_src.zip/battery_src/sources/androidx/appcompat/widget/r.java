package androidx.appcompat.widget;

import android.view.Menu;
import android.view.Window;
import androidx.appcompat.view.menu.MenuPresenter;

/* JADX INFO: compiled from: DecorContentParent.java */
/* JADX INFO: loaded from: classes.dex */
public interface r {
    void a(Menu menu, MenuPresenter.Callback callback);

    boolean b();

    void c();

    boolean d();

    boolean e();

    boolean f();

    boolean g();

    void k(int i10);

    void l();

    void setWindowCallback(Window.Callback callback);

    void setWindowTitle(CharSequence charSequence);
}
