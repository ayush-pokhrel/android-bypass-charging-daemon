package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import java.lang.ref.WeakReference;

/* JADX INFO: compiled from: TintResources.java */
/* JADX INFO: loaded from: classes.dex */
class g0 extends z {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private final WeakReference<Context> f996b;

    public g0(Context context, Resources resources) {
        super(resources);
        this.f996b = new WeakReference<>(context);
    }

    @Override // android.content.res.Resources
    public Drawable getDrawable(int i10) throws Resources.NotFoundException {
        Drawable drawableA = a(i10);
        Context context = this.f996b.get();
        if (drawableA != null && context != null) {
            y.g().w(context, i10, drawableA);
        }
        return drawableA;
    }
}
