package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.widget.CheckedTextView;
import androidx.appcompat.R$styleable;

/* JADX INFO: compiled from: AppCompatCheckedTextViewHelper.java */
/* JADX INFO: loaded from: classes.dex */
class e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final CheckedTextView f967a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private ColorStateList f968b = null;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private PorterDuff.Mode f969c = null;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private boolean f970d = false;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private boolean f971e = false;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private boolean f972f;

    e(CheckedTextView checkedTextView) {
        this.f967a = checkedTextView;
    }

    void a() {
        Drawable drawableA = androidx.core.widget.b.a(this.f967a);
        if (drawableA != null) {
            if (this.f970d || this.f971e) {
                Drawable drawableMutate = androidx.core.graphics.drawable.a.r(drawableA).mutate();
                if (this.f970d) {
                    androidx.core.graphics.drawable.a.o(drawableMutate, this.f968b);
                }
                if (this.f971e) {
                    androidx.core.graphics.drawable.a.p(drawableMutate, this.f969c);
                }
                if (drawableMutate.isStateful()) {
                    drawableMutate.setState(this.f967a.getDrawableState());
                }
                this.f967a.setCheckMarkDrawable(drawableMutate);
            }
        }
    }

    ColorStateList b() {
        return this.f968b;
    }

    PorterDuff.Mode c() {
        return this.f969c;
    }

    void d(AttributeSet attributeSet, int i10) {
        int i11;
        int iN;
        int iN2;
        Context context = this.f967a.getContext();
        int[] iArr = R$styleable.CheckedTextView;
        h0 h0VarW = h0.w(context, attributeSet, iArr, i10, 0);
        CheckedTextView checkedTextView = this.f967a;
        androidx.core.view.h0.j0(checkedTextView, checkedTextView.getContext(), iArr, attributeSet, h0VarW.r(), i10, 0);
        try {
            int i12 = R$styleable.CheckedTextView_checkMarkCompat;
            if (!h0VarW.s(i12) || (iN2 = h0VarW.n(i12, 0)) == 0) {
                i11 = R$styleable.CheckedTextView_android_checkMark;
                if (h0VarW.s(i11) && (iN = h0VarW.n(i11, 0)) != 0) {
                    CheckedTextView checkedTextView2 = this.f967a;
                    checkedTextView2.setCheckMarkDrawable(h.a.b(checkedTextView2.getContext(), iN));
                }
            } else {
                try {
                    CheckedTextView checkedTextView3 = this.f967a;
                    checkedTextView3.setCheckMarkDrawable(h.a.b(checkedTextView3.getContext(), iN2));
                } catch (Resources.NotFoundException unused) {
                    i11 = R$styleable.CheckedTextView_android_checkMark;
                    if (h0VarW.s(i11)) {
                        CheckedTextView checkedTextView4 = this.f967a;
                        checkedTextView4.setCheckMarkDrawable(h.a.b(checkedTextView4.getContext(), iN));
                    }
                }
            }
            int i13 = R$styleable.CheckedTextView_checkMarkTint;
            if (h0VarW.s(i13)) {
                androidx.core.widget.b.b(this.f967a, h0VarW.c(i13));
            }
            int i14 = R$styleable.CheckedTextView_checkMarkTintMode;
            if (h0VarW.s(i14)) {
                androidx.core.widget.b.c(this.f967a, t.d(h0VarW.k(i14, -1), null));
            }
        } finally {
            h0VarW.x();
        }
    }

    void e() {
        if (this.f972f) {
            this.f972f = false;
        } else {
            this.f972f = true;
            a();
        }
    }

    void f(ColorStateList colorStateList) {
        this.f968b = colorStateList;
        this.f970d = true;
        a();
    }

    void g(PorterDuff.Mode mode) {
        this.f969c = mode;
        this.f971e = true;
        a();
    }
}
