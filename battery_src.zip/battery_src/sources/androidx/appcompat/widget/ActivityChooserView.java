package androidx.appcompat.widget;

import android.R;
import android.content.Context;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.database.DataSetObserver;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;
import androidx.appcompat.R$dimen;
import androidx.appcompat.R$id;
import androidx.appcompat.R$layout;
import androidx.appcompat.R$string;
import androidx.appcompat.R$styleable;
import androidx.appcompat.view.menu.ShowableListMenu;

/* JADX INFO: loaded from: classes.dex */
public class ActivityChooserView extends ViewGroup {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    final f f687a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private final g f688b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private final View f689c;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private final Drawable f690g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    final FrameLayout f691h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private final ImageView f692i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    final FrameLayout f693j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    private final ImageView f694k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private final int f695l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    androidx.core.view.b f696m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    final DataSetObserver f697n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    private final ViewTreeObserver.OnGlobalLayoutListener f698o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    private ListPopupWindow f699p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    PopupWindow.OnDismissListener f700q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    boolean f701r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    int f702s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    private boolean f703t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    private int f704u;

    public static class InnerLayout extends LinearLayout {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private static final int[] f705a = {R.attr.background};

        public InnerLayout(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            h0 h0VarV = h0.v(context, attributeSet, f705a);
            setBackgroundDrawable(h0VarV.g(0));
            h0VarV.x();
        }
    }

    class a extends DataSetObserver {
        a() {
        }

        @Override // android.database.DataSetObserver
        public void onChanged() {
            super.onChanged();
            ActivityChooserView.this.f687a.notifyDataSetChanged();
        }

        @Override // android.database.DataSetObserver
        public void onInvalidated() {
            super.onInvalidated();
            ActivityChooserView.this.f687a.notifyDataSetInvalidated();
        }
    }

    class b implements ViewTreeObserver.OnGlobalLayoutListener {
        b() {
        }

        @Override // android.view.ViewTreeObserver.OnGlobalLayoutListener
        public void onGlobalLayout() {
            if (ActivityChooserView.this.b()) {
                if (!ActivityChooserView.this.isShown()) {
                    ActivityChooserView.this.getListPopupWindow().dismiss();
                    return;
                }
                ActivityChooserView.this.getListPopupWindow().show();
                androidx.core.view.b bVar = ActivityChooserView.this.f696m;
                if (bVar != null) {
                    bVar.subUiVisibilityChanged(true);
                }
            }
        }
    }

    class c extends View.AccessibilityDelegate {
        c() {
        }

        @Override // android.view.View.AccessibilityDelegate
        public void onInitializeAccessibilityNodeInfo(View view, AccessibilityNodeInfo accessibilityNodeInfo) {
            super.onInitializeAccessibilityNodeInfo(view, accessibilityNodeInfo);
            b0.d.L0(accessibilityNodeInfo).d0(true);
        }
    }

    class d extends w {
        d(View view) {
            super(view);
        }

        @Override // androidx.appcompat.widget.w
        public ShowableListMenu getPopup() {
            return ActivityChooserView.this.getListPopupWindow();
        }

        @Override // androidx.appcompat.widget.w
        protected boolean onForwardingStarted() {
            ActivityChooserView.this.c();
            return true;
        }

        @Override // androidx.appcompat.widget.w
        protected boolean onForwardingStopped() {
            ActivityChooserView.this.a();
            return true;
        }
    }

    class e extends DataSetObserver {
        e() {
        }

        @Override // android.database.DataSetObserver
        public void onChanged() {
            super.onChanged();
            ActivityChooserView.this.e();
        }
    }

    private class f extends BaseAdapter {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private int f711a = 4;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private boolean f712b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        private boolean f713c;

        /* JADX INFO: renamed from: g, reason: collision with root package name */
        private boolean f714g;

        f() {
        }

        public int a() {
            throw null;
        }

        public androidx.appcompat.widget.c b() {
            return null;
        }

        public ResolveInfo c() {
            throw null;
        }

        public int d() {
            throw null;
        }

        public boolean e() {
            return this.f712b;
        }

        public void f(androidx.appcompat.widget.c cVar) {
            ActivityChooserView.this.f687a.b();
            notifyDataSetChanged();
        }

        @Override // android.widget.Adapter
        public int getCount() {
            throw null;
        }

        @Override // android.widget.Adapter
        public Object getItem(int i10) {
            int itemViewType = getItemViewType(i10);
            if (itemViewType != 0) {
                if (itemViewType == 1) {
                    return null;
                }
                throw new IllegalArgumentException();
            }
            if (this.f712b) {
                throw null;
            }
            throw null;
        }

        @Override // android.widget.Adapter
        public long getItemId(int i10) {
            return i10;
        }

        @Override // android.widget.BaseAdapter, android.widget.Adapter
        public int getItemViewType(int i10) {
            return (this.f714g && i10 == getCount() - 1) ? 1 : 0;
        }

        @Override // android.widget.Adapter
        public View getView(int i10, View view, ViewGroup viewGroup) {
            int itemViewType = getItemViewType(i10);
            if (itemViewType != 0) {
                if (itemViewType != 1) {
                    throw new IllegalArgumentException();
                }
                if (view != null && view.getId() == 1) {
                    return view;
                }
                View viewInflate = LayoutInflater.from(ActivityChooserView.this.getContext()).inflate(R$layout.abc_activity_chooser_view_list_item, viewGroup, false);
                viewInflate.setId(1);
                ((TextView) viewInflate.findViewById(R$id.title)).setText(ActivityChooserView.this.getContext().getString(R$string.abc_activity_chooser_view_see_all));
                return viewInflate;
            }
            if (view == null || view.getId() != R$id.list_item) {
                view = LayoutInflater.from(ActivityChooserView.this.getContext()).inflate(R$layout.abc_activity_chooser_view_list_item, viewGroup, false);
            }
            PackageManager packageManager = ActivityChooserView.this.getContext().getPackageManager();
            ImageView imageView = (ImageView) view.findViewById(R$id.icon);
            ResolveInfo resolveInfo = (ResolveInfo) getItem(i10);
            imageView.setImageDrawable(resolveInfo.loadIcon(packageManager));
            ((TextView) view.findViewById(R$id.title)).setText(resolveInfo.loadLabel(packageManager));
            if (this.f712b && i10 == 0 && this.f713c) {
                view.setActivated(true);
            } else {
                view.setActivated(false);
            }
            return view;
        }

        @Override // android.widget.BaseAdapter, android.widget.Adapter
        public int getViewTypeCount() {
            return 3;
        }
    }

    private class g implements AdapterView.OnItemClickListener, View.OnClickListener, View.OnLongClickListener, PopupWindow.OnDismissListener {
        g() {
        }

        private void a() {
            PopupWindow.OnDismissListener onDismissListener = ActivityChooserView.this.f700q;
            if (onDismissListener != null) {
                onDismissListener.onDismiss();
            }
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            ActivityChooserView activityChooserView = ActivityChooserView.this;
            if (view == activityChooserView.f693j) {
                activityChooserView.a();
                ActivityChooserView.this.f687a.c();
                ActivityChooserView.this.f687a.b();
                throw null;
            }
            if (view != activityChooserView.f691h) {
                throw new IllegalArgumentException();
            }
            activityChooserView.f701r = false;
            activityChooserView.d(activityChooserView.f702s);
        }

        @Override // android.widget.PopupWindow.OnDismissListener
        public void onDismiss() {
            a();
            androidx.core.view.b bVar = ActivityChooserView.this.f696m;
            if (bVar != null) {
                bVar.subUiVisibilityChanged(false);
            }
        }

        @Override // android.widget.AdapterView.OnItemClickListener
        public void onItemClick(AdapterView<?> adapterView, View view, int i10, long j10) {
            int itemViewType = ((f) adapterView.getAdapter()).getItemViewType(i10);
            if (itemViewType != 0) {
                if (itemViewType != 1) {
                    throw new IllegalArgumentException();
                }
                ActivityChooserView.this.d(Integer.MAX_VALUE);
                return;
            }
            ActivityChooserView.this.a();
            ActivityChooserView activityChooserView = ActivityChooserView.this;
            if (!activityChooserView.f701r) {
                activityChooserView.f687a.e();
                ActivityChooserView.this.f687a.b();
                throw null;
            }
            if (i10 <= 0) {
                return;
            }
            activityChooserView.f687a.b();
            throw null;
        }

        @Override // android.view.View.OnLongClickListener
        public boolean onLongClick(View view) {
            ActivityChooserView activityChooserView = ActivityChooserView.this;
            if (view != activityChooserView.f693j) {
                throw new IllegalArgumentException();
            }
            if (activityChooserView.f687a.getCount() > 0) {
                ActivityChooserView activityChooserView2 = ActivityChooserView.this;
                activityChooserView2.f701r = true;
                activityChooserView2.d(activityChooserView2.f702s);
            }
            return true;
        }
    }

    public ActivityChooserView(Context context) {
        this(context, null);
    }

    public boolean a() {
        if (!b()) {
            return true;
        }
        getListPopupWindow().dismiss();
        ViewTreeObserver viewTreeObserver = getViewTreeObserver();
        if (!viewTreeObserver.isAlive()) {
            return true;
        }
        viewTreeObserver.removeGlobalOnLayoutListener(this.f698o);
        return true;
    }

    public boolean b() {
        return getListPopupWindow().isShowing();
    }

    public boolean c() {
        if (b() || !this.f703t) {
            return false;
        }
        this.f701r = false;
        d(this.f702s);
        return true;
    }

    void d(int i10) {
        this.f687a.b();
        throw new IllegalStateException("No data model. Did you call #setDataModel?");
    }

    void e() {
        if (this.f687a.getCount() > 0) {
            this.f691h.setEnabled(true);
        } else {
            this.f691h.setEnabled(false);
        }
        int iA = this.f687a.a();
        int iD = this.f687a.d();
        if (iA == 1 || (iA > 1 && iD > 0)) {
            this.f693j.setVisibility(0);
            ResolveInfo resolveInfoC = this.f687a.c();
            PackageManager packageManager = getContext().getPackageManager();
            this.f694k.setImageDrawable(resolveInfoC.loadIcon(packageManager));
            if (this.f704u != 0) {
                this.f693j.setContentDescription(getContext().getString(this.f704u, resolveInfoC.loadLabel(packageManager)));
            }
        } else {
            this.f693j.setVisibility(8);
        }
        if (this.f693j.getVisibility() == 0) {
            this.f689c.setBackgroundDrawable(this.f690g);
        } else {
            this.f689c.setBackgroundDrawable(null);
        }
    }

    public androidx.appcompat.widget.c getDataModel() {
        this.f687a.b();
        return null;
    }

    ListPopupWindow getListPopupWindow() {
        if (this.f699p == null) {
            ListPopupWindow listPopupWindow = new ListPopupWindow(getContext());
            this.f699p = listPopupWindow;
            listPopupWindow.l(this.f687a);
            this.f699p.y(this);
            this.f699p.E(true);
            this.f699p.G(this.f688b);
            this.f699p.F(this.f688b);
        }
        return this.f699p;
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.f687a.b();
        this.f703t = true;
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        this.f687a.b();
        ViewTreeObserver viewTreeObserver = getViewTreeObserver();
        if (viewTreeObserver.isAlive()) {
            viewTreeObserver.removeGlobalOnLayoutListener(this.f698o);
        }
        if (b()) {
            a();
        }
        this.f703t = false;
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onLayout(boolean z10, int i10, int i11, int i12, int i13) {
        this.f689c.layout(0, 0, i12 - i10, i13 - i11);
        if (b()) {
            return;
        }
        a();
    }

    @Override // android.view.View
    protected void onMeasure(int i10, int i11) {
        View view = this.f689c;
        if (this.f693j.getVisibility() != 0) {
            i11 = View.MeasureSpec.makeMeasureSpec(View.MeasureSpec.getSize(i11), 1073741824);
        }
        measureChild(view, i10, i11);
        setMeasuredDimension(view.getMeasuredWidth(), view.getMeasuredHeight());
    }

    public void setActivityChooserModel(androidx.appcompat.widget.c cVar) {
        this.f687a.f(cVar);
        if (b()) {
            a();
            c();
        }
    }

    public void setDefaultActionButtonContentDescription(int i10) {
        this.f704u = i10;
    }

    public void setExpandActivityOverflowButtonContentDescription(int i10) {
        this.f692i.setContentDescription(getContext().getString(i10));
    }

    public void setExpandActivityOverflowButtonDrawable(Drawable drawable) {
        this.f692i.setImageDrawable(drawable);
    }

    public void setInitialActivityCount(int i10) {
        this.f702s = i10;
    }

    public void setOnDismissListener(PopupWindow.OnDismissListener onDismissListener) {
        this.f700q = onDismissListener;
    }

    public void setProvider(androidx.core.view.b bVar) {
        this.f696m = bVar;
    }

    public ActivityChooserView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public ActivityChooserView(Context context, AttributeSet attributeSet, int i10) {
        super(context, attributeSet, i10);
        this.f697n = new a();
        this.f698o = new b();
        this.f702s = 4;
        int[] iArr = R$styleable.ActivityChooserView;
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, iArr, i10, 0);
        androidx.core.view.h0.j0(this, context, iArr, attributeSet, typedArrayObtainStyledAttributes, i10, 0);
        this.f702s = typedArrayObtainStyledAttributes.getInt(R$styleable.ActivityChooserView_initialActivityCount, 4);
        Drawable drawable = typedArrayObtainStyledAttributes.getDrawable(R$styleable.ActivityChooserView_expandActivityOverflowButtonDrawable);
        typedArrayObtainStyledAttributes.recycle();
        LayoutInflater.from(getContext()).inflate(R$layout.abc_activity_chooser_view, (ViewGroup) this, true);
        g gVar = new g();
        this.f688b = gVar;
        View viewFindViewById = findViewById(R$id.activity_chooser_view_content);
        this.f689c = viewFindViewById;
        this.f690g = viewFindViewById.getBackground();
        FrameLayout frameLayout = (FrameLayout) findViewById(R$id.default_activity_button);
        this.f693j = frameLayout;
        frameLayout.setOnClickListener(gVar);
        frameLayout.setOnLongClickListener(gVar);
        int i11 = R$id.image;
        this.f694k = (ImageView) frameLayout.findViewById(i11);
        FrameLayout frameLayout2 = (FrameLayout) findViewById(R$id.expand_activities_button);
        frameLayout2.setOnClickListener(gVar);
        frameLayout2.setAccessibilityDelegate(new c());
        frameLayout2.setOnTouchListener(new d(frameLayout2));
        this.f691h = frameLayout2;
        ImageView imageView = (ImageView) frameLayout2.findViewById(i11);
        this.f692i = imageView;
        imageView.setImageDrawable(drawable);
        f fVar = new f();
        this.f687a = fVar;
        fVar.registerDataSetObserver(new e());
        Resources resources = context.getResources();
        this.f695l = Math.max(resources.getDisplayMetrics().widthPixels / 2, resources.getDimensionPixelSize(R$dimen.abc_config_prefDialogWidth));
    }
}
