package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import androidx.appcompat.R$id;
import androidx.appcompat.R$styleable;

/* JADX INFO: loaded from: classes.dex */
public class ActionBarContainer extends FrameLayout {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private boolean f600a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private View f601b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private View f602c;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private View f603g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    Drawable f604h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    Drawable f605i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    Drawable f606j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    boolean f607k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    boolean f608l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    private int f609m;

    private static class a {
        public static void a(ActionBarContainer actionBarContainer) {
            actionBarContainer.invalidateOutline();
        }
    }

    public ActionBarContainer(Context context) {
        this(context, null);
    }

    private int a(View view) {
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) view.getLayoutParams();
        return view.getMeasuredHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
    }

    private boolean b(View view) {
        return view == null || view.getVisibility() == 8 || view.getMeasuredHeight() == 0;
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void drawableStateChanged() {
        super.drawableStateChanged();
        Drawable drawable = this.f604h;
        if (drawable != null && drawable.isStateful()) {
            this.f604h.setState(getDrawableState());
        }
        Drawable drawable2 = this.f605i;
        if (drawable2 != null && drawable2.isStateful()) {
            this.f605i.setState(getDrawableState());
        }
        Drawable drawable3 = this.f606j;
        if (drawable3 == null || !drawable3.isStateful()) {
            return;
        }
        this.f606j.setState(getDrawableState());
    }

    public View getTabContainer() {
        return this.f601b;
    }

    @Override // android.view.ViewGroup, android.view.View
    public void jumpDrawablesToCurrentState() {
        super.jumpDrawablesToCurrentState();
        Drawable drawable = this.f604h;
        if (drawable != null) {
            drawable.jumpToCurrentState();
        }
        Drawable drawable2 = this.f605i;
        if (drawable2 != null) {
            drawable2.jumpToCurrentState();
        }
        Drawable drawable3 = this.f606j;
        if (drawable3 != null) {
            drawable3.jumpToCurrentState();
        }
    }

    @Override // android.view.View
    public void onFinishInflate() {
        super.onFinishInflate();
        this.f602c = findViewById(R$id.action_bar);
        this.f603g = findViewById(R$id.action_context_bar);
    }

    @Override // android.view.View
    public boolean onHoverEvent(MotionEvent motionEvent) {
        super.onHoverEvent(motionEvent);
        return true;
    }

    @Override // android.view.ViewGroup
    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        return this.f600a || super.onInterceptTouchEvent(motionEvent);
    }

    /* JADX WARN: Code duplicated, block: B:17:0x0048 A[PHI: r0
      0x0048: PHI (r0v8 boolean) = (r0v1 boolean), (r0v1 boolean), (r0v0 boolean) binds: [B:31:0x00a5, B:33:0x00a9, B:15:0x0039] A[DONT_GENERATE, DONT_INLINE]] */
    @Override // android.widget.FrameLayout, android.view.ViewGroup, android.view.View
    public void onLayout(boolean z10, int i10, int i11, int i12, int i13) {
        Drawable drawable;
        super.onLayout(z10, i10, i11, i12, i13);
        View view = this.f601b;
        boolean z11 = true;
        boolean z12 = false;
        boolean z13 = (view == null || view.getVisibility() == 8) ? false : true;
        if (view != null && view.getVisibility() != 8) {
            int measuredHeight = getMeasuredHeight();
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) view.getLayoutParams();
            int measuredHeight2 = measuredHeight - view.getMeasuredHeight();
            int i14 = layoutParams.bottomMargin;
            view.layout(i10, measuredHeight2 - i14, i12, measuredHeight - i14);
        }
        if (this.f607k) {
            Drawable drawable2 = this.f606j;
            if (drawable2 != null) {
                drawable2.setBounds(0, 0, getMeasuredWidth(), getMeasuredHeight());
            } else {
                z11 = z12;
            }
        } else {
            if (this.f604h != null) {
                if (this.f602c.getVisibility() == 0) {
                    this.f604h.setBounds(this.f602c.getLeft(), this.f602c.getTop(), this.f602c.getRight(), this.f602c.getBottom());
                } else {
                    View view2 = this.f603g;
                    if (view2 == null || view2.getVisibility() != 0) {
                        this.f604h.setBounds(0, 0, 0, 0);
                    } else {
                        this.f604h.setBounds(this.f603g.getLeft(), this.f603g.getTop(), this.f603g.getRight(), this.f603g.getBottom());
                    }
                }
                z12 = true;
            }
            this.f608l = z13;
            if (!z13 || (drawable = this.f605i) == null) {
                z11 = z12;
            } else {
                drawable.setBounds(view.getLeft(), view.getTop(), view.getRight(), view.getBottom());
            }
        }
        if (z11) {
            invalidate();
        }
    }

    @Override // android.widget.FrameLayout, android.view.View
    public void onMeasure(int i10, int i11) {
        int iA;
        int i12;
        if (this.f602c == null && View.MeasureSpec.getMode(i11) == Integer.MIN_VALUE && (i12 = this.f609m) >= 0) {
            i11 = View.MeasureSpec.makeMeasureSpec(Math.min(i12, View.MeasureSpec.getSize(i11)), Integer.MIN_VALUE);
        }
        super.onMeasure(i10, i11);
        if (this.f602c == null) {
            return;
        }
        int mode = View.MeasureSpec.getMode(i11);
        View view = this.f601b;
        if (view == null || view.getVisibility() == 8 || mode == 1073741824) {
            return;
        }
        if (b(this.f602c)) {
            iA = !b(this.f603g) ? a(this.f603g) : 0;
        } else {
            iA = a(this.f602c);
        }
        setMeasuredDimension(getMeasuredWidth(), Math.min(iA + a(this.f601b), mode == Integer.MIN_VALUE ? View.MeasureSpec.getSize(i11) : Integer.MAX_VALUE));
    }

    @Override // android.view.View
    public boolean onTouchEvent(MotionEvent motionEvent) {
        super.onTouchEvent(motionEvent);
        return true;
    }

    public void setPrimaryBackground(Drawable drawable) {
        Drawable drawable2 = this.f604h;
        if (drawable2 != null) {
            drawable2.setCallback(null);
            unscheduleDrawable(this.f604h);
        }
        this.f604h = drawable;
        if (drawable != null) {
            drawable.setCallback(this);
            View view = this.f602c;
            if (view != null) {
                this.f604h.setBounds(view.getLeft(), this.f602c.getTop(), this.f602c.getRight(), this.f602c.getBottom());
            }
        }
        boolean z10 = false;
        if (!this.f607k ? !(this.f604h != null || this.f605i != null) : this.f606j == null) {
            z10 = true;
        }
        setWillNotDraw(z10);
        invalidate();
        a.a(this);
    }

    public void setSplitBackground(Drawable drawable) {
        Drawable drawable2;
        Drawable drawable3 = this.f606j;
        if (drawable3 != null) {
            drawable3.setCallback(null);
            unscheduleDrawable(this.f606j);
        }
        this.f606j = drawable;
        boolean z10 = false;
        if (drawable != null) {
            drawable.setCallback(this);
            if (this.f607k && (drawable2 = this.f606j) != null) {
                drawable2.setBounds(0, 0, getMeasuredWidth(), getMeasuredHeight());
            }
        }
        if (!this.f607k ? !(this.f604h != null || this.f605i != null) : this.f606j == null) {
            z10 = true;
        }
        setWillNotDraw(z10);
        invalidate();
        a.a(this);
    }

    public void setStackedBackground(Drawable drawable) {
        Drawable drawable2;
        Drawable drawable3 = this.f605i;
        if (drawable3 != null) {
            drawable3.setCallback(null);
            unscheduleDrawable(this.f605i);
        }
        this.f605i = drawable;
        if (drawable != null) {
            drawable.setCallback(this);
            if (this.f608l && (drawable2 = this.f605i) != null) {
                drawable2.setBounds(this.f601b.getLeft(), this.f601b.getTop(), this.f601b.getRight(), this.f601b.getBottom());
            }
        }
        boolean z10 = false;
        if (!this.f607k ? !(this.f604h != null || this.f605i != null) : this.f606j == null) {
            z10 = true;
        }
        setWillNotDraw(z10);
        invalidate();
        a.a(this);
    }

    public void setTabContainer(ScrollingTabContainerView scrollingTabContainerView) {
        View view = this.f601b;
        if (view != null) {
            removeView(view);
        }
        this.f601b = scrollingTabContainerView;
        if (scrollingTabContainerView != null) {
            addView(scrollingTabContainerView);
            ViewGroup.LayoutParams layoutParams = scrollingTabContainerView.getLayoutParams();
            layoutParams.width = -1;
            layoutParams.height = -2;
            scrollingTabContainerView.setAllowCollapse(false);
        }
    }

    public void setTransitioning(boolean z10) {
        this.f600a = z10;
        setDescendantFocusability(z10 ? 393216 : 262144);
    }

    @Override // android.view.View
    public void setVisibility(int i10) {
        super.setVisibility(i10);
        boolean z10 = i10 == 0;
        Drawable drawable = this.f604h;
        if (drawable != null) {
            drawable.setVisible(z10, false);
        }
        Drawable drawable2 = this.f605i;
        if (drawable2 != null) {
            drawable2.setVisible(z10, false);
        }
        Drawable drawable3 = this.f606j;
        if (drawable3 != null) {
            drawable3.setVisible(z10, false);
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public ActionMode startActionModeForChild(View view, ActionMode.Callback callback) {
        return null;
    }

    @Override // android.view.View
    protected boolean verifyDrawable(Drawable drawable) {
        return (drawable == this.f604h && !this.f607k) || (drawable == this.f605i && this.f608l) || ((drawable == this.f606j && this.f607k) || super.verifyDrawable(drawable));
    }

    public ActionBarContainer(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        androidx.core.view.h0.p0(this, new b(this));
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R$styleable.ActionBar);
        this.f604h = typedArrayObtainStyledAttributes.getDrawable(R$styleable.ActionBar_background);
        this.f605i = typedArrayObtainStyledAttributes.getDrawable(R$styleable.ActionBar_backgroundStacked);
        this.f609m = typedArrayObtainStyledAttributes.getDimensionPixelSize(R$styleable.ActionBar_height, -1);
        boolean z10 = true;
        if (getId() == R$id.split_action_bar) {
            this.f607k = true;
            this.f606j = typedArrayObtainStyledAttributes.getDrawable(R$styleable.ActionBar_backgroundSplit);
        }
        typedArrayObtainStyledAttributes.recycle();
        if (!this.f607k ? this.f604h != null || this.f605i != null : this.f606j != null) {
            z10 = false;
        }
        setWillNotDraw(z10);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public ActionMode startActionModeForChild(View view, ActionMode.Callback callback, int i10) {
        if (i10 != 0) {
            return super.startActionModeForChild(view, callback, i10);
        }
        return null;
    }
}
