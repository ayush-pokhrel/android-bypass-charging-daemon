package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import androidx.appcompat.R$attr;
import androidx.appcompat.R$styleable;

/* JADX INFO: compiled from: AbsActionBarView.java */
/* JADX INFO: loaded from: classes.dex */
abstract class a extends ViewGroup {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    protected final C0005a f914a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    protected final Context f915b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    protected ActionMenuView f916c;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    protected ActionMenuPresenter f917g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    protected int f918h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    protected androidx.core.view.n0 f919i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private boolean f920j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    private boolean f921k;

    /* JADX INFO: renamed from: androidx.appcompat.widget.a$a, reason: collision with other inner class name */
    /* JADX INFO: compiled from: AbsActionBarView.java */
    protected class C0005a implements androidx.core.view.o0 {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private boolean f922a = false;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        int f923b;

        protected C0005a() {
        }

        @Override // androidx.core.view.o0
        public void a(View view) {
            this.f922a = true;
        }

        @Override // androidx.core.view.o0
        public void b(View view) {
            if (this.f922a) {
                return;
            }
            a aVar = a.this;
            aVar.f919i = null;
            a.super.setVisibility(this.f923b);
        }

        @Override // androidx.core.view.o0
        public void c(View view) {
            a.super.setVisibility(0);
            this.f922a = false;
        }

        public C0005a d(androidx.core.view.n0 n0Var, int i10) {
            a.this.f919i = n0Var;
            this.f923b = i10;
            return this;
        }
    }

    a(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    protected static int d(int i10, int i11, boolean z10) {
        return z10 ? i10 - i11 : i10 + i11;
    }

    protected int c(View view, int i10, int i11, int i12) {
        view.measure(View.MeasureSpec.makeMeasureSpec(i10, Integer.MIN_VALUE), i11);
        return Math.max(0, (i10 - view.getMeasuredWidth()) - i12);
    }

    protected int e(View view, int i10, int i11, int i12, boolean z10) {
        int measuredWidth = view.getMeasuredWidth();
        int measuredHeight = view.getMeasuredHeight();
        int i13 = i11 + ((i12 - measuredHeight) / 2);
        if (z10) {
            view.layout(i10 - measuredWidth, i13, i10, measuredHeight + i13);
        } else {
            view.layout(i10, i13, i10 + measuredWidth, measuredHeight + i13);
        }
        return z10 ? -measuredWidth : measuredWidth;
    }

    public androidx.core.view.n0 f(int i10, long j10) {
        androidx.core.view.n0 n0Var = this.f919i;
        if (n0Var != null) {
            n0Var.c();
        }
        if (i10 != 0) {
            androidx.core.view.n0 n0VarB = androidx.core.view.h0.d(this).b(0.0f);
            n0VarB.f(j10);
            n0VarB.h(this.f914a.d(n0VarB, i10));
            return n0VarB;
        }
        if (getVisibility() != 0) {
            setAlpha(0.0f);
        }
        androidx.core.view.n0 n0VarB2 = androidx.core.view.h0.d(this).b(1.0f);
        n0VarB2.f(j10);
        n0VarB2.h(this.f914a.d(n0VarB2, i10));
        return n0VarB2;
    }

    public int getAnimatedVisibility() {
        return this.f919i != null ? this.f914a.f923b : getVisibility();
    }

    public int getContentHeight() {
        return this.f918h;
    }

    @Override // android.view.View
    protected void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        TypedArray typedArrayObtainStyledAttributes = getContext().obtainStyledAttributes(null, R$styleable.ActionBar, R$attr.actionBarStyle, 0);
        setContentHeight(typedArrayObtainStyledAttributes.getLayoutDimension(R$styleable.ActionBar_height, 0));
        typedArrayObtainStyledAttributes.recycle();
        ActionMenuPresenter actionMenuPresenter = this.f917g;
        if (actionMenuPresenter != null) {
            actionMenuPresenter.p(configuration);
        }
    }

    @Override // android.view.View
    public boolean onHoverEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 9) {
            this.f921k = false;
        }
        if (!this.f921k) {
            boolean zOnHoverEvent = super.onHoverEvent(motionEvent);
            if (actionMasked == 9 && !zOnHoverEvent) {
                this.f921k = true;
            }
        }
        if (actionMasked == 10 || actionMasked == 3) {
            this.f921k = false;
        }
        return true;
    }

    @Override // android.view.View
    public boolean onTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            this.f920j = false;
        }
        if (!this.f920j) {
            boolean zOnTouchEvent = super.onTouchEvent(motionEvent);
            if (actionMasked == 0 && !zOnTouchEvent) {
                this.f920j = true;
            }
        }
        if (actionMasked == 1 || actionMasked == 3) {
            this.f920j = false;
        }
        return true;
    }

    public void setContentHeight(int i10) {
        this.f918h = i10;
        requestLayout();
    }

    @Override // android.view.View
    public void setVisibility(int i10) {
        if (i10 != getVisibility()) {
            androidx.core.view.n0 n0Var = this.f919i;
            if (n0Var != null) {
                n0Var.c();
            }
            super.setVisibility(i10);
        }
    }

    a(Context context, AttributeSet attributeSet, int i10) {
        super(context, attributeSet, i10);
        this.f914a = new C0005a();
        TypedValue typedValue = new TypedValue();
        if (!context.getTheme().resolveAttribute(R$attr.actionBarPopupTheme, typedValue, true) || typedValue.resourceId == 0) {
            this.f915b = context;
        } else {
            this.f915b = new ContextThemeWrapper(context, typedValue.resourceId);
        }
    }
}
