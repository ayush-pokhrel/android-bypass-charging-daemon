package androidx.appcompat.widget;

import android.graphics.Rect;

/* JADX INFO: compiled from: FitWindowsViewGroup.java */
/* JADX INFO: loaded from: classes.dex */
public interface v {
    void a(Rect rect);
}
