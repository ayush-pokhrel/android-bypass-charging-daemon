package androidx.appcompat.widget;

import android.R;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.Window;
import androidx.appcompat.R$attr;
import androidx.appcompat.R$drawable;
import androidx.appcompat.R$id;
import androidx.appcompat.R$string;
import androidx.appcompat.R$styleable;
import androidx.appcompat.view.menu.ActionMenuItem;
import androidx.appcompat.view.menu.MenuBuilder;
import androidx.appcompat.view.menu.MenuPresenter;

/* JADX INFO: compiled from: ToolbarWidgetWrapper.java */
/* JADX INFO: loaded from: classes.dex */
public class l0 implements s {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    Toolbar f1015a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private int f1016b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private View f1017c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private View f1018d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private Drawable f1019e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private Drawable f1020f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private Drawable f1021g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private boolean f1022h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    CharSequence f1023i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private CharSequence f1024j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    private CharSequence f1025k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    Window.Callback f1026l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    boolean f1027m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    private ActionMenuPresenter f1028n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    private int f1029o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    private int f1030p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    private Drawable f1031q;

    /* JADX INFO: compiled from: ToolbarWidgetWrapper.java */
    class a implements View.OnClickListener {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        final ActionMenuItem f1032a;

        a() {
            this.f1032a = new ActionMenuItem(l0.this.f1015a.getContext(), 0, R.id.home, 0, 0, l0.this.f1023i);
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            l0 l0Var = l0.this;
            Window.Callback callback = l0Var.f1026l;
            if (callback == null || !l0Var.f1027m) {
                return;
            }
            callback.onMenuItemSelected(0, this.f1032a);
        }
    }

    /* JADX INFO: compiled from: ToolbarWidgetWrapper.java */
    class b extends androidx.core.view.p0 {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private boolean f1034a = false;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        final /* synthetic */ int f1035b;

        b(int i10) {
            this.f1035b = i10;
        }

        @Override // androidx.core.view.p0, androidx.core.view.o0
        public void a(View view) {
            this.f1034a = true;
        }

        @Override // androidx.core.view.o0
        public void b(View view) {
            if (this.f1034a) {
                return;
            }
            l0.this.f1015a.setVisibility(this.f1035b);
        }

        @Override // androidx.core.view.p0, androidx.core.view.o0
        public void c(View view) {
            l0.this.f1015a.setVisibility(0);
        }
    }

    public l0(Toolbar toolbar, boolean z10) {
        this(toolbar, z10, R$string.abc_action_bar_up_description, R$drawable.abc_ic_ab_back_material);
    }

    private void F(CharSequence charSequence) {
        this.f1023i = charSequence;
        if ((this.f1016b & 8) != 0) {
            this.f1015a.setTitle(charSequence);
            if (this.f1022h) {
                androidx.core.view.h0.o0(this.f1015a.getRootView(), charSequence);
            }
        }
    }

    private void G() {
        if ((this.f1016b & 4) != 0) {
            if (TextUtils.isEmpty(this.f1025k)) {
                this.f1015a.setNavigationContentDescription(this.f1030p);
            } else {
                this.f1015a.setNavigationContentDescription(this.f1025k);
            }
        }
    }

    private void H() {
        if ((this.f1016b & 4) == 0) {
            this.f1015a.setNavigationIcon((Drawable) null);
            return;
        }
        Toolbar toolbar = this.f1015a;
        Drawable drawable = this.f1021g;
        if (drawable == null) {
            drawable = this.f1031q;
        }
        toolbar.setNavigationIcon(drawable);
    }

    private void I() {
        Drawable drawable;
        int i10 = this.f1016b;
        if ((i10 & 2) == 0) {
            drawable = null;
        } else if ((i10 & 1) == 0 || (drawable = this.f1020f) == null) {
            drawable = this.f1019e;
        }
        this.f1015a.setLogo(drawable);
    }

    private int w() {
        if (this.f1015a.getNavigationIcon() == null) {
            return 11;
        }
        this.f1031q = this.f1015a.getNavigationIcon();
        return 15;
    }

    public void A(int i10) {
        B(i10 == 0 ? null : getContext().getString(i10));
    }

    public void B(CharSequence charSequence) {
        this.f1025k = charSequence;
        G();
    }

    public void C(Drawable drawable) {
        this.f1021g = drawable;
        H();
    }

    public void D(CharSequence charSequence) {
        this.f1024j = charSequence;
        if ((this.f1016b & 8) != 0) {
            this.f1015a.setSubtitle(charSequence);
        }
    }

    public void E(CharSequence charSequence) {
        this.f1022h = true;
        F(charSequence);
    }

    @Override // androidx.appcompat.widget.s
    public void a(Menu menu, MenuPresenter.Callback callback) {
        if (this.f1028n == null) {
            ActionMenuPresenter actionMenuPresenter = new ActionMenuPresenter(this.f1015a.getContext());
            this.f1028n = actionMenuPresenter;
            actionMenuPresenter.setId(R$id.action_menu_presenter);
        }
        this.f1028n.setCallback(callback);
        this.f1015a.setMenu((MenuBuilder) menu, this.f1028n);
    }

    @Override // androidx.appcompat.widget.s
    public boolean b() {
        return this.f1015a.isOverflowMenuShowing();
    }

    @Override // androidx.appcompat.widget.s
    public void c() {
        this.f1027m = true;
    }

    @Override // androidx.appcompat.widget.s
    public void collapseActionView() {
        this.f1015a.collapseActionView();
    }

    @Override // androidx.appcompat.widget.s
    public boolean d() {
        return this.f1015a.isOverflowMenuShowPending();
    }

    @Override // androidx.appcompat.widget.s
    public boolean e() {
        return this.f1015a.hideOverflowMenu();
    }

    @Override // androidx.appcompat.widget.s
    public boolean f() {
        return this.f1015a.showOverflowMenu();
    }

    @Override // androidx.appcompat.widget.s
    public boolean g() {
        return this.f1015a.canShowOverflowMenu();
    }

    @Override // androidx.appcompat.widget.s
    public Context getContext() {
        return this.f1015a.getContext();
    }

    @Override // androidx.appcompat.widget.s
    public CharSequence getTitle() {
        return this.f1015a.getTitle();
    }

    @Override // androidx.appcompat.widget.s
    public void h() {
        this.f1015a.dismissPopupMenus();
    }

    @Override // androidx.appcompat.widget.s
    public void i(MenuPresenter.Callback callback, MenuBuilder.Callback callback2) {
        this.f1015a.setMenuCallbacks(callback, callback2);
    }

    @Override // androidx.appcompat.widget.s
    public void j(ScrollingTabContainerView scrollingTabContainerView) {
        View view = this.f1017c;
        if (view != null) {
            ViewParent parent = view.getParent();
            Toolbar toolbar = this.f1015a;
            if (parent == toolbar) {
                toolbar.removeView(this.f1017c);
            }
        }
        this.f1017c = scrollingTabContainerView;
        if (scrollingTabContainerView == null || this.f1029o != 2) {
            return;
        }
        this.f1015a.addView(scrollingTabContainerView, 0);
        Toolbar.LayoutParams layoutParams = (Toolbar.LayoutParams) this.f1017c.getLayoutParams();
        ((ViewGroup.MarginLayoutParams) layoutParams).width = -2;
        ((ViewGroup.MarginLayoutParams) layoutParams).height = -2;
        layoutParams.gravity = 8388691;
        scrollingTabContainerView.setAllowCollapse(true);
    }

    @Override // androidx.appcompat.widget.s
    public ViewGroup k() {
        return this.f1015a;
    }

    @Override // androidx.appcompat.widget.s
    public boolean m() {
        return this.f1015a.hasExpandedActionView();
    }

    @Override // androidx.appcompat.widget.s
    public void n(int i10) {
        View view;
        int i11 = this.f1016b ^ i10;
        this.f1016b = i10;
        if (i11 != 0) {
            if ((i11 & 4) != 0) {
                if ((i10 & 4) != 0) {
                    G();
                }
                H();
            }
            if ((i11 & 3) != 0) {
                I();
            }
            if ((i11 & 8) != 0) {
                if ((i10 & 8) != 0) {
                    this.f1015a.setTitle(this.f1023i);
                    this.f1015a.setSubtitle(this.f1024j);
                } else {
                    this.f1015a.setTitle((CharSequence) null);
                    this.f1015a.setSubtitle((CharSequence) null);
                }
            }
            if ((i11 & 16) == 0 || (view = this.f1018d) == null) {
                return;
            }
            if ((i10 & 16) != 0) {
                this.f1015a.addView(view);
            } else {
                this.f1015a.removeView(view);
            }
        }
    }

    @Override // androidx.appcompat.widget.s
    public int o() {
        return this.f1016b;
    }

    @Override // androidx.appcompat.widget.s
    public Menu p() {
        return this.f1015a.getMenu();
    }

    @Override // androidx.appcompat.widget.s
    public void q(int i10) {
        z(i10 != 0 ? h.a.b(getContext(), i10) : null);
    }

    @Override // androidx.appcompat.widget.s
    public int r() {
        return this.f1029o;
    }

    @Override // androidx.appcompat.widget.s
    public androidx.core.view.n0 s(int i10, long j10) {
        return androidx.core.view.h0.d(this.f1015a).b(i10 == 0 ? 1.0f : 0.0f).f(j10).h(new b(i10));
    }

    @Override // androidx.appcompat.widget.s
    public void setIcon(int i10) {
        setIcon(i10 != 0 ? h.a.b(getContext(), i10) : null);
    }

    @Override // androidx.appcompat.widget.s
    public void setVisibility(int i10) {
        this.f1015a.setVisibility(i10);
    }

    @Override // androidx.appcompat.widget.s
    public void setWindowCallback(Window.Callback callback) {
        this.f1026l = callback;
    }

    @Override // androidx.appcompat.widget.s
    public void setWindowTitle(CharSequence charSequence) {
        if (this.f1022h) {
            return;
        }
        F(charSequence);
    }

    @Override // androidx.appcompat.widget.s
    public void t() {
        Log.i("ToolbarWidgetWrapper", "Progress display unsupported");
    }

    @Override // androidx.appcompat.widget.s
    public void u() {
        Log.i("ToolbarWidgetWrapper", "Progress display unsupported");
    }

    @Override // androidx.appcompat.widget.s
    public void v(boolean z10) {
        this.f1015a.setCollapsible(z10);
    }

    public void x(View view) {
        View view2 = this.f1018d;
        if (view2 != null && (this.f1016b & 16) != 0) {
            this.f1015a.removeView(view2);
        }
        this.f1018d = view;
        if (view == null || (this.f1016b & 16) == 0) {
            return;
        }
        this.f1015a.addView(view);
    }

    public void y(int i10) {
        if (i10 == this.f1030p) {
            return;
        }
        this.f1030p = i10;
        if (TextUtils.isEmpty(this.f1015a.getNavigationContentDescription())) {
            A(this.f1030p);
        }
    }

    public void z(Drawable drawable) {
        this.f1020f = drawable;
        I();
    }

    public l0(Toolbar toolbar, boolean z10, int i10, int i11) {
        Drawable drawable;
        this.f1029o = 0;
        this.f1030p = 0;
        this.f1015a = toolbar;
        this.f1023i = toolbar.getTitle();
        this.f1024j = toolbar.getSubtitle();
        this.f1022h = this.f1023i != null;
        this.f1021g = toolbar.getNavigationIcon();
        h0 h0VarW = h0.w(toolbar.getContext(), null, R$styleable.ActionBar, R$attr.actionBarStyle, 0);
        this.f1031q = h0VarW.g(R$styleable.ActionBar_homeAsUpIndicator);
        if (z10) {
            CharSequence charSequenceP = h0VarW.p(R$styleable.ActionBar_title);
            if (!TextUtils.isEmpty(charSequenceP)) {
                E(charSequenceP);
            }
            CharSequence charSequenceP2 = h0VarW.p(R$styleable.ActionBar_subtitle);
            if (!TextUtils.isEmpty(charSequenceP2)) {
                D(charSequenceP2);
            }
            Drawable drawableG = h0VarW.g(R$styleable.ActionBar_logo);
            if (drawableG != null) {
                z(drawableG);
            }
            Drawable drawableG2 = h0VarW.g(R$styleable.ActionBar_icon);
            if (drawableG2 != null) {
                setIcon(drawableG2);
            }
            if (this.f1021g == null && (drawable = this.f1031q) != null) {
                C(drawable);
            }
            n(h0VarW.k(R$styleable.ActionBar_displayOptions, 0));
            int iN = h0VarW.n(R$styleable.ActionBar_customNavigationLayout, 0);
            if (iN != 0) {
                x(LayoutInflater.from(this.f1015a.getContext()).inflate(iN, (ViewGroup) this.f1015a, false));
                n(this.f1016b | 16);
            }
            int iM = h0VarW.m(R$styleable.ActionBar_height, 0);
            if (iM > 0) {
                ViewGroup.LayoutParams layoutParams = this.f1015a.getLayoutParams();
                layoutParams.height = iM;
                this.f1015a.setLayoutParams(layoutParams);
            }
            int iE = h0VarW.e(R$styleable.ActionBar_contentInsetStart, -1);
            int iE2 = h0VarW.e(R$styleable.ActionBar_contentInsetEnd, -1);
            if (iE >= 0 || iE2 >= 0) {
                this.f1015a.setContentInsetsRelative(Math.max(iE, 0), Math.max(iE2, 0));
            }
            int iN2 = h0VarW.n(R$styleable.ActionBar_titleTextStyle, 0);
            if (iN2 != 0) {
                Toolbar toolbar2 = this.f1015a;
                toolbar2.setTitleTextAppearance(toolbar2.getContext(), iN2);
            }
            int iN3 = h0VarW.n(R$styleable.ActionBar_subtitleTextStyle, 0);
            if (iN3 != 0) {
                Toolbar toolbar3 = this.f1015a;
                toolbar3.setSubtitleTextAppearance(toolbar3.getContext(), iN3);
            }
            int iN4 = h0VarW.n(R$styleable.ActionBar_popupTheme, 0);
            if (iN4 != 0) {
                this.f1015a.setPopupTheme(iN4);
            }
        } else {
            this.f1016b = w();
        }
        h0VarW.x();
        y(i10);
        this.f1025k = this.f1015a.getNavigationContentDescription();
        this.f1015a.setNavigationOnClickListener(new a());
    }

    @Override // androidx.appcompat.widget.s
    public void setIcon(Drawable drawable) {
        this.f1019e = drawable;
        I();
    }

    @Override // androidx.appcompat.widget.s
    public void l(boolean z10) {
    }
}
