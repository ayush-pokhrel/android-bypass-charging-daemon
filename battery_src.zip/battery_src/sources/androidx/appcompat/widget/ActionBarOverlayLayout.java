package androidx.appcompat.widget;

import android.R;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewPropertyAnimator;
import android.view.Window;
import android.view.WindowInsets;
import android.widget.OverScroller;
import androidx.appcompat.R$attr;
import androidx.appcompat.R$id;
import androidx.appcompat.view.menu.MenuPresenter;
import androidx.core.view.t0;

/* JADX INFO: loaded from: classes.dex */
@SuppressLint({"UnknownNullness"})
public class ActionBarOverlayLayout extends ViewGroup implements r, androidx.core.view.u, androidx.core.view.v {
    static final int[] I = {R$attr.actionBarSize, R.attr.windowContentOverlay};
    private t0 A;
    private d B;
    private OverScroller C;
    ViewPropertyAnimator D;
    final AnimatorListenerAdapter E;
    private final Runnable F;
    private final Runnable G;
    private final androidx.core.view.w H;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private int f624a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private int f625b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private ContentFrameLayout f626c;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    ActionBarContainer f627g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private s f628h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private Drawable f629i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private boolean f630j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    private boolean f631k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private boolean f632l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    private boolean f633m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    boolean f634n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    private int f635o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    private int f636p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    private final Rect f637q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    private final Rect f638r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    private final Rect f639s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    private final Rect f640t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    private final Rect f641u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    private final Rect f642v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    private final Rect f643w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    private t0 f644x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    private t0 f645y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    private t0 f646z;

    public static class LayoutParams extends ViewGroup.MarginLayoutParams {
        public LayoutParams(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }

        public LayoutParams(int i10, int i11) {
            super(i10, i11);
        }

        public LayoutParams(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
        }
    }

    class a extends AnimatorListenerAdapter {
        a() {
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationCancel(Animator animator) {
            ActionBarOverlayLayout actionBarOverlayLayout = ActionBarOverlayLayout.this;
            actionBarOverlayLayout.D = null;
            actionBarOverlayLayout.f634n = false;
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
            ActionBarOverlayLayout actionBarOverlayLayout = ActionBarOverlayLayout.this;
            actionBarOverlayLayout.D = null;
            actionBarOverlayLayout.f634n = false;
        }
    }

    class b implements Runnable {
        b() {
        }

        @Override // java.lang.Runnable
        public void run() {
            ActionBarOverlayLayout.this.u();
            ActionBarOverlayLayout actionBarOverlayLayout = ActionBarOverlayLayout.this;
            actionBarOverlayLayout.D = actionBarOverlayLayout.f627g.animate().translationY(0.0f).setListener(ActionBarOverlayLayout.this.E);
        }
    }

    class c implements Runnable {
        c() {
        }

        @Override // java.lang.Runnable
        public void run() {
            ActionBarOverlayLayout.this.u();
            ActionBarOverlayLayout actionBarOverlayLayout = ActionBarOverlayLayout.this;
            actionBarOverlayLayout.D = actionBarOverlayLayout.f627g.animate().translationY(-ActionBarOverlayLayout.this.f627g.getHeight()).setListener(ActionBarOverlayLayout.this.E);
        }
    }

    public interface d {
        void a();

        void b();

        void c(int i10);

        void d();

        void e(boolean z10);

        void f();
    }

    public ActionBarOverlayLayout(Context context) {
        this(context, null);
    }

    private void A() {
        u();
        this.F.run();
    }

    private boolean B(float f10) {
        this.C.fling(0, 0, 0, (int) f10, 0, 0, Integer.MIN_VALUE, Integer.MAX_VALUE);
        return this.C.getFinalY() > this.f627g.getHeight();
    }

    private void p() {
        u();
        this.G.run();
    }

    /* JADX WARN: Code duplicated, block: B:7:0x0013  */
    private boolean q(View view, Rect rect, boolean z10, boolean z11, boolean z12, boolean z13) {
        boolean z14;
        LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
        if (z10) {
            int i10 = ((ViewGroup.MarginLayoutParams) layoutParams).leftMargin;
            int i11 = rect.left;
            if (i10 != i11) {
                ((ViewGroup.MarginLayoutParams) layoutParams).leftMargin = i11;
                z14 = true;
            } else {
                z14 = false;
            }
        } else {
            z14 = false;
        }
        if (z11) {
            int i12 = ((ViewGroup.MarginLayoutParams) layoutParams).topMargin;
            int i13 = rect.top;
            if (i12 != i13) {
                ((ViewGroup.MarginLayoutParams) layoutParams).topMargin = i13;
                z14 = true;
            }
        }
        if (z13) {
            int i14 = ((ViewGroup.MarginLayoutParams) layoutParams).rightMargin;
            int i15 = rect.right;
            if (i14 != i15) {
                ((ViewGroup.MarginLayoutParams) layoutParams).rightMargin = i15;
                z14 = true;
            }
        }
        if (z12) {
            int i16 = ((ViewGroup.MarginLayoutParams) layoutParams).bottomMargin;
            int i17 = rect.bottom;
            if (i16 != i17) {
                ((ViewGroup.MarginLayoutParams) layoutParams).bottomMargin = i17;
                return true;
            }
        }
        return z14;
    }

    /* JADX WARN: Multi-variable type inference failed */
    private s t(View view) {
        if (view instanceof s) {
            return (s) view;
        }
        if (view instanceof Toolbar) {
            return ((Toolbar) view).getWrapper();
        }
        throw new IllegalStateException("Can't make a decor toolbar out of " + view.getClass().getSimpleName());
    }

    private void v(Context context) {
        TypedArray typedArrayObtainStyledAttributes = getContext().getTheme().obtainStyledAttributes(I);
        this.f624a = typedArrayObtainStyledAttributes.getDimensionPixelSize(0, 0);
        Drawable drawable = typedArrayObtainStyledAttributes.getDrawable(1);
        this.f629i = drawable;
        setWillNotDraw(drawable == null);
        typedArrayObtainStyledAttributes.recycle();
        this.f630j = context.getApplicationInfo().targetSdkVersion < 19;
        this.C = new OverScroller(context);
    }

    private void x() {
        u();
        postDelayed(this.G, 600L);
    }

    private void y() {
        u();
        postDelayed(this.F, 600L);
    }

    @Override // androidx.appcompat.widget.r
    public void a(Menu menu, MenuPresenter.Callback callback) {
        z();
        this.f628h.a(menu, callback);
    }

    @Override // androidx.appcompat.widget.r
    public boolean b() {
        z();
        return this.f628h.b();
    }

    @Override // androidx.appcompat.widget.r
    public void c() {
        z();
        this.f628h.c();
    }

    @Override // android.view.ViewGroup
    protected boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof LayoutParams;
    }

    @Override // androidx.appcompat.widget.r
    public boolean d() {
        z();
        return this.f628h.d();
    }

    @Override // android.view.View
    public void draw(Canvas canvas) {
        super.draw(canvas);
        if (this.f629i == null || this.f630j) {
            return;
        }
        int bottom = this.f627g.getVisibility() == 0 ? (int) (this.f627g.getBottom() + this.f627g.getTranslationY() + 0.5f) : 0;
        this.f629i.setBounds(0, bottom, getWidth(), this.f629i.getIntrinsicHeight() + bottom);
        this.f629i.draw(canvas);
    }

    @Override // androidx.appcompat.widget.r
    public boolean e() {
        z();
        return this.f628h.e();
    }

    @Override // androidx.appcompat.widget.r
    public boolean f() {
        z();
        return this.f628h.f();
    }

    @Override // android.view.View
    protected boolean fitSystemWindows(Rect rect) {
        return super.fitSystemWindows(rect);
    }

    @Override // androidx.appcompat.widget.r
    public boolean g() {
        z();
        return this.f628h.g();
    }

    public int getActionBarHideOffset() {
        ActionBarContainer actionBarContainer = this.f627g;
        if (actionBarContainer != null) {
            return -((int) actionBarContainer.getTranslationY());
        }
        return 0;
    }

    @Override // android.view.ViewGroup
    public int getNestedScrollAxes() {
        return this.H.a();
    }

    public CharSequence getTitle() {
        z();
        return this.f628h.getTitle();
    }

    @Override // androidx.core.view.u
    public void h(View view, View view2, int i10, int i11) {
        if (i11 == 0) {
            onNestedScrollAccepted(view, view2, i10);
        }
    }

    @Override // androidx.core.view.u
    public void i(View view, int i10) {
        if (i10 == 0) {
            onStopNestedScroll(view);
        }
    }

    @Override // androidx.core.view.u
    public void j(View view, int i10, int i11, int[] iArr, int i12) {
        if (i12 == 0) {
            onNestedPreScroll(view, i10, i11, iArr);
        }
    }

    @Override // androidx.appcompat.widget.r
    public void k(int i10) {
        z();
        if (i10 == 2) {
            this.f628h.t();
        } else if (i10 == 5) {
            this.f628h.u();
        } else {
            if (i10 != 109) {
                return;
            }
            setOverlayMode(true);
        }
    }

    @Override // androidx.appcompat.widget.r
    public void l() {
        z();
        this.f628h.h();
    }

    @Override // androidx.core.view.v
    public void m(View view, int i10, int i11, int i12, int i13, int i14, int[] iArr) {
        n(view, i10, i11, i12, i13, i14);
    }

    @Override // androidx.core.view.u
    public void n(View view, int i10, int i11, int i12, int i13, int i14) {
        if (i14 == 0) {
            onNestedScroll(view, i10, i11, i12, i13);
        }
    }

    @Override // androidx.core.view.u
    public boolean o(View view, View view2, int i10, int i11) {
        return i11 == 0 && onStartNestedScroll(view, view2, i10);
    }

    @Override // android.view.View
    public WindowInsets onApplyWindowInsets(WindowInsets windowInsets) {
        z();
        t0 t0VarW = t0.w(windowInsets, this);
        boolean zQ = q(this.f627g, new Rect(t0VarW.j(), t0VarW.l(), t0VarW.k(), t0VarW.i()), true, true, false, true);
        androidx.core.view.h0.e(this, t0VarW, this.f637q);
        Rect rect = this.f637q;
        t0 t0VarN = t0VarW.n(rect.left, rect.top, rect.right, rect.bottom);
        this.f644x = t0VarN;
        boolean z10 = true;
        if (!this.f645y.equals(t0VarN)) {
            this.f645y = this.f644x;
            zQ = true;
        }
        if (this.f638r.equals(this.f637q)) {
            z10 = zQ;
        } else {
            this.f638r.set(this.f637q);
        }
        if (z10) {
            requestLayout();
        }
        return t0VarW.a().c().b().u();
    }

    @Override // android.view.View
    protected void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        v(getContext());
        androidx.core.view.h0.h0(this);
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        u();
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onLayout(boolean z10, int i10, int i11, int i12, int i13) {
        int childCount = getChildCount();
        int paddingLeft = getPaddingLeft();
        int paddingTop = getPaddingTop();
        for (int i14 = 0; i14 < childCount; i14++) {
            View childAt = getChildAt(i14);
            if (childAt.getVisibility() != 8) {
                LayoutParams layoutParams = (LayoutParams) childAt.getLayoutParams();
                int measuredWidth = childAt.getMeasuredWidth();
                int measuredHeight = childAt.getMeasuredHeight();
                int i15 = ((ViewGroup.MarginLayoutParams) layoutParams).leftMargin + paddingLeft;
                int i16 = ((ViewGroup.MarginLayoutParams) layoutParams).topMargin + paddingTop;
                childAt.layout(i15, i16, measuredWidth + i15, measuredHeight + i16);
            }
        }
    }

    @Override // android.view.View
    protected void onMeasure(int i10, int i11) {
        int measuredHeight;
        z();
        measureChildWithMargins(this.f627g, i10, 0, i11, 0);
        LayoutParams layoutParams = (LayoutParams) this.f627g.getLayoutParams();
        int iMax = Math.max(0, this.f627g.getMeasuredWidth() + ((ViewGroup.MarginLayoutParams) layoutParams).leftMargin + ((ViewGroup.MarginLayoutParams) layoutParams).rightMargin);
        int iMax2 = Math.max(0, this.f627g.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) layoutParams).topMargin + ((ViewGroup.MarginLayoutParams) layoutParams).bottomMargin);
        int iCombineMeasuredStates = View.combineMeasuredStates(0, this.f627g.getMeasuredState());
        boolean z10 = (androidx.core.view.h0.I(this) & 256) != 0;
        if (z10) {
            measuredHeight = this.f624a;
            if (this.f632l && this.f627g.getTabContainer() != null) {
                measuredHeight += this.f624a;
            }
        } else {
            measuredHeight = this.f627g.getVisibility() != 8 ? this.f627g.getMeasuredHeight() : 0;
        }
        this.f639s.set(this.f637q);
        t0 t0Var = this.f644x;
        this.f646z = t0Var;
        if (this.f631k || z10) {
            this.f646z = new t0.b(this.f646z).c(androidx.core.graphics.b.b(t0Var.j(), this.f646z.l() + measuredHeight, this.f646z.k(), this.f646z.i())).a();
        } else {
            Rect rect = this.f639s;
            rect.top += measuredHeight;
            rect.bottom = rect.bottom;
            this.f646z = t0Var.n(0, measuredHeight, 0, 0);
        }
        q(this.f626c, this.f639s, true, true, true, true);
        if (!this.A.equals(this.f646z)) {
            t0 t0Var2 = this.f646z;
            this.A = t0Var2;
            androidx.core.view.h0.f(this.f626c, t0Var2);
        }
        measureChildWithMargins(this.f626c, i10, 0, i11, 0);
        LayoutParams layoutParams2 = (LayoutParams) this.f626c.getLayoutParams();
        int iMax3 = Math.max(iMax, this.f626c.getMeasuredWidth() + ((ViewGroup.MarginLayoutParams) layoutParams2).leftMargin + ((ViewGroup.MarginLayoutParams) layoutParams2).rightMargin);
        int iMax4 = Math.max(iMax2, this.f626c.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) layoutParams2).topMargin + ((ViewGroup.MarginLayoutParams) layoutParams2).bottomMargin);
        int iCombineMeasuredStates2 = View.combineMeasuredStates(iCombineMeasuredStates, this.f626c.getMeasuredState());
        setMeasuredDimension(View.resolveSizeAndState(Math.max(iMax3 + getPaddingLeft() + getPaddingRight(), getSuggestedMinimumWidth()), i10, iCombineMeasuredStates2), View.resolveSizeAndState(Math.max(iMax4 + getPaddingTop() + getPaddingBottom(), getSuggestedMinimumHeight()), i11, iCombineMeasuredStates2 << 16));
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public boolean onNestedFling(View view, float f10, float f11, boolean z10) {
        if (!this.f633m || !z10) {
            return false;
        }
        if (B(f11)) {
            p();
        } else {
            A();
        }
        this.f634n = true;
        return true;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public boolean onNestedPreFling(View view, float f10, float f11) {
        return false;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void onNestedScroll(View view, int i10, int i11, int i12, int i13) {
        int i14 = this.f635o + i11;
        this.f635o = i14;
        setActionBarHideOffset(i14);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void onNestedScrollAccepted(View view, View view2, int i10) {
        this.H.b(view, view2, i10);
        this.f635o = getActionBarHideOffset();
        u();
        d dVar = this.B;
        if (dVar != null) {
            dVar.b();
        }
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public boolean onStartNestedScroll(View view, View view2, int i10) {
        if ((i10 & 2) == 0 || this.f627g.getVisibility() != 0) {
            return false;
        }
        return this.f633m;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void onStopNestedScroll(View view) {
        if (this.f633m && !this.f634n) {
            if (this.f635o <= this.f627g.getHeight()) {
                y();
            } else {
                x();
            }
        }
        d dVar = this.B;
        if (dVar != null) {
            dVar.d();
        }
    }

    @Override // android.view.View
    @Deprecated
    public void onWindowSystemUiVisibilityChanged(int i10) {
        super.onWindowSystemUiVisibilityChanged(i10);
        z();
        int i11 = this.f636p ^ i10;
        this.f636p = i10;
        boolean z10 = (i10 & 4) == 0;
        boolean z11 = (i10 & 256) != 0;
        d dVar = this.B;
        if (dVar != null) {
            dVar.e(!z11);
            if (z10 || !z11) {
                this.B.a();
            } else {
                this.B.f();
            }
        }
        if ((i11 & 256) == 0 || this.B == null) {
            return;
        }
        androidx.core.view.h0.h0(this);
    }

    @Override // android.view.View
    protected void onWindowVisibilityChanged(int i10) {
        super.onWindowVisibilityChanged(i10);
        this.f625b = i10;
        d dVar = this.B;
        if (dVar != null) {
            dVar.c(i10);
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.view.ViewGroup
    /* JADX INFO: renamed from: r, reason: merged with bridge method [inline-methods] */
    public LayoutParams generateDefaultLayoutParams() {
        return new LayoutParams(-1, -1);
    }

    @Override // android.view.ViewGroup
    /* JADX INFO: renamed from: s, reason: merged with bridge method [inline-methods] */
    public LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new LayoutParams(getContext(), attributeSet);
    }

    public void setActionBarHideOffset(int i10) {
        u();
        this.f627g.setTranslationY(-Math.max(0, Math.min(i10, this.f627g.getHeight())));
    }

    public void setActionBarVisibilityCallback(d dVar) {
        this.B = dVar;
        if (getWindowToken() != null) {
            this.B.c(this.f625b);
            int i10 = this.f636p;
            if (i10 != 0) {
                onWindowSystemUiVisibilityChanged(i10);
                androidx.core.view.h0.h0(this);
            }
        }
    }

    public void setHasNonEmbeddedTabs(boolean z10) {
        this.f632l = z10;
    }

    public void setHideOnContentScrollEnabled(boolean z10) {
        if (z10 != this.f633m) {
            this.f633m = z10;
            if (z10) {
                return;
            }
            u();
            setActionBarHideOffset(0);
        }
    }

    public void setIcon(int i10) {
        z();
        this.f628h.setIcon(i10);
    }

    public void setLogo(int i10) {
        z();
        this.f628h.q(i10);
    }

    public void setOverlayMode(boolean z10) {
        this.f631k = z10;
        this.f630j = z10 && getContext().getApplicationInfo().targetSdkVersion < 19;
    }

    @Override // androidx.appcompat.widget.r
    public void setWindowCallback(Window.Callback callback) {
        z();
        this.f628h.setWindowCallback(callback);
    }

    @Override // androidx.appcompat.widget.r
    public void setWindowTitle(CharSequence charSequence) {
        z();
        this.f628h.setWindowTitle(charSequence);
    }

    @Override // android.view.ViewGroup
    public boolean shouldDelayChildPressedState() {
        return false;
    }

    void u() {
        removeCallbacks(this.F);
        removeCallbacks(this.G);
        ViewPropertyAnimator viewPropertyAnimator = this.D;
        if (viewPropertyAnimator != null) {
            viewPropertyAnimator.cancel();
        }
    }

    public boolean w() {
        return this.f631k;
    }

    void z() {
        if (this.f626c == null) {
            this.f626c = (ContentFrameLayout) findViewById(R$id.action_bar_activity_content);
            this.f627g = (ActionBarContainer) findViewById(R$id.action_bar_container);
            this.f628h = t(findViewById(R$id.action_bar));
        }
    }

    public ActionBarOverlayLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f625b = 0;
        this.f637q = new Rect();
        this.f638r = new Rect();
        this.f639s = new Rect();
        this.f640t = new Rect();
        this.f641u = new Rect();
        this.f642v = new Rect();
        this.f643w = new Rect();
        t0 t0Var = t0.f2384b;
        this.f644x = t0Var;
        this.f645y = t0Var;
        this.f646z = t0Var;
        this.A = t0Var;
        this.E = new a();
        this.F = new b();
        this.G = new c();
        v(context);
        this.H = new androidx.core.view.w(this);
    }

    @Override // android.view.ViewGroup
    protected ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return new LayoutParams(layoutParams);
    }

    public void setIcon(Drawable drawable) {
        z();
        this.f628h.setIcon(drawable);
    }

    public void setShowingForActionMode(boolean z10) {
    }

    public void setUiOptions(int i10) {
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void onNestedPreScroll(View view, int i10, int i11, int[] iArr) {
    }
}
