package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.RippleDrawable;
import android.util.AttributeSet;
import android.widget.ImageView;
import androidx.appcompat.R$styleable;

/* JADX INFO: compiled from: AppCompatImageHelper.java */
/* JADX INFO: loaded from: classes.dex */
public class k {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final ImageView f1006a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private f0 f1007b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private f0 f1008c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private f0 f1009d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private int f1010e = 0;

    public k(ImageView imageView) {
        this.f1006a = imageView;
    }

    private boolean a(Drawable drawable) {
        if (this.f1009d == null) {
            this.f1009d = new f0();
        }
        f0 f0Var = this.f1009d;
        f0Var.a();
        ColorStateList colorStateListA = androidx.core.widget.g.a(this.f1006a);
        if (colorStateListA != null) {
            f0Var.f986d = true;
            f0Var.f983a = colorStateListA;
        }
        PorterDuff.Mode modeB = androidx.core.widget.g.b(this.f1006a);
        if (modeB != null) {
            f0Var.f985c = true;
            f0Var.f984b = modeB;
        }
        if (!f0Var.f986d && !f0Var.f985c) {
            return false;
        }
        g.i(drawable, f0Var, this.f1006a.getDrawableState());
        return true;
    }

    private boolean l() {
        return this.f1007b != null;
    }

    void b() {
        if (this.f1006a.getDrawable() != null) {
            this.f1006a.getDrawable().setLevel(this.f1010e);
        }
    }

    void c() {
        Drawable drawable = this.f1006a.getDrawable();
        if (drawable != null) {
            t.b(drawable);
        }
        if (drawable != null) {
            if (l() && a(drawable)) {
                return;
            }
            f0 f0Var = this.f1008c;
            if (f0Var != null) {
                g.i(drawable, f0Var, this.f1006a.getDrawableState());
                return;
            }
            f0 f0Var2 = this.f1007b;
            if (f0Var2 != null) {
                g.i(drawable, f0Var2, this.f1006a.getDrawableState());
            }
        }
    }

    ColorStateList d() {
        f0 f0Var = this.f1008c;
        if (f0Var != null) {
            return f0Var.f983a;
        }
        return null;
    }

    PorterDuff.Mode e() {
        f0 f0Var = this.f1008c;
        if (f0Var != null) {
            return f0Var.f984b;
        }
        return null;
    }

    boolean f() {
        return !(this.f1006a.getBackground() instanceof RippleDrawable);
    }

    public void g(AttributeSet attributeSet, int i10) {
        int iN;
        Context context = this.f1006a.getContext();
        int[] iArr = R$styleable.AppCompatImageView;
        h0 h0VarW = h0.w(context, attributeSet, iArr, i10, 0);
        ImageView imageView = this.f1006a;
        androidx.core.view.h0.j0(imageView, imageView.getContext(), iArr, attributeSet, h0VarW.r(), i10, 0);
        try {
            Drawable drawable = this.f1006a.getDrawable();
            if (drawable == null && (iN = h0VarW.n(R$styleable.AppCompatImageView_srcCompat, -1)) != -1 && (drawable = h.a.b(this.f1006a.getContext(), iN)) != null) {
                this.f1006a.setImageDrawable(drawable);
            }
            if (drawable != null) {
                t.b(drawable);
            }
            int i11 = R$styleable.AppCompatImageView_tint;
            if (h0VarW.s(i11)) {
                androidx.core.widget.g.c(this.f1006a, h0VarW.c(i11));
            }
            int i12 = R$styleable.AppCompatImageView_tintMode;
            if (h0VarW.s(i12)) {
                androidx.core.widget.g.d(this.f1006a, t.d(h0VarW.k(i12, -1), null));
            }
        } finally {
            h0VarW.x();
        }
    }

    void h(Drawable drawable) {
        this.f1010e = drawable.getLevel();
    }

    public void i(int i10) {
        if (i10 != 0) {
            Drawable drawableB = h.a.b(this.f1006a.getContext(), i10);
            if (drawableB != null) {
                t.b(drawableB);
            }
            this.f1006a.setImageDrawable(drawableB);
        } else {
            this.f1006a.setImageDrawable(null);
        }
        c();
    }

    void j(ColorStateList colorStateList) {
        if (this.f1008c == null) {
            this.f1008c = new f0();
        }
        f0 f0Var = this.f1008c;
        f0Var.f983a = colorStateList;
        f0Var.f986d = true;
        c();
    }

    void k(PorterDuff.Mode mode) {
        if (this.f1008c == null) {
            this.f1008c = new f0();
        }
        f0 f0Var = this.f1008c;
        f0Var.f984b = mode;
        f0Var.f985c = true;
        c();
    }
}
