package androidx.appcompat.widget;

import android.view.View;

/* JADX INFO: compiled from: TooltipCompat.java */
/* JADX INFO: loaded from: classes.dex */
public class m0 {

    /* JADX INFO: compiled from: TooltipCompat.java */
    static class a {
        static void a(View view, CharSequence charSequence) {
            view.setTooltipText(charSequence);
        }
    }

    public static void a(View view, CharSequence charSequence) {
        a.a(view, charSequence);
    }
}
