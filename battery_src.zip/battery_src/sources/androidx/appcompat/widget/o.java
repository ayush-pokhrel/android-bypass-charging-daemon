package androidx.appcompat.widget;

import android.widget.TextView;

/* JADX INFO: compiled from: AppCompatTextClassifierHelper.java */
/* JADX INFO: loaded from: classes.dex */
final class o {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private TextView f1045a;

    o(TextView textView) {
        this.f1045a = (TextView) a0.h.e(textView);
    }
}
