package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import androidx.appcompat.R$styleable;

/* JADX INFO: compiled from: AppCompatBackgroundHelper.java */
/* JADX INFO: loaded from: classes.dex */
class d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final View f961a;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private f0 f964d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private f0 f965e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private f0 f966f;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private int f963c = -1;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private final g f962b = g.b();

    d(View view) {
        this.f961a = view;
    }

    private boolean a(Drawable drawable) {
        if (this.f966f == null) {
            this.f966f = new f0();
        }
        f0 f0Var = this.f966f;
        f0Var.a();
        ColorStateList colorStateListO = androidx.core.view.h0.o(this.f961a);
        if (colorStateListO != null) {
            f0Var.f986d = true;
            f0Var.f983a = colorStateListO;
        }
        PorterDuff.Mode modeP = androidx.core.view.h0.p(this.f961a);
        if (modeP != null) {
            f0Var.f985c = true;
            f0Var.f984b = modeP;
        }
        if (!f0Var.f986d && !f0Var.f985c) {
            return false;
        }
        g.i(drawable, f0Var, this.f961a.getDrawableState());
        return true;
    }

    private boolean k() {
        return this.f964d != null;
    }

    void b() {
        Drawable background = this.f961a.getBackground();
        if (background != null) {
            if (k() && a(background)) {
                return;
            }
            f0 f0Var = this.f965e;
            if (f0Var != null) {
                g.i(background, f0Var, this.f961a.getDrawableState());
                return;
            }
            f0 f0Var2 = this.f964d;
            if (f0Var2 != null) {
                g.i(background, f0Var2, this.f961a.getDrawableState());
            }
        }
    }

    ColorStateList c() {
        f0 f0Var = this.f965e;
        if (f0Var != null) {
            return f0Var.f983a;
        }
        return null;
    }

    PorterDuff.Mode d() {
        f0 f0Var = this.f965e;
        if (f0Var != null) {
            return f0Var.f984b;
        }
        return null;
    }

    void e(AttributeSet attributeSet, int i10) {
        Context context = this.f961a.getContext();
        int[] iArr = R$styleable.ViewBackgroundHelper;
        h0 h0VarW = h0.w(context, attributeSet, iArr, i10, 0);
        View view = this.f961a;
        androidx.core.view.h0.j0(view, view.getContext(), iArr, attributeSet, h0VarW.r(), i10, 0);
        try {
            int i11 = R$styleable.ViewBackgroundHelper_android_background;
            if (h0VarW.s(i11)) {
                this.f963c = h0VarW.n(i11, -1);
                ColorStateList colorStateListF = this.f962b.f(this.f961a.getContext(), this.f963c);
                if (colorStateListF != null) {
                    h(colorStateListF);
                }
            }
            int i12 = R$styleable.ViewBackgroundHelper_backgroundTint;
            if (h0VarW.s(i12)) {
                androidx.core.view.h0.q0(this.f961a, h0VarW.c(i12));
            }
            int i13 = R$styleable.ViewBackgroundHelper_backgroundTintMode;
            if (h0VarW.s(i13)) {
                androidx.core.view.h0.r0(this.f961a, t.d(h0VarW.k(i13, -1), null));
            }
        } finally {
            h0VarW.x();
        }
    }

    void f(Drawable drawable) {
        this.f963c = -1;
        h(null);
        b();
    }

    void g(int i10) {
        this.f963c = i10;
        g gVar = this.f962b;
        h(gVar != null ? gVar.f(this.f961a.getContext(), i10) : null);
        b();
    }

    void h(ColorStateList colorStateList) {
        if (colorStateList != null) {
            if (this.f964d == null) {
                this.f964d = new f0();
            }
            f0 f0Var = this.f964d;
            f0Var.f983a = colorStateList;
            f0Var.f986d = true;
        } else {
            this.f964d = null;
        }
        b();
    }

    void i(ColorStateList colorStateList) {
        if (this.f965e == null) {
            this.f965e = new f0();
        }
        f0 f0Var = this.f965e;
        f0Var.f983a = colorStateList;
        f0Var.f986d = true;
        b();
    }

    void j(PorterDuff.Mode mode) {
        if (this.f965e == null) {
            this.f965e = new f0();
        }
        f0 f0Var = this.f965e;
        f0Var.f984b = mode;
        f0Var.f985c = true;
        b();
    }
}
