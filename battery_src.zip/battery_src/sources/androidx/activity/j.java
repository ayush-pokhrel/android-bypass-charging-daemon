package androidx.activity;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.window.OnBackInvokedDispatcher;
import androidx.lifecycle.Lifecycle;

/* JADX INFO: compiled from: ComponentDialog.kt */
/* JADX INFO: loaded from: classes.dex */
public class j extends Dialog implements androidx.lifecycle.l, p, p0.c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private androidx.lifecycle.n f250a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private final p0.b f251b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private final OnBackPressedDispatcher f252c;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public j(Context context, int i10) {
        super(context, i10);
        kotlin.jvm.internal.h.e(context, "context");
        this.f251b = p0.b.f15929d.a(this);
        this.f252c = new OnBackPressedDispatcher(new Runnable() { // from class: androidx.activity.i
            @Override // java.lang.Runnable
            public final void run() {
                j.e(this.f249a);
            }
        });
    }

    private final androidx.lifecycle.n d() {
        androidx.lifecycle.n nVar = this.f250a;
        if (nVar != null) {
            return nVar;
        }
        androidx.lifecycle.n nVar2 = new androidx.lifecycle.n(this);
        this.f250a = nVar2;
        return nVar2;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void e(j this$0) {
        kotlin.jvm.internal.h.e(this$0, "this$0");
        super.onBackPressed();
    }

    @Override // androidx.lifecycle.l
    public Lifecycle getLifecycle() {
        return d();
    }

    @Override // androidx.activity.p
    public final OnBackPressedDispatcher getOnBackPressedDispatcher() {
        return this.f252c;
    }

    @Override // p0.c
    public androidx.savedstate.a getSavedStateRegistry() {
        return this.f251b.b();
    }

    @Override // android.app.Dialog
    public void onBackPressed() {
        this.f252c.k();
    }

    @Override // android.app.Dialog
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        OnBackPressedDispatcher onBackPressedDispatcher = this.f252c;
        OnBackInvokedDispatcher onBackInvokedDispatcher = getOnBackInvokedDispatcher();
        kotlin.jvm.internal.h.d(onBackInvokedDispatcher, "onBackInvokedDispatcher");
        onBackPressedDispatcher.n(onBackInvokedDispatcher);
        this.f251b.d(bundle);
        d().i(Lifecycle.Event.ON_CREATE);
    }

    @Override // android.app.Dialog
    public Bundle onSaveInstanceState() {
        Bundle bundleOnSaveInstanceState = super.onSaveInstanceState();
        kotlin.jvm.internal.h.d(bundleOnSaveInstanceState, "super.onSaveInstanceState()");
        this.f251b.e(bundleOnSaveInstanceState);
        return bundleOnSaveInstanceState;
    }

    @Override // android.app.Dialog
    protected void onStart() {
        super.onStart();
        d().i(Lifecycle.Event.ON_RESUME);
    }

    @Override // android.app.Dialog
    protected void onStop() {
        d().i(Lifecycle.Event.ON_DESTROY);
        this.f250a = null;
        super.onStop();
    }
}
