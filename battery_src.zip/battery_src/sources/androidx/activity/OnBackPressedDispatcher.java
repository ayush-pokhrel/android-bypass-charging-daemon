package androidx.activity;

import android.window.BackEvent;
import android.window.OnBackAnimationCallback;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;
import androidx.lifecycle.Lifecycle;
import java.util.Iterator;
import java.util.ListIterator;

/* JADX INFO: compiled from: OnBackPressedDispatcher.kt */
/* JADX INFO: loaded from: classes.dex */
public final class OnBackPressedDispatcher {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final Runnable f218a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private final a0.a<Boolean> f219b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private final kotlin.collections.d<n> f220c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private n f221d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private OnBackInvokedCallback f222e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private OnBackInvokedDispatcher f223f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private boolean f224g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private boolean f225h;

    /* JADX INFO: compiled from: OnBackPressedDispatcher.kt */
    private final class LifecycleOnBackPressedCancellable implements androidx.lifecycle.i, androidx.activity.c {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private final Lifecycle f226a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private final n f227b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        private androidx.activity.c f228c;

        /* JADX INFO: renamed from: g, reason: collision with root package name */
        final /* synthetic */ OnBackPressedDispatcher f229g;

        public LifecycleOnBackPressedCancellable(OnBackPressedDispatcher onBackPressedDispatcher, Lifecycle lifecycle, n onBackPressedCallback) {
            kotlin.jvm.internal.h.e(lifecycle, "lifecycle");
            kotlin.jvm.internal.h.e(onBackPressedCallback, "onBackPressedCallback");
            this.f229g = onBackPressedDispatcher;
            this.f226a = lifecycle;
            this.f227b = onBackPressedCallback;
            lifecycle.a(this);
        }

        @Override // androidx.lifecycle.i
        public void a(androidx.lifecycle.l source, Lifecycle.Event event) {
            kotlin.jvm.internal.h.e(source, "source");
            kotlin.jvm.internal.h.e(event, "event");
            if (event == Lifecycle.Event.ON_START) {
                this.f228c = this.f229g.i(this.f227b);
                return;
            }
            if (event != Lifecycle.Event.ON_STOP) {
                if (event == Lifecycle.Event.ON_DESTROY) {
                    cancel();
                }
            } else {
                androidx.activity.c cVar = this.f228c;
                if (cVar != null) {
                    cVar.cancel();
                }
            }
        }

        @Override // androidx.activity.c
        public void cancel() {
            this.f226a.d(this);
            this.f227b.i(this);
            androidx.activity.c cVar = this.f228c;
            if (cVar != null) {
                cVar.cancel();
            }
            this.f228c = null;
        }
    }

    /* JADX INFO: compiled from: OnBackPressedDispatcher.kt */
    public static final class a {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public static final a f230a = new a();

        private a() {
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static final void c(bb.a onBackInvoked) {
            kotlin.jvm.internal.h.e(onBackInvoked, "$onBackInvoked");
            onBackInvoked.invoke();
        }

        public final OnBackInvokedCallback b(final bb.a<ra.o> onBackInvoked) {
            kotlin.jvm.internal.h.e(onBackInvoked, "onBackInvoked");
            return new OnBackInvokedCallback() { // from class: androidx.activity.o
                @Override // android.window.OnBackInvokedCallback
                public final void onBackInvoked() {
                    OnBackPressedDispatcher.a.c(onBackInvoked);
                }
            };
        }

        public final void d(Object dispatcher, int i10, Object callback) {
            kotlin.jvm.internal.h.e(dispatcher, "dispatcher");
            kotlin.jvm.internal.h.e(callback, "callback");
            ((OnBackInvokedDispatcher) dispatcher).registerOnBackInvokedCallback(i10, (OnBackInvokedCallback) callback);
        }

        public final void e(Object dispatcher, Object callback) {
            kotlin.jvm.internal.h.e(dispatcher, "dispatcher");
            kotlin.jvm.internal.h.e(callback, "callback");
            ((OnBackInvokedDispatcher) dispatcher).unregisterOnBackInvokedCallback((OnBackInvokedCallback) callback);
        }
    }

    /* JADX INFO: compiled from: OnBackPressedDispatcher.kt */
    public static final class b {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public static final b f231a = new b();

        /* JADX INFO: compiled from: OnBackPressedDispatcher.kt */
        public static final class a implements OnBackAnimationCallback {

            /* JADX INFO: renamed from: a, reason: collision with root package name */
            final /* synthetic */ bb.l<androidx.activity.b, ra.o> f232a;

            /* JADX INFO: renamed from: b, reason: collision with root package name */
            final /* synthetic */ bb.l<androidx.activity.b, ra.o> f233b;

            /* JADX INFO: renamed from: c, reason: collision with root package name */
            final /* synthetic */ bb.a<ra.o> f234c;

            /* JADX INFO: renamed from: g, reason: collision with root package name */
            final /* synthetic */ bb.a<ra.o> f235g;

            /* JADX WARN: Multi-variable type inference failed */
            a(bb.l<? super androidx.activity.b, ra.o> lVar, bb.l<? super androidx.activity.b, ra.o> lVar2, bb.a<ra.o> aVar, bb.a<ra.o> aVar2) {
                this.f232a = lVar;
                this.f233b = lVar2;
                this.f234c = aVar;
                this.f235g = aVar2;
            }

            @Override // android.window.OnBackAnimationCallback
            public void onBackCancelled() {
                this.f235g.invoke();
            }

            @Override // android.window.OnBackInvokedCallback
            public void onBackInvoked() {
                this.f234c.invoke();
            }

            @Override // android.window.OnBackAnimationCallback
            public void onBackProgressed(BackEvent backEvent) {
                kotlin.jvm.internal.h.e(backEvent, "backEvent");
                this.f233b.invoke(new androidx.activity.b(backEvent));
            }

            @Override // android.window.OnBackAnimationCallback
            public void onBackStarted(BackEvent backEvent) {
                kotlin.jvm.internal.h.e(backEvent, "backEvent");
                this.f232a.invoke(new androidx.activity.b(backEvent));
            }
        }

        private b() {
        }

        public final OnBackInvokedCallback a(bb.l<? super androidx.activity.b, ra.o> onBackStarted, bb.l<? super androidx.activity.b, ra.o> onBackProgressed, bb.a<ra.o> onBackInvoked, bb.a<ra.o> onBackCancelled) {
            kotlin.jvm.internal.h.e(onBackStarted, "onBackStarted");
            kotlin.jvm.internal.h.e(onBackProgressed, "onBackProgressed");
            kotlin.jvm.internal.h.e(onBackInvoked, "onBackInvoked");
            kotlin.jvm.internal.h.e(onBackCancelled, "onBackCancelled");
            return new a(onBackStarted, onBackProgressed, onBackInvoked, onBackCancelled);
        }
    }

    /* JADX INFO: compiled from: OnBackPressedDispatcher.kt */
    private final class c implements androidx.activity.c {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private final n f236a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        final /* synthetic */ OnBackPressedDispatcher f237b;

        public c(OnBackPressedDispatcher onBackPressedDispatcher, n onBackPressedCallback) {
            kotlin.jvm.internal.h.e(onBackPressedCallback, "onBackPressedCallback");
            this.f237b = onBackPressedDispatcher;
            this.f236a = onBackPressedCallback;
        }

        @Override // androidx.activity.c
        public void cancel() {
            this.f237b.f220c.remove(this.f236a);
            if (kotlin.jvm.internal.h.a(this.f237b.f221d, this.f236a)) {
                this.f236a.c();
                this.f237b.f221d = null;
            }
            this.f236a.i(this);
            bb.a<ra.o> aVarB = this.f236a.b();
            if (aVarB != null) {
                aVarB.invoke();
            }
            this.f236a.k(null);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public OnBackPressedDispatcher() {
        this(null, 1, 0 == true ? 1 : 0);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void j() {
        n nVarPrevious;
        kotlin.collections.d<n> dVar = this.f220c;
        ListIterator<n> listIterator = dVar.listIterator(dVar.size());
        do {
            if (!listIterator.hasPrevious()) {
                nVarPrevious = null;
                break;
            }
            nVarPrevious = listIterator.previous();
        } while (!nVarPrevious.g());
        n nVar = nVarPrevious;
        this.f221d = null;
        if (nVar != null) {
            nVar.c();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void l(androidx.activity.b bVar) {
        n nVarPrevious;
        kotlin.collections.d<n> dVar = this.f220c;
        ListIterator<n> listIterator = dVar.listIterator(dVar.size());
        do {
            if (!listIterator.hasPrevious()) {
                nVarPrevious = null;
                break;
            }
            nVarPrevious = listIterator.previous();
        } while (!nVarPrevious.g());
        n nVar = nVarPrevious;
        if (nVar != null) {
            nVar.e(bVar);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void m(androidx.activity.b bVar) {
        n nVarPrevious;
        kotlin.collections.d<n> dVar = this.f220c;
        ListIterator<n> listIterator = dVar.listIterator(dVar.size());
        do {
            if (!listIterator.hasPrevious()) {
                nVarPrevious = null;
                break;
            }
            nVarPrevious = listIterator.previous();
        } while (!nVarPrevious.g());
        n nVar = nVarPrevious;
        this.f221d = nVar;
        if (nVar != null) {
            nVar.f(bVar);
        }
    }

    private final void o(boolean z10) {
        OnBackInvokedDispatcher onBackInvokedDispatcher = this.f223f;
        OnBackInvokedCallback onBackInvokedCallback = this.f222e;
        if (onBackInvokedDispatcher == null || onBackInvokedCallback == null) {
            return;
        }
        if (z10 && !this.f224g) {
            a.f230a.d(onBackInvokedDispatcher, 0, onBackInvokedCallback);
            this.f224g = true;
        } else {
            if (z10 || !this.f224g) {
                return;
            }
            a.f230a.e(onBackInvokedDispatcher, onBackInvokedCallback);
            this.f224g = false;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void p() {
        boolean z10 = this.f225h;
        kotlin.collections.d<n> dVar = this.f220c;
        boolean z11 = false;
        if (dVar == null || !dVar.isEmpty()) {
            Iterator<n> it = dVar.iterator();
            while (it.hasNext()) {
                if (it.next().g()) {
                    z11 = true;
                    break;
                }
            }
        }
        this.f225h = z11;
        if (z11 != z10) {
            a0.a<Boolean> aVar = this.f219b;
            if (aVar != null) {
                aVar.accept(Boolean.valueOf(z11));
            }
            o(z11);
        }
    }

    public final void h(androidx.lifecycle.l owner, n onBackPressedCallback) {
        kotlin.jvm.internal.h.e(owner, "owner");
        kotlin.jvm.internal.h.e(onBackPressedCallback, "onBackPressedCallback");
        Lifecycle lifecycle = owner.getLifecycle();
        if (lifecycle.b() == Lifecycle.State.DESTROYED) {
            return;
        }
        onBackPressedCallback.a(new LifecycleOnBackPressedCancellable(this, lifecycle, onBackPressedCallback));
        p();
        onBackPressedCallback.k(new OnBackPressedDispatcher$addCallback$1(this));
    }

    public final androidx.activity.c i(n onBackPressedCallback) {
        kotlin.jvm.internal.h.e(onBackPressedCallback, "onBackPressedCallback");
        this.f220c.add(onBackPressedCallback);
        c cVar = new c(this, onBackPressedCallback);
        onBackPressedCallback.a(cVar);
        p();
        onBackPressedCallback.k(new OnBackPressedDispatcher$addCancellableCallback$1(this));
        return cVar;
    }

    public final void k() {
        n nVarPrevious;
        kotlin.collections.d<n> dVar = this.f220c;
        ListIterator<n> listIterator = dVar.listIterator(dVar.size());
        do {
            if (!listIterator.hasPrevious()) {
                nVarPrevious = null;
                break;
            }
            nVarPrevious = listIterator.previous();
        } while (!nVarPrevious.g());
        n nVar = nVarPrevious;
        this.f221d = null;
        if (nVar != null) {
            nVar.d();
            return;
        }
        Runnable runnable = this.f218a;
        if (runnable != null) {
            runnable.run();
        }
    }

    public final void n(OnBackInvokedDispatcher invoker) {
        kotlin.jvm.internal.h.e(invoker, "invoker");
        this.f223f = invoker;
        o(this.f225h);
    }

    public OnBackPressedDispatcher(Runnable runnable, a0.a<Boolean> aVar) {
        this.f218a = runnable;
        this.f219b = aVar;
        this.f220c = new kotlin.collections.d<>();
        this.f222e = b.f231a.a(new bb.l<androidx.activity.b, ra.o>() { // from class: androidx.activity.OnBackPressedDispatcher.1
            {
                super(1);
            }

            public final void a(androidx.activity.b backEvent) {
                kotlin.jvm.internal.h.e(backEvent, "backEvent");
                OnBackPressedDispatcher.this.m(backEvent);
            }

            @Override // bb.l
            public /* bridge */ /* synthetic */ ra.o invoke(androidx.activity.b bVar) {
                a(bVar);
                return ra.o.f16669a;
            }
        }, new bb.l<androidx.activity.b, ra.o>() { // from class: androidx.activity.OnBackPressedDispatcher.2
            {
                super(1);
            }

            public final void a(androidx.activity.b backEvent) {
                kotlin.jvm.internal.h.e(backEvent, "backEvent");
                OnBackPressedDispatcher.this.l(backEvent);
            }

            @Override // bb.l
            public /* bridge */ /* synthetic */ ra.o invoke(androidx.activity.b bVar) {
                a(bVar);
                return ra.o.f16669a;
            }
        }, new bb.a<ra.o>() { // from class: androidx.activity.OnBackPressedDispatcher.3
            {
                super(0);
            }

            @Override // bb.a
            public /* bridge */ /* synthetic */ ra.o invoke() {
                invoke2();
                return ra.o.f16669a;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2() {
                OnBackPressedDispatcher.this.k();
            }
        }, new bb.a<ra.o>() { // from class: androidx.activity.OnBackPressedDispatcher.4
            {
                super(0);
            }

            @Override // bb.a
            public /* bridge */ /* synthetic */ ra.o invoke() {
                invoke2();
                return ra.o.f16669a;
            }

            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
            public final void invoke2() {
                OnBackPressedDispatcher.this.j();
            }
        });
    }

    public /* synthetic */ OnBackPressedDispatcher(Runnable runnable, int i10, kotlin.jvm.internal.f fVar) {
        this((i10 & 1) != 0 ? null : runnable);
    }

    public OnBackPressedDispatcher(Runnable runnable) {
        this(runnable, null);
    }
}
