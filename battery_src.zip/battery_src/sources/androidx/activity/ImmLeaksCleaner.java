package androidx.activity;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import androidx.lifecycle.Lifecycle;
import java.lang.reflect.Field;

/* JADX INFO: loaded from: classes.dex */
final class ImmLeaksCleaner implements androidx.lifecycle.i {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private static int f213b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private static Field f214c;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private static Field f215g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private static Field f216h;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private Activity f217a;

    @SuppressLint({"SoonBlockedPrivateApi"})
    private static void b() {
        try {
            f213b = 2;
            Field declaredField = InputMethodManager.class.getDeclaredField("mServedView");
            f215g = declaredField;
            declaredField.setAccessible(true);
            Field declaredField2 = InputMethodManager.class.getDeclaredField("mNextServedView");
            f216h = declaredField2;
            declaredField2.setAccessible(true);
            Field declaredField3 = InputMethodManager.class.getDeclaredField("mH");
            f214c = declaredField3;
            declaredField3.setAccessible(true);
            f213b = 1;
        } catch (NoSuchFieldException unused) {
        }
    }

    @Override // androidx.lifecycle.i
    public void a(androidx.lifecycle.l lVar, Lifecycle.Event event) {
        if (event != Lifecycle.Event.ON_DESTROY) {
            return;
        }
        if (f213b == 0) {
            b();
        }
        if (f213b == 1) {
            InputMethodManager inputMethodManager = (InputMethodManager) this.f217a.getSystemService("input_method");
            try {
                Object obj = f214c.get(inputMethodManager);
                if (obj == null) {
                    return;
                }
                synchronized (obj) {
                    try {
                        try {
                            try {
                                View view = (View) f215g.get(inputMethodManager);
                                if (view == null) {
                                    return;
                                }
                                if (view.isAttachedToWindow()) {
                                    return;
                                }
                                try {
                                    f216h.set(inputMethodManager, null);
                                    inputMethodManager.isActive();
                                } catch (IllegalAccessException unused) {
                                }
                            } catch (ClassCastException unused2) {
                            }
                        } catch (IllegalAccessException unused3) {
                        }
                    } catch (Throwable th) {
                        throw th;
                    }
                }
            } catch (IllegalAccessException unused4) {
            }
        }
    }
}
