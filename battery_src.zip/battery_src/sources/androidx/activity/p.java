package androidx.activity;

/* JADX INFO: compiled from: OnBackPressedDispatcherOwner.kt */
/* JADX INFO: loaded from: classes.dex */
public interface p extends androidx.lifecycle.l {
    OnBackPressedDispatcher getOnBackPressedDispatcher();
}
