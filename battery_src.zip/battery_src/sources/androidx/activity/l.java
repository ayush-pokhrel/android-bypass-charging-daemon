package androidx.activity;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.Executor;

/* JADX INFO: compiled from: FullyDrawnReporter.kt */
/* JADX INFO: loaded from: classes.dex */
public final class l {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final Executor f254a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private final bb.a<ra.o> f255b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private final Object f256c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private int f257d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private boolean f258e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private boolean f259f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private final List<bb.a<ra.o>> f260g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private final Runnable f261h;

    public l(Executor executor, bb.a<ra.o> reportFullyDrawn) {
        kotlin.jvm.internal.h.e(executor, "executor");
        kotlin.jvm.internal.h.e(reportFullyDrawn, "reportFullyDrawn");
        this.f254a = executor;
        this.f255b = reportFullyDrawn;
        this.f256c = new Object();
        this.f260g = new ArrayList();
        this.f261h = new Runnable() { // from class: androidx.activity.k
            @Override // java.lang.Runnable
            public final void run() {
                l.d(this.f253a);
            }
        };
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void d(l this$0) {
        kotlin.jvm.internal.h.e(this$0, "this$0");
        synchronized (this$0.f256c) {
            try {
                this$0.f258e = false;
                if (this$0.f257d == 0 && !this$0.f259f) {
                    this$0.f255b.invoke();
                    this$0.b();
                }
                ra.o oVar = ra.o.f16669a;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void b() {
        synchronized (this.f256c) {
            try {
                this.f259f = true;
                Iterator<T> it = this.f260g.iterator();
                while (it.hasNext()) {
                    ((bb.a) it.next()).invoke();
                }
                this.f260g.clear();
                ra.o oVar = ra.o.f16669a;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final boolean c() {
        boolean z10;
        synchronized (this.f256c) {
            z10 = this.f259f;
        }
        return z10;
    }
}
