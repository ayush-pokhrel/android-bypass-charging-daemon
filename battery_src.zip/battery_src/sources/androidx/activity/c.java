package androidx.activity;

/* JADX INFO: compiled from: Cancellable.kt */
/* JADX INFO: loaded from: classes.dex */
public interface c {
    void cancel();
}
