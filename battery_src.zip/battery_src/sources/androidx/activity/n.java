package androidx.activity;

import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;

/* JADX INFO: compiled from: OnBackPressedCallback.kt */
/* JADX INFO: loaded from: classes.dex */
public abstract class n {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private boolean f262a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private final CopyOnWriteArrayList<c> f263b = new CopyOnWriteArrayList<>();

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private bb.a<ra.o> f264c;

    public n(boolean z10) {
        this.f262a = z10;
    }

    public final void a(c cancellable) {
        kotlin.jvm.internal.h.e(cancellable, "cancellable");
        this.f263b.add(cancellable);
    }

    public final bb.a<ra.o> b() {
        return this.f264c;
    }

    public abstract void d();

    public void e(b backEvent) {
        kotlin.jvm.internal.h.e(backEvent, "backEvent");
    }

    public void f(b backEvent) {
        kotlin.jvm.internal.h.e(backEvent, "backEvent");
    }

    public final boolean g() {
        return this.f262a;
    }

    public final void h() {
        Iterator<T> it = this.f263b.iterator();
        while (it.hasNext()) {
            ((c) it.next()).cancel();
        }
    }

    public final void i(c cancellable) {
        kotlin.jvm.internal.h.e(cancellable, "cancellable");
        this.f263b.remove(cancellable);
    }

    public final void j(boolean z10) {
        this.f262a = z10;
        bb.a<ra.o> aVar = this.f264c;
        if (aVar != null) {
            aVar.invoke();
        }
    }

    public final void k(bb.a<ra.o> aVar) {
        this.f264c = aVar;
    }

    public void c() {
    }
}
