package androidx.activity;

/* JADX INFO: loaded from: classes.dex */
public final class R$id {
    public static final int report_drawn = 2131296920;
    public static final int view_tree_on_back_pressed_dispatcher_owner = 2131297150;

    private R$id() {
    }
}
