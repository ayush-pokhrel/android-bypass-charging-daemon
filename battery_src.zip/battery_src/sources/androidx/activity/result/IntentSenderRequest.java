package androidx.activity.result;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.IntentSender;
import android.os.Parcel;
import android.os.Parcelable;
import kotlin.jvm.internal.f;
import kotlin.jvm.internal.h;

/* JADX INFO: compiled from: IntentSenderRequest.kt */
/* JADX INFO: loaded from: classes.dex */
@SuppressLint({"BanParcelableUsage"})
public final class IntentSenderRequest implements Parcelable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final IntentSender f290a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private final Intent f291b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private final int f292c;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private final int f293g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public static final c f289h = new c(null);
    public static final Parcelable.Creator<IntentSenderRequest> CREATOR = new b();

    /* JADX INFO: compiled from: IntentSenderRequest.kt */
    public static final class a {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private final IntentSender f294a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private Intent f295b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        private int f296c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        private int f297d;

        public a(IntentSender intentSender) {
            h.e(intentSender, "intentSender");
            this.f294a = intentSender;
        }

        public final IntentSenderRequest a() {
            return new IntentSenderRequest(this.f294a, this.f295b, this.f296c, this.f297d);
        }

        public final a b(Intent intent) {
            this.f295b = intent;
            return this;
        }

        public final a c(int i10, int i11) {
            this.f297d = i10;
            this.f296c = i11;
            return this;
        }
    }

    /* JADX INFO: compiled from: IntentSenderRequest.kt */
    public static final class b implements Parcelable.Creator<IntentSenderRequest> {
        b() {
        }

        @Override // android.os.Parcelable.Creator
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public IntentSenderRequest createFromParcel(Parcel inParcel) {
            h.e(inParcel, "inParcel");
            return new IntentSenderRequest(inParcel);
        }

        @Override // android.os.Parcelable.Creator
        /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
        public IntentSenderRequest[] newArray(int i10) {
            return new IntentSenderRequest[i10];
        }
    }

    /* JADX INFO: compiled from: IntentSenderRequest.kt */
    public static final class c {
        public /* synthetic */ c(f fVar) {
            this();
        }

        private c() {
        }
    }

    public IntentSenderRequest(IntentSender intentSender, Intent intent, int i10, int i11) {
        h.e(intentSender, "intentSender");
        this.f290a = intentSender;
        this.f291b = intent;
        this.f292c = i10;
        this.f293g = i11;
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public final Intent p() {
        return this.f291b;
    }

    public final int q() {
        return this.f292c;
    }

    public final int r() {
        return this.f293g;
    }

    public final IntentSender s() {
        return this.f290a;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel dest, int i10) {
        h.e(dest, "dest");
        dest.writeParcelable(this.f290a, i10);
        dest.writeParcelable(this.f291b, i10);
        dest.writeInt(this.f292c);
        dest.writeInt(this.f293g);
    }

    /* JADX WARN: Illegal instructions before constructor call */
    public IntentSenderRequest(Parcel parcel) {
        h.e(parcel, "parcel");
        Parcelable parcelable = parcel.readParcelable(IntentSender.class.getClassLoader());
        h.b(parcelable);
        this((IntentSender) parcelable, (Intent) parcel.readParcelable(Intent.class.getClassLoader()), parcel.readInt(), parcel.readInt());
    }
}
