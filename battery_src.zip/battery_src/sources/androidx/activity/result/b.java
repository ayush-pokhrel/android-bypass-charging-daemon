package androidx.activity.result;

import android.annotation.SuppressLint;

/* JADX INFO: compiled from: ActivityResultLauncher.java */
/* JADX INFO: loaded from: classes.dex */
public abstract class b<I> {
    public void a(@SuppressLint({"UnknownNullness"}) I i10) {
        b(i10, null);
    }

    public abstract void b(@SuppressLint({"UnknownNullness"}) I i10, androidx.core.app.c cVar);

    public abstract void c();
}
