package androidx.activity.result;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.i;
import androidx.lifecycle.l;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import kotlin.random.Random;

/* JADX INFO: loaded from: classes.dex */
public abstract class ActivityResultRegistry {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final Map<Integer, String> f268a = new HashMap();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    final Map<String, Integer> f269b = new HashMap();

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private final Map<String, d> f270c = new HashMap();

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    ArrayList<String> f271d = new ArrayList<>();

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    final transient Map<String, c<?>> f272e = new HashMap();

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    final Map<String, Object> f273f = new HashMap();

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    final Bundle f274g = new Bundle();

    /* JADX INFO: Add missing generic type declarations: [I] */
    class a<I> extends androidx.activity.result.b<I> {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        final /* synthetic */ String f279a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        final /* synthetic */ f.a f280b;

        a(String str, f.a aVar) {
            this.f279a = str;
            this.f280b = aVar;
        }

        @Override // androidx.activity.result.b
        public void b(I i10, androidx.core.app.c cVar) throws Exception {
            Integer num = ActivityResultRegistry.this.f269b.get(this.f279a);
            if (num != null) {
                ActivityResultRegistry.this.f271d.add(this.f279a);
                try {
                    ActivityResultRegistry.this.f(num.intValue(), this.f280b, i10, cVar);
                    return;
                } catch (Exception e10) {
                    ActivityResultRegistry.this.f271d.remove(this.f279a);
                    throw e10;
                }
            }
            throw new IllegalStateException("Attempting to launch an unregistered ActivityResultLauncher with contract " + this.f280b + " and input " + i10 + ". You must ensure the ActivityResultLauncher is registered before calling launch().");
        }

        @Override // androidx.activity.result.b
        public void c() {
            ActivityResultRegistry.this.l(this.f279a);
        }
    }

    /* JADX INFO: Add missing generic type declarations: [I] */
    class b<I> extends androidx.activity.result.b<I> {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        final /* synthetic */ String f282a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        final /* synthetic */ f.a f283b;

        b(String str, f.a aVar) {
            this.f282a = str;
            this.f283b = aVar;
        }

        @Override // androidx.activity.result.b
        public void b(I i10, androidx.core.app.c cVar) throws Exception {
            Integer num = ActivityResultRegistry.this.f269b.get(this.f282a);
            if (num != null) {
                ActivityResultRegistry.this.f271d.add(this.f282a);
                try {
                    ActivityResultRegistry.this.f(num.intValue(), this.f283b, i10, cVar);
                    return;
                } catch (Exception e10) {
                    ActivityResultRegistry.this.f271d.remove(this.f282a);
                    throw e10;
                }
            }
            throw new IllegalStateException("Attempting to launch an unregistered ActivityResultLauncher with contract " + this.f283b + " and input " + i10 + ". You must ensure the ActivityResultLauncher is registered before calling launch().");
        }

        @Override // androidx.activity.result.b
        public void c() {
            ActivityResultRegistry.this.l(this.f282a);
        }
    }

    private static class c<O> {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        final androidx.activity.result.a<O> f285a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        final f.a<?, O> f286b;

        c(androidx.activity.result.a<O> aVar, f.a<?, O> aVar2) {
            this.f285a = aVar;
            this.f286b = aVar2;
        }
    }

    private static class d {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        final Lifecycle f287a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private final ArrayList<i> f288b = new ArrayList<>();

        d(Lifecycle lifecycle) {
            this.f287a = lifecycle;
        }

        void a(i iVar) {
            this.f287a.a(iVar);
            this.f288b.add(iVar);
        }

        void b() {
            Iterator<i> it = this.f288b.iterator();
            while (it.hasNext()) {
                this.f287a.d(it.next());
            }
            this.f288b.clear();
        }
    }

    private void a(int i10, String str) {
        this.f268a.put(Integer.valueOf(i10), str);
        this.f269b.put(str, Integer.valueOf(i10));
    }

    private <O> void d(String str, int i10, Intent intent, c<O> cVar) {
        if (cVar == null || cVar.f285a == null || !this.f271d.contains(str)) {
            this.f273f.remove(str);
            this.f274g.putParcelable(str, new ActivityResult(i10, intent));
        } else {
            cVar.f285a.a(cVar.f286b.c(i10, intent));
            this.f271d.remove(str);
        }
    }

    private int e() {
        int iD = Random.f13994a.d(2147418112);
        while (true) {
            int i10 = iD + 65536;
            if (!this.f268a.containsKey(Integer.valueOf(i10))) {
                return i10;
            }
            iD = Random.f13994a.d(2147418112);
        }
    }

    private void k(String str) {
        if (this.f269b.get(str) != null) {
            return;
        }
        a(e(), str);
    }

    public final boolean b(int i10, int i11, Intent intent) {
        String str = this.f268a.get(Integer.valueOf(i10));
        if (str == null) {
            return false;
        }
        d(str, i11, intent, this.f272e.get(str));
        return true;
    }

    public final <O> boolean c(int i10, @SuppressLint({"UnknownNullness"}) O o10) {
        androidx.activity.result.a<?> aVar;
        String str = this.f268a.get(Integer.valueOf(i10));
        if (str == null) {
            return false;
        }
        c<?> cVar = this.f272e.get(str);
        if (cVar == null || (aVar = cVar.f285a) == null) {
            this.f274g.remove(str);
            this.f273f.put(str, o10);
            return true;
        }
        if (!this.f271d.remove(str)) {
            return true;
        }
        aVar.a(o10);
        return true;
    }

    public abstract <I, O> void f(int i10, f.a<I, O> aVar, @SuppressLint({"UnknownNullness"}) I i11, androidx.core.app.c cVar);

    public final void g(Bundle bundle) {
        if (bundle == null) {
            return;
        }
        ArrayList<Integer> integerArrayList = bundle.getIntegerArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_RCS");
        ArrayList<String> stringArrayList = bundle.getStringArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_KEYS");
        if (stringArrayList == null || integerArrayList == null) {
            return;
        }
        this.f271d = bundle.getStringArrayList("KEY_COMPONENT_ACTIVITY_LAUNCHED_KEYS");
        this.f274g.putAll(bundle.getBundle("KEY_COMPONENT_ACTIVITY_PENDING_RESULT"));
        for (int i10 = 0; i10 < stringArrayList.size(); i10++) {
            String str = stringArrayList.get(i10);
            if (this.f269b.containsKey(str)) {
                Integer numRemove = this.f269b.remove(str);
                if (!this.f274g.containsKey(str)) {
                    this.f268a.remove(numRemove);
                }
            }
            a(integerArrayList.get(i10).intValue(), stringArrayList.get(i10));
        }
    }

    public final void h(Bundle bundle) {
        bundle.putIntegerArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_RCS", new ArrayList<>(this.f269b.values()));
        bundle.putStringArrayList("KEY_COMPONENT_ACTIVITY_REGISTERED_KEYS", new ArrayList<>(this.f269b.keySet()));
        bundle.putStringArrayList("KEY_COMPONENT_ACTIVITY_LAUNCHED_KEYS", new ArrayList<>(this.f271d));
        bundle.putBundle("KEY_COMPONENT_ACTIVITY_PENDING_RESULT", (Bundle) this.f274g.clone());
    }

    public final <I, O> androidx.activity.result.b<I> i(final String str, l lVar, final f.a<I, O> aVar, final androidx.activity.result.a<O> aVar2) {
        Lifecycle lifecycle = lVar.getLifecycle();
        if (lifecycle.b().b(Lifecycle.State.STARTED)) {
            throw new IllegalStateException("LifecycleOwner " + lVar + " is attempting to register while current state is " + lifecycle.b() + ". LifecycleOwners must call register before they are STARTED.");
        }
        k(str);
        d dVar = this.f270c.get(str);
        if (dVar == null) {
            dVar = new d(lifecycle);
        }
        dVar.a(new i() { // from class: androidx.activity.result.ActivityResultRegistry.1
            @Override // androidx.lifecycle.i
            public void a(l lVar2, Lifecycle.Event event) {
                if (!Lifecycle.Event.ON_START.equals(event)) {
                    if (Lifecycle.Event.ON_STOP.equals(event)) {
                        ActivityResultRegistry.this.f272e.remove(str);
                        return;
                    } else {
                        if (Lifecycle.Event.ON_DESTROY.equals(event)) {
                            ActivityResultRegistry.this.l(str);
                            return;
                        }
                        return;
                    }
                }
                ActivityResultRegistry.this.f272e.put(str, new c<>(aVar2, aVar));
                if (ActivityResultRegistry.this.f273f.containsKey(str)) {
                    Object obj = ActivityResultRegistry.this.f273f.get(str);
                    ActivityResultRegistry.this.f273f.remove(str);
                    aVar2.a(obj);
                }
                ActivityResult activityResult = (ActivityResult) ActivityResultRegistry.this.f274g.getParcelable(str);
                if (activityResult != null) {
                    ActivityResultRegistry.this.f274g.remove(str);
                    aVar2.a(aVar.c(activityResult.q(), activityResult.p()));
                }
            }
        });
        this.f270c.put(str, dVar);
        return new a(str, aVar);
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final <I, O> androidx.activity.result.b<I> j(String str, f.a<I, O> aVar, androidx.activity.result.a<O> aVar2) {
        k(str);
        this.f272e.put(str, new c<>(aVar2, aVar));
        if (this.f273f.containsKey(str)) {
            Object obj = this.f273f.get(str);
            this.f273f.remove(str);
            aVar2.a(obj);
        }
        ActivityResult activityResult = (ActivityResult) this.f274g.getParcelable(str);
        if (activityResult != null) {
            this.f274g.remove(str);
            aVar2.a(aVar.c(activityResult.q(), activityResult.p()));
        }
        return new b(str, aVar);
    }

    final void l(String str) {
        Integer numRemove;
        if (!this.f271d.contains(str) && (numRemove = this.f269b.remove(str)) != null) {
            this.f268a.remove(numRemove);
        }
        this.f272e.remove(str);
        if (this.f273f.containsKey(str)) {
            Log.w("ActivityResultRegistry", "Dropping pending result for request " + str + ": " + this.f273f.get(str));
            this.f273f.remove(str);
        }
        if (this.f274g.containsKey(str)) {
            Log.w("ActivityResultRegistry", "Dropping pending result for request " + str + ": " + this.f274g.getParcelable(str));
            this.f274g.remove(str);
        }
        d dVar = this.f270c.get(str);
        if (dVar != null) {
            dVar.b();
            this.f270c.remove(str);
        }
    }
}
