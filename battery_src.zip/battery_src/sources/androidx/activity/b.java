package androidx.activity;

import android.window.BackEvent;

/* JADX INFO: compiled from: BackEventCompat.kt */
/* JADX INFO: loaded from: classes.dex */
public final class b {

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public static final a f239e = new a(null);

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final float f240a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private final float f241b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private final float f242c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private final int f243d;

    /* JADX INFO: compiled from: BackEventCompat.kt */
    public static final class a {
        public /* synthetic */ a(kotlin.jvm.internal.f fVar) {
            this();
        }

        private a() {
        }
    }

    public b(float f10, float f11, float f12, int i10) {
        this.f240a = f10;
        this.f241b = f11;
        this.f242c = f12;
        this.f243d = i10;
    }

    public final float a() {
        return this.f242c;
    }

    public final int b() {
        return this.f243d;
    }

    public final float c() {
        return this.f241b;
    }

    public String toString() {
        return "BackEventCompat{touchX=" + this.f240a + ", touchY=" + this.f241b + ", progress=" + this.f242c + ", swipeEdge=" + this.f243d + '}';
    }

    /* JADX WARN: Illegal instructions before constructor call */
    public b(BackEvent backEvent) {
        kotlin.jvm.internal.h.e(backEvent, "backEvent");
        androidx.activity.a aVar = androidx.activity.a.f238a;
        this(aVar.d(backEvent), aVar.e(backEvent), aVar.b(backEvent), aVar.c(backEvent));
    }
}
