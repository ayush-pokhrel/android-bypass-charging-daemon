package androidx.activity;

import android.view.View;

/* JADX INFO: compiled from: ViewTreeFullyLoadedReporterOwner.kt */
/* JADX INFO: loaded from: classes.dex */
public final class q {
    public static final void a(View view, m fullyDrawnReporterOwner) {
        kotlin.jvm.internal.h.e(view, "<this>");
        kotlin.jvm.internal.h.e(fullyDrawnReporterOwner, "fullyDrawnReporterOwner");
        view.setTag(R$id.report_drawn, fullyDrawnReporterOwner);
    }
}
