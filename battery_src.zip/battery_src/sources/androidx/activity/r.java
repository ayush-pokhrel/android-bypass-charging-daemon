package androidx.activity;

import android.view.View;

/* JADX INFO: compiled from: ViewTreeOnBackPressedDispatcherOwner.kt */
/* JADX INFO: loaded from: classes.dex */
public final class r {
    public static final void a(View view, p onBackPressedDispatcherOwner) {
        kotlin.jvm.internal.h.e(view, "<this>");
        kotlin.jvm.internal.h.e(onBackPressedDispatcherOwner, "onBackPressedDispatcherOwner");
        view.setTag(R$id.view_tree_on_back_pressed_dispatcher_owner, onBackPressedDispatcherOwner);
    }
}
