package androidx.constraintlayout.utils.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.ViewParent;
import androidx.constraintlayout.motion.widget.MotionLayout;
import androidx.constraintlayout.widget.R$styleable;

/* JADX INFO: loaded from: classes.dex */
public class MotionTelltales extends MockView {

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    private Paint f1924o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    MotionLayout f1925p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    float[] f1926q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    Matrix f1927r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    int f1928s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    int f1929t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    float f1930u;

    public MotionTelltales(Context context) {
        super(context);
        this.f1924o = new Paint();
        this.f1926q = new float[2];
        this.f1927r = new Matrix();
        this.f1928s = 0;
        this.f1929t = -65281;
        this.f1930u = 0.25f;
        a(context, null);
    }

    private void a(Context context, AttributeSet attributeSet) {
        if (attributeSet != null) {
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R$styleable.MotionTelltales);
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            for (int i10 = 0; i10 < indexCount; i10++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i10);
                if (index == R$styleable.MotionTelltales_telltales_tailColor) {
                    this.f1929t = typedArrayObtainStyledAttributes.getColor(index, this.f1929t);
                } else if (index == R$styleable.MotionTelltales_telltales_velocityMode) {
                    this.f1928s = typedArrayObtainStyledAttributes.getInt(index, this.f1928s);
                } else if (index == R$styleable.MotionTelltales_telltales_tailScale) {
                    this.f1930u = typedArrayObtainStyledAttributes.getFloat(index, this.f1930u);
                }
            }
        }
        this.f1924o.setColor(this.f1929t);
        this.f1924o.setStrokeWidth(5.0f);
    }

    @Override // android.view.View
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
    }

    @Override // androidx.constraintlayout.utils.widget.MockView, android.view.View
    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        getMatrix().invert(this.f1927r);
        if (this.f1925p == null) {
            ViewParent parent = getParent();
            if (parent instanceof MotionLayout) {
                this.f1925p = (MotionLayout) parent;
                return;
            }
            return;
        }
        int width = getWidth();
        int height = getHeight();
        float[] fArr = {0.1f, 0.25f, 0.5f, 0.75f, 0.9f};
        for (int i10 = 0; i10 < 5; i10++) {
            float f10 = fArr[i10];
            for (int i11 = 0; i11 < 5; i11++) {
                float f11 = fArr[i11];
                this.f1925p.O(this, f11, f10, this.f1926q, this.f1928s);
                this.f1927r.mapVectors(this.f1926q);
                float f12 = width * f11;
                float f13 = height * f10;
                float[] fArr2 = this.f1926q;
                float f14 = fArr2[0];
                float f15 = this.f1930u;
                float f16 = f13 - (fArr2[1] * f15);
                this.f1927r.mapVectors(fArr2);
                canvas.drawLine(f12, f13, f12 - (f14 * f15), f16, this.f1924o);
            }
        }
    }

    @Override // android.view.View
    protected void onLayout(boolean z10, int i10, int i11, int i12, int i13) {
        super.onLayout(z10, i10, i11, i12, i13);
        postInvalidate();
    }

    public void setText(CharSequence charSequence) {
        this.f1918i = charSequence.toString();
        requestLayout();
    }

    public MotionTelltales(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f1924o = new Paint();
        this.f1926q = new float[2];
        this.f1927r = new Matrix();
        this.f1928s = 0;
        this.f1929t = -65281;
        this.f1930u = 0.25f;
        a(context, attributeSet);
    }

    public MotionTelltales(Context context, AttributeSet attributeSet, int i10) {
        super(context, attributeSet, i10);
        this.f1924o = new Paint();
        this.f1926q = new float[2];
        this.f1927r = new Matrix();
        this.f1928s = 0;
        this.f1929t = -65281;
        this.f1930u = 0.25f;
        a(context, attributeSet);
    }
}
