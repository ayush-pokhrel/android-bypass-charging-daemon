package androidx.constraintlayout.utils.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.View;
import androidx.constraintlayout.widget.R$styleable;

/* JADX INFO: loaded from: classes.dex */
public class MockView extends View {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private Paint f1913a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private Paint f1914b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private Paint f1915c;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private boolean f1916g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private boolean f1917h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    protected String f1918i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private Rect f1919j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    private int f1920k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private int f1921l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    private int f1922m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    private int f1923n;

    public MockView(Context context) {
        super(context);
        this.f1913a = new Paint();
        this.f1914b = new Paint();
        this.f1915c = new Paint();
        this.f1916g = true;
        this.f1917h = true;
        this.f1918i = null;
        this.f1919j = new Rect();
        this.f1920k = Color.argb(255, 0, 0, 0);
        this.f1921l = Color.argb(255, 200, 200, 200);
        this.f1922m = Color.argb(255, 50, 50, 50);
        this.f1923n = 4;
        a(context, null);
    }

    private void a(Context context, AttributeSet attributeSet) {
        if (attributeSet != null) {
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R$styleable.MockView);
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            for (int i10 = 0; i10 < indexCount; i10++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i10);
                if (index == R$styleable.MockView_mock_label) {
                    this.f1918i = typedArrayObtainStyledAttributes.getString(index);
                } else if (index == R$styleable.MockView_mock_showDiagonals) {
                    this.f1916g = typedArrayObtainStyledAttributes.getBoolean(index, this.f1916g);
                } else if (index == R$styleable.MockView_mock_diagonalsColor) {
                    this.f1920k = typedArrayObtainStyledAttributes.getColor(index, this.f1920k);
                } else if (index == R$styleable.MockView_mock_labelBackgroundColor) {
                    this.f1922m = typedArrayObtainStyledAttributes.getColor(index, this.f1922m);
                } else if (index == R$styleable.MockView_mock_labelColor) {
                    this.f1921l = typedArrayObtainStyledAttributes.getColor(index, this.f1921l);
                } else if (index == R$styleable.MockView_mock_showLabel) {
                    this.f1917h = typedArrayObtainStyledAttributes.getBoolean(index, this.f1917h);
                }
            }
        }
        if (this.f1918i == null) {
            try {
                this.f1918i = context.getResources().getResourceEntryName(getId());
            } catch (Exception unused) {
            }
        }
        this.f1913a.setColor(this.f1920k);
        this.f1913a.setAntiAlias(true);
        this.f1914b.setColor(this.f1921l);
        this.f1914b.setAntiAlias(true);
        this.f1915c.setColor(this.f1922m);
        this.f1923n = Math.round(this.f1923n * (getResources().getDisplayMetrics().xdpi / 160.0f));
    }

    @Override // android.view.View
    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int width = getWidth();
        int height = getHeight();
        if (this.f1916g) {
            width--;
            height--;
            float f10 = width;
            float f11 = height;
            canvas.drawLine(0.0f, 0.0f, f10, f11, this.f1913a);
            canvas.drawLine(0.0f, f11, f10, 0.0f, this.f1913a);
            canvas.drawLine(0.0f, 0.0f, f10, 0.0f, this.f1913a);
            canvas.drawLine(f10, 0.0f, f10, f11, this.f1913a);
            canvas.drawLine(f10, f11, 0.0f, f11, this.f1913a);
            canvas.drawLine(0.0f, f11, 0.0f, 0.0f, this.f1913a);
        }
        String str = this.f1918i;
        if (str == null || !this.f1917h) {
            return;
        }
        this.f1914b.getTextBounds(str, 0, str.length(), this.f1919j);
        float fWidth = (width - this.f1919j.width()) / 2.0f;
        float fHeight = ((height - this.f1919j.height()) / 2.0f) + this.f1919j.height();
        this.f1919j.offset((int) fWidth, (int) fHeight);
        Rect rect = this.f1919j;
        int i10 = rect.left;
        int i11 = this.f1923n;
        rect.set(i10 - i11, rect.top - i11, rect.right + i11, rect.bottom + i11);
        canvas.drawRect(this.f1919j, this.f1915c);
        canvas.drawText(this.f1918i, fWidth, fHeight, this.f1914b);
    }

    public MockView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f1913a = new Paint();
        this.f1914b = new Paint();
        this.f1915c = new Paint();
        this.f1916g = true;
        this.f1917h = true;
        this.f1918i = null;
        this.f1919j = new Rect();
        this.f1920k = Color.argb(255, 0, 0, 0);
        this.f1921l = Color.argb(255, 200, 200, 200);
        this.f1922m = Color.argb(255, 50, 50, 50);
        this.f1923n = 4;
        a(context, attributeSet);
    }

    public MockView(Context context, AttributeSet attributeSet, int i10) {
        super(context, attributeSet, i10);
        this.f1913a = new Paint();
        this.f1914b = new Paint();
        this.f1915c = new Paint();
        this.f1916g = true;
        this.f1917h = true;
        this.f1918i = null;
        this.f1919j = new Rect();
        this.f1920k = Color.argb(255, 0, 0, 0);
        this.f1921l = Color.argb(255, 200, 200, 200);
        this.f1922m = Color.argb(255, 50, 50, 50);
        this.f1923n = 4;
        a(context, attributeSet);
    }
}
