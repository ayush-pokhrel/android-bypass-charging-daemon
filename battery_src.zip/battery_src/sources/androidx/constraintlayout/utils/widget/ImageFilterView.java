package androidx.constraintlayout.utils.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Outline;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.widget.ImageView;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.constraintlayout.widget.R$styleable;

/* JADX INFO: loaded from: classes.dex */
public class ImageFilterView extends AppCompatImageView {

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private c f1894g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private boolean f1895h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private float f1896i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private float f1897j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    private float f1898k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private Path f1899l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    ViewOutlineProvider f1900m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    RectF f1901n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    Drawable[] f1902o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    LayerDrawable f1903p;

    class a extends ViewOutlineProvider {
        a() {
        }

        @Override // android.view.ViewOutlineProvider
        public void getOutline(View view, Outline outline) {
            int width = ImageFilterView.this.getWidth();
            int height = ImageFilterView.this.getHeight();
            outline.setRoundRect(0, 0, width, height, (Math.min(width, height) * ImageFilterView.this.f1897j) / 2.0f);
        }
    }

    class b extends ViewOutlineProvider {
        b() {
        }

        @Override // android.view.ViewOutlineProvider
        public void getOutline(View view, Outline outline) {
            outline.setRoundRect(0, 0, ImageFilterView.this.getWidth(), ImageFilterView.this.getHeight(), ImageFilterView.this.f1898k);
        }
    }

    static class c {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        float[] f1906a = new float[20];

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        ColorMatrix f1907b = new ColorMatrix();

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        ColorMatrix f1908c = new ColorMatrix();

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        float f1909d = 1.0f;

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        float f1910e = 1.0f;

        /* JADX INFO: renamed from: f, reason: collision with root package name */
        float f1911f = 1.0f;

        /* JADX INFO: renamed from: g, reason: collision with root package name */
        float f1912g = 1.0f;

        c() {
        }

        private void a(float f10) {
            float[] fArr = this.f1906a;
            fArr[0] = f10;
            fArr[1] = 0.0f;
            fArr[2] = 0.0f;
            fArr[3] = 0.0f;
            fArr[4] = 0.0f;
            fArr[5] = 0.0f;
            fArr[6] = f10;
            fArr[7] = 0.0f;
            fArr[8] = 0.0f;
            fArr[9] = 0.0f;
            fArr[10] = 0.0f;
            fArr[11] = 0.0f;
            fArr[12] = f10;
            fArr[13] = 0.0f;
            fArr[14] = 0.0f;
            fArr[15] = 0.0f;
            fArr[16] = 0.0f;
            fArr[17] = 0.0f;
            fArr[18] = 1.0f;
            fArr[19] = 0.0f;
        }

        private void b(float f10) {
            float f11 = 1.0f - f10;
            float f12 = 0.2999f * f11;
            float f13 = 0.587f * f11;
            float f14 = f11 * 0.114f;
            float[] fArr = this.f1906a;
            fArr[0] = f12 + f10;
            fArr[1] = f13;
            fArr[2] = f14;
            fArr[3] = 0.0f;
            fArr[4] = 0.0f;
            fArr[5] = f12;
            fArr[6] = f13 + f10;
            fArr[7] = f14;
            fArr[8] = 0.0f;
            fArr[9] = 0.0f;
            fArr[10] = f12;
            fArr[11] = f13;
            fArr[12] = f14 + f10;
            fArr[13] = 0.0f;
            fArr[14] = 0.0f;
            fArr[15] = 0.0f;
            fArr[16] = 0.0f;
            fArr[17] = 0.0f;
            fArr[18] = 1.0f;
            fArr[19] = 0.0f;
        }

        private void d(float f10) {
            float fLog;
            float fPow;
            float fLog2;
            if (f10 <= 0.0f) {
                f10 = 0.01f;
            }
            float f11 = (5000.0f / f10) / 100.0f;
            if (f11 > 66.0f) {
                double d10 = f11 - 60.0f;
                fPow = ((float) Math.pow(d10, -0.13320475816726685d)) * 329.69873f;
                fLog = ((float) Math.pow(d10, 0.07551484555006027d)) * 288.12216f;
            } else {
                fLog = (((float) Math.log(f11)) * 99.4708f) - 161.11957f;
                fPow = 255.0f;
            }
            if (f11 < 66.0f) {
                fLog2 = f11 > 19.0f ? (((float) Math.log(f11 - 10.0f)) * 138.51773f) - 305.0448f : 0.0f;
            } else {
                fLog2 = 255.0f;
            }
            float fMin = Math.min(255.0f, Math.max(fPow, 0.0f));
            float fMin2 = Math.min(255.0f, Math.max(fLog, 0.0f));
            float fMin3 = Math.min(255.0f, Math.max(fLog2, 0.0f));
            float fLog3 = (((float) Math.log(50.0f)) * 99.4708f) - 161.11957f;
            float fLog4 = (((float) Math.log(40.0f)) * 138.51773f) - 305.0448f;
            float fMin4 = Math.min(255.0f, Math.max(255.0f, 0.0f));
            float fMin5 = Math.min(255.0f, Math.max(fLog3, 0.0f));
            float fMin6 = fMin3 / Math.min(255.0f, Math.max(fLog4, 0.0f));
            float[] fArr = this.f1906a;
            fArr[0] = fMin / fMin4;
            fArr[1] = 0.0f;
            fArr[2] = 0.0f;
            fArr[3] = 0.0f;
            fArr[4] = 0.0f;
            fArr[5] = 0.0f;
            fArr[6] = fMin2 / fMin5;
            fArr[7] = 0.0f;
            fArr[8] = 0.0f;
            fArr[9] = 0.0f;
            fArr[10] = 0.0f;
            fArr[11] = 0.0f;
            fArr[12] = fMin6;
            fArr[13] = 0.0f;
            fArr[14] = 0.0f;
            fArr[15] = 0.0f;
            fArr[16] = 0.0f;
            fArr[17] = 0.0f;
            fArr[18] = 1.0f;
            fArr[19] = 0.0f;
        }

        void c(ImageView imageView) {
            boolean z10;
            this.f1907b.reset();
            float f10 = this.f1910e;
            boolean z11 = true;
            if (f10 != 1.0f) {
                b(f10);
                this.f1907b.set(this.f1906a);
                z10 = true;
            } else {
                z10 = false;
            }
            float f11 = this.f1911f;
            if (f11 != 1.0f) {
                this.f1908c.setScale(f11, f11, f11, 1.0f);
                this.f1907b.postConcat(this.f1908c);
                z10 = true;
            }
            float f12 = this.f1912g;
            if (f12 != 1.0f) {
                d(f12);
                this.f1908c.set(this.f1906a);
                this.f1907b.postConcat(this.f1908c);
                z10 = true;
            }
            float f13 = this.f1909d;
            if (f13 != 1.0f) {
                a(f13);
                this.f1908c.set(this.f1906a);
                this.f1907b.postConcat(this.f1908c);
            } else {
                z11 = z10;
            }
            if (z11) {
                imageView.setColorFilter(new ColorMatrixColorFilter(this.f1907b));
            } else {
                imageView.clearColorFilter();
            }
        }
    }

    public ImageFilterView(Context context) {
        super(context);
        this.f1894g = new c();
        this.f1895h = true;
        this.f1896i = 0.0f;
        this.f1897j = 0.0f;
        this.f1898k = Float.NaN;
        c(context, null);
    }

    private void c(Context context, AttributeSet attributeSet) {
        if (attributeSet != null) {
            TypedArray typedArrayObtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, R$styleable.ImageFilterView);
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            Drawable drawable = typedArrayObtainStyledAttributes.getDrawable(R$styleable.ImageFilterView_altSrc);
            for (int i10 = 0; i10 < indexCount; i10++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i10);
                if (index == R$styleable.ImageFilterView_crossfade) {
                    this.f1896i = typedArrayObtainStyledAttributes.getFloat(index, 0.0f);
                } else if (index == R$styleable.ImageFilterView_warmth) {
                    setWarmth(typedArrayObtainStyledAttributes.getFloat(index, 0.0f));
                } else if (index == R$styleable.ImageFilterView_saturation) {
                    setSaturation(typedArrayObtainStyledAttributes.getFloat(index, 0.0f));
                } else if (index == R$styleable.ImageFilterView_contrast) {
                    setContrast(typedArrayObtainStyledAttributes.getFloat(index, 0.0f));
                } else if (index == R$styleable.ImageFilterView_round) {
                    setRound(typedArrayObtainStyledAttributes.getDimension(index, 0.0f));
                } else if (index == R$styleable.ImageFilterView_roundPercent) {
                    setRoundPercent(typedArrayObtainStyledAttributes.getFloat(index, 0.0f));
                } else if (index == R$styleable.ImageFilterView_overlay) {
                    setOverlay(typedArrayObtainStyledAttributes.getBoolean(index, this.f1895h));
                }
            }
            typedArrayObtainStyledAttributes.recycle();
            if (drawable != null) {
                Drawable[] drawableArr = new Drawable[2];
                this.f1902o = drawableArr;
                drawableArr[0] = getDrawable();
                this.f1902o[1] = drawable;
                LayerDrawable layerDrawable = new LayerDrawable(this.f1902o);
                this.f1903p = layerDrawable;
                layerDrawable.getDrawable(1).setAlpha((int) (this.f1896i * 255.0f));
                super.setImageDrawable(this.f1903p);
            }
        }
    }

    private void setOverlay(boolean z10) {
        this.f1895h = z10;
    }

    @Override // android.view.View
    public void draw(Canvas canvas) {
        super.draw(canvas);
    }

    public float getBrightness() {
        return this.f1894g.f1909d;
    }

    public float getContrast() {
        return this.f1894g.f1911f;
    }

    public float getCrossfade() {
        return this.f1896i;
    }

    public float getRound() {
        return this.f1898k;
    }

    public float getRoundPercent() {
        return this.f1897j;
    }

    public float getSaturation() {
        return this.f1894g.f1910e;
    }

    public float getWarmth() {
        return this.f1894g.f1912g;
    }

    public void setBrightness(float f10) {
        c cVar = this.f1894g;
        cVar.f1909d = f10;
        cVar.c(this);
    }

    public void setContrast(float f10) {
        c cVar = this.f1894g;
        cVar.f1911f = f10;
        cVar.c(this);
    }

    public void setCrossfade(float f10) {
        this.f1896i = f10;
        if (this.f1902o != null) {
            if (!this.f1895h) {
                this.f1903p.getDrawable(0).setAlpha((int) ((1.0f - this.f1896i) * 255.0f));
            }
            this.f1903p.getDrawable(1).setAlpha((int) (this.f1896i * 255.0f));
            super.setImageDrawable(this.f1903p);
        }
    }

    public void setRound(float f10) {
        if (Float.isNaN(f10)) {
            this.f1898k = f10;
            float f11 = this.f1897j;
            this.f1897j = -1.0f;
            setRoundPercent(f11);
            return;
        }
        boolean z10 = this.f1898k != f10;
        this.f1898k = f10;
        if (f10 != 0.0f) {
            if (this.f1899l == null) {
                this.f1899l = new Path();
            }
            if (this.f1901n == null) {
                this.f1901n = new RectF();
            }
            if (this.f1900m == null) {
                b bVar = new b();
                this.f1900m = bVar;
                setOutlineProvider(bVar);
            }
            setClipToOutline(true);
            this.f1901n.set(0.0f, 0.0f, getWidth(), getHeight());
            this.f1899l.reset();
            Path path = this.f1899l;
            RectF rectF = this.f1901n;
            float f12 = this.f1898k;
            path.addRoundRect(rectF, f12, f12, Path.Direction.CW);
        } else {
            setClipToOutline(false);
        }
        if (z10) {
            invalidateOutline();
        }
    }

    public void setRoundPercent(float f10) {
        boolean z10 = this.f1897j != f10;
        this.f1897j = f10;
        if (f10 != 0.0f) {
            if (this.f1899l == null) {
                this.f1899l = new Path();
            }
            if (this.f1901n == null) {
                this.f1901n = new RectF();
            }
            if (this.f1900m == null) {
                a aVar = new a();
                this.f1900m = aVar;
                setOutlineProvider(aVar);
            }
            setClipToOutline(true);
            int width = getWidth();
            int height = getHeight();
            float fMin = (Math.min(width, height) * this.f1897j) / 2.0f;
            this.f1901n.set(0.0f, 0.0f, width, height);
            this.f1899l.reset();
            this.f1899l.addRoundRect(this.f1901n, fMin, fMin, Path.Direction.CW);
        } else {
            setClipToOutline(false);
        }
        if (z10) {
            invalidateOutline();
        }
    }

    public void setSaturation(float f10) {
        c cVar = this.f1894g;
        cVar.f1910e = f10;
        cVar.c(this);
    }

    public void setWarmth(float f10) {
        c cVar = this.f1894g;
        cVar.f1912g = f10;
        cVar.c(this);
    }

    public ImageFilterView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f1894g = new c();
        this.f1895h = true;
        this.f1896i = 0.0f;
        this.f1897j = 0.0f;
        this.f1898k = Float.NaN;
        c(context, attributeSet);
    }

    public ImageFilterView(Context context, AttributeSet attributeSet, int i10) {
        super(context, attributeSet, i10);
        this.f1894g = new c();
        this.f1895h = true;
        this.f1896i = 0.0f;
        this.f1897j = 0.0f;
        this.f1898k = Float.NaN;
        c(context, attributeSet);
    }
}
