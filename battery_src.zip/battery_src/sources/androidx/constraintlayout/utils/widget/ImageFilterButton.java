package androidx.constraintlayout.utils.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Outline;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewOutlineProvider;
import androidx.appcompat.widget.AppCompatImageButton;
import androidx.constraintlayout.widget.R$styleable;

/* JADX INFO: loaded from: classes.dex */
public class ImageFilterButton extends AppCompatImageButton {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private ImageFilterView.c f1882a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private float f1883b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private float f1884c;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private float f1885g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private Path f1886h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    ViewOutlineProvider f1887i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    RectF f1888j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    Drawable[] f1889k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    LayerDrawable f1890l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    private boolean f1891m;

    class a extends ViewOutlineProvider {
        a() {
        }

        @Override // android.view.ViewOutlineProvider
        public void getOutline(View view, Outline outline) {
            int width = ImageFilterButton.this.getWidth();
            int height = ImageFilterButton.this.getHeight();
            outline.setRoundRect(0, 0, width, height, (Math.min(width, height) * ImageFilterButton.this.f1884c) / 2.0f);
        }
    }

    class b extends ViewOutlineProvider {
        b() {
        }

        @Override // android.view.ViewOutlineProvider
        public void getOutline(View view, Outline outline) {
            outline.setRoundRect(0, 0, ImageFilterButton.this.getWidth(), ImageFilterButton.this.getHeight(), ImageFilterButton.this.f1885g);
        }
    }

    public ImageFilterButton(Context context) {
        super(context);
        this.f1882a = new ImageFilterView.c();
        this.f1883b = 0.0f;
        this.f1884c = 0.0f;
        this.f1885g = Float.NaN;
        this.f1891m = true;
        c(context, null);
    }

    private void c(Context context, AttributeSet attributeSet) {
        setPadding(0, 0, 0, 0);
        if (attributeSet != null) {
            TypedArray typedArrayObtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, R$styleable.ImageFilterView);
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            Drawable drawable = typedArrayObtainStyledAttributes.getDrawable(R$styleable.ImageFilterView_altSrc);
            for (int i10 = 0; i10 < indexCount; i10++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i10);
                if (index == R$styleable.ImageFilterView_crossfade) {
                    this.f1883b = typedArrayObtainStyledAttributes.getFloat(index, 0.0f);
                } else if (index == R$styleable.ImageFilterView_warmth) {
                    setWarmth(typedArrayObtainStyledAttributes.getFloat(index, 0.0f));
                } else if (index == R$styleable.ImageFilterView_saturation) {
                    setSaturation(typedArrayObtainStyledAttributes.getFloat(index, 0.0f));
                } else if (index == R$styleable.ImageFilterView_contrast) {
                    setContrast(typedArrayObtainStyledAttributes.getFloat(index, 0.0f));
                } else if (index == R$styleable.ImageFilterView_round) {
                    setRound(typedArrayObtainStyledAttributes.getDimension(index, 0.0f));
                } else if (index == R$styleable.ImageFilterView_roundPercent) {
                    setRoundPercent(typedArrayObtainStyledAttributes.getFloat(index, 0.0f));
                } else if (index == R$styleable.ImageFilterView_overlay) {
                    setOverlay(typedArrayObtainStyledAttributes.getBoolean(index, this.f1891m));
                }
            }
            typedArrayObtainStyledAttributes.recycle();
            if (drawable != null) {
                Drawable[] drawableArr = new Drawable[2];
                this.f1889k = drawableArr;
                drawableArr[0] = getDrawable();
                this.f1889k[1] = drawable;
                LayerDrawable layerDrawable = new LayerDrawable(this.f1889k);
                this.f1890l = layerDrawable;
                layerDrawable.getDrawable(1).setAlpha((int) (this.f1883b * 255.0f));
                super.setImageDrawable(this.f1890l);
            }
        }
    }

    private void setOverlay(boolean z10) {
        this.f1891m = z10;
    }

    @Override // android.view.View
    public void draw(Canvas canvas) {
        super.draw(canvas);
    }

    public float getContrast() {
        return this.f1882a.f1911f;
    }

    public float getCrossfade() {
        return this.f1883b;
    }

    public float getRound() {
        return this.f1885g;
    }

    public float getRoundPercent() {
        return this.f1884c;
    }

    public float getSaturation() {
        return this.f1882a.f1910e;
    }

    public float getWarmth() {
        return this.f1882a.f1912g;
    }

    public void setBrightness(float f10) {
        ImageFilterView.c cVar = this.f1882a;
        cVar.f1909d = f10;
        cVar.c(this);
    }

    public void setContrast(float f10) {
        ImageFilterView.c cVar = this.f1882a;
        cVar.f1911f = f10;
        cVar.c(this);
    }

    public void setCrossfade(float f10) {
        this.f1883b = f10;
        if (this.f1889k != null) {
            if (!this.f1891m) {
                this.f1890l.getDrawable(0).setAlpha((int) ((1.0f - this.f1883b) * 255.0f));
            }
            this.f1890l.getDrawable(1).setAlpha((int) (this.f1883b * 255.0f));
            super.setImageDrawable(this.f1890l);
        }
    }

    public void setRound(float f10) {
        if (Float.isNaN(f10)) {
            this.f1885g = f10;
            float f11 = this.f1884c;
            this.f1884c = -1.0f;
            setRoundPercent(f11);
            return;
        }
        boolean z10 = this.f1885g != f10;
        this.f1885g = f10;
        if (f10 != 0.0f) {
            if (this.f1886h == null) {
                this.f1886h = new Path();
            }
            if (this.f1888j == null) {
                this.f1888j = new RectF();
            }
            if (this.f1887i == null) {
                b bVar = new b();
                this.f1887i = bVar;
                setOutlineProvider(bVar);
            }
            setClipToOutline(true);
            this.f1888j.set(0.0f, 0.0f, getWidth(), getHeight());
            this.f1886h.reset();
            Path path = this.f1886h;
            RectF rectF = this.f1888j;
            float f12 = this.f1885g;
            path.addRoundRect(rectF, f12, f12, Path.Direction.CW);
        } else {
            setClipToOutline(false);
        }
        if (z10) {
            invalidateOutline();
        }
    }

    public void setRoundPercent(float f10) {
        boolean z10 = this.f1884c != f10;
        this.f1884c = f10;
        if (f10 != 0.0f) {
            if (this.f1886h == null) {
                this.f1886h = new Path();
            }
            if (this.f1888j == null) {
                this.f1888j = new RectF();
            }
            if (this.f1887i == null) {
                a aVar = new a();
                this.f1887i = aVar;
                setOutlineProvider(aVar);
            }
            setClipToOutline(true);
            int width = getWidth();
            int height = getHeight();
            float fMin = (Math.min(width, height) * this.f1884c) / 2.0f;
            this.f1888j.set(0.0f, 0.0f, width, height);
            this.f1886h.reset();
            this.f1886h.addRoundRect(this.f1888j, fMin, fMin, Path.Direction.CW);
        } else {
            setClipToOutline(false);
        }
        if (z10) {
            invalidateOutline();
        }
    }

    public void setSaturation(float f10) {
        ImageFilterView.c cVar = this.f1882a;
        cVar.f1910e = f10;
        cVar.c(this);
    }

    public void setWarmth(float f10) {
        ImageFilterView.c cVar = this.f1882a;
        cVar.f1912g = f10;
        cVar.c(this);
    }

    public ImageFilterButton(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f1882a = new ImageFilterView.c();
        this.f1883b = 0.0f;
        this.f1884c = 0.0f;
        this.f1885g = Float.NaN;
        this.f1891m = true;
        c(context, attributeSet);
    }

    public ImageFilterButton(Context context, AttributeSet attributeSet, int i10) {
        super(context, attributeSet, i10);
        this.f1882a = new ImageFilterView.c();
        this.f1883b = 0.0f;
        this.f1884c = 0.0f;
        this.f1885g = Float.NaN;
        this.f1891m = true;
        c(context, attributeSet);
    }
}
