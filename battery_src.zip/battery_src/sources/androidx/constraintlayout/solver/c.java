package androidx.constraintlayout.solver;

/* JADX INFO: compiled from: Cache.java */
/* JADX INFO: loaded from: classes.dex */
public class c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    e<b> f1613a = new f(256);

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    e<b> f1614b = new f(256);

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    e<SolverVariable> f1615c = new f(256);

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    SolverVariable[] f1616d = new SolverVariable[32];
}
