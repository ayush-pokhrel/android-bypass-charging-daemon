package androidx.constraintlayout.solver;

import java.util.Arrays;
import java.util.Comparator;

/* JADX INFO: compiled from: PriorityGoalRow.java */
/* JADX INFO: loaded from: classes.dex */
public class g extends androidx.constraintlayout.solver.b {

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private int f1640g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private SolverVariable[] f1641h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private SolverVariable[] f1642i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private int f1643j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    b f1644k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    c f1645l;

    /* JADX INFO: compiled from: PriorityGoalRow.java */
    class a implements Comparator<SolverVariable> {
        a() {
        }

        @Override // java.util.Comparator
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public int compare(SolverVariable solverVariable, SolverVariable solverVariable2) {
            return solverVariable.f1577c - solverVariable2.f1577c;
        }
    }

    /* JADX INFO: compiled from: PriorityGoalRow.java */
    class b implements Comparable {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        SolverVariable f1647a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        g f1648b;

        public b(g gVar) {
            this.f1648b = gVar;
        }

        public boolean a(SolverVariable solverVariable, float f10) {
            boolean z10 = true;
            if (!this.f1647a.f1575a) {
                for (int i10 = 0; i10 < 9; i10++) {
                    float f11 = solverVariable.f1583i[i10];
                    if (f11 != 0.0f) {
                        float f12 = f11 * f10;
                        if (Math.abs(f12) < 1.0E-4f) {
                            f12 = 0.0f;
                        }
                        this.f1647a.f1583i[i10] = f12;
                    } else {
                        this.f1647a.f1583i[i10] = 0.0f;
                    }
                }
                return true;
            }
            for (int i11 = 0; i11 < 9; i11++) {
                float[] fArr = this.f1647a.f1583i;
                float f13 = fArr[i11] + (solverVariable.f1583i[i11] * f10);
                fArr[i11] = f13;
                if (Math.abs(f13) < 1.0E-4f) {
                    this.f1647a.f1583i[i11] = 0.0f;
                } else {
                    z10 = false;
                }
            }
            if (z10) {
                g.this.G(this.f1647a);
            }
            return false;
        }

        public void b(SolverVariable solverVariable) {
            this.f1647a = solverVariable;
        }

        public final boolean c() {
            for (int i10 = 8; i10 >= 0; i10--) {
                float f10 = this.f1647a.f1583i[i10];
                if (f10 > 0.0f) {
                    return false;
                }
                if (f10 < 0.0f) {
                    return true;
                }
            }
            return false;
        }

        @Override // java.lang.Comparable
        public int compareTo(Object obj) {
            return this.f1647a.f1577c - ((SolverVariable) obj).f1577c;
        }

        public final boolean d(SolverVariable solverVariable) {
            for (int i10 = 8; i10 >= 0; i10--) {
                float f10 = solverVariable.f1583i[i10];
                float f11 = this.f1647a.f1583i[i10];
                if (f11 != f10) {
                    if (f11 < f10) {
                        return true;
                    }
                }
            }
            return false;
        }

        public void e() {
            Arrays.fill(this.f1647a.f1583i, 0.0f);
        }

        public String toString() {
            String str = "[ ";
            if (this.f1647a != null) {
                for (int i10 = 0; i10 < 9; i10++) {
                    str = str + this.f1647a.f1583i[i10] + " ";
                }
            }
            return str + "] " + this.f1647a;
        }
    }

    public g(c cVar) {
        super(cVar);
        this.f1640g = 128;
        this.f1641h = new SolverVariable[128];
        this.f1642i = new SolverVariable[128];
        this.f1643j = 0;
        this.f1644k = new b(this);
        this.f1645l = cVar;
    }

    private final void F(SolverVariable solverVariable) {
        int i10;
        int i11 = this.f1643j + 1;
        SolverVariable[] solverVariableArr = this.f1641h;
        if (i11 > solverVariableArr.length) {
            SolverVariable[] solverVariableArr2 = (SolverVariable[]) Arrays.copyOf(solverVariableArr, solverVariableArr.length * 2);
            this.f1641h = solverVariableArr2;
            this.f1642i = (SolverVariable[]) Arrays.copyOf(solverVariableArr2, solverVariableArr2.length * 2);
        }
        SolverVariable[] solverVariableArr3 = this.f1641h;
        int i12 = this.f1643j;
        solverVariableArr3[i12] = solverVariable;
        int i13 = i12 + 1;
        this.f1643j = i13;
        if (i13 > 1 && solverVariableArr3[i12].f1577c > solverVariable.f1577c) {
            int i14 = 0;
            while (true) {
                i10 = this.f1643j;
                if (i14 >= i10) {
                    break;
                }
                this.f1642i[i14] = this.f1641h[i14];
                i14++;
            }
            Arrays.sort(this.f1642i, 0, i10, new a());
            for (int i15 = 0; i15 < this.f1643j; i15++) {
                this.f1641h[i15] = this.f1642i[i15];
            }
        }
        solverVariable.f1575a = true;
        solverVariable.a(this);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void G(SolverVariable solverVariable) {
        int i10 = 0;
        while (i10 < this.f1643j) {
            if (this.f1641h[i10] == solverVariable) {
                while (true) {
                    int i11 = this.f1643j;
                    if (i10 >= i11 - 1) {
                        this.f1643j = i11 - 1;
                        solverVariable.f1575a = false;
                        return;
                    } else {
                        SolverVariable[] solverVariableArr = this.f1641h;
                        int i12 = i10 + 1;
                        solverVariableArr[i10] = solverVariableArr[i12];
                        i10 = i12;
                    }
                }
            } else {
                i10++;
            }
        }
    }

    @Override // androidx.constraintlayout.solver.b
    public void C(androidx.constraintlayout.solver.b bVar, boolean z10) {
        SolverVariable solverVariable = bVar.f1607a;
        if (solverVariable == null) {
            return;
        }
        androidx.constraintlayout.solver.b.a aVar = bVar.f1611e;
        int iE = aVar.e();
        for (int i10 = 0; i10 < iE; i10++) {
            SolverVariable solverVariableI = aVar.i(i10);
            float fA = aVar.a(i10);
            this.f1644k.b(solverVariableI);
            if (this.f1644k.a(solverVariable, fA)) {
                F(solverVariableI);
            }
            this.f1608b += bVar.f1608b * fA;
        }
        G(solverVariable);
    }

    @Override // androidx.constraintlayout.solver.b, androidx.constraintlayout.solver.d.a
    public void b(SolverVariable solverVariable) {
        this.f1644k.b(solverVariable);
        this.f1644k.e();
        solverVariable.f1583i[solverVariable.f1579e] = 1.0f;
        F(solverVariable);
    }

    /* JADX WARN: Code duplicated, block: B:15:0x002e  */
    @Override // androidx.constraintlayout.solver.b, androidx.constraintlayout.solver.d.a
    public SolverVariable c(d dVar, boolean[] zArr) {
        int i10 = -1;
        for (int i11 = 0; i11 < this.f1643j; i11++) {
            SolverVariable solverVariable = this.f1641h[i11];
            if (!zArr[solverVariable.f1577c]) {
                this.f1644k.b(solverVariable);
                if (i10 == -1) {
                    if (this.f1644k.c()) {
                        i10 = i11;
                    }
                } else if (this.f1644k.d(this.f1641h[i10])) {
                    i10 = i11;
                }
            }
        }
        if (i10 == -1) {
            return null;
        }
        return this.f1641h[i10];
    }

    @Override // androidx.constraintlayout.solver.b, androidx.constraintlayout.solver.d.a
    public void clear() {
        this.f1643j = 0;
        this.f1608b = 0.0f;
    }

    @Override // androidx.constraintlayout.solver.b
    public String toString() {
        String str = " goal -> (" + this.f1608b + ") : ";
        for (int i10 = 0; i10 < this.f1643j; i10++) {
            this.f1644k.b(this.f1641h[i10]);
            str = str + this.f1644k + " ";
        }
        return str;
    }
}
