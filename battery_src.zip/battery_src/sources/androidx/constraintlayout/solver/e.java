package androidx.constraintlayout.solver;

/* JADX INFO: compiled from: Pools.java */
/* JADX INFO: loaded from: classes.dex */
interface e<T> {
    boolean a(T t10);

    T b();

    void c(T[] tArr, int i10);
}
