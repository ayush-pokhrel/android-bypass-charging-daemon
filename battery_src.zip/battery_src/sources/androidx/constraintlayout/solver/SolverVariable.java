package androidx.constraintlayout.solver;

import java.util.Arrays;
import java.util.HashSet;

/* JADX INFO: loaded from: classes.dex */
public class SolverVariable {

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    private static int f1574o = 1;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public boolean f1575a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private String f1576b;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public float f1580f;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    Type f1584j;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public int f1577c = -1;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    int f1578d = -1;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f1579e = 0;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public boolean f1581g = false;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    float[] f1582h = new float[9];

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    float[] f1583i = new float[9];

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    b[] f1585k = new b[16];

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    int f1586l = 0;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public int f1587m = 0;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    HashSet<b> f1588n = null;

    public enum Type {
        UNRESTRICTED,
        CONSTANT,
        SLACK,
        ERROR,
        UNKNOWN
    }

    public SolverVariable(Type type, String str) {
        this.f1584j = type;
    }

    static void b() {
        f1574o++;
    }

    public final void a(b bVar) {
        int i10 = 0;
        while (true) {
            int i11 = this.f1586l;
            if (i10 >= i11) {
                b[] bVarArr = this.f1585k;
                if (i11 >= bVarArr.length) {
                    this.f1585k = (b[]) Arrays.copyOf(bVarArr, bVarArr.length * 2);
                }
                b[] bVarArr2 = this.f1585k;
                int i12 = this.f1586l;
                bVarArr2[i12] = bVar;
                this.f1586l = i12 + 1;
                return;
            }
            if (this.f1585k[i10] == bVar) {
                return;
            } else {
                i10++;
            }
        }
    }

    public final void c(b bVar) {
        int i10 = this.f1586l;
        int i11 = 0;
        while (i11 < i10) {
            if (this.f1585k[i11] == bVar) {
                while (i11 < i10 - 1) {
                    b[] bVarArr = this.f1585k;
                    int i12 = i11 + 1;
                    bVarArr[i11] = bVarArr[i12];
                    i11 = i12;
                }
                this.f1586l--;
                return;
            }
            i11++;
        }
    }

    public void d() {
        this.f1576b = null;
        this.f1584j = Type.UNKNOWN;
        this.f1579e = 0;
        this.f1577c = -1;
        this.f1578d = -1;
        this.f1580f = 0.0f;
        this.f1581g = false;
        int i10 = this.f1586l;
        for (int i11 = 0; i11 < i10; i11++) {
            this.f1585k[i11] = null;
        }
        this.f1586l = 0;
        this.f1587m = 0;
        this.f1575a = false;
        Arrays.fill(this.f1583i, 0.0f);
    }

    public void e(d dVar, float f10) {
        this.f1580f = f10;
        this.f1581g = true;
        int i10 = this.f1586l;
        for (int i11 = 0; i11 < i10; i11++) {
            this.f1585k[i11].B(dVar, this, false);
        }
        this.f1586l = 0;
    }

    public void f(Type type, String str) {
        this.f1584j = type;
    }

    public final void g(b bVar) {
        int i10 = this.f1586l;
        for (int i11 = 0; i11 < i10; i11++) {
            this.f1585k[i11].C(bVar, false);
        }
        this.f1586l = 0;
    }

    public String toString() {
        if (this.f1576b != null) {
            return "" + this.f1576b;
        }
        return "" + this.f1577c;
    }
}
