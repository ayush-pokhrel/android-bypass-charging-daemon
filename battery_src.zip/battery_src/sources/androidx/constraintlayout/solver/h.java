package androidx.constraintlayout.solver;

import java.util.Arrays;

/* JADX INFO: compiled from: SolverVariableValues.java */
/* JADX INFO: loaded from: classes.dex */
public class h implements b.a {

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    private static float f1650n = 0.001f;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final int f1651a = -1;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private int f1652b = 16;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private int f1653c = 16;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    int[] f1654d = new int[16];

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    int[] f1655e = new int[16];

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    int[] f1656f = new int[16];

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    float[] f1657g = new float[16];

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    int[] f1658h = new int[16];

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    int[] f1659i = new int[16];

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    int f1660j = 0;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    int f1661k = -1;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private final b f1662l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    protected final c f1663m;

    h(b bVar, c cVar) {
        this.f1662l = bVar;
        this.f1663m = cVar;
        clear();
    }

    private void l(SolverVariable solverVariable, int i10) {
        int[] iArr;
        int i11 = solverVariable.f1577c % this.f1653c;
        int[] iArr2 = this.f1654d;
        int i12 = iArr2[i11];
        if (i12 == -1) {
            iArr2[i11] = i10;
        } else {
            while (true) {
                iArr = this.f1655e;
                int i13 = iArr[i12];
                if (i13 == -1) {
                    break;
                } else {
                    i12 = i13;
                }
            }
            iArr[i12] = i10;
        }
        this.f1655e[i10] = -1;
    }

    private void m(int i10, SolverVariable solverVariable, float f10) {
        this.f1656f[i10] = solverVariable.f1577c;
        this.f1657g[i10] = f10;
        this.f1658h[i10] = -1;
        this.f1659i[i10] = -1;
        solverVariable.a(this.f1662l);
        solverVariable.f1587m++;
        this.f1660j++;
    }

    private int n() {
        for (int i10 = 0; i10 < this.f1652b; i10++) {
            if (this.f1656f[i10] == -1) {
                return i10;
            }
        }
        return -1;
    }

    private void o() {
        int i10 = this.f1652b * 2;
        this.f1656f = Arrays.copyOf(this.f1656f, i10);
        this.f1657g = Arrays.copyOf(this.f1657g, i10);
        this.f1658h = Arrays.copyOf(this.f1658h, i10);
        this.f1659i = Arrays.copyOf(this.f1659i, i10);
        this.f1655e = Arrays.copyOf(this.f1655e, i10);
        for (int i11 = this.f1652b; i11 < i10; i11++) {
            this.f1656f[i11] = -1;
            this.f1655e[i11] = -1;
        }
        this.f1652b = i10;
    }

    private void q(int i10, SolverVariable solverVariable, float f10) {
        int iN = n();
        m(iN, solverVariable, f10);
        if (i10 != -1) {
            this.f1658h[iN] = i10;
            int[] iArr = this.f1659i;
            iArr[iN] = iArr[i10];
            iArr[i10] = iN;
        } else {
            this.f1658h[iN] = -1;
            if (this.f1660j > 0) {
                this.f1659i[iN] = this.f1661k;
                this.f1661k = iN;
            } else {
                this.f1659i[iN] = -1;
            }
        }
        int i11 = this.f1659i[iN];
        if (i11 != -1) {
            this.f1658h[i11] = iN;
        }
        l(solverVariable, iN);
    }

    private void r(SolverVariable solverVariable) {
        int[] iArr;
        int i10;
        int i11 = solverVariable.f1577c;
        int i12 = i11 % this.f1653c;
        int[] iArr2 = this.f1654d;
        int i13 = iArr2[i12];
        if (i13 == -1) {
            return;
        }
        if (this.f1656f[i13] == i11) {
            int[] iArr3 = this.f1655e;
            iArr2[i12] = iArr3[i13];
            iArr3[i13] = -1;
            return;
        }
        while (true) {
            iArr = this.f1655e;
            i10 = iArr[i13];
            if (i10 == -1 || this.f1656f[i10] == i11) {
                break;
            } else {
                i13 = i10;
            }
        }
        if (i10 == -1 || this.f1656f[i10] != i11) {
            return;
        }
        iArr[i13] = iArr[i10];
        iArr[i10] = -1;
    }

    @Override // androidx.constraintlayout.solver.b.a
    public float a(int i10) {
        int i11 = this.f1660j;
        int i12 = this.f1661k;
        for (int i13 = 0; i13 < i11; i13++) {
            if (i13 == i10) {
                return this.f1657g[i12];
            }
            i12 = this.f1659i[i12];
            if (i12 == -1) {
                return 0.0f;
            }
        }
        return 0.0f;
    }

    @Override // androidx.constraintlayout.solver.b.a
    public void b(SolverVariable solverVariable, float f10, boolean z10) {
        float f11 = f1650n;
        if (f10 <= (-f11) || f10 >= f11) {
            int iP = p(solverVariable);
            if (iP == -1) {
                g(solverVariable, f10);
                return;
            }
            float[] fArr = this.f1657g;
            float f12 = fArr[iP] + f10;
            fArr[iP] = f12;
            float f13 = f1650n;
            if (f12 <= (-f13) || f12 >= f13) {
                return;
            }
            fArr[iP] = 0.0f;
            h(solverVariable, z10);
        }
    }

    @Override // androidx.constraintlayout.solver.b.a
    public float c(SolverVariable solverVariable) {
        int iP = p(solverVariable);
        if (iP != -1) {
            return this.f1657g[iP];
        }
        return 0.0f;
    }

    @Override // androidx.constraintlayout.solver.b.a
    public void clear() {
        int i10 = this.f1660j;
        for (int i11 = 0; i11 < i10; i11++) {
            SolverVariable solverVariableI = i(i11);
            if (solverVariableI != null) {
                solverVariableI.c(this.f1662l);
            }
        }
        for (int i12 = 0; i12 < this.f1652b; i12++) {
            this.f1656f[i12] = -1;
            this.f1655e[i12] = -1;
        }
        for (int i13 = 0; i13 < this.f1653c; i13++) {
            this.f1654d[i13] = -1;
        }
        this.f1660j = 0;
        this.f1661k = -1;
    }

    @Override // androidx.constraintlayout.solver.b.a
    public boolean d(SolverVariable solverVariable) {
        return p(solverVariable) != -1;
    }

    @Override // androidx.constraintlayout.solver.b.a
    public int e() {
        return this.f1660j;
    }

    @Override // androidx.constraintlayout.solver.b.a
    public float f(b bVar, boolean z10) {
        float fC = c(bVar.f1607a);
        h(bVar.f1607a, z10);
        h hVar = (h) bVar.f1611e;
        int iE = hVar.e();
        int i10 = 0;
        int i11 = 0;
        while (i10 < iE) {
            int i12 = hVar.f1656f[i11];
            if (i12 != -1) {
                b(this.f1663m.f1616d[i12], hVar.f1657g[i11] * fC, z10);
                i10++;
            }
            i11++;
        }
        return fC;
    }

    @Override // androidx.constraintlayout.solver.b.a
    public void g(SolverVariable solverVariable, float f10) {
        float f11 = f1650n;
        if (f10 > (-f11) && f10 < f11) {
            h(solverVariable, true);
            return;
        }
        if (this.f1660j == 0) {
            m(0, solverVariable, f10);
            l(solverVariable, 0);
            this.f1661k = 0;
            return;
        }
        int iP = p(solverVariable);
        if (iP != -1) {
            this.f1657g[iP] = f10;
            return;
        }
        if (this.f1660j + 1 >= this.f1652b) {
            o();
        }
        int i10 = this.f1660j;
        int i11 = this.f1661k;
        int i12 = -1;
        for (int i13 = 0; i13 < i10; i13++) {
            int i14 = this.f1656f[i11];
            int i15 = solverVariable.f1577c;
            if (i14 == i15) {
                this.f1657g[i11] = f10;
                return;
            }
            if (i14 < i15) {
                i12 = i11;
            }
            i11 = this.f1659i[i11];
            if (i11 == -1) {
                break;
            }
        }
        q(i12, solverVariable, f10);
    }

    @Override // androidx.constraintlayout.solver.b.a
    public float h(SolverVariable solverVariable, boolean z10) {
        int iP = p(solverVariable);
        if (iP == -1) {
            return 0.0f;
        }
        r(solverVariable);
        float f10 = this.f1657g[iP];
        if (this.f1661k == iP) {
            this.f1661k = this.f1659i[iP];
        }
        this.f1656f[iP] = -1;
        int[] iArr = this.f1658h;
        int i10 = iArr[iP];
        if (i10 != -1) {
            int[] iArr2 = this.f1659i;
            iArr2[i10] = iArr2[iP];
        }
        int i11 = this.f1659i[iP];
        if (i11 != -1) {
            iArr[i11] = iArr[iP];
        }
        this.f1660j--;
        solverVariable.f1587m--;
        if (z10) {
            solverVariable.c(this.f1662l);
        }
        return f10;
    }

    @Override // androidx.constraintlayout.solver.b.a
    public SolverVariable i(int i10) {
        int i11 = this.f1660j;
        if (i11 == 0) {
            return null;
        }
        int i12 = this.f1661k;
        for (int i13 = 0; i13 < i11; i13++) {
            if (i13 == i10 && i12 != -1) {
                return this.f1663m.f1616d[this.f1656f[i12]];
            }
            i12 = this.f1659i[i12];
            if (i12 == -1) {
                break;
            }
        }
        return null;
    }

    @Override // androidx.constraintlayout.solver.b.a
    public void j(float f10) {
        int i10 = this.f1660j;
        int i11 = this.f1661k;
        for (int i12 = 0; i12 < i10; i12++) {
            float[] fArr = this.f1657g;
            fArr[i11] = fArr[i11] / f10;
            i11 = this.f1659i[i11];
            if (i11 == -1) {
                return;
            }
        }
    }

    @Override // androidx.constraintlayout.solver.b.a
    public void k() {
        int i10 = this.f1660j;
        int i11 = this.f1661k;
        for (int i12 = 0; i12 < i10; i12++) {
            float[] fArr = this.f1657g;
            fArr[i11] = fArr[i11] * (-1.0f);
            i11 = this.f1659i[i11];
            if (i11 == -1) {
                return;
            }
        }
    }

    public int p(SolverVariable solverVariable) {
        if (this.f1660j == 0) {
            return -1;
        }
        int i10 = solverVariable.f1577c;
        int i11 = this.f1654d[i10 % this.f1653c];
        if (i11 == -1) {
            return -1;
        }
        if (this.f1656f[i11] == i10) {
            return i11;
        }
        do {
            i11 = this.f1655e[i11];
            if (i11 == -1) {
                break;
            }
        } while (this.f1656f[i11] != i10);
        if (i11 != -1 && this.f1656f[i11] == i10) {
            return i11;
        }
        return -1;
    }

    public String toString() {
        String str = hashCode() + " { ";
        int i10 = this.f1660j;
        for (int i11 = 0; i11 < i10; i11++) {
            SolverVariable solverVariableI = i(i11);
            if (solverVariableI != null) {
                String str2 = str + solverVariableI + " = " + a(i11) + " ";
                int iP = p(solverVariableI);
                String str3 = str2 + "[p: ";
                String str4 = (this.f1658h[iP] != -1 ? str3 + this.f1663m.f1616d[this.f1656f[this.f1658h[iP]]] : str3 + "none") + ", n: ";
                str = (this.f1659i[iP] != -1 ? str4 + this.f1663m.f1616d[this.f1656f[this.f1659i[iP]]] : str4 + "none") + "]";
            }
        }
        return str + " }";
    }
}
