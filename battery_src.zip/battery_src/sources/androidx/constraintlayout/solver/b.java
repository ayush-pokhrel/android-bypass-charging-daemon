package androidx.constraintlayout.solver;

import java.util.ArrayList;

/* JADX INFO: compiled from: ArrayRow.java */
/* JADX INFO: loaded from: classes.dex */
public class b implements d.a {

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public a f1611e;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    SolverVariable f1607a = null;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    float f1608b = 0.0f;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    boolean f1609c = false;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    ArrayList<SolverVariable> f1610d = new ArrayList<>();

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    boolean f1612f = false;

    /* JADX INFO: compiled from: ArrayRow.java */
    public interface a {
        float a(int i10);

        void b(SolverVariable solverVariable, float f10, boolean z10);

        float c(SolverVariable solverVariable);

        void clear();

        boolean d(SolverVariable solverVariable);

        int e();

        float f(b bVar, boolean z10);

        void g(SolverVariable solverVariable, float f10);

        float h(SolverVariable solverVariable, boolean z10);

        SolverVariable i(int i10);

        void j(float f10);

        void k();
    }

    public b() {
    }

    private boolean v(SolverVariable solverVariable, d dVar) {
        return solverVariable.f1587m <= 1;
    }

    private SolverVariable x(boolean[] zArr, SolverVariable solverVariable) {
        SolverVariable.Type type;
        int iE = this.f1611e.e();
        SolverVariable solverVariable2 = null;
        float f10 = 0.0f;
        for (int i10 = 0; i10 < iE; i10++) {
            float fA = this.f1611e.a(i10);
            if (fA < 0.0f) {
                SolverVariable solverVariableI = this.f1611e.i(i10);
                if ((zArr == null || !zArr[solverVariableI.f1577c]) && solverVariableI != solverVariable && (((type = solverVariableI.f1584j) == SolverVariable.Type.SLACK || type == SolverVariable.Type.ERROR) && fA < f10)) {
                    f10 = fA;
                    solverVariable2 = solverVariableI;
                }
            }
        }
        return solverVariable2;
    }

    String A() {
        boolean z10;
        String str = (this.f1607a == null ? "0" : "" + this.f1607a) + " = ";
        if (this.f1608b != 0.0f) {
            str = str + this.f1608b;
            z10 = true;
        } else {
            z10 = false;
        }
        int iE = this.f1611e.e();
        for (int i10 = 0; i10 < iE; i10++) {
            SolverVariable solverVariableI = this.f1611e.i(i10);
            if (solverVariableI != null) {
                float fA = this.f1611e.a(i10);
                if (fA != 0.0f) {
                    String string = solverVariableI.toString();
                    if (z10) {
                        if (fA > 0.0f) {
                            str = str + " + ";
                        } else {
                            str = str + " - ";
                            fA *= -1.0f;
                        }
                    } else if (fA < 0.0f) {
                        str = str + "- ";
                        fA *= -1.0f;
                    }
                    str = fA == 1.0f ? str + string : str + fA + " " + string;
                    z10 = true;
                }
            }
        }
        if (z10) {
            return str;
        }
        return str + "0.0";
    }

    public void B(d dVar, SolverVariable solverVariable, boolean z10) {
        if (solverVariable.f1581g) {
            this.f1608b += solverVariable.f1580f * this.f1611e.c(solverVariable);
            this.f1611e.h(solverVariable, z10);
            if (z10) {
                solverVariable.c(this);
            }
        }
    }

    public void C(b bVar, boolean z10) {
        this.f1608b += bVar.f1608b * this.f1611e.f(bVar, z10);
        if (z10) {
            bVar.f1607a.c(this);
        }
    }

    public void D(d dVar) {
        if (dVar.f1626f.length == 0) {
            return;
        }
        boolean z10 = false;
        while (!z10) {
            int iE = this.f1611e.e();
            for (int i10 = 0; i10 < iE; i10++) {
                SolverVariable solverVariableI = this.f1611e.i(i10);
                if (solverVariableI.f1578d != -1 || solverVariableI.f1581g) {
                    this.f1610d.add(solverVariableI);
                }
            }
            if (this.f1610d.size() > 0) {
                for (SolverVariable solverVariable : this.f1610d) {
                    if (solverVariable.f1581g) {
                        B(dVar, solverVariable, true);
                    } else {
                        C(dVar.f1626f[solverVariable.f1578d], true);
                    }
                }
                this.f1610d.clear();
            } else {
                z10 = true;
            }
        }
    }

    @Override // androidx.constraintlayout.solver.d.a
    public void a(d.a aVar) {
        if (aVar instanceof b) {
            b bVar = (b) aVar;
            this.f1607a = null;
            this.f1611e.clear();
            for (int i10 = 0; i10 < bVar.f1611e.e(); i10++) {
                this.f1611e.b(bVar.f1611e.i(i10), bVar.f1611e.a(i10), true);
            }
        }
    }

    @Override // androidx.constraintlayout.solver.d.a
    public void b(SolverVariable solverVariable) {
        int i10 = solverVariable.f1579e;
        float f10 = 1.0f;
        if (i10 != 1) {
            if (i10 == 2) {
                f10 = 1000.0f;
            } else if (i10 == 3) {
                f10 = 1000000.0f;
            } else if (i10 == 4) {
                f10 = 1.0E9f;
            } else if (i10 == 5) {
                f10 = 1.0E12f;
            }
        }
        this.f1611e.g(solverVariable, f10);
    }

    @Override // androidx.constraintlayout.solver.d.a
    public SolverVariable c(d dVar, boolean[] zArr) {
        return x(zArr, null);
    }

    @Override // androidx.constraintlayout.solver.d.a
    public void clear() {
        this.f1611e.clear();
        this.f1607a = null;
        this.f1608b = 0.0f;
    }

    public b d(d dVar, int i10) {
        this.f1611e.g(dVar.o(i10, "ep"), 1.0f);
        this.f1611e.g(dVar.o(i10, "em"), -1.0f);
        return this;
    }

    b e(SolverVariable solverVariable, int i10) {
        this.f1611e.g(solverVariable, i10);
        return this;
    }

    boolean f(d dVar) {
        boolean z10;
        SolverVariable solverVariableG = g(dVar);
        if (solverVariableG == null) {
            z10 = true;
        } else {
            y(solverVariableG);
            z10 = false;
        }
        if (this.f1611e.e() == 0) {
            this.f1612f = true;
        }
        return z10;
    }

    SolverVariable g(d dVar) {
        int iE = this.f1611e.e();
        SolverVariable solverVariable = null;
        float f10 = 0.0f;
        float f11 = 0.0f;
        boolean z10 = false;
        boolean z11 = false;
        SolverVariable solverVariable2 = null;
        for (int i10 = 0; i10 < iE; i10++) {
            float fA = this.f1611e.a(i10);
            SolverVariable solverVariableI = this.f1611e.i(i10);
            if (solverVariableI.f1584j == SolverVariable.Type.UNRESTRICTED) {
                if (solverVariable == null || f10 > fA) {
                    boolean zV = v(solverVariableI, dVar);
                    z10 = zV;
                    f10 = fA;
                    solverVariable = solverVariableI;
                } else if (!z10 && v(solverVariableI, dVar)) {
                    f10 = fA;
                    solverVariable = solverVariableI;
                    z10 = true;
                }
            } else if (solverVariable == null && fA < 0.0f) {
                if (solverVariable2 == null || f11 > fA) {
                    boolean zV2 = v(solverVariableI, dVar);
                    z11 = zV2;
                    f11 = fA;
                    solverVariable2 = solverVariableI;
                } else if (!z11 && v(solverVariableI, dVar)) {
                    f11 = fA;
                    solverVariable2 = solverVariableI;
                    z11 = true;
                }
            }
        }
        return solverVariable != null ? solverVariable : solverVariable2;
    }

    @Override // androidx.constraintlayout.solver.d.a
    public SolverVariable getKey() {
        return this.f1607a;
    }

    b h(SolverVariable solverVariable, SolverVariable solverVariable2, int i10, float f10, SolverVariable solverVariable3, SolverVariable solverVariable4, int i11) {
        if (solverVariable2 == solverVariable3) {
            this.f1611e.g(solverVariable, 1.0f);
            this.f1611e.g(solverVariable4, 1.0f);
            this.f1611e.g(solverVariable2, -2.0f);
            return this;
        }
        if (f10 == 0.5f) {
            this.f1611e.g(solverVariable, 1.0f);
            this.f1611e.g(solverVariable2, -1.0f);
            this.f1611e.g(solverVariable3, -1.0f);
            this.f1611e.g(solverVariable4, 1.0f);
            if (i10 > 0 || i11 > 0) {
                this.f1608b = (-i10) + i11;
            }
        } else if (f10 <= 0.0f) {
            this.f1611e.g(solverVariable, -1.0f);
            this.f1611e.g(solverVariable2, 1.0f);
            this.f1608b = i10;
        } else if (f10 >= 1.0f) {
            this.f1611e.g(solverVariable4, -1.0f);
            this.f1611e.g(solverVariable3, 1.0f);
            this.f1608b = -i11;
        } else {
            float f11 = 1.0f - f10;
            this.f1611e.g(solverVariable, f11 * 1.0f);
            this.f1611e.g(solverVariable2, f11 * (-1.0f));
            this.f1611e.g(solverVariable3, (-1.0f) * f10);
            this.f1611e.g(solverVariable4, 1.0f * f10);
            if (i10 > 0 || i11 > 0) {
                this.f1608b = ((-i10) * f11) + (i11 * f10);
            }
        }
        return this;
    }

    b i(SolverVariable solverVariable, int i10) {
        this.f1607a = solverVariable;
        float f10 = i10;
        solverVariable.f1580f = f10;
        this.f1608b = f10;
        this.f1612f = true;
        return this;
    }

    b j(SolverVariable solverVariable, SolverVariable solverVariable2, float f10) {
        this.f1611e.g(solverVariable, -1.0f);
        this.f1611e.g(solverVariable2, f10);
        return this;
    }

    public b k(SolverVariable solverVariable, SolverVariable solverVariable2, SolverVariable solverVariable3, SolverVariable solverVariable4, float f10) {
        this.f1611e.g(solverVariable, -1.0f);
        this.f1611e.g(solverVariable2, 1.0f);
        this.f1611e.g(solverVariable3, f10);
        this.f1611e.g(solverVariable4, -f10);
        return this;
    }

    public b l(float f10, float f11, float f12, SolverVariable solverVariable, SolverVariable solverVariable2, SolverVariable solverVariable3, SolverVariable solverVariable4) {
        this.f1608b = 0.0f;
        if (f11 == 0.0f || f10 == f12) {
            this.f1611e.g(solverVariable, 1.0f);
            this.f1611e.g(solverVariable2, -1.0f);
            this.f1611e.g(solverVariable4, 1.0f);
            this.f1611e.g(solverVariable3, -1.0f);
        } else if (f10 == 0.0f) {
            this.f1611e.g(solverVariable, 1.0f);
            this.f1611e.g(solverVariable2, -1.0f);
        } else if (f12 == 0.0f) {
            this.f1611e.g(solverVariable3, 1.0f);
            this.f1611e.g(solverVariable4, -1.0f);
        } else {
            float f13 = (f10 / f11) / (f12 / f11);
            this.f1611e.g(solverVariable, 1.0f);
            this.f1611e.g(solverVariable2, -1.0f);
            this.f1611e.g(solverVariable4, f13);
            this.f1611e.g(solverVariable3, -f13);
        }
        return this;
    }

    public b m(SolverVariable solverVariable, int i10) {
        if (i10 < 0) {
            this.f1608b = i10 * (-1);
            this.f1611e.g(solverVariable, 1.0f);
        } else {
            this.f1608b = i10;
            this.f1611e.g(solverVariable, -1.0f);
        }
        return this;
    }

    public b n(SolverVariable solverVariable, SolverVariable solverVariable2, int i10) {
        boolean z10 = false;
        if (i10 != 0) {
            if (i10 < 0) {
                i10 *= -1;
                z10 = true;
            }
            this.f1608b = i10;
        }
        if (z10) {
            this.f1611e.g(solverVariable, 1.0f);
            this.f1611e.g(solverVariable2, -1.0f);
        } else {
            this.f1611e.g(solverVariable, -1.0f);
            this.f1611e.g(solverVariable2, 1.0f);
        }
        return this;
    }

    public b o(SolverVariable solverVariable, SolverVariable solverVariable2, SolverVariable solverVariable3, int i10) {
        boolean z10 = false;
        if (i10 != 0) {
            if (i10 < 0) {
                i10 *= -1;
                z10 = true;
            }
            this.f1608b = i10;
        }
        if (z10) {
            this.f1611e.g(solverVariable, 1.0f);
            this.f1611e.g(solverVariable2, -1.0f);
            this.f1611e.g(solverVariable3, -1.0f);
        } else {
            this.f1611e.g(solverVariable, -1.0f);
            this.f1611e.g(solverVariable2, 1.0f);
            this.f1611e.g(solverVariable3, 1.0f);
        }
        return this;
    }

    public b p(SolverVariable solverVariable, SolverVariable solverVariable2, SolverVariable solverVariable3, int i10) {
        boolean z10 = false;
        if (i10 != 0) {
            if (i10 < 0) {
                i10 *= -1;
                z10 = true;
            }
            this.f1608b = i10;
        }
        if (z10) {
            this.f1611e.g(solverVariable, 1.0f);
            this.f1611e.g(solverVariable2, -1.0f);
            this.f1611e.g(solverVariable3, 1.0f);
        } else {
            this.f1611e.g(solverVariable, -1.0f);
            this.f1611e.g(solverVariable2, 1.0f);
            this.f1611e.g(solverVariable3, -1.0f);
        }
        return this;
    }

    public b q(SolverVariable solverVariable, SolverVariable solverVariable2, SolverVariable solverVariable3, SolverVariable solverVariable4, float f10) {
        this.f1611e.g(solverVariable3, 0.5f);
        this.f1611e.g(solverVariable4, 0.5f);
        this.f1611e.g(solverVariable, -0.5f);
        this.f1611e.g(solverVariable2, -0.5f);
        this.f1608b = -f10;
        return this;
    }

    void r() {
        float f10 = this.f1608b;
        if (f10 < 0.0f) {
            this.f1608b = f10 * (-1.0f);
            this.f1611e.k();
        }
    }

    boolean s() {
        SolverVariable solverVariable = this.f1607a;
        return solverVariable != null && (solverVariable.f1584j == SolverVariable.Type.UNRESTRICTED || this.f1608b >= 0.0f);
    }

    boolean t(SolverVariable solverVariable) {
        return this.f1611e.d(solverVariable);
    }

    public String toString() {
        return A();
    }

    public boolean u() {
        return this.f1607a == null && this.f1608b == 0.0f && this.f1611e.e() == 0;
    }

    public SolverVariable w(SolverVariable solverVariable) {
        return x(null, solverVariable);
    }

    void y(SolverVariable solverVariable) {
        SolverVariable solverVariable2 = this.f1607a;
        if (solverVariable2 != null) {
            this.f1611e.g(solverVariable2, -1.0f);
            this.f1607a = null;
        }
        float fH = this.f1611e.h(solverVariable, true) * (-1.0f);
        this.f1607a = solverVariable;
        if (fH == 1.0f) {
            return;
        }
        this.f1608b /= fH;
        this.f1611e.j(fH);
    }

    public void z() {
        this.f1607a = null;
        this.f1611e.clear();
        this.f1608b = 0.0f;
        this.f1612f = false;
    }

    public b(c cVar) {
        this.f1611e = new androidx.constraintlayout.solver.a(this, cVar);
    }
}
