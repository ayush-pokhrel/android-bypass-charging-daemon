package androidx.constraintlayout.solver;

/* JADX INFO: compiled from: Pools.java */
/* JADX INFO: loaded from: classes.dex */
class f<T> implements e<T> {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final Object[] f1638a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private int f1639b;

    f(int i10) {
        if (i10 <= 0) {
            throw new IllegalArgumentException("The max pool size must be > 0");
        }
        this.f1638a = new Object[i10];
    }

    @Override // androidx.constraintlayout.solver.e
    public boolean a(T t10) {
        int i10 = this.f1639b;
        Object[] objArr = this.f1638a;
        if (i10 >= objArr.length) {
            return false;
        }
        objArr[i10] = t10;
        this.f1639b = i10 + 1;
        return true;
    }

    @Override // androidx.constraintlayout.solver.e
    public T b() {
        int i10 = this.f1639b;
        if (i10 <= 0) {
            return null;
        }
        int i11 = i10 - 1;
        Object[] objArr = this.f1638a;
        T t10 = (T) objArr[i11];
        objArr[i11] = null;
        this.f1639b = i10 - 1;
        return t10;
    }

    @Override // androidx.constraintlayout.solver.e
    public void c(T[] tArr, int i10) {
        if (i10 > tArr.length) {
            i10 = tArr.length;
        }
        for (int i11 = 0; i11 < i10; i11++) {
            T t10 = tArr[i11];
            int i12 = this.f1639b;
            Object[] objArr = this.f1638a;
            if (i12 < objArr.length) {
                objArr[i12] = t10;
                this.f1639b = i12 + 1;
            }
        }
    }
}
