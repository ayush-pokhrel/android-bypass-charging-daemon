package androidx.constraintlayout.solver;

import java.util.Arrays;

/* JADX INFO: compiled from: ArrayLinkedVariables.java */
/* JADX INFO: loaded from: classes.dex */
public class a implements b.a {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private static float f1595l = 0.001f;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private final b f1597b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    protected final c f1598c;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    int f1596a = 0;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private int f1599d = 8;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private SolverVariable f1600e = null;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private int[] f1601f = new int[8];

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private int[] f1602g = new int[8];

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private float[] f1603h = new float[8];

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private int f1604i = -1;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private int f1605j = -1;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    private boolean f1606k = false;

    a(b bVar, c cVar) {
        this.f1597b = bVar;
        this.f1598c = cVar;
    }

    @Override // androidx.constraintlayout.solver.b.a
    public float a(int i10) {
        int i11 = this.f1604i;
        for (int i12 = 0; i11 != -1 && i12 < this.f1596a; i12++) {
            if (i12 == i10) {
                return this.f1603h[i11];
            }
            i11 = this.f1602g[i11];
        }
        return 0.0f;
    }

    @Override // androidx.constraintlayout.solver.b.a
    public void b(SolverVariable solverVariable, float f10, boolean z10) {
        float f11 = f1595l;
        if (f10 <= (-f11) || f10 >= f11) {
            int i10 = this.f1604i;
            if (i10 == -1) {
                this.f1604i = 0;
                this.f1603h[0] = f10;
                this.f1601f[0] = solverVariable.f1577c;
                this.f1602g[0] = -1;
                solverVariable.f1587m++;
                solverVariable.a(this.f1597b);
                this.f1596a++;
                if (this.f1606k) {
                    return;
                }
                int i11 = this.f1605j + 1;
                this.f1605j = i11;
                int[] iArr = this.f1601f;
                if (i11 >= iArr.length) {
                    this.f1606k = true;
                    this.f1605j = iArr.length - 1;
                    return;
                }
                return;
            }
            int i12 = -1;
            for (int i13 = 0; i10 != -1 && i13 < this.f1596a; i13++) {
                int i14 = this.f1601f[i10];
                int i15 = solverVariable.f1577c;
                if (i14 == i15) {
                    float[] fArr = this.f1603h;
                    float f12 = fArr[i10] + f10;
                    float f13 = f1595l;
                    if (f12 > (-f13) && f12 < f13) {
                        f12 = 0.0f;
                    }
                    fArr[i10] = f12;
                    if (f12 == 0.0f) {
                        if (i10 == this.f1604i) {
                            this.f1604i = this.f1602g[i10];
                        } else {
                            int[] iArr2 = this.f1602g;
                            iArr2[i12] = iArr2[i10];
                        }
                        if (z10) {
                            solverVariable.c(this.f1597b);
                        }
                        if (this.f1606k) {
                            this.f1605j = i10;
                        }
                        solverVariable.f1587m--;
                        this.f1596a--;
                        return;
                    }
                    return;
                }
                if (i14 < i15) {
                    i12 = i10;
                }
                i10 = this.f1602g[i10];
            }
            int length = this.f1605j;
            int i16 = length + 1;
            if (this.f1606k) {
                int[] iArr3 = this.f1601f;
                if (iArr3[length] != -1) {
                    length = iArr3.length;
                }
            } else {
                length = i16;
            }
            int[] iArr4 = this.f1601f;
            if (length >= iArr4.length && this.f1596a < iArr4.length) {
                int i17 = 0;
                while (true) {
                    int[] iArr5 = this.f1601f;
                    if (i17 >= iArr5.length) {
                        break;
                    }
                    if (iArr5[i17] == -1) {
                        length = i17;
                        break;
                    }
                    i17++;
                }
            }
            int[] iArr6 = this.f1601f;
            if (length >= iArr6.length) {
                length = iArr6.length;
                int i18 = this.f1599d * 2;
                this.f1599d = i18;
                this.f1606k = false;
                this.f1605j = length - 1;
                this.f1603h = Arrays.copyOf(this.f1603h, i18);
                this.f1601f = Arrays.copyOf(this.f1601f, this.f1599d);
                this.f1602g = Arrays.copyOf(this.f1602g, this.f1599d);
            }
            this.f1601f[length] = solverVariable.f1577c;
            this.f1603h[length] = f10;
            if (i12 != -1) {
                int[] iArr7 = this.f1602g;
                iArr7[length] = iArr7[i12];
                iArr7[i12] = length;
            } else {
                this.f1602g[length] = this.f1604i;
                this.f1604i = length;
            }
            solverVariable.f1587m++;
            solverVariable.a(this.f1597b);
            this.f1596a++;
            if (!this.f1606k) {
                this.f1605j++;
            }
            int i19 = this.f1605j;
            int[] iArr8 = this.f1601f;
            if (i19 >= iArr8.length) {
                this.f1606k = true;
                this.f1605j = iArr8.length - 1;
            }
        }
    }

    @Override // androidx.constraintlayout.solver.b.a
    public final float c(SolverVariable solverVariable) {
        int i10 = this.f1604i;
        for (int i11 = 0; i10 != -1 && i11 < this.f1596a; i11++) {
            if (this.f1601f[i10] == solverVariable.f1577c) {
                return this.f1603h[i10];
            }
            i10 = this.f1602g[i10];
        }
        return 0.0f;
    }

    @Override // androidx.constraintlayout.solver.b.a
    public final void clear() {
        int i10 = this.f1604i;
        for (int i11 = 0; i10 != -1 && i11 < this.f1596a; i11++) {
            SolverVariable solverVariable = this.f1598c.f1616d[this.f1601f[i10]];
            if (solverVariable != null) {
                solverVariable.c(this.f1597b);
            }
            i10 = this.f1602g[i10];
        }
        this.f1604i = -1;
        this.f1605j = -1;
        this.f1606k = false;
        this.f1596a = 0;
    }

    @Override // androidx.constraintlayout.solver.b.a
    public boolean d(SolverVariable solverVariable) {
        int i10 = this.f1604i;
        if (i10 == -1) {
            return false;
        }
        for (int i11 = 0; i10 != -1 && i11 < this.f1596a; i11++) {
            if (this.f1601f[i10] == solverVariable.f1577c) {
                return true;
            }
            i10 = this.f1602g[i10];
        }
        return false;
    }

    @Override // androidx.constraintlayout.solver.b.a
    public int e() {
        return this.f1596a;
    }

    @Override // androidx.constraintlayout.solver.b.a
    public float f(b bVar, boolean z10) {
        float fC = c(bVar.f1607a);
        h(bVar.f1607a, z10);
        b.a aVar = bVar.f1611e;
        int iE = aVar.e();
        for (int i10 = 0; i10 < iE; i10++) {
            SolverVariable solverVariableI = aVar.i(i10);
            b(solverVariableI, aVar.c(solverVariableI) * fC, z10);
        }
        return fC;
    }

    @Override // androidx.constraintlayout.solver.b.a
    public final void g(SolverVariable solverVariable, float f10) {
        if (f10 == 0.0f) {
            h(solverVariable, true);
            return;
        }
        int i10 = this.f1604i;
        if (i10 == -1) {
            this.f1604i = 0;
            this.f1603h[0] = f10;
            this.f1601f[0] = solverVariable.f1577c;
            this.f1602g[0] = -1;
            solverVariable.f1587m++;
            solverVariable.a(this.f1597b);
            this.f1596a++;
            if (this.f1606k) {
                return;
            }
            int i11 = this.f1605j + 1;
            this.f1605j = i11;
            int[] iArr = this.f1601f;
            if (i11 >= iArr.length) {
                this.f1606k = true;
                this.f1605j = iArr.length - 1;
                return;
            }
            return;
        }
        int i12 = -1;
        for (int i13 = 0; i10 != -1 && i13 < this.f1596a; i13++) {
            int i14 = this.f1601f[i10];
            int i15 = solverVariable.f1577c;
            if (i14 == i15) {
                this.f1603h[i10] = f10;
                return;
            }
            if (i14 < i15) {
                i12 = i10;
            }
            i10 = this.f1602g[i10];
        }
        int length = this.f1605j;
        int i16 = length + 1;
        if (this.f1606k) {
            int[] iArr2 = this.f1601f;
            if (iArr2[length] != -1) {
                length = iArr2.length;
            }
        } else {
            length = i16;
        }
        int[] iArr3 = this.f1601f;
        if (length >= iArr3.length && this.f1596a < iArr3.length) {
            int i17 = 0;
            while (true) {
                int[] iArr4 = this.f1601f;
                if (i17 >= iArr4.length) {
                    break;
                }
                if (iArr4[i17] == -1) {
                    length = i17;
                    break;
                }
                i17++;
            }
        }
        int[] iArr5 = this.f1601f;
        if (length >= iArr5.length) {
            length = iArr5.length;
            int i18 = this.f1599d * 2;
            this.f1599d = i18;
            this.f1606k = false;
            this.f1605j = length - 1;
            this.f1603h = Arrays.copyOf(this.f1603h, i18);
            this.f1601f = Arrays.copyOf(this.f1601f, this.f1599d);
            this.f1602g = Arrays.copyOf(this.f1602g, this.f1599d);
        }
        this.f1601f[length] = solverVariable.f1577c;
        this.f1603h[length] = f10;
        if (i12 != -1) {
            int[] iArr6 = this.f1602g;
            iArr6[length] = iArr6[i12];
            iArr6[i12] = length;
        } else {
            this.f1602g[length] = this.f1604i;
            this.f1604i = length;
        }
        solverVariable.f1587m++;
        solverVariable.a(this.f1597b);
        int i19 = this.f1596a + 1;
        this.f1596a = i19;
        if (!this.f1606k) {
            this.f1605j++;
        }
        int[] iArr7 = this.f1601f;
        if (i19 >= iArr7.length) {
            this.f1606k = true;
        }
        if (this.f1605j >= iArr7.length) {
            this.f1606k = true;
            this.f1605j = iArr7.length - 1;
        }
    }

    @Override // androidx.constraintlayout.solver.b.a
    public final float h(SolverVariable solverVariable, boolean z10) {
        if (this.f1600e == solverVariable) {
            this.f1600e = null;
        }
        int i10 = this.f1604i;
        if (i10 == -1) {
            return 0.0f;
        }
        int i11 = 0;
        int i12 = -1;
        while (i10 != -1 && i11 < this.f1596a) {
            if (this.f1601f[i10] == solverVariable.f1577c) {
                if (i10 == this.f1604i) {
                    this.f1604i = this.f1602g[i10];
                } else {
                    int[] iArr = this.f1602g;
                    iArr[i12] = iArr[i10];
                }
                if (z10) {
                    solverVariable.c(this.f1597b);
                }
                solverVariable.f1587m--;
                this.f1596a--;
                this.f1601f[i10] = -1;
                if (this.f1606k) {
                    this.f1605j = i10;
                }
                return this.f1603h[i10];
            }
            i11++;
            i12 = i10;
            i10 = this.f1602g[i10];
        }
        return 0.0f;
    }

    @Override // androidx.constraintlayout.solver.b.a
    public SolverVariable i(int i10) {
        int i11 = this.f1604i;
        for (int i12 = 0; i11 != -1 && i12 < this.f1596a; i12++) {
            if (i12 == i10) {
                return this.f1598c.f1616d[this.f1601f[i11]];
            }
            i11 = this.f1602g[i11];
        }
        return null;
    }

    @Override // androidx.constraintlayout.solver.b.a
    public void j(float f10) {
        int i10 = this.f1604i;
        for (int i11 = 0; i10 != -1 && i11 < this.f1596a; i11++) {
            float[] fArr = this.f1603h;
            fArr[i10] = fArr[i10] / f10;
            i10 = this.f1602g[i10];
        }
    }

    @Override // androidx.constraintlayout.solver.b.a
    public void k() {
        int i10 = this.f1604i;
        for (int i11 = 0; i10 != -1 && i11 < this.f1596a; i11++) {
            float[] fArr = this.f1603h;
            fArr[i10] = fArr[i10] * (-1.0f);
            i10 = this.f1602g[i10];
        }
    }

    public String toString() {
        int i10 = this.f1604i;
        String str = "";
        for (int i11 = 0; i10 != -1 && i11 < this.f1596a; i11++) {
            str = ((str + " -> ") + this.f1603h[i10] + " : ") + this.f1598c.f1616d[this.f1601f[i10]];
            i10 = this.f1602g[i10];
        }
        return str;
    }
}
