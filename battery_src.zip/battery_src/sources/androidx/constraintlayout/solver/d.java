package androidx.constraintlayout.solver;

import androidx.constraintlayout.solver.widgets.ConstraintAnchor;
import androidx.constraintlayout.solver.widgets.ConstraintWidget;
import java.util.Arrays;
import java.util.HashMap;

/* JADX INFO: compiled from: LinearSystem.java */
/* JADX INFO: loaded from: classes.dex */
public class d {

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    private static int f1617q = 1000;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public static boolean f1618r = true;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public static long f1619s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public static long f1620t;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private a f1623c;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    androidx.constraintlayout.solver.b[] f1626f;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    final c f1633m;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    private a f1636p;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    int f1621a = 0;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private HashMap<String, SolverVariable> f1622b = null;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private int f1624d = 32;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private int f1625e = 32;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public boolean f1627g = false;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public boolean f1628h = false;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private boolean[] f1629i = new boolean[32];

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    int f1630j = 1;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    int f1631k = 0;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private int f1632l = 32;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    private SolverVariable[] f1634n = new SolverVariable[f1617q];

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    private int f1635o = 0;

    /* JADX INFO: compiled from: LinearSystem.java */
    interface a {
        void a(a aVar);

        void b(SolverVariable solverVariable);

        SolverVariable c(d dVar, boolean[] zArr);

        void clear();

        SolverVariable getKey();
    }

    /* JADX INFO: compiled from: LinearSystem.java */
    class b extends androidx.constraintlayout.solver.b {
        public b(c cVar) {
            this.f1611e = new h(this, cVar);
        }
    }

    public d() {
        this.f1626f = null;
        this.f1626f = new androidx.constraintlayout.solver.b[32];
        D();
        c cVar = new c();
        this.f1633m = cVar;
        this.f1623c = new g(cVar);
        if (f1618r) {
            this.f1636p = new b(cVar);
        } else {
            this.f1636p = new androidx.constraintlayout.solver.b(cVar);
        }
    }

    private final int C(a aVar, boolean z10) {
        for (int i10 = 0; i10 < this.f1630j; i10++) {
            this.f1629i[i10] = false;
        }
        boolean z11 = false;
        int i11 = 0;
        while (!z11) {
            i11++;
            if (i11 >= this.f1630j * 2) {
                return i11;
            }
            if (aVar.getKey() != null) {
                this.f1629i[aVar.getKey().f1577c] = true;
            }
            SolverVariable solverVariableC = aVar.c(this, this.f1629i);
            if (solverVariableC != null) {
                boolean[] zArr = this.f1629i;
                int i12 = solverVariableC.f1577c;
                if (zArr[i12]) {
                    return i11;
                }
                zArr[i12] = true;
            }
            if (solverVariableC != null) {
                float f10 = Float.MAX_VALUE;
                int i13 = -1;
                for (int i14 = 0; i14 < this.f1631k; i14++) {
                    androidx.constraintlayout.solver.b bVar = this.f1626f[i14];
                    if (bVar.f1607a.f1584j != SolverVariable.Type.UNRESTRICTED && !bVar.f1612f && bVar.t(solverVariableC)) {
                        float fC = bVar.f1611e.c(solverVariableC);
                        if (fC < 0.0f) {
                            float f11 = (-bVar.f1608b) / fC;
                            if (f11 < f10) {
                                i13 = i14;
                                f10 = f11;
                            }
                        }
                    }
                }
                if (i13 > -1) {
                    androidx.constraintlayout.solver.b bVar2 = this.f1626f[i13];
                    bVar2.f1607a.f1578d = -1;
                    bVar2.y(solverVariableC);
                    SolverVariable solverVariable = bVar2.f1607a;
                    solverVariable.f1578d = i13;
                    solverVariable.g(bVar2);
                }
            } else {
                z11 = true;
            }
        }
        return i11;
    }

    private void D() {
        int i10 = 0;
        if (f1618r) {
            while (true) {
                androidx.constraintlayout.solver.b[] bVarArr = this.f1626f;
                if (i10 >= bVarArr.length) {
                    return;
                }
                androidx.constraintlayout.solver.b bVar = bVarArr[i10];
                if (bVar != null) {
                    this.f1633m.f1613a.a(bVar);
                }
                this.f1626f[i10] = null;
                i10++;
            }
        } else {
            while (true) {
                androidx.constraintlayout.solver.b[] bVarArr2 = this.f1626f;
                if (i10 >= bVarArr2.length) {
                    return;
                }
                androidx.constraintlayout.solver.b bVar2 = bVarArr2[i10];
                if (bVar2 != null) {
                    this.f1633m.f1614b.a(bVar2);
                }
                this.f1626f[i10] = null;
                i10++;
            }
        }
    }

    private SolverVariable a(SolverVariable.Type type, String str) {
        SolverVariable solverVariableB = this.f1633m.f1615c.b();
        if (solverVariableB == null) {
            solverVariableB = new SolverVariable(type, str);
            solverVariableB.f(type, str);
        } else {
            solverVariableB.d();
            solverVariableB.f(type, str);
        }
        int i10 = this.f1635o;
        int i11 = f1617q;
        if (i10 >= i11) {
            int i12 = i11 * 2;
            f1617q = i12;
            this.f1634n = (SolverVariable[]) Arrays.copyOf(this.f1634n, i12);
        }
        SolverVariable[] solverVariableArr = this.f1634n;
        int i13 = this.f1635o;
        this.f1635o = i13 + 1;
        solverVariableArr[i13] = solverVariableB;
        return solverVariableB;
    }

    private final void l(androidx.constraintlayout.solver.b bVar) {
        if (f1618r) {
            androidx.constraintlayout.solver.b bVar2 = this.f1626f[this.f1631k];
            if (bVar2 != null) {
                this.f1633m.f1613a.a(bVar2);
            }
        } else {
            androidx.constraintlayout.solver.b bVar3 = this.f1626f[this.f1631k];
            if (bVar3 != null) {
                this.f1633m.f1614b.a(bVar3);
            }
        }
        androidx.constraintlayout.solver.b[] bVarArr = this.f1626f;
        int i10 = this.f1631k;
        bVarArr[i10] = bVar;
        SolverVariable solverVariable = bVar.f1607a;
        solverVariable.f1578d = i10;
        this.f1631k = i10 + 1;
        solverVariable.g(bVar);
    }

    private void n() {
        for (int i10 = 0; i10 < this.f1631k; i10++) {
            androidx.constraintlayout.solver.b bVar = this.f1626f[i10];
            bVar.f1607a.f1580f = bVar.f1608b;
        }
    }

    public static androidx.constraintlayout.solver.b s(d dVar, SolverVariable solverVariable, SolverVariable solverVariable2, float f10) {
        return dVar.r().j(solverVariable, solverVariable2, f10);
    }

    private int u(a aVar) throws Exception {
        for (int i10 = 0; i10 < this.f1631k; i10++) {
            androidx.constraintlayout.solver.b bVar = this.f1626f[i10];
            if (bVar.f1607a.f1584j != SolverVariable.Type.UNRESTRICTED && bVar.f1608b < 0.0f) {
                boolean z10 = false;
                int i11 = 0;
                while (!z10) {
                    i11++;
                    float f10 = Float.MAX_VALUE;
                    int i12 = -1;
                    int i13 = -1;
                    int i14 = 0;
                    int i15 = 0;
                    while (true) {
                        if (i14 >= this.f1631k) {
                            break;
                        }
                        androidx.constraintlayout.solver.b bVar2 = this.f1626f[i14];
                        if (bVar2.f1607a.f1584j != SolverVariable.Type.UNRESTRICTED && !bVar2.f1612f && bVar2.f1608b < 0.0f) {
                            for (int i16 = 1; i16 < this.f1630j; i16++) {
                                SolverVariable solverVariable = this.f1633m.f1616d[i16];
                                float fC = bVar2.f1611e.c(solverVariable);
                                if (fC > 0.0f) {
                                    for (int i17 = 0; i17 < 9; i17++) {
                                        float f11 = solverVariable.f1582h[i17] / fC;
                                        if ((f11 < f10 && i17 == i15) || i17 > i15) {
                                            f10 = f11;
                                            i12 = i14;
                                            i13 = i16;
                                            i15 = i17;
                                        }
                                    }
                                }
                            }
                        }
                        i14++;
                    }
                    if (i12 != -1) {
                        androidx.constraintlayout.solver.b bVar3 = this.f1626f[i12];
                        bVar3.f1607a.f1578d = -1;
                        bVar3.y(this.f1633m.f1616d[i13]);
                        SolverVariable solverVariable2 = bVar3.f1607a;
                        solverVariable2.f1578d = i12;
                        solverVariable2.g(bVar3);
                    } else {
                        z10 = true;
                    }
                    if (i11 > this.f1630j / 2) {
                        z10 = true;
                    }
                }
                return i11;
            }
        }
        return 0;
    }

    public static t.a x() {
        return null;
    }

    private void z() {
        int i10 = this.f1624d * 2;
        this.f1624d = i10;
        this.f1626f = (androidx.constraintlayout.solver.b[]) Arrays.copyOf(this.f1626f, i10);
        c cVar = this.f1633m;
        cVar.f1616d = (SolverVariable[]) Arrays.copyOf(cVar.f1616d, this.f1624d);
        int i11 = this.f1624d;
        this.f1629i = new boolean[i11];
        this.f1625e = i11;
        this.f1632l = i11;
    }

    public void A() throws Exception {
        if (!this.f1627g && !this.f1628h) {
            B(this.f1623c);
            return;
        }
        for (int i10 = 0; i10 < this.f1631k; i10++) {
            if (!this.f1626f[i10].f1612f) {
                B(this.f1623c);
                return;
            }
        }
        n();
    }

    void B(a aVar) throws Exception {
        u(aVar);
        C(aVar, false);
        n();
    }

    public void E() {
        c cVar;
        int i10 = 0;
        while (true) {
            cVar = this.f1633m;
            SolverVariable[] solverVariableArr = cVar.f1616d;
            if (i10 >= solverVariableArr.length) {
                break;
            }
            SolverVariable solverVariable = solverVariableArr[i10];
            if (solverVariable != null) {
                solverVariable.d();
            }
            i10++;
        }
        cVar.f1615c.c(this.f1634n, this.f1635o);
        this.f1635o = 0;
        Arrays.fill(this.f1633m.f1616d, (Object) null);
        HashMap<String, SolverVariable> map = this.f1622b;
        if (map != null) {
            map.clear();
        }
        this.f1621a = 0;
        this.f1623c.clear();
        this.f1630j = 1;
        for (int i11 = 0; i11 < this.f1631k; i11++) {
            this.f1626f[i11].f1609c = false;
        }
        D();
        this.f1631k = 0;
        if (f1618r) {
            this.f1636p = new b(this.f1633m);
        } else {
            this.f1636p = new androidx.constraintlayout.solver.b(this.f1633m);
        }
    }

    public void b(ConstraintWidget constraintWidget, ConstraintWidget constraintWidget2, float f10, int i10) {
        ConstraintAnchor.Type type = ConstraintAnchor.Type.LEFT;
        SolverVariable solverVariableQ = q(constraintWidget.n(type));
        ConstraintAnchor.Type type2 = ConstraintAnchor.Type.TOP;
        SolverVariable solverVariableQ2 = q(constraintWidget.n(type2));
        ConstraintAnchor.Type type3 = ConstraintAnchor.Type.RIGHT;
        SolverVariable solverVariableQ3 = q(constraintWidget.n(type3));
        ConstraintAnchor.Type type4 = ConstraintAnchor.Type.BOTTOM;
        SolverVariable solverVariableQ4 = q(constraintWidget.n(type4));
        SolverVariable solverVariableQ5 = q(constraintWidget2.n(type));
        SolverVariable solverVariableQ6 = q(constraintWidget2.n(type2));
        SolverVariable solverVariableQ7 = q(constraintWidget2.n(type3));
        SolverVariable solverVariableQ8 = q(constraintWidget2.n(type4));
        androidx.constraintlayout.solver.b bVarR = r();
        double d10 = f10;
        double d11 = i10;
        bVarR.q(solverVariableQ2, solverVariableQ4, solverVariableQ6, solverVariableQ8, (float) (Math.sin(d10) * d11));
        d(bVarR);
        androidx.constraintlayout.solver.b bVarR2 = r();
        bVarR2.q(solverVariableQ, solverVariableQ3, solverVariableQ5, solverVariableQ7, (float) (Math.cos(d10) * d11));
        d(bVarR2);
    }

    public void c(SolverVariable solverVariable, SolverVariable solverVariable2, int i10, float f10, SolverVariable solverVariable3, SolverVariable solverVariable4, int i11, int i12) {
        androidx.constraintlayout.solver.b bVarR = r();
        bVarR.h(solverVariable, solverVariable2, i10, f10, solverVariable3, solverVariable4, i11);
        if (i12 != 8) {
            bVarR.d(this, i12);
        }
        d(bVarR);
    }

    public void d(androidx.constraintlayout.solver.b bVar) {
        SolverVariable solverVariableW;
        if (bVar == null) {
            return;
        }
        boolean z10 = true;
        if (this.f1631k + 1 >= this.f1632l || this.f1630j + 1 >= this.f1625e) {
            z();
        }
        boolean z11 = false;
        if (!bVar.f1612f) {
            bVar.D(this);
            if (bVar.u()) {
                return;
            }
            bVar.r();
            if (bVar.f(this)) {
                SolverVariable solverVariableP = p();
                bVar.f1607a = solverVariableP;
                l(bVar);
                this.f1636p.a(bVar);
                C(this.f1636p, true);
                if (solverVariableP.f1578d == -1) {
                    if (bVar.f1607a == solverVariableP && (solverVariableW = bVar.w(solverVariableP)) != null) {
                        bVar.y(solverVariableW);
                    }
                    if (!bVar.f1612f) {
                        bVar.f1607a.g(bVar);
                    }
                    this.f1631k--;
                }
            } else {
                z10 = false;
            }
            if (!bVar.s()) {
                return;
            } else {
                z11 = z10;
            }
        }
        if (z11) {
            return;
        }
        l(bVar);
    }

    public androidx.constraintlayout.solver.b e(SolverVariable solverVariable, SolverVariable solverVariable2, int i10, int i11) {
        if (i11 == 8 && solverVariable2.f1581g && solverVariable.f1578d == -1) {
            solverVariable.e(this, solverVariable2.f1580f + i10);
            return null;
        }
        androidx.constraintlayout.solver.b bVarR = r();
        bVarR.n(solverVariable, solverVariable2, i10);
        if (i11 != 8) {
            bVarR.d(this, i11);
        }
        d(bVarR);
        return bVarR;
    }

    public void f(SolverVariable solverVariable, int i10) {
        int i11 = solverVariable.f1578d;
        if (i11 == -1) {
            solverVariable.e(this, i10);
            return;
        }
        if (i11 == -1) {
            androidx.constraintlayout.solver.b bVarR = r();
            bVarR.i(solverVariable, i10);
            d(bVarR);
            return;
        }
        androidx.constraintlayout.solver.b bVar = this.f1626f[i11];
        if (bVar.f1612f) {
            bVar.f1608b = i10;
            return;
        }
        if (bVar.f1611e.e() == 0) {
            bVar.f1612f = true;
            bVar.f1608b = i10;
        } else {
            androidx.constraintlayout.solver.b bVarR2 = r();
            bVarR2.m(solverVariable, i10);
            d(bVarR2);
        }
    }

    public void g(SolverVariable solverVariable, SolverVariable solverVariable2, int i10, boolean z10) {
        androidx.constraintlayout.solver.b bVarR = r();
        SolverVariable solverVariableT = t();
        solverVariableT.f1579e = 0;
        bVarR.o(solverVariable, solverVariable2, solverVariableT, i10);
        d(bVarR);
    }

    public void h(SolverVariable solverVariable, SolverVariable solverVariable2, int i10, int i11) {
        androidx.constraintlayout.solver.b bVarR = r();
        SolverVariable solverVariableT = t();
        solverVariableT.f1579e = 0;
        bVarR.o(solverVariable, solverVariable2, solverVariableT, i10);
        if (i11 != 8) {
            m(bVarR, (int) (bVarR.f1611e.c(solverVariableT) * (-1.0f)), i11);
        }
        d(bVarR);
    }

    public void i(SolverVariable solverVariable, SolverVariable solverVariable2, int i10, boolean z10) {
        androidx.constraintlayout.solver.b bVarR = r();
        SolverVariable solverVariableT = t();
        solverVariableT.f1579e = 0;
        bVarR.p(solverVariable, solverVariable2, solverVariableT, i10);
        d(bVarR);
    }

    public void j(SolverVariable solverVariable, SolverVariable solverVariable2, int i10, int i11) {
        androidx.constraintlayout.solver.b bVarR = r();
        SolverVariable solverVariableT = t();
        solverVariableT.f1579e = 0;
        bVarR.p(solverVariable, solverVariable2, solverVariableT, i10);
        if (i11 != 8) {
            m(bVarR, (int) (bVarR.f1611e.c(solverVariableT) * (-1.0f)), i11);
        }
        d(bVarR);
    }

    public void k(SolverVariable solverVariable, SolverVariable solverVariable2, SolverVariable solverVariable3, SolverVariable solverVariable4, float f10, int i10) {
        androidx.constraintlayout.solver.b bVarR = r();
        bVarR.k(solverVariable, solverVariable2, solverVariable3, solverVariable4, f10);
        if (i10 != 8) {
            bVarR.d(this, i10);
        }
        d(bVarR);
    }

    void m(androidx.constraintlayout.solver.b bVar, int i10, int i11) {
        bVar.e(o(i11, null), i10);
    }

    public SolverVariable o(int i10, String str) {
        if (this.f1630j + 1 >= this.f1625e) {
            z();
        }
        SolverVariable solverVariableA = a(SolverVariable.Type.ERROR, str);
        int i11 = this.f1621a + 1;
        this.f1621a = i11;
        this.f1630j++;
        solverVariableA.f1577c = i11;
        solverVariableA.f1579e = i10;
        this.f1633m.f1616d[i11] = solverVariableA;
        this.f1623c.b(solverVariableA);
        return solverVariableA;
    }

    public SolverVariable p() {
        if (this.f1630j + 1 >= this.f1625e) {
            z();
        }
        SolverVariable solverVariableA = a(SolverVariable.Type.SLACK, null);
        int i10 = this.f1621a + 1;
        this.f1621a = i10;
        this.f1630j++;
        solverVariableA.f1577c = i10;
        this.f1633m.f1616d[i10] = solverVariableA;
        return solverVariableA;
    }

    public SolverVariable q(Object obj) {
        SolverVariable solverVariableF = null;
        if (obj == null) {
            return null;
        }
        if (this.f1630j + 1 >= this.f1625e) {
            z();
        }
        if (obj instanceof ConstraintAnchor) {
            ConstraintAnchor constraintAnchor = (ConstraintAnchor) obj;
            solverVariableF = constraintAnchor.f();
            if (solverVariableF == null) {
                constraintAnchor.m(this.f1633m);
                solverVariableF = constraintAnchor.f();
            }
            int i10 = solverVariableF.f1577c;
            if (i10 == -1 || i10 > this.f1621a || this.f1633m.f1616d[i10] == null) {
                if (i10 != -1) {
                    solverVariableF.d();
                }
                int i11 = this.f1621a + 1;
                this.f1621a = i11;
                this.f1630j++;
                solverVariableF.f1577c = i11;
                solverVariableF.f1584j = SolverVariable.Type.UNRESTRICTED;
                this.f1633m.f1616d[i11] = solverVariableF;
            }
        }
        return solverVariableF;
    }

    public androidx.constraintlayout.solver.b r() {
        androidx.constraintlayout.solver.b bVarB;
        if (f1618r) {
            bVarB = this.f1633m.f1613a.b();
            if (bVarB == null) {
                bVarB = new b(this.f1633m);
                f1620t++;
            } else {
                bVarB.z();
            }
        } else {
            bVarB = this.f1633m.f1614b.b();
            if (bVarB == null) {
                bVarB = new androidx.constraintlayout.solver.b(this.f1633m);
                f1619s++;
            } else {
                bVarB.z();
            }
        }
        SolverVariable.b();
        return bVarB;
    }

    public SolverVariable t() {
        if (this.f1630j + 1 >= this.f1625e) {
            z();
        }
        SolverVariable solverVariableA = a(SolverVariable.Type.SLACK, null);
        int i10 = this.f1621a + 1;
        this.f1621a = i10;
        this.f1630j++;
        solverVariableA.f1577c = i10;
        this.f1633m.f1616d[i10] = solverVariableA;
        return solverVariableA;
    }

    public c w() {
        return this.f1633m;
    }

    public int y(Object obj) {
        SolverVariable solverVariableF = ((ConstraintAnchor) obj).f();
        if (solverVariableF != null) {
            return (int) (solverVariableF.f1580f + 0.5f);
        }
        return 0;
    }

    public void v(t.a aVar) {
    }
}
