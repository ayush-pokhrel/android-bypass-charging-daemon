package androidx.constraintlayout.solver.widgets;

import java.util.ArrayList;
import java.util.HashMap;

/* JADX INFO: compiled from: Flow.java */
/* JADX INFO: loaded from: classes.dex */
public class e extends h {

    /* JADX INFO: renamed from: s1, reason: collision with root package name */
    private ConstraintWidget[] f1860s1;
    private int V0 = -1;
    private int W0 = -1;
    private int X0 = -1;
    private int Y0 = -1;
    private int Z0 = -1;

    /* JADX INFO: renamed from: a1, reason: collision with root package name */
    private int f1842a1 = -1;

    /* JADX INFO: renamed from: b1, reason: collision with root package name */
    private float f1843b1 = 0.5f;

    /* JADX INFO: renamed from: c1, reason: collision with root package name */
    private float f1844c1 = 0.5f;

    /* JADX INFO: renamed from: d1, reason: collision with root package name */
    private float f1845d1 = 0.5f;

    /* JADX INFO: renamed from: e1, reason: collision with root package name */
    private float f1846e1 = 0.5f;

    /* JADX INFO: renamed from: f1, reason: collision with root package name */
    private float f1847f1 = 0.5f;

    /* JADX INFO: renamed from: g1, reason: collision with root package name */
    private float f1848g1 = 0.5f;

    /* JADX INFO: renamed from: h1, reason: collision with root package name */
    private int f1849h1 = 0;

    /* JADX INFO: renamed from: i1, reason: collision with root package name */
    private int f1850i1 = 0;

    /* JADX INFO: renamed from: j1, reason: collision with root package name */
    private int f1851j1 = 2;

    /* JADX INFO: renamed from: k1, reason: collision with root package name */
    private int f1852k1 = 2;

    /* JADX INFO: renamed from: l1, reason: collision with root package name */
    private int f1853l1 = 0;

    /* JADX INFO: renamed from: m1, reason: collision with root package name */
    private int f1854m1 = -1;

    /* JADX INFO: renamed from: n1, reason: collision with root package name */
    private int f1855n1 = 0;

    /* JADX INFO: renamed from: o1, reason: collision with root package name */
    private ArrayList<a> f1856o1 = new ArrayList<>();

    /* JADX INFO: renamed from: p1, reason: collision with root package name */
    private ConstraintWidget[] f1857p1 = null;

    /* JADX INFO: renamed from: q1, reason: collision with root package name */
    private ConstraintWidget[] f1858q1 = null;

    /* JADX INFO: renamed from: r1, reason: collision with root package name */
    private int[] f1859r1 = null;

    /* JADX INFO: renamed from: t1, reason: collision with root package name */
    private int f1861t1 = 0;

    /* JADX INFO: compiled from: Flow.java */
    private class a {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private int f1862a;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        private ConstraintAnchor f1865d;

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        private ConstraintAnchor f1866e;

        /* JADX INFO: renamed from: f, reason: collision with root package name */
        private ConstraintAnchor f1867f;

        /* JADX INFO: renamed from: g, reason: collision with root package name */
        private ConstraintAnchor f1868g;

        /* JADX INFO: renamed from: h, reason: collision with root package name */
        private int f1869h;

        /* JADX INFO: renamed from: i, reason: collision with root package name */
        private int f1870i;

        /* JADX INFO: renamed from: j, reason: collision with root package name */
        private int f1871j;

        /* JADX INFO: renamed from: k, reason: collision with root package name */
        private int f1872k;

        /* JADX INFO: renamed from: q, reason: collision with root package name */
        private int f1878q;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private ConstraintWidget f1863b = null;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        int f1864c = 0;

        /* JADX INFO: renamed from: l, reason: collision with root package name */
        private int f1873l = 0;

        /* JADX INFO: renamed from: m, reason: collision with root package name */
        private int f1874m = 0;

        /* JADX INFO: renamed from: n, reason: collision with root package name */
        private int f1875n = 0;

        /* JADX INFO: renamed from: o, reason: collision with root package name */
        private int f1876o = 0;

        /* JADX INFO: renamed from: p, reason: collision with root package name */
        private int f1877p = 0;

        public a(int i10, ConstraintAnchor constraintAnchor, ConstraintAnchor constraintAnchor2, ConstraintAnchor constraintAnchor3, ConstraintAnchor constraintAnchor4, int i11) {
            this.f1869h = 0;
            this.f1870i = 0;
            this.f1871j = 0;
            this.f1872k = 0;
            this.f1878q = 0;
            this.f1862a = i10;
            this.f1865d = constraintAnchor;
            this.f1866e = constraintAnchor2;
            this.f1867f = constraintAnchor3;
            this.f1868g = constraintAnchor4;
            this.f1869h = e.this.Q0();
            this.f1870i = e.this.S0();
            this.f1871j = e.this.R0();
            this.f1872k = e.this.P0();
            this.f1878q = i11;
        }

        private void h() {
            this.f1873l = 0;
            this.f1874m = 0;
            this.f1863b = null;
            this.f1864c = 0;
            int i10 = this.f1876o;
            for (int i11 = 0; i11 < i10 && this.f1875n + i11 < e.this.f1861t1; i11++) {
                ConstraintWidget constraintWidget = e.this.f1860s1[this.f1875n + i11];
                if (this.f1862a == 0) {
                    int iQ = constraintWidget.Q();
                    int i12 = e.this.f1849h1;
                    if (constraintWidget.P() == 8) {
                        i12 = 0;
                    }
                    this.f1873l += iQ + i12;
                    int iB1 = e.this.B1(constraintWidget, this.f1878q);
                    if (this.f1863b == null || this.f1864c < iB1) {
                        this.f1863b = constraintWidget;
                        this.f1864c = iB1;
                        this.f1874m = iB1;
                    }
                } else {
                    int iC1 = e.this.C1(constraintWidget, this.f1878q);
                    int iB2 = e.this.B1(constraintWidget, this.f1878q);
                    int i13 = e.this.f1850i1;
                    if (constraintWidget.P() == 8) {
                        i13 = 0;
                    }
                    this.f1874m += iB2 + i13;
                    if (this.f1863b == null || this.f1864c < iC1) {
                        this.f1863b = constraintWidget;
                        this.f1864c = iC1;
                        this.f1873l = iC1;
                    }
                }
            }
        }

        public void b(ConstraintWidget constraintWidget) {
            if (this.f1862a == 0) {
                int iC1 = e.this.C1(constraintWidget, this.f1878q);
                if (constraintWidget.z() == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT) {
                    this.f1877p++;
                    iC1 = 0;
                }
                this.f1873l += iC1 + (constraintWidget.P() != 8 ? e.this.f1849h1 : 0);
                int iB1 = e.this.B1(constraintWidget, this.f1878q);
                if (this.f1863b == null || this.f1864c < iB1) {
                    this.f1863b = constraintWidget;
                    this.f1864c = iB1;
                    this.f1874m = iB1;
                }
            } else {
                int iC2 = e.this.C1(constraintWidget, this.f1878q);
                int iB2 = e.this.B1(constraintWidget, this.f1878q);
                if (constraintWidget.N() == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT) {
                    this.f1877p++;
                    iB2 = 0;
                }
                this.f1874m += iB2 + (constraintWidget.P() != 8 ? e.this.f1850i1 : 0);
                if (this.f1863b == null || this.f1864c < iC2) {
                    this.f1863b = constraintWidget;
                    this.f1864c = iC2;
                    this.f1873l = iC2;
                }
            }
            this.f1876o++;
        }

        public void c() {
            this.f1864c = 0;
            this.f1863b = null;
            this.f1873l = 0;
            this.f1874m = 0;
            this.f1875n = 0;
            this.f1876o = 0;
            this.f1877p = 0;
        }

        public void d(boolean z10, int i10, boolean z11) {
            ConstraintWidget constraintWidget;
            char c10;
            int i11 = this.f1876o;
            for (int i12 = 0; i12 < i11 && this.f1875n + i12 < e.this.f1861t1; i12++) {
                ConstraintWidget constraintWidget2 = e.this.f1860s1[this.f1875n + i12];
                if (constraintWidget2 != null) {
                    constraintWidget2.a0();
                }
            }
            if (i11 == 0 || this.f1863b == null) {
                return;
            }
            boolean z12 = z11 && i10 == 0;
            int i13 = -1;
            int i14 = -1;
            for (int i15 = 0; i15 < i11; i15++) {
                int i16 = z10 ? (i11 - 1) - i15 : i15;
                if (this.f1875n + i16 >= e.this.f1861t1) {
                    break;
                }
                if (e.this.f1860s1[this.f1875n + i16].P() == 0) {
                    if (i13 == -1) {
                        i13 = i15;
                    }
                    i14 = i15;
                }
            }
            ConstraintWidget constraintWidget3 = null;
            if (this.f1862a != 0) {
                ConstraintWidget constraintWidget4 = this.f1863b;
                constraintWidget4.k0(e.this.V0);
                int i17 = this.f1869h;
                if (i10 > 0) {
                    i17 += e.this.f1849h1;
                }
                if (z10) {
                    constraintWidget4.F.a(this.f1867f, i17);
                    if (z11) {
                        constraintWidget4.D.a(this.f1865d, this.f1871j);
                    }
                    if (i10 > 0) {
                        this.f1867f.f1665b.D.a(constraintWidget4.F, 0);
                    }
                } else {
                    constraintWidget4.D.a(this.f1865d, i17);
                    if (z11) {
                        constraintWidget4.F.a(this.f1867f, this.f1871j);
                    }
                    if (i10 > 0) {
                        this.f1865d.f1665b.F.a(constraintWidget4.D, 0);
                    }
                }
                int i18 = 0;
                while (i18 < i11 && this.f1875n + i18 < e.this.f1861t1) {
                    ConstraintWidget constraintWidget5 = e.this.f1860s1[this.f1875n + i18];
                    if (i18 == 0) {
                        constraintWidget5.j(constraintWidget5.E, this.f1866e, this.f1870i);
                        int i19 = e.this.W0;
                        float f10 = e.this.f1844c1;
                        if (this.f1875n == 0 && e.this.Y0 != -1) {
                            i19 = e.this.Y0;
                            f10 = e.this.f1846e1;
                        } else if (z11 && e.this.f1842a1 != -1) {
                            i19 = e.this.f1842a1;
                            f10 = e.this.f1848g1;
                        }
                        constraintWidget5.z0(i19);
                        constraintWidget5.y0(f10);
                    }
                    if (i18 == i11 - 1) {
                        constraintWidget5.j(constraintWidget5.G, this.f1868g, this.f1872k);
                    }
                    if (constraintWidget3 != null) {
                        constraintWidget5.E.a(constraintWidget3.G, e.this.f1850i1);
                        if (i18 == i13) {
                            constraintWidget5.E.n(this.f1870i);
                        }
                        constraintWidget3.G.a(constraintWidget5.E, 0);
                        if (i18 == i14 + 1) {
                            constraintWidget3.G.n(this.f1872k);
                        }
                    }
                    if (constraintWidget5 != constraintWidget4) {
                        if (z10) {
                            int i20 = e.this.f1851j1;
                            if (i20 == 0) {
                                constraintWidget5.F.a(constraintWidget4.F, 0);
                            } else if (i20 == 1) {
                                constraintWidget5.D.a(constraintWidget4.D, 0);
                            } else if (i20 == 2) {
                                constraintWidget5.D.a(constraintWidget4.D, 0);
                                constraintWidget5.F.a(constraintWidget4.F, 0);
                            }
                        } else {
                            int i21 = e.this.f1851j1;
                            if (i21 == 0) {
                                constraintWidget5.D.a(constraintWidget4.D, 0);
                            } else if (i21 == 1) {
                                constraintWidget5.F.a(constraintWidget4.F, 0);
                            } else if (i21 == 2) {
                                if (z12) {
                                    constraintWidget5.D.a(this.f1865d, this.f1869h);
                                    constraintWidget5.F.a(this.f1867f, this.f1871j);
                                } else {
                                    constraintWidget5.D.a(constraintWidget4.D, 0);
                                    constraintWidget5.F.a(constraintWidget4.F, 0);
                                }
                            }
                        }
                    }
                    i18++;
                    constraintWidget3 = constraintWidget5;
                }
                return;
            }
            ConstraintWidget constraintWidget6 = this.f1863b;
            constraintWidget6.z0(e.this.W0);
            int i22 = this.f1870i;
            if (i10 > 0) {
                i22 += e.this.f1850i1;
            }
            constraintWidget6.E.a(this.f1866e, i22);
            if (z11) {
                constraintWidget6.G.a(this.f1868g, this.f1872k);
            }
            if (i10 > 0) {
                this.f1866e.f1665b.G.a(constraintWidget6.E, 0);
            }
            if (e.this.f1852k1 != 3 || constraintWidget6.T()) {
                constraintWidget = constraintWidget6;
                break;
            }
            int i23 = 0;
            while (true) {
                if (i23 < i11) {
                    int i24 = z10 ? (i11 - 1) - i23 : i23;
                    if (this.f1875n + i24 < e.this.f1861t1) {
                        constraintWidget = e.this.f1860s1[this.f1875n + i24];
                        if (constraintWidget.T()) {
                            break;
                        } else {
                            i23++;
                        }
                    }
                }
                constraintWidget = constraintWidget6;
                break;
            }
            int i25 = 0;
            while (i25 < i11) {
                int i26 = z10 ? (i11 - 1) - i25 : i25;
                if (this.f1875n + i26 >= e.this.f1861t1) {
                    return;
                }
                ConstraintWidget constraintWidget7 = e.this.f1860s1[this.f1875n + i26];
                if (i25 == 0) {
                    constraintWidget7.j(constraintWidget7.D, this.f1865d, this.f1869h);
                }
                if (i26 == 0) {
                    int i27 = e.this.V0;
                    float f11 = e.this.f1843b1;
                    if (this.f1875n == 0 && e.this.X0 != -1) {
                        i27 = e.this.X0;
                        f11 = e.this.f1845d1;
                    } else if (z11 && e.this.Z0 != -1) {
                        i27 = e.this.Z0;
                        f11 = e.this.f1847f1;
                    }
                    constraintWidget7.k0(i27);
                    constraintWidget7.j0(f11);
                }
                if (i25 == i11 - 1) {
                    constraintWidget7.j(constraintWidget7.F, this.f1867f, this.f1871j);
                }
                if (constraintWidget3 != null) {
                    constraintWidget7.D.a(constraintWidget3.F, e.this.f1849h1);
                    if (i25 == i13) {
                        constraintWidget7.D.n(this.f1869h);
                    }
                    constraintWidget3.F.a(constraintWidget7.D, 0);
                    if (i25 == i14 + 1) {
                        constraintWidget3.F.n(this.f1871j);
                    }
                }
                if (constraintWidget7 != constraintWidget6) {
                    c10 = 3;
                    if (e.this.f1852k1 == 3 && constraintWidget.T() && constraintWidget7 != constraintWidget && constraintWidget7.T()) {
                        constraintWidget7.H.a(constraintWidget.H, 0);
                    } else {
                        int i28 = e.this.f1852k1;
                        if (i28 == 0) {
                            constraintWidget7.E.a(constraintWidget6.E, 0);
                        } else if (i28 == 1) {
                            constraintWidget7.G.a(constraintWidget6.G, 0);
                        } else if (z12) {
                            constraintWidget7.E.a(this.f1866e, this.f1870i);
                            constraintWidget7.G.a(this.f1868g, this.f1872k);
                        } else {
                            constraintWidget7.E.a(constraintWidget6.E, 0);
                            constraintWidget7.G.a(constraintWidget6.G, 0);
                        }
                    }
                } else {
                    c10 = 3;
                }
                i25++;
                constraintWidget3 = constraintWidget7;
            }
        }

        public int e() {
            return this.f1862a == 1 ? this.f1874m - e.this.f1850i1 : this.f1874m;
        }

        public int f() {
            return this.f1862a == 0 ? this.f1873l - e.this.f1849h1 : this.f1873l;
        }

        public void g(int i10) {
            int i11 = this.f1877p;
            if (i11 == 0) {
                return;
            }
            int i12 = this.f1876o;
            int i13 = i10 / i11;
            for (int i14 = 0; i14 < i12 && this.f1875n + i14 < e.this.f1861t1; i14++) {
                ConstraintWidget constraintWidget = e.this.f1860s1[this.f1875n + i14];
                if (this.f1862a == 0) {
                    if (constraintWidget != null && constraintWidget.z() == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT && constraintWidget.f1704l == 0) {
                        e.this.U0(constraintWidget, ConstraintWidget.DimensionBehaviour.FIXED, i13, constraintWidget.N(), constraintWidget.w());
                    }
                } else if (constraintWidget != null && constraintWidget.N() == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT && constraintWidget.f1706m == 0) {
                    e.this.U0(constraintWidget, constraintWidget.z(), constraintWidget.Q(), ConstraintWidget.DimensionBehaviour.FIXED, i13);
                }
            }
            h();
        }

        public void i(int i10) {
            this.f1875n = i10;
        }

        public void j(int i10, ConstraintAnchor constraintAnchor, ConstraintAnchor constraintAnchor2, ConstraintAnchor constraintAnchor3, ConstraintAnchor constraintAnchor4, int i11, int i12, int i13, int i14, int i15) {
            this.f1862a = i10;
            this.f1865d = constraintAnchor;
            this.f1866e = constraintAnchor2;
            this.f1867f = constraintAnchor3;
            this.f1868g = constraintAnchor4;
            this.f1869h = i11;
            this.f1870i = i12;
            this.f1871j = i13;
            this.f1872k = i14;
            this.f1878q = i15;
        }
    }

    private void A1(boolean z10) {
        ConstraintWidget constraintWidget;
        if (this.f1859r1 == null || this.f1858q1 == null || this.f1857p1 == null) {
            return;
        }
        for (int i10 = 0; i10 < this.f1861t1; i10++) {
            this.f1860s1[i10].a0();
        }
        int[] iArr = this.f1859r1;
        int i11 = iArr[0];
        int i12 = iArr[1];
        ConstraintWidget constraintWidget2 = null;
        for (int i13 = 0; i13 < i11; i13++) {
            ConstraintWidget constraintWidget3 = this.f1858q1[z10 ? (i11 - i13) - 1 : i13];
            if (constraintWidget3 != null && constraintWidget3.P() != 8) {
                if (i13 == 0) {
                    constraintWidget3.j(constraintWidget3.D, this.D, Q0());
                    constraintWidget3.k0(this.V0);
                    constraintWidget3.j0(this.f1843b1);
                }
                if (i13 == i11 - 1) {
                    constraintWidget3.j(constraintWidget3.F, this.F, R0());
                }
                if (i13 > 0) {
                    constraintWidget3.j(constraintWidget3.D, constraintWidget2.F, this.f1849h1);
                    constraintWidget2.j(constraintWidget2.F, constraintWidget3.D, 0);
                }
                constraintWidget2 = constraintWidget3;
            }
        }
        for (int i14 = 0; i14 < i12; i14++) {
            ConstraintWidget constraintWidget4 = this.f1857p1[i14];
            if (constraintWidget4 != null && constraintWidget4.P() != 8) {
                if (i14 == 0) {
                    constraintWidget4.j(constraintWidget4.E, this.E, S0());
                    constraintWidget4.z0(this.W0);
                    constraintWidget4.y0(this.f1844c1);
                }
                if (i14 == i12 - 1) {
                    constraintWidget4.j(constraintWidget4.G, this.G, P0());
                }
                if (i14 > 0) {
                    constraintWidget4.j(constraintWidget4.E, constraintWidget2.G, this.f1850i1);
                    constraintWidget2.j(constraintWidget2.G, constraintWidget4.E, 0);
                }
                constraintWidget2 = constraintWidget4;
            }
        }
        for (int i15 = 0; i15 < i11; i15++) {
            for (int i16 = 0; i16 < i12; i16++) {
                int i17 = (i16 * i11) + i15;
                if (this.f1855n1 == 1) {
                    i17 = (i15 * i12) + i16;
                }
                ConstraintWidget[] constraintWidgetArr = this.f1860s1;
                if (i17 < constraintWidgetArr.length && (constraintWidget = constraintWidgetArr[i17]) != null && constraintWidget.P() != 8) {
                    ConstraintWidget constraintWidget5 = this.f1858q1[i15];
                    ConstraintWidget constraintWidget6 = this.f1857p1[i16];
                    if (constraintWidget != constraintWidget5) {
                        constraintWidget.j(constraintWidget.D, constraintWidget5.D, 0);
                        constraintWidget.j(constraintWidget.F, constraintWidget5.F, 0);
                    }
                    if (constraintWidget != constraintWidget6) {
                        constraintWidget.j(constraintWidget.E, constraintWidget6.E, 0);
                        constraintWidget.j(constraintWidget.G, constraintWidget6.G, 0);
                    }
                }
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final int B1(ConstraintWidget constraintWidget, int i10) {
        if (constraintWidget == null) {
            return 0;
        }
        if (constraintWidget.N() == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT) {
            int i11 = constraintWidget.f1706m;
            if (i11 == 0) {
                return 0;
            }
            if (i11 == 2) {
                int i12 = (int) (constraintWidget.f1720t * i10);
                if (i12 != constraintWidget.w()) {
                    U0(constraintWidget, constraintWidget.z(), constraintWidget.Q(), ConstraintWidget.DimensionBehaviour.FIXED, i12);
                }
                return i12;
            }
            if (i11 == 1) {
                return constraintWidget.w();
            }
            if (i11 == 3) {
                return (int) ((constraintWidget.Q() * constraintWidget.S) + 0.5f);
            }
        }
        return constraintWidget.w();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final int C1(ConstraintWidget constraintWidget, int i10) {
        if (constraintWidget == null) {
            return 0;
        }
        if (constraintWidget.z() == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT) {
            int i11 = constraintWidget.f1704l;
            if (i11 == 0) {
                return 0;
            }
            if (i11 == 2) {
                int i12 = (int) (constraintWidget.f1714q * i10);
                if (i12 != constraintWidget.Q()) {
                    U0(constraintWidget, ConstraintWidget.DimensionBehaviour.FIXED, i12, constraintWidget.N(), constraintWidget.w());
                }
                return i12;
            }
            if (i11 == 1) {
                return constraintWidget.Q();
            }
            if (i11 == 3) {
                return (int) ((constraintWidget.w() * constraintWidget.S) + 0.5f);
            }
        }
        return constraintWidget.Q();
    }

    /* JADX WARN: Code duplicated, block: B:100:0x00fc  */
    /* JADX WARN: Code duplicated, block: B:106:0x010f A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:109:0x0117 A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:117:0x011d A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:118:0x0115 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:119:0x0059 A[ADDED_TO_REGION, EDGE_INSN: B:119:0x0059->B:42:0x0059 BREAK  A[LOOP:1: B:44:0x005c->B:124:0x005c], REMOVE, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:121:0x010d A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:122:0x0059 A[ADDED_TO_REGION, EDGE_INSN: B:122:0x0059->B:42:0x0059 BREAK  A[LOOP:1: B:44:0x005c->B:124:0x005c], REMOVE, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:132:0x00d3 A[ADDED_TO_REGION, REMOVE, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:136:0x00ed A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:139:0x0104 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:45:0x005e A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:46:0x0060  */
    /* JADX WARN: Code duplicated, block: B:47:0x006a  */
    /* JADX WARN: Code duplicated, block: B:50:0x0078  */
    /* JADX WARN: Code duplicated, block: B:54:0x0080  */
    /* JADX WARN: Code duplicated, block: B:57:0x0088  */
    /* JADX WARN: Code duplicated, block: B:61:0x0090  */
    /* JADX WARN: Code duplicated, block: B:64:0x0097  */
    /* JADX WARN: Code duplicated, block: B:66:0x009a  */
    /* JADX WARN: Code duplicated, block: B:68:0x009f  */
    /* JADX WARN: Code duplicated, block: B:72:0x00a6  */
    /* JADX WARN: Code duplicated, block: B:77:0x00b5  */
    /* JADX WARN: Code duplicated, block: B:79:0x00bb  */
    /* JADX WARN: Code duplicated, block: B:82:0x00c9  */
    /* JADX WARN: Code duplicated, block: B:84:0x00cf  */
    /* JADX WARN: Code duplicated, block: B:89:0x00dd  */
    /* JADX WARN: Code duplicated, block: B:91:0x00e3 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:92:0x00e5  */
    /* JADX WARN: Code duplicated, block: B:97:0x00f4  */
    /* JADX WARN: Code duplicated, block: B:99:0x00fa A[DONT_INVERT] */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:105:0x010d -> B:42:0x0059). Please report as a decompilation issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:106:0x010f -> B:42:0x0059). Please report as a decompilation issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:108:0x0115 -> B:42:0x0059). Please report as a decompilation issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:109:0x0117 -> B:42:0x0059). Please report as a decompilation issue!!! */
    /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
        jadx.core.utils.exceptions.JadxOverflowException: Regions count limit reached at block B:45:0x005e
        	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
        	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
        	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:19)
        */
    private void D1(androidx.constraintlayout.solver.widgets.ConstraintWidget[] r11, int r12, int r13, int r14, int[] r15) {
        /*
            Method dump skipped, instruction units count: 292
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.constraintlayout.solver.widgets.e.D1(androidx.constraintlayout.solver.widgets.ConstraintWidget[], int, int, int, int[]):void");
    }

    private void E1(ConstraintWidget[] constraintWidgetArr, int i10, int i11, int i12, int[] iArr) {
        int i13;
        int i14;
        int i15;
        ConstraintAnchor constraintAnchor;
        int iR0;
        ConstraintAnchor constraintAnchor2;
        int iP0;
        int i16;
        if (i10 == 0) {
            return;
        }
        this.f1856o1.clear();
        a aVar = new a(i11, this.D, this.E, this.F, this.G, i12);
        this.f1856o1.add(aVar);
        if (i11 == 0) {
            i13 = 0;
            int i17 = 0;
            int i18 = 0;
            while (i18 < i10) {
                ConstraintWidget constraintWidget = constraintWidgetArr[i18];
                int iC1 = C1(constraintWidget, i12);
                if (constraintWidget.z() == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT) {
                    i13++;
                }
                int i19 = i13;
                boolean z10 = (i17 == i12 || (this.f1849h1 + i17) + iC1 > i12) && aVar.f1863b != null;
                if (!z10 && i18 > 0 && (i16 = this.f1854m1) > 0 && i18 % i16 == 0) {
                    z10 = true;
                }
                if (z10) {
                    aVar = new a(i11, this.D, this.E, this.F, this.G, i12);
                    aVar.i(i18);
                    this.f1856o1.add(aVar);
                } else {
                    if (i18 > 0) {
                        i17 += this.f1849h1 + iC1;
                    }
                    aVar.b(constraintWidget);
                    i18++;
                    i13 = i19;
                }
                i17 = iC1;
                aVar.b(constraintWidget);
                i18++;
                i13 = i19;
            }
        } else {
            i13 = 0;
            int i20 = 0;
            int i21 = 0;
            while (i21 < i10) {
                ConstraintWidget constraintWidget2 = constraintWidgetArr[i21];
                int iB1 = B1(constraintWidget2, i12);
                if (constraintWidget2.N() == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT) {
                    i13++;
                }
                int i22 = i13;
                boolean z11 = (i20 == i12 || (this.f1850i1 + i20) + iB1 > i12) && aVar.f1863b != null;
                if (!z11 && i21 > 0 && (i14 = this.f1854m1) > 0 && i21 % i14 == 0) {
                    z11 = true;
                }
                if (z11) {
                    aVar = new a(i11, this.D, this.E, this.F, this.G, i12);
                    aVar.i(i21);
                    this.f1856o1.add(aVar);
                } else {
                    if (i21 > 0) {
                        i20 += this.f1850i1 + iB1;
                    }
                    aVar.b(constraintWidget2);
                    i21++;
                    i13 = i22;
                }
                i20 = iB1;
                aVar.b(constraintWidget2);
                i21++;
                i13 = i22;
            }
        }
        int size = this.f1856o1.size();
        ConstraintAnchor constraintAnchor3 = this.D;
        ConstraintAnchor constraintAnchor4 = this.E;
        ConstraintAnchor constraintAnchor5 = this.F;
        ConstraintAnchor constraintAnchor6 = this.G;
        int iQ0 = Q0();
        int iS0 = S0();
        int iR1 = R0();
        int iP1 = P0();
        ConstraintWidget.DimensionBehaviour dimensionBehaviourZ = z();
        ConstraintWidget.DimensionBehaviour dimensionBehaviour = ConstraintWidget.DimensionBehaviour.WRAP_CONTENT;
        boolean z12 = dimensionBehaviourZ == dimensionBehaviour || N() == dimensionBehaviour;
        if (i13 > 0 && z12) {
            for (int i23 = 0; i23 < size; i23++) {
                a aVar2 = this.f1856o1.get(i23);
                if (i11 == 0) {
                    aVar2.g(i12 - aVar2.f());
                } else {
                    aVar2.g(i12 - aVar2.e());
                }
            }
        }
        int i24 = iS0;
        int i25 = iR1;
        int iE = 0;
        int iF = 0;
        int i26 = 0;
        int i27 = iQ0;
        ConstraintAnchor constraintAnchor7 = constraintAnchor4;
        ConstraintAnchor constraintAnchor8 = constraintAnchor3;
        int i28 = iP1;
        while (i26 < size) {
            a aVar3 = this.f1856o1.get(i26);
            if (i11 == 0) {
                if (i26 < size - 1) {
                    constraintAnchor2 = this.f1856o1.get(i26 + 1).f1863b.E;
                    iP0 = 0;
                } else {
                    constraintAnchor2 = this.G;
                    iP0 = P0();
                }
                ConstraintAnchor constraintAnchor9 = aVar3.f1863b.G;
                ConstraintAnchor constraintAnchor10 = constraintAnchor8;
                ConstraintAnchor constraintAnchor11 = constraintAnchor8;
                int i29 = iE;
                ConstraintAnchor constraintAnchor12 = constraintAnchor7;
                int i30 = iF;
                ConstraintAnchor constraintAnchor13 = constraintAnchor5;
                ConstraintAnchor constraintAnchor14 = constraintAnchor5;
                i15 = i26;
                aVar3.j(i11, constraintAnchor10, constraintAnchor12, constraintAnchor13, constraintAnchor2, i27, i24, i25, iP0, i12);
                int iMax = Math.max(i30, aVar3.f());
                iE = i29 + aVar3.e();
                if (i15 > 0) {
                    iE += this.f1850i1;
                }
                constraintAnchor8 = constraintAnchor11;
                iF = iMax;
                i24 = 0;
                constraintAnchor7 = constraintAnchor9;
                constraintAnchor = constraintAnchor14;
                int i31 = iP0;
                constraintAnchor6 = constraintAnchor2;
                i28 = i31;
            } else {
                ConstraintAnchor constraintAnchor15 = constraintAnchor8;
                int i32 = iE;
                int i33 = iF;
                i15 = i26;
                if (i15 < size - 1) {
                    constraintAnchor = this.f1856o1.get(i15 + 1).f1863b.D;
                    iR0 = 0;
                } else {
                    constraintAnchor = this.F;
                    iR0 = R0();
                }
                ConstraintAnchor constraintAnchor16 = aVar3.f1863b.F;
                aVar3.j(i11, constraintAnchor15, constraintAnchor7, constraintAnchor, constraintAnchor6, i27, i24, iR0, i28, i12);
                iF = i33 + aVar3.f();
                int iMax2 = Math.max(i32, aVar3.e());
                if (i15 > 0) {
                    iF += this.f1849h1;
                }
                iE = iMax2;
                i27 = 0;
                i25 = iR0;
                constraintAnchor8 = constraintAnchor16;
            }
            i26 = i15 + 1;
            constraintAnchor5 = constraintAnchor;
        }
        iArr[0] = iF;
        iArr[1] = iE;
    }

    private void F1(ConstraintWidget[] constraintWidgetArr, int i10, int i11, int i12, int[] iArr) {
        a aVar;
        if (i10 == 0) {
            return;
        }
        if (this.f1856o1.size() == 0) {
            aVar = new a(i11, this.D, this.E, this.F, this.G, i12);
            this.f1856o1.add(aVar);
        } else {
            a aVar2 = this.f1856o1.get(0);
            aVar2.c();
            aVar = aVar2;
            aVar.j(i11, this.D, this.E, this.F, this.G, Q0(), S0(), R0(), P0(), i12);
        }
        for (int i13 = 0; i13 < i10; i13++) {
            aVar.b(constraintWidgetArr[i13]);
        }
        iArr[0] = aVar.f();
        iArr[1] = aVar.e();
    }

    public void G1(float f10) {
        this.f1845d1 = f10;
    }

    public void H1(int i10) {
        this.X0 = i10;
    }

    public void I1(float f10) {
        this.f1846e1 = f10;
    }

    public void J1(int i10) {
        this.Y0 = i10;
    }

    public void K1(int i10) {
        this.f1851j1 = i10;
    }

    public void L1(float f10) {
        this.f1843b1 = f10;
    }

    public void M1(int i10) {
        this.f1849h1 = i10;
    }

    public void N1(int i10) {
        this.V0 = i10;
    }

    public void O1(float f10) {
        this.f1847f1 = f10;
    }

    public void P1(int i10) {
        this.Z0 = i10;
    }

    public void Q1(float f10) {
        this.f1848g1 = f10;
    }

    public void R1(int i10) {
        this.f1842a1 = i10;
    }

    public void S1(int i10) {
        this.f1854m1 = i10;
    }

    @Override // androidx.constraintlayout.solver.widgets.h
    public void T0(int i10, int i11, int i12, int i13) {
        int i14;
        int i15;
        boolean z10;
        if (this.H0 > 0 && !V0()) {
            Y0(0, 0);
            X0(false);
            return;
        }
        int iQ0 = Q0();
        int iR0 = R0();
        int iS0 = S0();
        int iP0 = P0();
        int[] iArr = new int[2];
        int i16 = (i11 - iQ0) - iR0;
        int i17 = this.f1855n1;
        if (i17 == 1) {
            i16 = (i13 - iS0) - iP0;
        }
        int i18 = i16;
        if (i17 == 0) {
            if (this.V0 == -1) {
                this.V0 = 0;
            }
            if (this.W0 == -1) {
                this.W0 = 0;
            }
        } else {
            if (this.V0 == -1) {
                this.V0 = 0;
            }
            if (this.W0 == -1) {
                this.W0 = 0;
            }
        }
        ConstraintWidget[] constraintWidgetArr = this.G0;
        int i19 = 0;
        int i20 = 0;
        while (true) {
            i14 = this.H0;
            if (i19 >= i14) {
                break;
            }
            if (this.G0[i19].P() == 8) {
                i20++;
            }
            i19++;
        }
        if (i20 > 0) {
            constraintWidgetArr = new ConstraintWidget[i14 - i20];
            int i21 = 0;
            for (int i22 = 0; i22 < this.H0; i22++) {
                ConstraintWidget constraintWidget = this.G0[i22];
                if (constraintWidget.P() != 8) {
                    constraintWidgetArr[i21] = constraintWidget;
                    i21++;
                }
            }
            i15 = i21;
        } else {
            i15 = i14;
        }
        this.f1860s1 = constraintWidgetArr;
        this.f1861t1 = i15;
        int i23 = this.f1853l1;
        if (i23 == 0) {
            z10 = true;
            F1(constraintWidgetArr, i15, this.f1855n1, i18, iArr);
        } else if (i23 == 1) {
            z10 = true;
            E1(constraintWidgetArr, i15, this.f1855n1, i18, iArr);
        } else if (i23 != 2) {
            z10 = true;
        } else {
            z10 = true;
            D1(constraintWidgetArr, i15, this.f1855n1, i18, iArr);
        }
        int iMin = iArr[0] + iQ0 + iR0;
        int iMin2 = iArr[z10 ? 1 : 0] + iS0 + iP0;
        if (i10 == 1073741824) {
            iMin = i11;
        } else if (i10 == Integer.MIN_VALUE) {
            iMin = Math.min(iMin, i11);
        } else if (i10 != 0) {
            iMin = 0;
        }
        if (i12 == 1073741824) {
            iMin2 = i13;
        } else if (i12 == Integer.MIN_VALUE) {
            iMin2 = Math.min(iMin2, i13);
        } else if (i12 != 0) {
            iMin2 = 0;
        }
        Y0(iMin, iMin2);
        F0(iMin);
        i0(iMin2);
        if (this.H0 <= 0) {
            z10 = false;
        }
        X0(z10);
    }

    public void T1(int i10) {
        this.f1855n1 = i10;
    }

    public void U1(int i10) {
        this.f1852k1 = i10;
    }

    public void V1(float f10) {
        this.f1844c1 = f10;
    }

    public void W1(int i10) {
        this.f1850i1 = i10;
    }

    public void X1(int i10) {
        this.W0 = i10;
    }

    public void Y1(int i10) {
        this.f1853l1 = i10;
    }

    @Override // androidx.constraintlayout.solver.widgets.ConstraintWidget
    public void f(androidx.constraintlayout.solver.d dVar) {
        super.f(dVar);
        boolean zD1 = H() != null ? ((d) H()).d1() : false;
        int i10 = this.f1853l1;
        if (i10 != 0) {
            if (i10 == 1) {
                int size = this.f1856o1.size();
                int i11 = 0;
                while (i11 < size) {
                    this.f1856o1.get(i11).d(zD1, i11, i11 == size + (-1));
                    i11++;
                }
            } else if (i10 == 2) {
                A1(zD1);
            }
        } else if (this.f1856o1.size() > 0) {
            this.f1856o1.get(0).d(zD1, 0, true);
        }
        X0(false);
    }

    @Override // u.b, androidx.constraintlayout.solver.widgets.ConstraintWidget
    public void l(ConstraintWidget constraintWidget, HashMap<ConstraintWidget, ConstraintWidget> map) {
        super.l(constraintWidget, map);
        e eVar = (e) constraintWidget;
        this.V0 = eVar.V0;
        this.W0 = eVar.W0;
        this.X0 = eVar.X0;
        this.Y0 = eVar.Y0;
        this.Z0 = eVar.Z0;
        this.f1842a1 = eVar.f1842a1;
        this.f1843b1 = eVar.f1843b1;
        this.f1844c1 = eVar.f1844c1;
        this.f1845d1 = eVar.f1845d1;
        this.f1846e1 = eVar.f1846e1;
        this.f1847f1 = eVar.f1847f1;
        this.f1848g1 = eVar.f1848g1;
        this.f1849h1 = eVar.f1849h1;
        this.f1850i1 = eVar.f1850i1;
        this.f1851j1 = eVar.f1851j1;
        this.f1852k1 = eVar.f1852k1;
        this.f1853l1 = eVar.f1853l1;
        this.f1854m1 = eVar.f1854m1;
        this.f1855n1 = eVar.f1855n1;
    }
}
