package androidx.constraintlayout.solver.widgets;

import java.util.ArrayList;
import java.util.Arrays;

/* JADX INFO: compiled from: ConstraintWidgetContainer.java */
/* JADX INFO: loaded from: classes.dex */
public class d extends u.c {
    int M0;
    int N0;
    int O0;
    int P0;
    androidx.constraintlayout.solver.widgets.analyzer.b H0 = new androidx.constraintlayout.solver.widgets.analyzer.b(this);
    public androidx.constraintlayout.solver.widgets.analyzer.d I0 = new androidx.constraintlayout.solver.widgets.analyzer.d(this);
    protected androidx.constraintlayout.solver.widgets.analyzer.b.InterfaceC0007b J0 = null;
    private boolean K0 = false;
    protected androidx.constraintlayout.solver.d L0 = new androidx.constraintlayout.solver.d();
    int Q0 = 0;
    int R0 = 0;
    c[] S0 = new c[4];
    c[] T0 = new c[4];
    public boolean U0 = false;
    public boolean V0 = false;
    public boolean W0 = false;
    public int X0 = 0;
    public int Y0 = 0;
    private int Z0 = 263;

    /* JADX INFO: renamed from: a1, reason: collision with root package name */
    public boolean f1838a1 = false;

    /* JADX INFO: renamed from: b1, reason: collision with root package name */
    private boolean f1839b1 = false;

    /* JADX INFO: renamed from: c1, reason: collision with root package name */
    private boolean f1840c1 = false;

    /* JADX INFO: renamed from: d1, reason: collision with root package name */
    int f1841d1 = 0;

    private void R0(ConstraintWidget constraintWidget) {
        int i10 = this.Q0 + 1;
        c[] cVarArr = this.T0;
        if (i10 >= cVarArr.length) {
            this.T0 = (c[]) Arrays.copyOf(cVarArr, cVarArr.length * 2);
        }
        this.T0[this.Q0] = new c(constraintWidget, 0, d1());
        this.Q0++;
    }

    private void S0(ConstraintWidget constraintWidget) {
        int i10 = this.R0 + 1;
        c[] cVarArr = this.S0;
        if (i10 >= cVarArr.length) {
            this.S0 = (c[]) Arrays.copyOf(cVarArr, cVarArr.length * 2);
        }
        this.S0[this.R0] = new c(constraintWidget, 1, d1());
        this.R0++;
    }

    private void h1() {
        this.Q0 = 0;
        this.R0 = 0;
    }

    @Override // androidx.constraintlayout.solver.widgets.ConstraintWidget
    public void J0(boolean z10, boolean z11) {
        super.J0(z10, z11);
        int size = this.G0.size();
        for (int i10 = 0; i10 < size; i10++) {
            this.G0.get(i10).J0(z10, z11);
        }
    }

    /* JADX WARN: Code duplicated, block: B:62:0x0152  */
    /* JADX WARN: Code duplicated, block: B:83:0x01c8 A[PHI: r0 r5
      0x01c8: PHI (r0v26 ??) = (r0v25 ??), (r0v28 ??), (r0v28 ??), (r0v28 ??) binds: [B:70:0x018d, B:78:0x01b0, B:79:0x01b2, B:81:0x01b8] A[DONT_GENERATE, DONT_INLINE]
      0x01c8: PHI (r5v11 boolean) = (r5v10 boolean), (r5v13 boolean), (r5v13 boolean), (r5v13 boolean) binds: [B:70:0x018d, B:78:0x01b0, B:79:0x01b2, B:81:0x01b8] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v25 */
    /* JADX WARN: Type inference failed for: r0v26 */
    /* JADX WARN: Type inference failed for: r0v28 */
    /* JADX WARN: Type inference failed for: r0v31 */
    /* JADX WARN: Type inference failed for: r0v33 */
    /* JADX WARN: Type inference failed for: r0v65 */
    /* JADX WARN: Type inference failed for: r0v66 */
    /* JADX WARN: Type inference failed for: r0v67 */
    /* JADX WARN: Type inference failed for: r0v68 */
    /* JADX WARN: Type inference failed for: r0v69 */
    /* JADX WARN: Type inference failed for: r11v0 */
    /* JADX WARN: Type inference failed for: r11v1 */
    /* JADX WARN: Type inference failed for: r11v10 */
    /* JADX WARN: Type inference failed for: r11v11 */
    /* JADX WARN: Type inference failed for: r11v12 */
    /* JADX WARN: Type inference failed for: r11v13 */
    /* JADX WARN: Type inference failed for: r11v2 */
    /* JADX WARN: Type inference failed for: r11v23 */
    /* JADX WARN: Type inference failed for: r11v24 */
    /* JADX WARN: Type inference failed for: r11v25 */
    /* JADX WARN: Type inference failed for: r11v26 */
    /* JADX WARN: Type inference failed for: r11v8 */
    /* JADX WARN: Type inference failed for: r11v9, types: [boolean] */
    @Override // u.c
    public void M0() {
        ?? r11;
        boolean z10;
        ?? r12;
        boolean z11;
        ?? r10;
        ?? r13;
        boolean z12;
        boolean zQ0;
        this.U = 0;
        this.V = 0;
        int iMax = Math.max(0, Q());
        int iMax2 = Math.max(0, w());
        this.f1839b1 = false;
        this.f1840c1 = false;
        boolean z13 = g1(64) || g1(128);
        androidx.constraintlayout.solver.d dVar = this.L0;
        dVar.f1627g = false;
        dVar.f1628h = false;
        if (this.Z0 != 0 && z13) {
            dVar.f1628h = true;
        }
        ConstraintWidget.DimensionBehaviour[] dimensionBehaviourArr = this.O;
        ConstraintWidget.DimensionBehaviour dimensionBehaviour = dimensionBehaviourArr[1];
        ConstraintWidget.DimensionBehaviour dimensionBehaviour2 = dimensionBehaviourArr[0];
        ArrayList<ConstraintWidget> arrayList = this.G0;
        ConstraintWidget.DimensionBehaviour dimensionBehaviourZ = z();
        ConstraintWidget.DimensionBehaviour dimensionBehaviour3 = ConstraintWidget.DimensionBehaviour.WRAP_CONTENT;
        boolean z14 = dimensionBehaviourZ == dimensionBehaviour3 || N() == dimensionBehaviour3;
        h1();
        int size = this.G0.size();
        for (int i10 = 0; i10 < size; i10++) {
            ConstraintWidget constraintWidget = this.G0.get(i10);
            if (constraintWidget instanceof u.c) {
                ((u.c) constraintWidget).M0();
            }
        }
        int i11 = 0;
        boolean z15 = false;
        ?? r14 = 1;
        while (r14 != 0) {
            int i12 = i11 + 1;
            try {
                this.L0.E();
                h1();
                m(this.L0);
                for (int i13 = 0; i13 < size; i13++) {
                    this.G0.get(i13).m(this.L0);
                }
                zQ0 = Q0(this.L0);
                r11 = zQ0;
                if (zQ0) {
                    this.L0.A();
                }
            } catch (Exception e10) {
                e10.printStackTrace();
                System.out.println("EXCEPTION : " + e10);
                r11 = r14;
            }
            if (r11 != 0) {
                l1(this.L0, g.f1881a);
            } else {
                K0(this.L0);
                for (int i14 = 0; i14 < size; i14++) {
                    r11 = zQ0;
                    this.G0.get(i14).K0(this.L0);
                }
            }
            if (z14) {
                r11 = zQ0;
                if (i12 >= 8 || !g.f1881a[2]) {
                    r11 = zQ0;
                    r11 = zQ0;
                    r11 = zQ0;
                    r11 = zQ0;
                    z10 = false;
                } else {
                    int iMax3 = 0;
                    int iMax4 = 0;
                    for (int i15 = 0; i15 < size; i15++) {
                        r11 = zQ0;
                        ConstraintWidget constraintWidget2 = this.G0.get(i15);
                        iMax3 = Math.max(iMax3, constraintWidget2.U + constraintWidget2.Q());
                        iMax4 = Math.max(iMax4, constraintWidget2.V + constraintWidget2.w());
                    }
                    r11 = zQ0;
                    int iMax5 = Math.max(this.f1685b0, iMax3);
                    int iMax6 = Math.max(this.f1687c0, iMax4);
                    ConstraintWidget.DimensionBehaviour dimensionBehaviour4 = ConstraintWidget.DimensionBehaviour.WRAP_CONTENT;
                    if (dimensionBehaviour2 != dimensionBehaviour4 || Q() >= iMax5) {
                        z10 = false;
                        z15 = z15;
                    } else {
                        F0(iMax5);
                        this.O[0] = dimensionBehaviour4;
                        z10 = true;
                        z15 = true;
                    }
                    if (dimensionBehaviour == dimensionBehaviour4 && w() < iMax6) {
                        i0(iMax6);
                        this.O[1] = dimensionBehaviour4;
                        z10 = true;
                        z15 = true;
                    }
                }
            } else {
                r11 = zQ0;
                r11 = zQ0;
                r11 = zQ0;
                r11 = zQ0;
                z10 = false;
            }
            int iMax7 = Math.max(this.f1685b0, Q());
            boolean z16 = z10;
            boolean z17 = z15;
            if (iMax7 > Q()) {
                F0(iMax7);
                this.O[0] = ConstraintWidget.DimensionBehaviour.FIXED;
                z16 = true;
                z17 = true;
            }
            int iMax8 = Math.max(this.f1687c0, w());
            if (iMax8 > w()) {
                i0(iMax8);
                r12 = 1;
                this.O[1] = ConstraintWidget.DimensionBehaviour.FIXED;
                r10 = 1;
                z11 = true;
            } else {
                r12 = 1;
                z11 = z17;
            }
            if (z11) {
                r10 = z16;
                r13 = r10;
                z12 = z11;
            } else {
                r10 = z16;
                ConstraintWidget.DimensionBehaviour dimensionBehaviour5 = this.O[0];
                ConstraintWidget.DimensionBehaviour dimensionBehaviour6 = ConstraintWidget.DimensionBehaviour.WRAP_CONTENT;
                if (dimensionBehaviour5 == dimensionBehaviour6 && iMax > 0) {
                    r10 = r10;
                    z11 = z11;
                    if (Q() > iMax) {
                        this.f1839b1 = r12;
                        this.O[0] = ConstraintWidget.DimensionBehaviour.FIXED;
                        F0(iMax);
                        ?? r15 = r12;
                        z11 = r15 == true ? 1 : 0;
                        r10 = r15;
                    }
                }
                r10 = r10;
                r10 = r10;
                z11 = z11;
                z11 = z11;
                if (this.O[r12] != dimensionBehaviour6 || iMax2 <= 0 || w() <= iMax2) {
                    r10 = z16;
                    r13 = r10;
                    z12 = z11;
                } else {
                    this.f1840c1 = r12;
                    this.O[r12] = ConstraintWidget.DimensionBehaviour.FIXED;
                    i0(iMax2);
                    r13 = 1;
                    z12 = true;
                }
            }
            i11 = i12;
            r14 = r13;
            z15 = z12;
        }
        this.G0 = arrayList;
        if (z15) {
            ConstraintWidget.DimensionBehaviour[] dimensionBehaviourArr2 = this.O;
            dimensionBehaviourArr2[0] = dimensionBehaviour2;
            dimensionBehaviourArr2[1] = dimensionBehaviour;
        }
        b0(this.L0.w());
    }

    void P0(ConstraintWidget constraintWidget, int i10) {
        if (i10 == 0) {
            R0(constraintWidget);
        } else if (i10 == 1) {
            S0(constraintWidget);
        }
    }

    public boolean Q0(androidx.constraintlayout.solver.d dVar) {
        f(dVar);
        int size = this.G0.size();
        boolean z10 = false;
        for (int i10 = 0; i10 < size; i10++) {
            ConstraintWidget constraintWidget = this.G0.get(i10);
            constraintWidget.p0(0, false);
            constraintWidget.p0(1, false);
            if (constraintWidget instanceof a) {
                z10 = true;
            }
        }
        if (z10) {
            for (int i11 = 0; i11 < size; i11++) {
                ConstraintWidget constraintWidget2 = this.G0.get(i11);
                if (constraintWidget2 instanceof a) {
                    ((a) constraintWidget2).O0();
                }
            }
        }
        for (int i12 = 0; i12 < size; i12++) {
            ConstraintWidget constraintWidget3 = this.G0.get(i12);
            if (constraintWidget3.e()) {
                constraintWidget3.f(dVar);
            }
        }
        for (int i13 = 0; i13 < size; i13++) {
            ConstraintWidget constraintWidget4 = this.G0.get(i13);
            if (constraintWidget4 instanceof d) {
                ConstraintWidget.DimensionBehaviour[] dimensionBehaviourArr = constraintWidget4.O;
                ConstraintWidget.DimensionBehaviour dimensionBehaviour = dimensionBehaviourArr[0];
                ConstraintWidget.DimensionBehaviour dimensionBehaviour2 = dimensionBehaviourArr[1];
                ConstraintWidget.DimensionBehaviour dimensionBehaviour3 = ConstraintWidget.DimensionBehaviour.WRAP_CONTENT;
                if (dimensionBehaviour == dimensionBehaviour3) {
                    constraintWidget4.m0(ConstraintWidget.DimensionBehaviour.FIXED);
                }
                if (dimensionBehaviour2 == dimensionBehaviour3) {
                    constraintWidget4.B0(ConstraintWidget.DimensionBehaviour.FIXED);
                }
                constraintWidget4.f(dVar);
                if (dimensionBehaviour == dimensionBehaviour3) {
                    constraintWidget4.m0(dimensionBehaviour);
                }
                if (dimensionBehaviour2 == dimensionBehaviour3) {
                    constraintWidget4.B0(dimensionBehaviour2);
                }
            } else {
                g.a(this, dVar, constraintWidget4);
                if (!constraintWidget4.e()) {
                    constraintWidget4.f(dVar);
                }
            }
        }
        if (this.Q0 > 0) {
            b.a(this, dVar, 0);
        }
        if (this.R0 > 0) {
            b.a(this, dVar, 1);
        }
        return true;
    }

    public boolean T0(boolean z10) {
        return this.I0.f(z10);
    }

    public boolean U0(boolean z10) {
        return this.I0.g(z10);
    }

    public boolean V0(boolean z10, int i10) {
        return this.I0.h(z10, i10);
    }

    public void W0(t.a aVar) {
        this.L0.v(aVar);
    }

    public androidx.constraintlayout.solver.widgets.analyzer.b.InterfaceC0007b X0() {
        return this.J0;
    }

    public int Y0() {
        return this.Z0;
    }

    @Override // u.c, androidx.constraintlayout.solver.widgets.ConstraintWidget
    public void Z() {
        this.L0.E();
        this.M0 = 0;
        this.O0 = 0;
        this.N0 = 0;
        this.P0 = 0;
        this.f1838a1 = false;
        super.Z();
    }

    public boolean Z0() {
        return false;
    }

    public void a1() {
        this.I0.j();
    }

    public void b1() {
        this.I0.k();
    }

    public boolean c1() {
        return this.f1840c1;
    }

    public boolean d1() {
        return this.K0;
    }

    public boolean e1() {
        return this.f1839b1;
    }

    public long f1(int i10, int i11, int i12, int i13, int i14, int i15, int i16, int i17, int i18) {
        this.M0 = i17;
        this.N0 = i18;
        return this.H0.d(this, i10, i17, i18, i11, i12, i13, i14, i15, i16);
    }

    public boolean g1(int i10) {
        return (this.Z0 & i10) == i10;
    }

    public void i1(androidx.constraintlayout.solver.widgets.analyzer.b.InterfaceC0007b interfaceC0007b) {
        this.J0 = interfaceC0007b;
        this.I0.n(interfaceC0007b);
    }

    public void j1(int i10) {
        this.Z0 = i10;
        androidx.constraintlayout.solver.d.f1618r = g.b(i10, 256);
    }

    public void k1(boolean z10) {
        this.K0 = z10;
    }

    public void l1(androidx.constraintlayout.solver.d dVar, boolean[] zArr) {
        zArr[2] = false;
        K0(dVar);
        int size = this.G0.size();
        for (int i10 = 0; i10 < size; i10++) {
            this.G0.get(i10).K0(dVar);
        }
    }

    public void m1() {
        this.H0.e(this);
    }
}
