package androidx.constraintlayout.solver.widgets;

/* JADX INFO: compiled from: Optimizer.java */
/* JADX INFO: loaded from: classes.dex */
public class g {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    static boolean[] f1881a = new boolean[3];

    static void a(d dVar, androidx.constraintlayout.solver.d dVar2, ConstraintWidget constraintWidget) {
        constraintWidget.f1700j = -1;
        constraintWidget.f1702k = -1;
        ConstraintWidget.DimensionBehaviour dimensionBehaviour = dVar.O[0];
        ConstraintWidget.DimensionBehaviour dimensionBehaviour2 = ConstraintWidget.DimensionBehaviour.WRAP_CONTENT;
        if (dimensionBehaviour != dimensionBehaviour2 && constraintWidget.O[0] == ConstraintWidget.DimensionBehaviour.MATCH_PARENT) {
            int i10 = constraintWidget.D.f1668e;
            int iQ = dVar.Q() - constraintWidget.F.f1668e;
            ConstraintAnchor constraintAnchor = constraintWidget.D;
            constraintAnchor.f1670g = dVar2.q(constraintAnchor);
            ConstraintAnchor constraintAnchor2 = constraintWidget.F;
            constraintAnchor2.f1670g = dVar2.q(constraintAnchor2);
            dVar2.f(constraintWidget.D.f1670g, i10);
            dVar2.f(constraintWidget.F.f1670g, iQ);
            constraintWidget.f1700j = 2;
            constraintWidget.l0(i10, iQ);
        }
        if (dVar.O[1] == dimensionBehaviour2 || constraintWidget.O[1] != ConstraintWidget.DimensionBehaviour.MATCH_PARENT) {
            return;
        }
        int i11 = constraintWidget.E.f1668e;
        int iW = dVar.w() - constraintWidget.G.f1668e;
        ConstraintAnchor constraintAnchor3 = constraintWidget.E;
        constraintAnchor3.f1670g = dVar2.q(constraintAnchor3);
        ConstraintAnchor constraintAnchor4 = constraintWidget.G;
        constraintAnchor4.f1670g = dVar2.q(constraintAnchor4);
        dVar2.f(constraintWidget.E.f1670g, i11);
        dVar2.f(constraintWidget.G.f1670g, iW);
        if (constraintWidget.f1683a0 > 0 || constraintWidget.P() == 8) {
            ConstraintAnchor constraintAnchor5 = constraintWidget.H;
            constraintAnchor5.f1670g = dVar2.q(constraintAnchor5);
            dVar2.f(constraintWidget.H.f1670g, constraintWidget.f1683a0 + i11);
        }
        constraintWidget.f1702k = 2;
        constraintWidget.A0(i11, iW);
    }

    public static final boolean b(int i10, int i11) {
        return (i10 & i11) == i11;
    }
}
