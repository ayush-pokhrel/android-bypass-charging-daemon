package androidx.constraintlayout.solver.widgets;

import androidx.constraintlayout.solver.SolverVariable;
import java.util.HashSet;
import java.util.Iterator;

/* JADX INFO: loaded from: classes.dex */
public class ConstraintAnchor {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final ConstraintWidget f1665b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public final Type f1666c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public ConstraintAnchor f1667d;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    SolverVariable f1670g;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private HashSet<ConstraintAnchor> f1664a = null;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public int f1668e = 0;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    int f1669f = -1;

    public enum Type {
        NONE,
        LEFT,
        TOP,
        RIGHT,
        BOTTOM,
        BASELINE,
        CENTER,
        CENTER_X,
        CENTER_Y
    }

    static /* synthetic */ class a {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        static final /* synthetic */ int[] f1681a;

        static {
            int[] iArr = new int[Type.values().length];
            f1681a = iArr;
            try {
                iArr[Type.CENTER.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                f1681a[Type.LEFT.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                f1681a[Type.RIGHT.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                f1681a[Type.TOP.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                f1681a[Type.BOTTOM.ordinal()] = 5;
            } catch (NoSuchFieldError unused5) {
            }
            try {
                f1681a[Type.BASELINE.ordinal()] = 6;
            } catch (NoSuchFieldError unused6) {
            }
            try {
                f1681a[Type.CENTER_X.ordinal()] = 7;
            } catch (NoSuchFieldError unused7) {
            }
            try {
                f1681a[Type.CENTER_Y.ordinal()] = 8;
            } catch (NoSuchFieldError unused8) {
            }
            try {
                f1681a[Type.NONE.ordinal()] = 9;
            } catch (NoSuchFieldError unused9) {
            }
        }
    }

    public ConstraintAnchor(ConstraintWidget constraintWidget, Type type) {
        this.f1665b = constraintWidget;
        this.f1666c = type;
    }

    public boolean a(ConstraintAnchor constraintAnchor, int i10) {
        return b(constraintAnchor, i10, -1, false);
    }

    public boolean b(ConstraintAnchor constraintAnchor, int i10, int i11, boolean z10) {
        if (constraintAnchor == null) {
            l();
            return true;
        }
        if (!z10 && !k(constraintAnchor)) {
            return false;
        }
        this.f1667d = constraintAnchor;
        if (constraintAnchor.f1664a == null) {
            constraintAnchor.f1664a = new HashSet<>();
        }
        this.f1667d.f1664a.add(this);
        if (i10 > 0) {
            this.f1668e = i10;
        } else {
            this.f1668e = 0;
        }
        this.f1669f = i11;
        return true;
    }

    public int c() {
        ConstraintAnchor constraintAnchor;
        if (this.f1665b.P() == 8) {
            return 0;
        }
        return (this.f1669f <= -1 || (constraintAnchor = this.f1667d) == null || constraintAnchor.f1665b.P() != 8) ? this.f1668e : this.f1669f;
    }

    public final ConstraintAnchor d() {
        switch (a.f1681a[this.f1666c.ordinal()]) {
            case 1:
            case 6:
            case 7:
            case 8:
            case 9:
                return null;
            case 2:
                return this.f1665b.F;
            case 3:
                return this.f1665b.D;
            case 4:
                return this.f1665b.G;
            case 5:
                return this.f1665b.E;
            default:
                throw new AssertionError(this.f1666c.name());
        }
    }

    public ConstraintWidget e() {
        return this.f1665b;
    }

    public SolverVariable f() {
        return this.f1670g;
    }

    public ConstraintAnchor g() {
        return this.f1667d;
    }

    public Type h() {
        return this.f1666c;
    }

    public boolean i() {
        HashSet<ConstraintAnchor> hashSet = this.f1664a;
        if (hashSet == null) {
            return false;
        }
        Iterator<ConstraintAnchor> it = hashSet.iterator();
        while (it.hasNext()) {
            if (it.next().d().j()) {
                return true;
            }
        }
        return false;
    }

    public boolean j() {
        return this.f1667d != null;
    }

    public boolean k(ConstraintAnchor constraintAnchor) {
        if (constraintAnchor == null) {
            return false;
        }
        Type typeH = constraintAnchor.h();
        Type type = this.f1666c;
        if (typeH == type) {
            return type != Type.BASELINE || (constraintAnchor.e().T() && e().T());
        }
        switch (a.f1681a[type.ordinal()]) {
            case 1:
                return (typeH == Type.BASELINE || typeH == Type.CENTER_X || typeH == Type.CENTER_Y) ? false : true;
            case 2:
            case 3:
                boolean z10 = typeH == Type.LEFT || typeH == Type.RIGHT;
                if (constraintAnchor.e() instanceof f) {
                    return z10 || typeH == Type.CENTER_X;
                }
                return z10;
            case 4:
            case 5:
                boolean z11 = typeH == Type.TOP || typeH == Type.BOTTOM;
                if (constraintAnchor.e() instanceof f) {
                    return z11 || typeH == Type.CENTER_Y;
                }
                return z11;
            case 6:
            case 7:
            case 8:
            case 9:
                return false;
            default:
                throw new AssertionError(this.f1666c.name());
        }
    }

    public void l() {
        HashSet<ConstraintAnchor> hashSet;
        ConstraintAnchor constraintAnchor = this.f1667d;
        if (constraintAnchor != null && (hashSet = constraintAnchor.f1664a) != null) {
            hashSet.remove(this);
        }
        this.f1667d = null;
        this.f1668e = 0;
        this.f1669f = -1;
    }

    public void m(androidx.constraintlayout.solver.c cVar) {
        SolverVariable solverVariable = this.f1670g;
        if (solverVariable == null) {
            this.f1670g = new SolverVariable(SolverVariable.Type.UNRESTRICTED, null);
        } else {
            solverVariable.d();
        }
    }

    public void n(int i10) {
        if (j()) {
            this.f1669f = i10;
        }
    }

    public String toString() {
        return this.f1665b.s() + ":" + this.f1666c.toString();
    }
}
