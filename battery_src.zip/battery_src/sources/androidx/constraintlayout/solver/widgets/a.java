package androidx.constraintlayout.solver.widgets;

import androidx.constraintlayout.solver.SolverVariable;
import java.util.HashMap;

/* JADX INFO: compiled from: Barrier.java */
/* JADX INFO: loaded from: classes.dex */
public class a extends u.b {
    private int I0 = 0;
    private boolean J0 = true;
    private int K0 = 0;

    public boolean L0() {
        return this.J0;
    }

    public int M0() {
        return this.I0;
    }

    public int N0() {
        return this.K0;
    }

    protected void O0() {
        for (int i10 = 0; i10 < this.H0; i10++) {
            ConstraintWidget constraintWidget = this.G0[i10];
            int i11 = this.I0;
            if (i11 == 0 || i11 == 1) {
                constraintWidget.p0(0, true);
            } else if (i11 == 2 || i11 == 3) {
                constraintWidget.p0(1, true);
            }
        }
    }

    public void P0(boolean z10) {
        this.J0 = z10;
    }

    public void Q0(int i10) {
        this.I0 = i10;
    }

    public void R0(int i10) {
        this.K0 = i10;
    }

    @Override // androidx.constraintlayout.solver.widgets.ConstraintWidget
    public void f(androidx.constraintlayout.solver.d dVar) {
        ConstraintAnchor[] constraintAnchorArr;
        boolean z10;
        int i10;
        int i11;
        int i12;
        ConstraintAnchor[] constraintAnchorArr2 = this.L;
        constraintAnchorArr2[0] = this.D;
        constraintAnchorArr2[2] = this.E;
        constraintAnchorArr2[1] = this.F;
        constraintAnchorArr2[3] = this.G;
        int i13 = 0;
        while (true) {
            constraintAnchorArr = this.L;
            if (i13 >= constraintAnchorArr.length) {
                break;
            }
            ConstraintAnchor constraintAnchor = constraintAnchorArr[i13];
            constraintAnchor.f1670g = dVar.q(constraintAnchor);
            i13++;
        }
        int i14 = this.I0;
        if (i14 < 0 || i14 >= 4) {
            return;
        }
        ConstraintAnchor constraintAnchor2 = constraintAnchorArr[i14];
        int i15 = 0;
        while (true) {
            if (i15 >= this.H0) {
                z10 = false;
                break;
            }
            ConstraintWidget constraintWidget = this.G0[i15];
            if ((this.J0 || constraintWidget.g()) && ((((i11 = this.I0) == 0 || i11 == 1) && constraintWidget.z() == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT && constraintWidget.D.f1667d != null && constraintWidget.F.f1667d != null) || (((i12 = this.I0) == 2 || i12 == 3) && constraintWidget.N() == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT && constraintWidget.E.f1667d != null && constraintWidget.G.f1667d != null))) {
                z10 = true;
                break;
            }
            i15++;
        }
        boolean z11 = this.D.i() || this.F.i();
        boolean z12 = this.E.i() || this.G.i();
        int i16 = !(!z10 && (((i10 = this.I0) == 0 && z11) || ((i10 == 2 && z12) || ((i10 == 1 && z11) || (i10 == 3 && z12))))) ? 4 : 5;
        for (int i17 = 0; i17 < this.H0; i17++) {
            ConstraintWidget constraintWidget2 = this.G0[i17];
            if (this.J0 || constraintWidget2.g()) {
                SolverVariable solverVariableQ = dVar.q(constraintWidget2.L[this.I0]);
                ConstraintAnchor[] constraintAnchorArr3 = constraintWidget2.L;
                int i18 = this.I0;
                ConstraintAnchor constraintAnchor3 = constraintAnchorArr3[i18];
                constraintAnchor3.f1670g = solverVariableQ;
                ConstraintAnchor constraintAnchor4 = constraintAnchor3.f1667d;
                int i19 = (constraintAnchor4 == null || constraintAnchor4.f1665b != this) ? 0 : constraintAnchor3.f1668e;
                if (i18 == 0 || i18 == 2) {
                    dVar.i(constraintAnchor2.f1670g, solverVariableQ, this.K0 - i19, z10);
                } else {
                    dVar.g(constraintAnchor2.f1670g, solverVariableQ, this.K0 + i19, z10);
                }
                dVar.e(constraintAnchor2.f1670g, solverVariableQ, this.K0 + i19, i16);
            }
        }
        int i20 = this.I0;
        if (i20 == 0) {
            dVar.e(this.F.f1670g, this.D.f1670g, 0, 8);
            dVar.e(this.D.f1670g, this.P.F.f1670g, 0, 4);
            dVar.e(this.D.f1670g, this.P.D.f1670g, 0, 0);
            return;
        }
        if (i20 == 1) {
            dVar.e(this.D.f1670g, this.F.f1670g, 0, 8);
            dVar.e(this.D.f1670g, this.P.D.f1670g, 0, 4);
            dVar.e(this.D.f1670g, this.P.F.f1670g, 0, 0);
        } else if (i20 == 2) {
            dVar.e(this.G.f1670g, this.E.f1670g, 0, 8);
            dVar.e(this.E.f1670g, this.P.G.f1670g, 0, 4);
            dVar.e(this.E.f1670g, this.P.E.f1670g, 0, 0);
        } else if (i20 == 3) {
            dVar.e(this.E.f1670g, this.G.f1670g, 0, 8);
            dVar.e(this.E.f1670g, this.P.E.f1670g, 0, 4);
            dVar.e(this.E.f1670g, this.P.G.f1670g, 0, 0);
        }
    }

    @Override // androidx.constraintlayout.solver.widgets.ConstraintWidget
    public boolean g() {
        return true;
    }

    @Override // u.b, androidx.constraintlayout.solver.widgets.ConstraintWidget
    public void l(ConstraintWidget constraintWidget, HashMap<ConstraintWidget, ConstraintWidget> map) {
        super.l(constraintWidget, map);
        a aVar = (a) constraintWidget;
        this.I0 = aVar.I0;
        this.J0 = aVar.J0;
        this.K0 = aVar.K0;
    }

    @Override // androidx.constraintlayout.solver.widgets.ConstraintWidget
    public String toString() {
        String str = "[Barrier] " + s() + " {";
        for (int i10 = 0; i10 < this.H0; i10++) {
            ConstraintWidget constraintWidget = this.G0[i10];
            if (i10 > 0) {
                str = str + ", ";
            }
            str = str + constraintWidget.s();
        }
        return str + "}";
    }
}
