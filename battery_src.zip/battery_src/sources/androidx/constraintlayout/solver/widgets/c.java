package androidx.constraintlayout.solver.widgets;

import java.util.ArrayList;

/* JADX INFO: compiled from: ChainHead.java */
/* JADX INFO: loaded from: classes.dex */
public class c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    protected ConstraintWidget f1816a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    protected ConstraintWidget f1817b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    protected ConstraintWidget f1818c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    protected ConstraintWidget f1819d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    protected ConstraintWidget f1820e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    protected ConstraintWidget f1821f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    protected ConstraintWidget f1822g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    protected ArrayList<ConstraintWidget> f1823h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    protected int f1824i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    protected int f1825j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    protected float f1826k = 0.0f;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    int f1827l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    int f1828m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    int f1829n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    boolean f1830o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    private int f1831p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    private boolean f1832q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    protected boolean f1833r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    protected boolean f1834s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    protected boolean f1835t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    protected boolean f1836u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    private boolean f1837v;

    public c(ConstraintWidget constraintWidget, int i10, boolean z10) {
        this.f1816a = constraintWidget;
        this.f1831p = i10;
        this.f1832q = z10;
    }

    private void b() {
        int i10 = this.f1831p * 2;
        ConstraintWidget constraintWidget = this.f1816a;
        this.f1830o = true;
        ConstraintWidget constraintWidget2 = constraintWidget;
        boolean z10 = false;
        while (!z10) {
            this.f1824i++;
            ConstraintWidget[] constraintWidgetArr = constraintWidget.C0;
            int i11 = this.f1831p;
            ConstraintWidget constraintWidget3 = null;
            constraintWidgetArr[i11] = null;
            constraintWidget.B0[i11] = null;
            if (constraintWidget.P() != 8) {
                this.f1827l++;
                ConstraintWidget.DimensionBehaviour dimensionBehaviourT = constraintWidget.t(this.f1831p);
                ConstraintWidget.DimensionBehaviour dimensionBehaviour = ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT;
                if (dimensionBehaviourT != dimensionBehaviour) {
                    this.f1828m += constraintWidget.B(this.f1831p);
                }
                int iC = this.f1828m + constraintWidget.L[i10].c();
                this.f1828m = iC;
                int i12 = i10 + 1;
                this.f1828m = iC + constraintWidget.L[i12].c();
                int iC2 = this.f1829n + constraintWidget.L[i10].c();
                this.f1829n = iC2;
                this.f1829n = iC2 + constraintWidget.L[i12].c();
                if (this.f1817b == null) {
                    this.f1817b = constraintWidget;
                }
                this.f1819d = constraintWidget;
                ConstraintWidget.DimensionBehaviour[] dimensionBehaviourArr = constraintWidget.O;
                int i13 = this.f1831p;
                if (dimensionBehaviourArr[i13] == dimensionBehaviour) {
                    int i14 = constraintWidget.f1708n[i13];
                    if (i14 == 0 || i14 == 3 || i14 == 2) {
                        this.f1825j++;
                        float f10 = constraintWidget.A0[i13];
                        if (f10 > 0.0f) {
                            this.f1826k += f10;
                        }
                        if (c(constraintWidget, i13)) {
                            if (f10 < 0.0f) {
                                this.f1833r = true;
                            } else {
                                this.f1834s = true;
                            }
                            if (this.f1823h == null) {
                                this.f1823h = new ArrayList<>();
                            }
                            this.f1823h.add(constraintWidget);
                        }
                        if (this.f1821f == null) {
                            this.f1821f = constraintWidget;
                        }
                        ConstraintWidget constraintWidget4 = this.f1822g;
                        if (constraintWidget4 != null) {
                            constraintWidget4.B0[this.f1831p] = constraintWidget;
                        }
                        this.f1822g = constraintWidget;
                    }
                    if (this.f1831p == 0) {
                        if (constraintWidget.f1704l != 0 || constraintWidget.f1710o != 0 || constraintWidget.f1712p != 0) {
                            this.f1830o = false;
                        }
                    } else if (constraintWidget.f1706m != 0 || constraintWidget.f1716r != 0 || constraintWidget.f1718s != 0) {
                        this.f1830o = false;
                    }
                    if (constraintWidget.S != 0.0f) {
                        this.f1830o = false;
                        this.f1836u = true;
                    }
                }
            }
            if (constraintWidget2 != constraintWidget) {
                constraintWidget2.C0[this.f1831p] = constraintWidget;
            }
            ConstraintAnchor constraintAnchor = constraintWidget.L[i10 + 1].f1667d;
            if (constraintAnchor != null) {
                ConstraintWidget constraintWidget5 = constraintAnchor.f1665b;
                ConstraintAnchor constraintAnchor2 = constraintWidget5.L[i10].f1667d;
                if (constraintAnchor2 != null && constraintAnchor2.f1665b == constraintWidget) {
                    constraintWidget3 = constraintWidget5;
                }
            }
            if (constraintWidget3 == null) {
                constraintWidget3 = constraintWidget;
                z10 = true;
            }
            constraintWidget2 = constraintWidget;
            constraintWidget = constraintWidget3;
        }
        ConstraintWidget constraintWidget6 = this.f1817b;
        if (constraintWidget6 != null) {
            this.f1828m -= constraintWidget6.L[i10].c();
        }
        ConstraintWidget constraintWidget7 = this.f1819d;
        if (constraintWidget7 != null) {
            this.f1828m -= constraintWidget7.L[i10 + 1].c();
        }
        this.f1818c = constraintWidget;
        if (this.f1831p == 0 && this.f1832q) {
            this.f1820e = constraintWidget;
        } else {
            this.f1820e = this.f1816a;
        }
        this.f1835t = this.f1834s && this.f1833r;
    }

    private static boolean c(ConstraintWidget constraintWidget, int i10) {
        int i11;
        return constraintWidget.P() != 8 && constraintWidget.O[i10] == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT && ((i11 = constraintWidget.f1708n[i10]) == 0 || i11 == 3);
    }

    public void a() {
        if (!this.f1837v) {
            b();
        }
        this.f1837v = true;
    }
}
