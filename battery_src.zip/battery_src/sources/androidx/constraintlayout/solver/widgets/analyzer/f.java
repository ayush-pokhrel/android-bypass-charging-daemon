package androidx.constraintlayout.solver.widgets.analyzer;

import androidx.constraintlayout.solver.widgets.ConstraintWidget;

/* JADX INFO: compiled from: GuidelineReference.java */
/* JADX INFO: loaded from: classes.dex */
class f extends WidgetRun {
    public f(ConstraintWidget constraintWidget) {
        super(constraintWidget);
        constraintWidget.f1690e.f();
        constraintWidget.f1692f.f();
        this.f1767f = ((androidx.constraintlayout.solver.widgets.f) constraintWidget).L0();
    }

    private void q(DependencyNode dependencyNode) {
        this.f1769h.f1751k.add(dependencyNode);
        dependencyNode.f1752l.add(this.f1769h);
    }

    @Override // androidx.constraintlayout.solver.widgets.analyzer.WidgetRun, v.a
    public void a(v.a aVar) {
        DependencyNode dependencyNode = this.f1769h;
        if (dependencyNode.f1743c && !dependencyNode.f1750j) {
            this.f1769h.d((int) ((dependencyNode.f1752l.get(0).f1747g * ((androidx.constraintlayout.solver.widgets.f) this.f1763b).O0()) + 0.5f));
        }
    }

    @Override // androidx.constraintlayout.solver.widgets.analyzer.WidgetRun
    void d() {
        androidx.constraintlayout.solver.widgets.f fVar = (androidx.constraintlayout.solver.widgets.f) this.f1763b;
        int iM0 = fVar.M0();
        int iN0 = fVar.N0();
        fVar.O0();
        if (fVar.L0() == 1) {
            if (iM0 != -1) {
                this.f1769h.f1752l.add(this.f1763b.P.f1690e.f1769h);
                this.f1763b.P.f1690e.f1769h.f1751k.add(this.f1769h);
                this.f1769h.f1746f = iM0;
            } else if (iN0 != -1) {
                this.f1769h.f1752l.add(this.f1763b.P.f1690e.f1770i);
                this.f1763b.P.f1690e.f1770i.f1751k.add(this.f1769h);
                this.f1769h.f1746f = -iN0;
            } else {
                DependencyNode dependencyNode = this.f1769h;
                dependencyNode.f1742b = true;
                dependencyNode.f1752l.add(this.f1763b.P.f1690e.f1770i);
                this.f1763b.P.f1690e.f1770i.f1751k.add(this.f1769h);
            }
            q(this.f1763b.f1690e.f1769h);
            q(this.f1763b.f1690e.f1770i);
            return;
        }
        if (iM0 != -1) {
            this.f1769h.f1752l.add(this.f1763b.P.f1692f.f1769h);
            this.f1763b.P.f1692f.f1769h.f1751k.add(this.f1769h);
            this.f1769h.f1746f = iM0;
        } else if (iN0 != -1) {
            this.f1769h.f1752l.add(this.f1763b.P.f1692f.f1770i);
            this.f1763b.P.f1692f.f1770i.f1751k.add(this.f1769h);
            this.f1769h.f1746f = -iN0;
        } else {
            DependencyNode dependencyNode2 = this.f1769h;
            dependencyNode2.f1742b = true;
            dependencyNode2.f1752l.add(this.f1763b.P.f1692f.f1770i);
            this.f1763b.P.f1692f.f1770i.f1751k.add(this.f1769h);
        }
        q(this.f1763b.f1692f.f1769h);
        q(this.f1763b.f1692f.f1770i);
    }

    @Override // androidx.constraintlayout.solver.widgets.analyzer.WidgetRun
    public void e() {
        if (((androidx.constraintlayout.solver.widgets.f) this.f1763b).L0() == 1) {
            this.f1763b.G0(this.f1769h.f1747g);
        } else {
            this.f1763b.H0(this.f1769h.f1747g);
        }
    }

    @Override // androidx.constraintlayout.solver.widgets.analyzer.WidgetRun
    void f() {
        this.f1769h.c();
    }

    @Override // androidx.constraintlayout.solver.widgets.analyzer.WidgetRun
    boolean m() {
        return false;
    }
}
