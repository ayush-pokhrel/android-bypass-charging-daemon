package androidx.constraintlayout.solver.widgets.analyzer;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public class DependencyNode implements v.a {

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    WidgetRun f1744d;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    int f1746f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public int f1747g;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public v.a f1741a = null;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public boolean f1742b = false;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public boolean f1743c = false;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    Type f1745e = Type.UNKNOWN;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    int f1748h = 1;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    e f1749i = null;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public boolean f1750j = false;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    List<v.a> f1751k = new ArrayList();

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    List<DependencyNode> f1752l = new ArrayList();

    enum Type {
        UNKNOWN,
        HORIZONTAL_DIMENSION,
        VERTICAL_DIMENSION,
        LEFT,
        RIGHT,
        TOP,
        BOTTOM,
        BASELINE
    }

    public DependencyNode(WidgetRun widgetRun) {
        this.f1744d = widgetRun;
    }

    @Override // v.a
    public void a(v.a aVar) {
        Iterator<DependencyNode> it = this.f1752l.iterator();
        while (it.hasNext()) {
            if (!it.next().f1750j) {
                return;
            }
        }
        this.f1743c = true;
        v.a aVar2 = this.f1741a;
        if (aVar2 != null) {
            aVar2.a(this);
        }
        if (this.f1742b) {
            this.f1744d.a(this);
            return;
        }
        DependencyNode dependencyNode = null;
        int i10 = 0;
        for (DependencyNode dependencyNode2 : this.f1752l) {
            if (!(dependencyNode2 instanceof e)) {
                i10++;
                dependencyNode = dependencyNode2;
            }
        }
        if (dependencyNode != null && i10 == 1 && dependencyNode.f1750j) {
            e eVar = this.f1749i;
            if (eVar != null) {
                if (!eVar.f1750j) {
                    return;
                } else {
                    this.f1746f = this.f1748h * eVar.f1747g;
                }
            }
            d(dependencyNode.f1747g + this.f1746f);
        }
        v.a aVar3 = this.f1741a;
        if (aVar3 != null) {
            aVar3.a(this);
        }
    }

    public void b(v.a aVar) {
        this.f1751k.add(aVar);
        if (this.f1750j) {
            aVar.a(aVar);
        }
    }

    public void c() {
        this.f1752l.clear();
        this.f1751k.clear();
        this.f1750j = false;
        this.f1747g = 0;
        this.f1743c = false;
        this.f1742b = false;
    }

    public void d(int i10) {
        if (this.f1750j) {
            return;
        }
        this.f1750j = true;
        this.f1747g = i10;
        for (v.a aVar : this.f1751k) {
            aVar.a(aVar);
        }
    }

    public String toString() {
        StringBuilder sb2 = new StringBuilder();
        sb2.append(this.f1744d.f1763b.s());
        sb2.append(":");
        sb2.append(this.f1745e);
        sb2.append("(");
        sb2.append(this.f1750j ? Integer.valueOf(this.f1747g) : "unresolved");
        sb2.append(") <t=");
        sb2.append(this.f1752l.size());
        sb2.append(":d=");
        sb2.append(this.f1751k.size());
        sb2.append(">");
        return sb2.toString();
    }
}
