package androidx.constraintlayout.solver.widgets.analyzer;

import androidx.constraintlayout.solver.widgets.ConstraintAnchor;
import androidx.constraintlayout.solver.widgets.ConstraintWidget;
import java.util.ArrayList;
import java.util.Iterator;

/* JADX INFO: compiled from: ChainRun.java */
/* JADX INFO: loaded from: classes.dex */
public class c extends WidgetRun {

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    ArrayList<WidgetRun> f1791k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private int f1792l;

    public c(ConstraintWidget constraintWidget, int i10) {
        super(constraintWidget);
        this.f1791k = new ArrayList<>();
        this.f1767f = i10;
        q();
    }

    private void q() {
        ConstraintWidget constraintWidget;
        ConstraintWidget constraintWidget2 = this.f1763b;
        ConstraintWidget constraintWidgetI = constraintWidget2.I(this.f1767f);
        while (true) {
            ConstraintWidget constraintWidget3 = constraintWidgetI;
            constraintWidget = constraintWidget2;
            constraintWidget2 = constraintWidget3;
            if (constraintWidget2 == null) {
                break;
            } else {
                constraintWidgetI = constraintWidget2.I(this.f1767f);
            }
        }
        this.f1763b = constraintWidget;
        this.f1791k.add(constraintWidget.K(this.f1767f));
        ConstraintWidget constraintWidgetG = constraintWidget.G(this.f1767f);
        while (constraintWidgetG != null) {
            this.f1791k.add(constraintWidgetG.K(this.f1767f));
            constraintWidgetG = constraintWidgetG.G(this.f1767f);
        }
        for (WidgetRun widgetRun : this.f1791k) {
            int i10 = this.f1767f;
            if (i10 == 0) {
                widgetRun.f1763b.f1686c = this;
            } else if (i10 == 1) {
                widgetRun.f1763b.f1688d = this;
            }
        }
        if (this.f1767f == 0 && ((androidx.constraintlayout.solver.widgets.d) this.f1763b.H()).d1() && this.f1791k.size() > 1) {
            ArrayList<WidgetRun> arrayList = this.f1791k;
            this.f1763b = arrayList.get(arrayList.size() - 1).f1763b;
        }
        this.f1792l = this.f1767f == 0 ? this.f1763b.y() : this.f1763b.M();
    }

    private ConstraintWidget r() {
        for (int i10 = 0; i10 < this.f1791k.size(); i10++) {
            WidgetRun widgetRun = this.f1791k.get(i10);
            if (widgetRun.f1763b.P() != 8) {
                return widgetRun.f1763b;
            }
        }
        return null;
    }

    private ConstraintWidget s() {
        for (int size = this.f1791k.size() - 1; size >= 0; size--) {
            WidgetRun widgetRun = this.f1791k.get(size);
            if (widgetRun.f1763b.P() != 8) {
                return widgetRun.f1763b;
            }
        }
        return null;
    }

    /* JADX WARN: Code duplicated, block: B:120:0x01d5 A[PHI: r1 r22 r23 r24
      0x01d5: PHI (r1v61 int) = (r1v59 int), (r1v67 int) binds: [B:119:0x01d3, B:110:0x01ad] A[DONT_GENERATE, DONT_INLINE]
      0x01d5: PHI (r22v1 float) = (r22v0 float), (r22v3 float) binds: [B:119:0x01d3, B:110:0x01ad] A[DONT_GENERATE, DONT_INLINE]
      0x01d5: PHI (r23v4 boolean) = (r23v3 boolean), (r23v6 boolean) binds: [B:119:0x01d3, B:110:0x01ad] A[DONT_GENERATE, DONT_INLINE]
      0x01d5: PHI (r24v4 int) = (r24v3 int), (r24v6 int) binds: [B:119:0x01d3, B:110:0x01ad] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Code duplicated, block: B:302:0x00f6 A[ADDED_TO_REGION, REMOVE, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:64:0x00d9  */
    /* JADX WARN: Code duplicated, block: B:66:0x00e8  */
    /* JADX WARN: Code duplicated, block: B:67:0x00eb  */
    /* JADX WARN: Code duplicated, block: B:69:0x00ee A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:92:0x0155  */
    @Override // androidx.constraintlayout.solver.widgets.analyzer.WidgetRun, v.a
    public void a(v.a aVar) {
        int i10;
        int i11;
        int i12;
        int i13;
        int i14;
        float f10;
        boolean z10;
        int i15;
        int i16;
        int i17;
        int i18;
        boolean z11;
        int i19;
        float f11;
        int iMax;
        int i20;
        int i21;
        float f12;
        if (this.f1769h.f1750j && this.f1770i.f1750j) {
            ConstraintWidget constraintWidgetH = this.f1763b.H();
            boolean zD1 = (constraintWidgetH == null || !(constraintWidgetH instanceof androidx.constraintlayout.solver.widgets.d)) ? false : ((androidx.constraintlayout.solver.widgets.d) constraintWidgetH).d1();
            int i22 = this.f1770i.f1747g - this.f1769h.f1747g;
            int size = this.f1791k.size();
            int i23 = 0;
            while (true) {
                i10 = -1;
                i11 = 8;
                if (i23 >= size) {
                    i23 = -1;
                    break;
                } else if (this.f1791k.get(i23).f1763b.P() != 8) {
                    break;
                } else {
                    i23++;
                }
            }
            int i24 = size - 1;
            for (int i25 = i24; i25 >= 0; i25--) {
                if (this.f1791k.get(i25).f1763b.P() != 8) {
                    i10 = i25;
                    break;
                }
            }
            int i26 = 0;
            while (true) {
                if (i26 >= 2) {
                    i12 = 0;
                    i13 = 0;
                    i14 = 0;
                    f10 = 0.0f;
                    break;
                }
                int i27 = 0;
                i13 = 0;
                i14 = 0;
                int i28 = 0;
                f10 = 0.0f;
                while (i27 < size) {
                    WidgetRun widgetRun = this.f1791k.get(i27);
                    if (widgetRun.f1763b.P() != i11) {
                        i28++;
                        if (i27 > 0 && i27 >= i23) {
                            i13 += widgetRun.f1769h.f1746f;
                        }
                        e eVar = widgetRun.f1766e;
                        int i29 = eVar.f1747g;
                        boolean z12 = widgetRun.f1765d != ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT;
                        if (z12) {
                            int i30 = this.f1767f;
                            if (i30 == 0 && !widgetRun.f1763b.f1690e.f1766e.f1750j) {
                                return;
                            }
                            if (i30 == 1 && !widgetRun.f1763b.f1692f.f1766e.f1750j) {
                                return;
                            } else {
                                i20 = i29;
                            }
                        } else {
                            i20 = i29;
                            if (widgetRun.f1762a == 1 && i26 == 0) {
                                i21 = eVar.f1802m;
                                i14++;
                            } else {
                                if (eVar.f1750j) {
                                    i21 = i20;
                                }
                                if (z12) {
                                    i13 += i21;
                                } else {
                                    i14++;
                                    f12 = widgetRun.f1763b.A0[this.f1767f];
                                    if (f12 >= 0.0f) {
                                        f10 += f12;
                                    }
                                }
                                if (i27 >= i24 && i27 < i10) {
                                    i13 += -widgetRun.f1770i.f1746f;
                                }
                            }
                            z12 = true;
                            if (z12) {
                                i14++;
                                f12 = widgetRun.f1763b.A0[this.f1767f];
                                if (f12 >= 0.0f) {
                                    f10 += f12;
                                }
                            } else {
                                i13 += i21;
                            }
                            if (i27 >= i24) {
                            }
                        }
                        i21 = i20;
                        if (z12) {
                            i14++;
                            f12 = widgetRun.f1763b.A0[this.f1767f];
                            if (f12 >= 0.0f) {
                                f10 += f12;
                            }
                        } else {
                            i13 += i21;
                        }
                        if (i27 >= i24) {
                        }
                    }
                    i27++;
                    i11 = 8;
                }
                if (i13 < i22 || i14 == 0) {
                    i12 = i28;
                    break;
                } else {
                    i26++;
                    i11 = 8;
                }
            }
            int i31 = this.f1769h.f1747g;
            if (zD1) {
                i31 = this.f1770i.f1747g;
            }
            if (i13 > i22) {
                i31 = zD1 ? i31 + ((int) (((i13 - i22) / 2.0f) + 0.5f)) : i31 - ((int) (((i13 - i22) / 2.0f) + 0.5f));
            }
            if (i14 > 0) {
                float f13 = i22 - i13;
                int i32 = (int) ((f13 / i14) + 0.5f);
                int i33 = 0;
                int i34 = 0;
                while (i33 < size) {
                    WidgetRun widgetRun2 = this.f1791k.get(i33);
                    int i35 = i32;
                    int i36 = i13;
                    if (widgetRun2.f1763b.P() != 8 && widgetRun2.f1765d == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT) {
                        e eVar2 = widgetRun2.f1766e;
                        if (eVar2.f1750j) {
                            z11 = zD1;
                            i19 = i12;
                            i31 = i31;
                            f11 = f13;
                        } else {
                            int i37 = f10 > 0.0f ? (int) (((widgetRun2.f1763b.A0[this.f1767f] * f13) / f10) + 0.5f) : i35;
                            if (this.f1767f == 0) {
                                ConstraintWidget constraintWidget = widgetRun2.f1763b;
                                f11 = f13;
                                int i38 = constraintWidget.f1712p;
                                z11 = zD1;
                                i19 = i12;
                                iMax = Math.max(constraintWidget.f1710o, widgetRun2.f1762a == 1 ? Math.min(i37, eVar2.f1802m) : i37);
                                if (i38 > 0) {
                                    iMax = Math.min(i38, iMax);
                                }
                                if (iMax != i37) {
                                    i34++;
                                    i37 = iMax;
                                }
                            } else {
                                z11 = zD1;
                                i19 = i12;
                                f11 = f13;
                                ConstraintWidget constraintWidget2 = widgetRun2.f1763b;
                                int i39 = constraintWidget2.f1718s;
                                iMax = Math.max(constraintWidget2.f1716r, widgetRun2.f1762a == 1 ? Math.min(i37, eVar2.f1802m) : i37);
                                if (i39 > 0) {
                                    iMax = Math.min(i39, iMax);
                                }
                                if (iMax != i37) {
                                    i34++;
                                    i37 = iMax;
                                }
                            }
                            widgetRun2.f1766e.d(i37);
                        }
                    } else {
                        z11 = zD1;
                        i19 = i12;
                        i31 = i31;
                        f11 = f13;
                    }
                    i33++;
                    i32 = i35;
                    i13 = i36;
                    i31 = i31;
                    f13 = f11;
                    zD1 = z11;
                    i12 = i19;
                }
                z10 = zD1;
                i15 = i12;
                i16 = i31;
                int i40 = i13;
                if (i34 > 0) {
                    i14 -= i34;
                    i13 = 0;
                    for (int i41 = 0; i41 < size; i41++) {
                        WidgetRun widgetRun3 = this.f1791k.get(i41);
                        if (widgetRun3.f1763b.P() != 8) {
                            if (i41 > 0 && i41 >= i23) {
                                i13 += widgetRun3.f1769h.f1746f;
                            }
                            i13 += widgetRun3.f1766e.f1747g;
                            if (i41 < i24 && i41 < i10) {
                                i13 += -widgetRun3.f1770i.f1746f;
                            }
                        }
                    }
                } else {
                    i13 = i40;
                }
                i18 = 2;
                if (this.f1792l == 2 && i34 == 0) {
                    i17 = 0;
                    this.f1792l = 0;
                } else {
                    i17 = 0;
                }
            } else {
                z10 = zD1;
                i15 = i12;
                i16 = i31;
                i17 = 0;
                i18 = 2;
            }
            if (i13 > i22) {
                this.f1792l = i18;
            }
            if (i15 > 0 && i14 == 0 && i23 == i10) {
                this.f1792l = i18;
            }
            int i42 = this.f1792l;
            if (i42 == 1) {
                int i43 = i15;
                int i44 = i43 > 1 ? (i22 - i13) / (i43 - 1) : i43 == 1 ? (i22 - i13) / 2 : i17;
                if (i14 > 0) {
                    i44 = i17;
                }
                int i45 = i16;
                for (int i46 = i17; i46 < size; i46++) {
                    WidgetRun widgetRun4 = this.f1791k.get(z10 ? size - (i46 + 1) : i46);
                    if (widgetRun4.f1763b.P() == 8) {
                        widgetRun4.f1769h.d(i45);
                        widgetRun4.f1770i.d(i45);
                    } else {
                        if (i46 > 0) {
                            i45 = z10 ? i45 - i44 : i45 + i44;
                        }
                        if (i46 > 0 && i46 >= i23) {
                            i45 = z10 ? i45 - widgetRun4.f1769h.f1746f : i45 + widgetRun4.f1769h.f1746f;
                        }
                        if (z10) {
                            widgetRun4.f1770i.d(i45);
                        } else {
                            widgetRun4.f1769h.d(i45);
                        }
                        e eVar3 = widgetRun4.f1766e;
                        int i47 = eVar3.f1747g;
                        if (widgetRun4.f1765d == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT && widgetRun4.f1762a == 1) {
                            i47 = eVar3.f1802m;
                        }
                        i45 = z10 ? i45 - i47 : i45 + i47;
                        if (z10) {
                            widgetRun4.f1769h.d(i45);
                        } else {
                            widgetRun4.f1770i.d(i45);
                        }
                        widgetRun4.f1768g = true;
                        if (i46 < i24 && i46 < i10) {
                            i45 = z10 ? i45 - (-widgetRun4.f1770i.f1746f) : i45 + (-widgetRun4.f1770i.f1746f);
                        }
                    }
                }
                return;
            }
            int i48 = i15;
            if (i42 == 0) {
                int i49 = (i22 - i13) / (i48 + 1);
                if (i14 > 0) {
                    i49 = i17;
                }
                int i50 = i16;
                for (int i51 = i17; i51 < size; i51++) {
                    WidgetRun widgetRun5 = this.f1791k.get(z10 ? size - (i51 + 1) : i51);
                    if (widgetRun5.f1763b.P() == 8) {
                        widgetRun5.f1769h.d(i50);
                        widgetRun5.f1770i.d(i50);
                    } else {
                        int i52 = z10 ? i50 - i49 : i50 + i49;
                        if (i51 > 0 && i51 >= i23) {
                            i52 = z10 ? i52 - widgetRun5.f1769h.f1746f : i52 + widgetRun5.f1769h.f1746f;
                        }
                        if (z10) {
                            widgetRun5.f1770i.d(i52);
                        } else {
                            widgetRun5.f1769h.d(i52);
                        }
                        e eVar4 = widgetRun5.f1766e;
                        int iMin = eVar4.f1747g;
                        if (widgetRun5.f1765d == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT && widgetRun5.f1762a == 1) {
                            iMin = Math.min(iMin, eVar4.f1802m);
                        }
                        i50 = z10 ? i52 - iMin : i52 + iMin;
                        if (z10) {
                            widgetRun5.f1769h.d(i50);
                        } else {
                            widgetRun5.f1770i.d(i50);
                        }
                        if (i51 < i24 && i51 < i10) {
                            i50 = z10 ? i50 - (-widgetRun5.f1770i.f1746f) : i50 + (-widgetRun5.f1770i.f1746f);
                        }
                    }
                }
                return;
            }
            if (i42 == 2) {
                float fX = this.f1767f == 0 ? this.f1763b.x() : this.f1763b.L();
                if (z10) {
                    fX = 1.0f - fX;
                }
                int i53 = (int) (((i22 - i13) * fX) + 0.5f);
                if (i53 < 0 || i14 > 0) {
                    i53 = i17;
                }
                int i54 = z10 ? i16 - i53 : i16 + i53;
                for (int i55 = i17; i55 < size; i55++) {
                    WidgetRun widgetRun6 = this.f1791k.get(z10 ? size - (i55 + 1) : i55);
                    if (widgetRun6.f1763b.P() == 8) {
                        widgetRun6.f1769h.d(i54);
                        widgetRun6.f1770i.d(i54);
                    } else {
                        if (i55 > 0 && i55 >= i23) {
                            i54 = z10 ? i54 - widgetRun6.f1769h.f1746f : i54 + widgetRun6.f1769h.f1746f;
                        }
                        if (z10) {
                            widgetRun6.f1770i.d(i54);
                        } else {
                            widgetRun6.f1769h.d(i54);
                        }
                        e eVar5 = widgetRun6.f1766e;
                        int i56 = eVar5.f1747g;
                        if (widgetRun6.f1765d == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT && widgetRun6.f1762a == 1) {
                            i56 = eVar5.f1802m;
                        }
                        i54 = z10 ? i54 - i56 : i54 + i56;
                        if (z10) {
                            widgetRun6.f1769h.d(i54);
                        } else {
                            widgetRun6.f1770i.d(i54);
                        }
                        if (i55 < i24 && i55 < i10) {
                            i54 = z10 ? i54 - (-widgetRun6.f1770i.f1746f) : i54 + (-widgetRun6.f1770i.f1746f);
                        }
                    }
                }
            }
        }
    }

    @Override // androidx.constraintlayout.solver.widgets.analyzer.WidgetRun
    void d() {
        Iterator<WidgetRun> it = this.f1791k.iterator();
        while (it.hasNext()) {
            it.next().d();
        }
        int size = this.f1791k.size();
        if (size < 1) {
            return;
        }
        ConstraintWidget constraintWidget = this.f1791k.get(0).f1763b;
        ConstraintWidget constraintWidget2 = this.f1791k.get(size - 1).f1763b;
        if (this.f1767f == 0) {
            ConstraintAnchor constraintAnchor = constraintWidget.D;
            ConstraintAnchor constraintAnchor2 = constraintWidget2.F;
            DependencyNode dependencyNodeI = i(constraintAnchor, 0);
            int iC = constraintAnchor.c();
            ConstraintWidget constraintWidgetR = r();
            if (constraintWidgetR != null) {
                iC = constraintWidgetR.D.c();
            }
            if (dependencyNodeI != null) {
                b(this.f1769h, dependencyNodeI, iC);
            }
            DependencyNode dependencyNodeI2 = i(constraintAnchor2, 0);
            int iC2 = constraintAnchor2.c();
            ConstraintWidget constraintWidgetS = s();
            if (constraintWidgetS != null) {
                iC2 = constraintWidgetS.F.c();
            }
            if (dependencyNodeI2 != null) {
                b(this.f1770i, dependencyNodeI2, -iC2);
            }
        } else {
            ConstraintAnchor constraintAnchor3 = constraintWidget.E;
            ConstraintAnchor constraintAnchor4 = constraintWidget2.G;
            DependencyNode dependencyNodeI3 = i(constraintAnchor3, 1);
            int iC3 = constraintAnchor3.c();
            ConstraintWidget constraintWidgetR2 = r();
            if (constraintWidgetR2 != null) {
                iC3 = constraintWidgetR2.E.c();
            }
            if (dependencyNodeI3 != null) {
                b(this.f1769h, dependencyNodeI3, iC3);
            }
            DependencyNode dependencyNodeI4 = i(constraintAnchor4, 1);
            int iC4 = constraintAnchor4.c();
            ConstraintWidget constraintWidgetS2 = s();
            if (constraintWidgetS2 != null) {
                iC4 = constraintWidgetS2.G.c();
            }
            if (dependencyNodeI4 != null) {
                b(this.f1770i, dependencyNodeI4, -iC4);
            }
        }
        this.f1769h.f1741a = this;
        this.f1770i.f1741a = this;
    }

    @Override // androidx.constraintlayout.solver.widgets.analyzer.WidgetRun
    public void e() {
        for (int i10 = 0; i10 < this.f1791k.size(); i10++) {
            this.f1791k.get(i10).e();
        }
    }

    @Override // androidx.constraintlayout.solver.widgets.analyzer.WidgetRun
    void f() {
        this.f1764c = null;
        Iterator<WidgetRun> it = this.f1791k.iterator();
        while (it.hasNext()) {
            it.next().f();
        }
    }

    @Override // androidx.constraintlayout.solver.widgets.analyzer.WidgetRun
    public long j() {
        int size = this.f1791k.size();
        long j10 = 0;
        for (int i10 = 0; i10 < size; i10++) {
            WidgetRun widgetRun = this.f1791k.get(i10);
            j10 = j10 + ((long) widgetRun.f1769h.f1746f) + widgetRun.j() + ((long) widgetRun.f1770i.f1746f);
        }
        return j10;
    }

    @Override // androidx.constraintlayout.solver.widgets.analyzer.WidgetRun
    boolean m() {
        int size = this.f1791k.size();
        for (int i10 = 0; i10 < size; i10++) {
            if (!this.f1791k.get(i10).m()) {
                return false;
            }
        }
        return true;
    }

    public String toString() {
        StringBuilder sb2 = new StringBuilder();
        sb2.append("ChainRun ");
        sb2.append(this.f1767f == 0 ? "horizontal : " : "vertical : ");
        String string = sb2.toString();
        Iterator<WidgetRun> it = this.f1791k.iterator();
        while (it.hasNext()) {
            String str = string + "<";
            string = (str + it.next()) + "> ";
        }
        return string;
    }
}
