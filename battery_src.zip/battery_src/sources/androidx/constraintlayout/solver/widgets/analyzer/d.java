package androidx.constraintlayout.solver.widgets.analyzer;

import androidx.constraintlayout.solver.widgets.ConstraintAnchor;
import androidx.constraintlayout.solver.widgets.ConstraintWidget;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;

/* JADX INFO: compiled from: DependencyGraph.java */
/* JADX INFO: loaded from: classes.dex */
public class d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private androidx.constraintlayout.solver.widgets.d f1793a;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private androidx.constraintlayout.solver.widgets.d f1796d;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private boolean f1794b = true;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private boolean f1795c = true;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private ArrayList<WidgetRun> f1797e = new ArrayList<>();

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private ArrayList<i> f1798f = new ArrayList<>();

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private b.InterfaceC0007b f1799g = null;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private b.a f1800h = new b.a();

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    ArrayList<i> f1801i = new ArrayList<>();

    public d(androidx.constraintlayout.solver.widgets.d dVar) {
        this.f1793a = dVar;
        this.f1796d = dVar;
    }

    private void a(DependencyNode dependencyNode, int i10, int i11, DependencyNode dependencyNode2, ArrayList<i> arrayList, i iVar) {
        WidgetRun widgetRun = dependencyNode.f1744d;
        if (widgetRun.f1764c == null) {
            androidx.constraintlayout.solver.widgets.d dVar = this.f1793a;
            if (widgetRun == dVar.f1690e || widgetRun == dVar.f1692f) {
                return;
            }
            if (iVar == null) {
                iVar = new i(widgetRun, i11);
                arrayList.add(iVar);
            }
            widgetRun.f1764c = iVar;
            iVar.a(widgetRun);
            for (v.a aVar : widgetRun.f1769h.f1751k) {
                if (aVar instanceof DependencyNode) {
                    a((DependencyNode) aVar, i10, 0, dependencyNode2, arrayList, iVar);
                }
            }
            for (v.a aVar2 : widgetRun.f1770i.f1751k) {
                if (aVar2 instanceof DependencyNode) {
                    a((DependencyNode) aVar2, i10, 1, dependencyNode2, arrayList, iVar);
                }
            }
            if (i10 == 1 && (widgetRun instanceof j)) {
                for (v.a aVar3 : ((j) widgetRun).f1813k.f1751k) {
                    if (aVar3 instanceof DependencyNode) {
                        a((DependencyNode) aVar3, i10, 2, dependencyNode2, arrayList, iVar);
                    }
                }
            }
            for (DependencyNode dependencyNode3 : widgetRun.f1769h.f1752l) {
                if (dependencyNode3 == dependencyNode2) {
                    iVar.f1807b = true;
                }
                a(dependencyNode3, i10, 0, dependencyNode2, arrayList, iVar);
            }
            for (DependencyNode dependencyNode4 : widgetRun.f1770i.f1752l) {
                if (dependencyNode4 == dependencyNode2) {
                    iVar.f1807b = true;
                }
                a(dependencyNode4, i10, 1, dependencyNode2, arrayList, iVar);
            }
            if (i10 == 1 && (widgetRun instanceof j)) {
                Iterator<DependencyNode> it = ((j) widgetRun).f1813k.f1752l.iterator();
                while (it.hasNext()) {
                    a(it.next(), i10, 2, dependencyNode2, arrayList, iVar);
                }
            }
        }
    }

    private boolean b(androidx.constraintlayout.solver.widgets.d dVar) {
        int iQ;
        ConstraintWidget.DimensionBehaviour dimensionBehaviour;
        int iW;
        ConstraintWidget.DimensionBehaviour dimensionBehaviour2;
        ConstraintWidget.DimensionBehaviour[] dimensionBehaviourArr;
        ConstraintWidget.DimensionBehaviour dimensionBehaviour3;
        ConstraintWidget.DimensionBehaviour dimensionBehaviour4;
        ConstraintWidget.DimensionBehaviour dimensionBehaviour5;
        ConstraintWidget.DimensionBehaviour dimensionBehaviour6;
        for (ConstraintWidget constraintWidget : dVar.G0) {
            ConstraintWidget.DimensionBehaviour[] dimensionBehaviourArr2 = constraintWidget.O;
            ConstraintWidget.DimensionBehaviour dimensionBehaviour7 = dimensionBehaviourArr2[0];
            ConstraintWidget.DimensionBehaviour dimensionBehaviour8 = dimensionBehaviourArr2[1];
            if (constraintWidget.P() == 8) {
                constraintWidget.f1682a = true;
            } else {
                if (constraintWidget.f1714q < 1.0f && dimensionBehaviour7 == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT) {
                    constraintWidget.f1704l = 2;
                }
                if (constraintWidget.f1720t < 1.0f && dimensionBehaviour8 == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT) {
                    constraintWidget.f1706m = 2;
                }
                if (constraintWidget.u() > 0.0f) {
                    ConstraintWidget.DimensionBehaviour dimensionBehaviour9 = ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT;
                    if (dimensionBehaviour7 == dimensionBehaviour9 && (dimensionBehaviour8 == ConstraintWidget.DimensionBehaviour.WRAP_CONTENT || dimensionBehaviour8 == ConstraintWidget.DimensionBehaviour.FIXED)) {
                        constraintWidget.f1704l = 3;
                    } else if (dimensionBehaviour8 == dimensionBehaviour9 && (dimensionBehaviour7 == ConstraintWidget.DimensionBehaviour.WRAP_CONTENT || dimensionBehaviour7 == ConstraintWidget.DimensionBehaviour.FIXED)) {
                        constraintWidget.f1706m = 3;
                    } else if (dimensionBehaviour7 == dimensionBehaviour9 && dimensionBehaviour8 == dimensionBehaviour9) {
                        if (constraintWidget.f1704l == 0) {
                            constraintWidget.f1704l = 3;
                        }
                        if (constraintWidget.f1706m == 0) {
                            constraintWidget.f1706m = 3;
                        }
                    }
                }
                ConstraintWidget.DimensionBehaviour dimensionBehaviour10 = ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT;
                if (dimensionBehaviour7 == dimensionBehaviour10 && constraintWidget.f1704l == 1 && (constraintWidget.D.f1667d == null || constraintWidget.F.f1667d == null)) {
                    dimensionBehaviour7 = ConstraintWidget.DimensionBehaviour.WRAP_CONTENT;
                }
                ConstraintWidget.DimensionBehaviour dimensionBehaviour11 = dimensionBehaviour7;
                if (dimensionBehaviour8 == dimensionBehaviour10 && constraintWidget.f1706m == 1 && (constraintWidget.E.f1667d == null || constraintWidget.G.f1667d == null)) {
                    dimensionBehaviour8 = ConstraintWidget.DimensionBehaviour.WRAP_CONTENT;
                }
                ConstraintWidget.DimensionBehaviour dimensionBehaviour12 = dimensionBehaviour8;
                h hVar = constraintWidget.f1690e;
                hVar.f1765d = dimensionBehaviour11;
                int i10 = constraintWidget.f1704l;
                hVar.f1762a = i10;
                j jVar = constraintWidget.f1692f;
                jVar.f1765d = dimensionBehaviour12;
                int i11 = constraintWidget.f1706m;
                jVar.f1762a = i11;
                ConstraintWidget.DimensionBehaviour dimensionBehaviour13 = ConstraintWidget.DimensionBehaviour.MATCH_PARENT;
                if ((dimensionBehaviour11 == dimensionBehaviour13 || dimensionBehaviour11 == ConstraintWidget.DimensionBehaviour.FIXED || dimensionBehaviour11 == ConstraintWidget.DimensionBehaviour.WRAP_CONTENT) && (dimensionBehaviour12 == dimensionBehaviour13 || dimensionBehaviour12 == ConstraintWidget.DimensionBehaviour.FIXED || dimensionBehaviour12 == ConstraintWidget.DimensionBehaviour.WRAP_CONTENT)) {
                    int iQ2 = constraintWidget.Q();
                    if (dimensionBehaviour11 == dimensionBehaviour13) {
                        iQ = (dVar.Q() - constraintWidget.D.f1668e) - constraintWidget.F.f1668e;
                        dimensionBehaviour = ConstraintWidget.DimensionBehaviour.FIXED;
                    } else {
                        iQ = iQ2;
                        dimensionBehaviour = dimensionBehaviour11;
                    }
                    int iW2 = constraintWidget.w();
                    if (dimensionBehaviour12 == dimensionBehaviour13) {
                        iW = (dVar.w() - constraintWidget.E.f1668e) - constraintWidget.G.f1668e;
                        dimensionBehaviour2 = ConstraintWidget.DimensionBehaviour.FIXED;
                    } else {
                        iW = iW2;
                        dimensionBehaviour2 = dimensionBehaviour12;
                    }
                    l(constraintWidget, dimensionBehaviour, iQ, dimensionBehaviour2, iW);
                    constraintWidget.f1690e.f1766e.d(constraintWidget.Q());
                    constraintWidget.f1692f.f1766e.d(constraintWidget.w());
                    constraintWidget.f1682a = true;
                } else {
                    if (dimensionBehaviour11 == dimensionBehaviour10 && (dimensionBehaviour12 == (dimensionBehaviour6 = ConstraintWidget.DimensionBehaviour.WRAP_CONTENT) || dimensionBehaviour12 == ConstraintWidget.DimensionBehaviour.FIXED)) {
                        if (i10 == 3) {
                            if (dimensionBehaviour12 == dimensionBehaviour6) {
                                l(constraintWidget, dimensionBehaviour6, 0, dimensionBehaviour6, 0);
                            }
                            int iW3 = constraintWidget.w();
                            int i12 = (int) ((iW3 * constraintWidget.S) + 0.5f);
                            ConstraintWidget.DimensionBehaviour dimensionBehaviour14 = ConstraintWidget.DimensionBehaviour.FIXED;
                            l(constraintWidget, dimensionBehaviour14, i12, dimensionBehaviour14, iW3);
                            constraintWidget.f1690e.f1766e.d(constraintWidget.Q());
                            constraintWidget.f1692f.f1766e.d(constraintWidget.w());
                            constraintWidget.f1682a = true;
                        } else if (i10 == 1) {
                            l(constraintWidget, dimensionBehaviour6, 0, dimensionBehaviour12, 0);
                            constraintWidget.f1690e.f1766e.f1802m = constraintWidget.Q();
                        } else if (i10 == 2) {
                            ConstraintWidget.DimensionBehaviour dimensionBehaviour15 = dVar.O[0];
                            ConstraintWidget.DimensionBehaviour dimensionBehaviour16 = ConstraintWidget.DimensionBehaviour.FIXED;
                            if (dimensionBehaviour15 == dimensionBehaviour16 || dimensionBehaviour15 == dimensionBehaviour13) {
                                l(constraintWidget, dimensionBehaviour16, (int) ((constraintWidget.f1714q * dVar.Q()) + 0.5f), dimensionBehaviour12, constraintWidget.w());
                                constraintWidget.f1690e.f1766e.d(constraintWidget.Q());
                                constraintWidget.f1692f.f1766e.d(constraintWidget.w());
                                constraintWidget.f1682a = true;
                            }
                        } else {
                            ConstraintAnchor[] constraintAnchorArr = constraintWidget.L;
                            if (constraintAnchorArr[0].f1667d == null || constraintAnchorArr[1].f1667d == null) {
                                l(constraintWidget, dimensionBehaviour6, 0, dimensionBehaviour12, 0);
                                constraintWidget.f1690e.f1766e.d(constraintWidget.Q());
                                constraintWidget.f1692f.f1766e.d(constraintWidget.w());
                                constraintWidget.f1682a = true;
                            }
                        }
                    }
                    if (dimensionBehaviour12 == dimensionBehaviour10 && (dimensionBehaviour11 == (dimensionBehaviour5 = ConstraintWidget.DimensionBehaviour.WRAP_CONTENT) || dimensionBehaviour11 == ConstraintWidget.DimensionBehaviour.FIXED)) {
                        if (i11 == 3) {
                            if (dimensionBehaviour11 == dimensionBehaviour5) {
                                l(constraintWidget, dimensionBehaviour5, 0, dimensionBehaviour5, 0);
                            }
                            int iQ3 = constraintWidget.Q();
                            float f10 = constraintWidget.S;
                            if (constraintWidget.v() == -1) {
                                f10 = 1.0f / f10;
                            }
                            ConstraintWidget.DimensionBehaviour dimensionBehaviour17 = ConstraintWidget.DimensionBehaviour.FIXED;
                            l(constraintWidget, dimensionBehaviour17, iQ3, dimensionBehaviour17, (int) ((iQ3 * f10) + 0.5f));
                            constraintWidget.f1690e.f1766e.d(constraintWidget.Q());
                            constraintWidget.f1692f.f1766e.d(constraintWidget.w());
                            constraintWidget.f1682a = true;
                        } else if (i11 == 1) {
                            l(constraintWidget, dimensionBehaviour11, 0, dimensionBehaviour5, 0);
                            constraintWidget.f1692f.f1766e.f1802m = constraintWidget.w();
                        } else if (i11 == 2) {
                            ConstraintWidget.DimensionBehaviour dimensionBehaviour18 = dVar.O[1];
                            ConstraintWidget.DimensionBehaviour dimensionBehaviour19 = ConstraintWidget.DimensionBehaviour.FIXED;
                            if (dimensionBehaviour18 == dimensionBehaviour19 || dimensionBehaviour18 == dimensionBehaviour13) {
                                l(constraintWidget, dimensionBehaviour11, constraintWidget.Q(), dimensionBehaviour19, (int) ((constraintWidget.f1720t * dVar.w()) + 0.5f));
                                constraintWidget.f1690e.f1766e.d(constraintWidget.Q());
                                constraintWidget.f1692f.f1766e.d(constraintWidget.w());
                                constraintWidget.f1682a = true;
                            }
                        } else {
                            ConstraintAnchor[] constraintAnchorArr2 = constraintWidget.L;
                            if (constraintAnchorArr2[2].f1667d == null || constraintAnchorArr2[3].f1667d == null) {
                                l(constraintWidget, dimensionBehaviour5, 0, dimensionBehaviour12, 0);
                                constraintWidget.f1690e.f1766e.d(constraintWidget.Q());
                                constraintWidget.f1692f.f1766e.d(constraintWidget.w());
                                constraintWidget.f1682a = true;
                            }
                        }
                    }
                    if (dimensionBehaviour11 == dimensionBehaviour10 && dimensionBehaviour12 == dimensionBehaviour10) {
                        if (i10 == 1 || i11 == 1) {
                            ConstraintWidget.DimensionBehaviour dimensionBehaviour20 = ConstraintWidget.DimensionBehaviour.WRAP_CONTENT;
                            l(constraintWidget, dimensionBehaviour20, 0, dimensionBehaviour20, 0);
                            constraintWidget.f1690e.f1766e.f1802m = constraintWidget.Q();
                            constraintWidget.f1692f.f1766e.f1802m = constraintWidget.w();
                        } else if (i11 == 2 && i10 == 2 && ((dimensionBehaviour3 = (dimensionBehaviourArr = dVar.O)[0]) == (dimensionBehaviour4 = ConstraintWidget.DimensionBehaviour.FIXED) || dimensionBehaviour3 == dimensionBehaviour4)) {
                            ConstraintWidget.DimensionBehaviour dimensionBehaviour21 = dimensionBehaviourArr[1];
                            if (dimensionBehaviour21 == dimensionBehaviour4 || dimensionBehaviour21 == dimensionBehaviour4) {
                                l(constraintWidget, dimensionBehaviour4, (int) ((constraintWidget.f1714q * dVar.Q()) + 0.5f), dimensionBehaviour4, (int) ((constraintWidget.f1720t * dVar.w()) + 0.5f));
                                constraintWidget.f1690e.f1766e.d(constraintWidget.Q());
                                constraintWidget.f1692f.f1766e.d(constraintWidget.w());
                                constraintWidget.f1682a = true;
                            }
                        }
                    }
                }
            }
        }
        return false;
    }

    private int e(androidx.constraintlayout.solver.widgets.d dVar, int i10) {
        int size = this.f1801i.size();
        long jMax = 0;
        for (int i11 = 0; i11 < size; i11++) {
            jMax = Math.max(jMax, this.f1801i.get(i11).b(dVar, i10));
        }
        return (int) jMax;
    }

    private void i(WidgetRun widgetRun, int i10, ArrayList<i> arrayList) {
        for (v.a aVar : widgetRun.f1769h.f1751k) {
            if (aVar instanceof DependencyNode) {
                a((DependencyNode) aVar, i10, 0, widgetRun.f1770i, arrayList, null);
            } else if (aVar instanceof WidgetRun) {
                a(((WidgetRun) aVar).f1769h, i10, 0, widgetRun.f1770i, arrayList, null);
            }
        }
        for (v.a aVar2 : widgetRun.f1770i.f1751k) {
            if (aVar2 instanceof DependencyNode) {
                a((DependencyNode) aVar2, i10, 1, widgetRun.f1769h, arrayList, null);
            } else if (aVar2 instanceof WidgetRun) {
                a(((WidgetRun) aVar2).f1770i, i10, 1, widgetRun.f1769h, arrayList, null);
            }
        }
        if (i10 == 1) {
            for (v.a aVar3 : ((j) widgetRun).f1813k.f1751k) {
                if (aVar3 instanceof DependencyNode) {
                    a((DependencyNode) aVar3, i10, 2, null, arrayList, null);
                }
            }
        }
    }

    private void l(ConstraintWidget constraintWidget, ConstraintWidget.DimensionBehaviour dimensionBehaviour, int i10, ConstraintWidget.DimensionBehaviour dimensionBehaviour2, int i11) {
        b.a aVar = this.f1800h;
        aVar.f1781a = dimensionBehaviour;
        aVar.f1782b = dimensionBehaviour2;
        aVar.f1783c = i10;
        aVar.f1784d = i11;
        this.f1799g.a(constraintWidget, aVar);
        constraintWidget.F0(this.f1800h.f1785e);
        constraintWidget.i0(this.f1800h.f1786f);
        constraintWidget.h0(this.f1800h.f1788h);
        constraintWidget.c0(this.f1800h.f1787g);
    }

    public void c() {
        d(this.f1797e);
        this.f1801i.clear();
        i.f1805h = 0;
        i(this.f1793a.f1690e, 0, this.f1801i);
        i(this.f1793a.f1692f, 1, this.f1801i);
        this.f1794b = false;
    }

    public void d(ArrayList<WidgetRun> arrayList) {
        arrayList.clear();
        this.f1796d.f1690e.f();
        this.f1796d.f1692f.f();
        arrayList.add(this.f1796d.f1690e);
        arrayList.add(this.f1796d.f1692f);
        HashSet hashSet = null;
        for (ConstraintWidget constraintWidget : this.f1796d.G0) {
            if (constraintWidget instanceof androidx.constraintlayout.solver.widgets.f) {
                arrayList.add(new f(constraintWidget));
            } else {
                if (constraintWidget.W()) {
                    if (constraintWidget.f1686c == null) {
                        constraintWidget.f1686c = new c(constraintWidget, 0);
                    }
                    if (hashSet == null) {
                        hashSet = new HashSet();
                    }
                    hashSet.add(constraintWidget.f1686c);
                } else {
                    arrayList.add(constraintWidget.f1690e);
                }
                if (constraintWidget.Y()) {
                    if (constraintWidget.f1688d == null) {
                        constraintWidget.f1688d = new c(constraintWidget, 1);
                    }
                    if (hashSet == null) {
                        hashSet = new HashSet();
                    }
                    hashSet.add(constraintWidget.f1688d);
                } else {
                    arrayList.add(constraintWidget.f1692f);
                }
                if (constraintWidget instanceof u.b) {
                    arrayList.add(new g(constraintWidget));
                }
            }
        }
        if (hashSet != null) {
            arrayList.addAll(hashSet);
        }
        Iterator<WidgetRun> it = arrayList.iterator();
        while (it.hasNext()) {
            it.next().f();
        }
        for (WidgetRun widgetRun : arrayList) {
            if (widgetRun.f1763b != this.f1796d) {
                widgetRun.d();
            }
        }
    }

    public boolean f(boolean z10) {
        boolean z11;
        boolean z12 = false;
        if (this.f1794b || this.f1795c) {
            for (ConstraintWidget constraintWidget : this.f1793a.G0) {
                constraintWidget.f1682a = false;
                constraintWidget.f1690e.r();
                constraintWidget.f1692f.q();
            }
            androidx.constraintlayout.solver.widgets.d dVar = this.f1793a;
            dVar.f1682a = false;
            dVar.f1690e.r();
            this.f1793a.f1692f.q();
            this.f1795c = false;
        }
        if (b(this.f1796d)) {
            return false;
        }
        this.f1793a.G0(0);
        this.f1793a.H0(0);
        ConstraintWidget.DimensionBehaviour dimensionBehaviourT = this.f1793a.t(0);
        ConstraintWidget.DimensionBehaviour dimensionBehaviourT2 = this.f1793a.t(1);
        if (this.f1794b) {
            c();
        }
        int iR = this.f1793a.R();
        int iS = this.f1793a.S();
        this.f1793a.f1690e.f1769h.d(iR);
        this.f1793a.f1692f.f1769h.d(iS);
        m();
        ConstraintWidget.DimensionBehaviour dimensionBehaviour = ConstraintWidget.DimensionBehaviour.WRAP_CONTENT;
        if (dimensionBehaviourT == dimensionBehaviour || dimensionBehaviourT2 == dimensionBehaviour) {
            if (z10) {
                Iterator<WidgetRun> it = this.f1797e.iterator();
                while (it.hasNext()) {
                    if (!it.next().m()) {
                        z10 = false;
                        break;
                    }
                }
            }
            if (z10 && dimensionBehaviourT == ConstraintWidget.DimensionBehaviour.WRAP_CONTENT) {
                this.f1793a.m0(ConstraintWidget.DimensionBehaviour.FIXED);
                androidx.constraintlayout.solver.widgets.d dVar2 = this.f1793a;
                dVar2.F0(e(dVar2, 0));
                androidx.constraintlayout.solver.widgets.d dVar3 = this.f1793a;
                dVar3.f1690e.f1766e.d(dVar3.Q());
            }
            if (z10 && dimensionBehaviourT2 == ConstraintWidget.DimensionBehaviour.WRAP_CONTENT) {
                this.f1793a.B0(ConstraintWidget.DimensionBehaviour.FIXED);
                androidx.constraintlayout.solver.widgets.d dVar4 = this.f1793a;
                dVar4.i0(e(dVar4, 1));
                androidx.constraintlayout.solver.widgets.d dVar5 = this.f1793a;
                dVar5.f1692f.f1766e.d(dVar5.w());
            }
        }
        androidx.constraintlayout.solver.widgets.d dVar6 = this.f1793a;
        ConstraintWidget.DimensionBehaviour dimensionBehaviour2 = dVar6.O[0];
        ConstraintWidget.DimensionBehaviour dimensionBehaviour3 = ConstraintWidget.DimensionBehaviour.FIXED;
        if (dimensionBehaviour2 == dimensionBehaviour3 || dimensionBehaviour2 == ConstraintWidget.DimensionBehaviour.MATCH_PARENT) {
            int iQ = dVar6.Q() + iR;
            this.f1793a.f1690e.f1770i.d(iQ);
            this.f1793a.f1690e.f1766e.d(iQ - iR);
            m();
            androidx.constraintlayout.solver.widgets.d dVar7 = this.f1793a;
            ConstraintWidget.DimensionBehaviour dimensionBehaviour4 = dVar7.O[1];
            if (dimensionBehaviour4 == dimensionBehaviour3 || dimensionBehaviour4 == ConstraintWidget.DimensionBehaviour.MATCH_PARENT) {
                int iW = dVar7.w() + iS;
                this.f1793a.f1692f.f1770i.d(iW);
                this.f1793a.f1692f.f1766e.d(iW - iS);
            }
            m();
            z11 = true;
        } else {
            z11 = false;
        }
        for (WidgetRun widgetRun : this.f1797e) {
            if (widgetRun.f1763b != this.f1793a || widgetRun.f1768g) {
                widgetRun.e();
            }
        }
        for (WidgetRun widgetRun2 : this.f1797e) {
            if (z11 || widgetRun2.f1763b != this.f1793a) {
                if (!widgetRun2.f1769h.f1750j || ((!widgetRun2.f1770i.f1750j && !(widgetRun2 instanceof f)) || (!widgetRun2.f1766e.f1750j && !(widgetRun2 instanceof c) && !(widgetRun2 instanceof f)))) {
                    this.f1793a.m0(dimensionBehaviourT);
                    this.f1793a.B0(dimensionBehaviourT2);
                    return z12;
                }
            }
        }
        z12 = true;
        this.f1793a.m0(dimensionBehaviourT);
        this.f1793a.B0(dimensionBehaviourT2);
        return z12;
    }

    public boolean g(boolean z10) {
        if (this.f1794b) {
            for (ConstraintWidget constraintWidget : this.f1793a.G0) {
                constraintWidget.f1682a = false;
                h hVar = constraintWidget.f1690e;
                hVar.f1766e.f1750j = false;
                hVar.f1768g = false;
                hVar.r();
                j jVar = constraintWidget.f1692f;
                jVar.f1766e.f1750j = false;
                jVar.f1768g = false;
                jVar.q();
            }
            androidx.constraintlayout.solver.widgets.d dVar = this.f1793a;
            dVar.f1682a = false;
            h hVar2 = dVar.f1690e;
            hVar2.f1766e.f1750j = false;
            hVar2.f1768g = false;
            hVar2.r();
            j jVar2 = this.f1793a.f1692f;
            jVar2.f1766e.f1750j = false;
            jVar2.f1768g = false;
            jVar2.q();
            c();
        }
        if (b(this.f1796d)) {
            return false;
        }
        this.f1793a.G0(0);
        this.f1793a.H0(0);
        this.f1793a.f1690e.f1769h.d(0);
        this.f1793a.f1692f.f1769h.d(0);
        return true;
    }

    /* JADX WARN: Code duplicated, block: B:36:0x00c1  */
    public boolean h(boolean z10, int i10) {
        boolean z11;
        ConstraintWidget.DimensionBehaviour dimensionBehaviour;
        boolean z12 = false;
        ConstraintWidget.DimensionBehaviour dimensionBehaviourT = this.f1793a.t(0);
        ConstraintWidget.DimensionBehaviour dimensionBehaviourT2 = this.f1793a.t(1);
        int iR = this.f1793a.R();
        int iS = this.f1793a.S();
        if (z10 && (dimensionBehaviourT == (dimensionBehaviour = ConstraintWidget.DimensionBehaviour.WRAP_CONTENT) || dimensionBehaviourT2 == dimensionBehaviour)) {
            for (WidgetRun widgetRun : this.f1797e) {
                if (widgetRun.f1767f == i10 && !widgetRun.m()) {
                    z10 = false;
                    break;
                }
            }
            if (i10 == 0) {
                if (z10 && dimensionBehaviourT == ConstraintWidget.DimensionBehaviour.WRAP_CONTENT) {
                    this.f1793a.m0(ConstraintWidget.DimensionBehaviour.FIXED);
                    androidx.constraintlayout.solver.widgets.d dVar = this.f1793a;
                    dVar.F0(e(dVar, 0));
                    androidx.constraintlayout.solver.widgets.d dVar2 = this.f1793a;
                    dVar2.f1690e.f1766e.d(dVar2.Q());
                }
            } else if (z10 && dimensionBehaviourT2 == ConstraintWidget.DimensionBehaviour.WRAP_CONTENT) {
                this.f1793a.B0(ConstraintWidget.DimensionBehaviour.FIXED);
                androidx.constraintlayout.solver.widgets.d dVar3 = this.f1793a;
                dVar3.i0(e(dVar3, 1));
                androidx.constraintlayout.solver.widgets.d dVar4 = this.f1793a;
                dVar4.f1692f.f1766e.d(dVar4.w());
            }
        }
        if (i10 == 0) {
            androidx.constraintlayout.solver.widgets.d dVar5 = this.f1793a;
            ConstraintWidget.DimensionBehaviour dimensionBehaviour2 = dVar5.O[0];
            if (dimensionBehaviour2 == ConstraintWidget.DimensionBehaviour.FIXED || dimensionBehaviour2 == ConstraintWidget.DimensionBehaviour.MATCH_PARENT) {
                int iQ = dVar5.Q() + iR;
                this.f1793a.f1690e.f1770i.d(iQ);
                this.f1793a.f1690e.f1766e.d(iQ - iR);
                z11 = true;
            } else {
                z11 = false;
            }
        } else {
            androidx.constraintlayout.solver.widgets.d dVar6 = this.f1793a;
            ConstraintWidget.DimensionBehaviour dimensionBehaviour3 = dVar6.O[1];
            if (dimensionBehaviour3 == ConstraintWidget.DimensionBehaviour.FIXED || dimensionBehaviour3 == ConstraintWidget.DimensionBehaviour.MATCH_PARENT) {
                int iW = dVar6.w() + iS;
                this.f1793a.f1692f.f1770i.d(iW);
                this.f1793a.f1692f.f1766e.d(iW - iS);
                z11 = true;
            } else {
                z11 = false;
            }
        }
        m();
        for (WidgetRun widgetRun2 : this.f1797e) {
            if (widgetRun2.f1767f == i10 && (widgetRun2.f1763b != this.f1793a || widgetRun2.f1768g)) {
                widgetRun2.e();
            }
        }
        for (WidgetRun widgetRun3 : this.f1797e) {
            if (widgetRun3.f1767f == i10 && (z11 || widgetRun3.f1763b != this.f1793a)) {
                if (!widgetRun3.f1769h.f1750j || !widgetRun3.f1770i.f1750j || (!(widgetRun3 instanceof c) && !widgetRun3.f1766e.f1750j)) {
                    this.f1793a.m0(dimensionBehaviourT);
                    this.f1793a.B0(dimensionBehaviourT2);
                    return z12;
                }
            }
        }
        z12 = true;
        this.f1793a.m0(dimensionBehaviourT);
        this.f1793a.B0(dimensionBehaviourT2);
        return z12;
    }

    public void j() {
        this.f1794b = true;
    }

    public void k() {
        this.f1795c = true;
    }

    public void m() {
        e eVar;
        for (ConstraintWidget constraintWidget : this.f1793a.G0) {
            if (!constraintWidget.f1682a) {
                ConstraintWidget.DimensionBehaviour[] dimensionBehaviourArr = constraintWidget.O;
                boolean z10 = false;
                ConstraintWidget.DimensionBehaviour dimensionBehaviour = dimensionBehaviourArr[0];
                ConstraintWidget.DimensionBehaviour dimensionBehaviour2 = dimensionBehaviourArr[1];
                int i10 = constraintWidget.f1704l;
                int i11 = constraintWidget.f1706m;
                ConstraintWidget.DimensionBehaviour dimensionBehaviour3 = ConstraintWidget.DimensionBehaviour.WRAP_CONTENT;
                boolean z11 = dimensionBehaviour == dimensionBehaviour3 || (dimensionBehaviour == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT && i10 == 1);
                if (dimensionBehaviour2 == dimensionBehaviour3 || (dimensionBehaviour2 == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT && i11 == 1)) {
                    z10 = true;
                }
                e eVar2 = constraintWidget.f1690e.f1766e;
                boolean z12 = eVar2.f1750j;
                e eVar3 = constraintWidget.f1692f.f1766e;
                boolean z13 = eVar3.f1750j;
                if (z12 && z13) {
                    ConstraintWidget.DimensionBehaviour dimensionBehaviour4 = ConstraintWidget.DimensionBehaviour.FIXED;
                    l(constraintWidget, dimensionBehaviour4, eVar2.f1747g, dimensionBehaviour4, eVar3.f1747g);
                    constraintWidget.f1682a = true;
                } else if (z12 && z10) {
                    l(constraintWidget, ConstraintWidget.DimensionBehaviour.FIXED, eVar2.f1747g, dimensionBehaviour3, eVar3.f1747g);
                    if (dimensionBehaviour2 == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT) {
                        constraintWidget.f1692f.f1766e.f1802m = constraintWidget.w();
                    } else {
                        constraintWidget.f1692f.f1766e.d(constraintWidget.w());
                        constraintWidget.f1682a = true;
                    }
                } else if (z13 && z11) {
                    l(constraintWidget, dimensionBehaviour3, eVar2.f1747g, ConstraintWidget.DimensionBehaviour.FIXED, eVar3.f1747g);
                    if (dimensionBehaviour == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT) {
                        constraintWidget.f1690e.f1766e.f1802m = constraintWidget.Q();
                    } else {
                        constraintWidget.f1690e.f1766e.d(constraintWidget.Q());
                        constraintWidget.f1682a = true;
                    }
                }
                if (constraintWidget.f1682a && (eVar = constraintWidget.f1692f.f1814l) != null) {
                    eVar.d(constraintWidget.o());
                }
            }
        }
    }

    public void n(b.InterfaceC0007b interfaceC0007b) {
        this.f1799g = interfaceC0007b;
    }
}
