package androidx.constraintlayout.solver.widgets.analyzer;

/* JADX INFO: compiled from: DimensionDependency.java */
/* JADX INFO: loaded from: classes.dex */
class e extends DependencyNode {

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public int f1802m;

    public e(WidgetRun widgetRun) {
        super(widgetRun);
        if (widgetRun instanceof h) {
            this.f1745e = DependencyNode.Type.HORIZONTAL_DIMENSION;
        } else {
            this.f1745e = DependencyNode.Type.VERTICAL_DIMENSION;
        }
    }

    @Override // androidx.constraintlayout.solver.widgets.analyzer.DependencyNode
    public void d(int i10) {
        if (this.f1750j) {
            return;
        }
        this.f1750j = true;
        this.f1747g = i10;
        for (v.a aVar : this.f1751k) {
            aVar.a(aVar);
        }
    }
}
