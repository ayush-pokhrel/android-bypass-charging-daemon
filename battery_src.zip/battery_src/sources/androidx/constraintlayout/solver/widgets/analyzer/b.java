package androidx.constraintlayout.solver.widgets.analyzer;

import androidx.constraintlayout.solver.widgets.ConstraintAnchor;
import androidx.constraintlayout.solver.widgets.ConstraintWidget;
import java.util.ArrayList;

/* JADX INFO: compiled from: BasicMeasure.java */
/* JADX INFO: loaded from: classes.dex */
public class b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final ArrayList<ConstraintWidget> f1778a = new ArrayList<>();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private a f1779b = new a();

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private androidx.constraintlayout.solver.widgets.d f1780c;

    /* JADX INFO: compiled from: BasicMeasure.java */
    public static class a {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public ConstraintWidget.DimensionBehaviour f1781a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public ConstraintWidget.DimensionBehaviour f1782b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        public int f1783c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        public int f1784d;

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        public int f1785e;

        /* JADX INFO: renamed from: f, reason: collision with root package name */
        public int f1786f;

        /* JADX INFO: renamed from: g, reason: collision with root package name */
        public int f1787g;

        /* JADX INFO: renamed from: h, reason: collision with root package name */
        public boolean f1788h;

        /* JADX INFO: renamed from: i, reason: collision with root package name */
        public boolean f1789i;

        /* JADX INFO: renamed from: j, reason: collision with root package name */
        public boolean f1790j;
    }

    /* JADX INFO: renamed from: androidx.constraintlayout.solver.widgets.analyzer.b$b, reason: collision with other inner class name */
    /* JADX INFO: compiled from: BasicMeasure.java */
    public interface InterfaceC0007b {
        void a(ConstraintWidget constraintWidget, a aVar);

        void b();
    }

    public b(androidx.constraintlayout.solver.widgets.d dVar) {
        this.f1780c = dVar;
    }

    private boolean a(InterfaceC0007b interfaceC0007b, ConstraintWidget constraintWidget, boolean z10) {
        this.f1779b.f1781a = constraintWidget.z();
        this.f1779b.f1782b = constraintWidget.N();
        this.f1779b.f1783c = constraintWidget.Q();
        this.f1779b.f1784d = constraintWidget.w();
        a aVar = this.f1779b;
        aVar.f1789i = false;
        aVar.f1790j = z10;
        ConstraintWidget.DimensionBehaviour dimensionBehaviour = aVar.f1781a;
        ConstraintWidget.DimensionBehaviour dimensionBehaviour2 = ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT;
        boolean z11 = dimensionBehaviour == dimensionBehaviour2;
        boolean z12 = aVar.f1782b == dimensionBehaviour2;
        boolean z13 = z11 && constraintWidget.S > 0.0f;
        boolean z14 = z12 && constraintWidget.S > 0.0f;
        if (z13 && constraintWidget.f1708n[0] == 4) {
            aVar.f1781a = ConstraintWidget.DimensionBehaviour.FIXED;
        }
        if (z14 && constraintWidget.f1708n[1] == 4) {
            aVar.f1782b = ConstraintWidget.DimensionBehaviour.FIXED;
        }
        interfaceC0007b.a(constraintWidget, aVar);
        constraintWidget.F0(this.f1779b.f1785e);
        constraintWidget.i0(this.f1779b.f1786f);
        constraintWidget.h0(this.f1779b.f1788h);
        constraintWidget.c0(this.f1779b.f1787g);
        a aVar2 = this.f1779b;
        aVar2.f1790j = false;
        return aVar2.f1789i;
    }

    private void b(androidx.constraintlayout.solver.widgets.d dVar) {
        int size = dVar.G0.size();
        InterfaceC0007b interfaceC0007bX0 = dVar.X0();
        for (int i10 = 0; i10 < size; i10++) {
            ConstraintWidget constraintWidget = dVar.G0.get(i10);
            if (!(constraintWidget instanceof androidx.constraintlayout.solver.widgets.f) && (!constraintWidget.f1690e.f1766e.f1750j || !constraintWidget.f1692f.f1766e.f1750j)) {
                ConstraintWidget.DimensionBehaviour dimensionBehaviourT = constraintWidget.t(0);
                ConstraintWidget.DimensionBehaviour dimensionBehaviourT2 = constraintWidget.t(1);
                ConstraintWidget.DimensionBehaviour dimensionBehaviour = ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT;
                if (dimensionBehaviourT != dimensionBehaviour || constraintWidget.f1704l == 1 || dimensionBehaviourT2 != dimensionBehaviour || constraintWidget.f1706m == 1) {
                    a(interfaceC0007bX0, constraintWidget, false);
                }
            }
        }
        interfaceC0007bX0.b();
    }

    private void c(androidx.constraintlayout.solver.widgets.d dVar, String str, int i10, int i11) {
        int iF = dVar.F();
        int iE = dVar.E();
        dVar.v0(0);
        dVar.u0(0);
        dVar.F0(i10);
        dVar.i0(i11);
        dVar.v0(iF);
        dVar.u0(iE);
        this.f1780c.M0();
    }

    /* JADX WARN: Code duplicated, block: B:140:0x020d  */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r11v0 */
    /* JADX WARN: Type inference failed for: r11v1, types: [boolean] */
    /* JADX WARN: Type inference failed for: r11v27 */
    /* JADX WARN: Type inference failed for: r14v28 */
    /* JADX WARN: Type inference failed for: r14v29 */
    /* JADX WARN: Type inference failed for: r14v5, types: [int] */
    /* JADX WARN: Type inference failed for: r15v0 */
    /* JADX WARN: Type inference failed for: r15v1 */
    /* JADX WARN: Type inference failed for: r15v10 */
    /* JADX WARN: Type inference failed for: r15v13 */
    /* JADX WARN: Type inference failed for: r15v14 */
    /* JADX WARN: Type inference failed for: r15v18 */
    /* JADX WARN: Type inference failed for: r15v19 */
    /* JADX WARN: Type inference failed for: r15v2 */
    /* JADX WARN: Type inference failed for: r15v20 */
    /* JADX WARN: Type inference failed for: r15v21 */
    /* JADX WARN: Type inference failed for: r15v22 */
    /* JADX WARN: Type inference failed for: r15v23 */
    /* JADX WARN: Type inference failed for: r15v3 */
    /* JADX WARN: Type inference failed for: r15v4 */
    /* JADX WARN: Type inference failed for: r15v5 */
    /* JADX WARN: Type inference failed for: r15v7 */
    /* JADX WARN: Type inference failed for: r15v8 */
    /* JADX WARN: Type inference failed for: r15v9 */
    /* JADX WARN: Type inference failed for: r18v0, types: [androidx.constraintlayout.solver.widgets.analyzer.b] */
    /* JADX WARN: Type inference failed for: r2v41 */
    /* JADX WARN: Type inference failed for: r2v45, types: [int] */
    /* JADX WARN: Type inference failed for: r2v47 */
    public long d(androidx.constraintlayout.solver.widgets.d dVar, int i10, int i11, int i12, int i13, int i14, int i15, int i16, int i17, int i18) {
        boolean z10;
        boolean zU0;
        int i19;
        int i20;
        boolean z11;
        boolean z12;
        ?? r15;
        int i21;
        int i22;
        InterfaceC0007b interfaceC0007b;
        int i23;
        ?? r16;
        int i24;
        int i25;
        ?? r10;
        InterfaceC0007b interfaceC0007bX0 = dVar.X0();
        int size = dVar.G0.size();
        int iQ = dVar.Q();
        int iW = dVar.w();
        boolean zB = androidx.constraintlayout.solver.widgets.g.b(i10, 128);
        ?? r11 = 1;
        boolean z13 = zB || androidx.constraintlayout.solver.widgets.g.b(i10, 64);
        if (z13) {
            for (int i26 = 0; i26 < size; i26++) {
                ConstraintWidget constraintWidget = dVar.G0.get(i26);
                ConstraintWidget.DimensionBehaviour dimensionBehaviourZ = constraintWidget.z();
                ConstraintWidget.DimensionBehaviour dimensionBehaviour = ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT;
                boolean z14 = (dimensionBehaviourZ == dimensionBehaviour) && (constraintWidget.N() == dimensionBehaviour) && constraintWidget.u() > 0.0f;
                if ((constraintWidget.W() && z14) || ((constraintWidget.Y() && z14) || (constraintWidget instanceof androidx.constraintlayout.solver.widgets.h) || constraintWidget.W() || constraintWidget.Y())) {
                    z13 = false;
                    break;
                }
            }
        }
        if (z13) {
            boolean z15 = androidx.constraintlayout.solver.d.f1618r;
        }
        int i27 = 2;
        if (z13 && ((i13 == 1073741824 && i15 == 1073741824) || zB)) {
            int iMin = Math.min(dVar.D(), i14);
            int iMin2 = Math.min(dVar.C(), i16);
            if (i13 == 1073741824 && dVar.Q() != iMin) {
                dVar.F0(iMin);
                dVar.a1();
            }
            if (i15 == 1073741824 && dVar.w() != iMin2) {
                dVar.i0(iMin2);
                dVar.a1();
            }
            if (i13 == 1073741824 && i15 == 1073741824) {
                zU0 = dVar.T0(zB);
                i19 = 2;
                z10 = false;
            } else {
                zU0 = dVar.U0(zB);
                z10 = false;
                if (i13 == 1073741824) {
                    zU0 &= dVar.V0(zB, 0);
                    i19 = 1;
                } else {
                    i19 = 0;
                }
                if (i15 == 1073741824) {
                    zU0 &= dVar.V0(zB, 1);
                    i19++;
                }
            }
            if (zU0) {
                dVar.J0(i13 == 1073741824 ? true : z10, i15 == 1073741824 ? true : z10);
            }
        } else {
            z10 = false;
            zU0 = false;
            i19 = 0;
        }
        if (zU0 && i19 == 2) {
            return 0L;
        }
        if (size > 0) {
            b(dVar);
        }
        int iY0 = dVar.Y0();
        int size2 = this.f1778a.size();
        if (size > 0) {
            c(dVar, "First pass", iQ, iW);
        }
        if (size2 > 0) {
            ConstraintWidget.DimensionBehaviour dimensionBehaviourZ2 = dVar.z();
            ConstraintWidget.DimensionBehaviour dimensionBehaviour2 = ConstraintWidget.DimensionBehaviour.WRAP_CONTENT;
            boolean z16 = dimensionBehaviourZ2 == dimensionBehaviour2 ? true : z10;
            boolean z17 = dVar.N() == dimensionBehaviour2 ? true : z10;
            int iMax = Math.max(dVar.Q(), this.f1780c.F());
            int iMax2 = Math.max(dVar.w(), this.f1780c.E());
            boolean z18 = z10;
            ?? r17 = z18;
            ?? r14 = z18;
            while (r14 < size2) {
                ConstraintWidget constraintWidget2 = this.f1778a.get(r14);
                if (constraintWidget2 instanceof androidx.constraintlayout.solver.widgets.h) {
                    int iQ2 = constraintWidget2.Q();
                    int iW2 = constraintWidget2.w();
                    int i28 = (r17 == true ? 1 : 0) | (a(interfaceC0007bX0, constraintWidget2, r11) ? 1 : 0);
                    int iQ3 = constraintWidget2.Q();
                    int iW3 = constraintWidget2.w();
                    if (iQ3 != iQ2) {
                        constraintWidget2.F0(iQ3);
                        if (z16 && constraintWidget2.J() > iMax) {
                            iMax = Math.max(iMax, constraintWidget2.J() + constraintWidget2.n(ConstraintAnchor.Type.RIGHT).c());
                        }
                        i25 = 1;
                    } else {
                        i25 = i28;
                    }
                    if (iW3 != iW2) {
                        constraintWidget2.i0(iW3);
                        if (z17 && constraintWidget2.q() > iMax2) {
                            iMax2 = Math.max(iMax2, constraintWidget2.q() + constraintWidget2.n(ConstraintAnchor.Type.BOTTOM).c());
                        }
                        i25 = 1;
                    }
                    r17 = i25 | (((androidx.constraintlayout.solver.widgets.h) constraintWidget2).W0() ? 1 : 0);
                    r10 = 1;
                } else {
                    r10 = r11;
                }
                int i29 = r14 + r10;
                r11 = r10;
                i27 = 2;
                iY0 = iY0;
                r14 = i29;
                r17 = r17;
            }
            int i30 = iY0;
            int i31 = i27;
            int i32 = 0;
            ?? r18 = r17;
            while (i32 < i31) {
                int i33 = 0;
                while (i33 < size2) {
                    ConstraintWidget constraintWidget3 = this.f1778a.get(i33);
                    if (!(constraintWidget3 instanceof u.a) || (constraintWidget3 instanceof androidx.constraintlayout.solver.widgets.h)) {
                        r15 = r18;
                        r15 = r18;
                        if ((constraintWidget3 instanceof androidx.constraintlayout.solver.widgets.f) || constraintWidget3.P() == 8 || ((constraintWidget3.f1690e.f1766e.f1750j && constraintWidget3.f1692f.f1766e.f1750j) || (constraintWidget3 instanceof androidx.constraintlayout.solver.widgets.h))) {
                            r15 = r18;
                            i21 = size2;
                            interfaceC0007b = interfaceC0007bX0;
                            i22 = i32;
                            r16 = r15;
                        } else {
                            int iQ4 = constraintWidget3.Q();
                            int iW4 = constraintWidget3.w();
                            i21 = size2;
                            int iO = constraintWidget3.o();
                            i22 = i32;
                            int i34 = (r15 == true ? 1 : 0) | (a(interfaceC0007bX0, constraintWidget3, true) ? 1 : 0);
                            int iQ5 = constraintWidget3.Q();
                            interfaceC0007b = interfaceC0007bX0;
                            int iW5 = constraintWidget3.w();
                            if (iQ5 != iQ4) {
                                constraintWidget3.F0(iQ5);
                                if (z16 && constraintWidget3.J() > iMax) {
                                    iMax = Math.max(iMax, constraintWidget3.J() + constraintWidget3.n(ConstraintAnchor.Type.RIGHT).c());
                                }
                                i23 = 1;
                            } else {
                                i23 = i34;
                            }
                            if (iW5 != iW4) {
                                constraintWidget3.i0(iW5);
                                if (z17 && constraintWidget3.q() > iMax2) {
                                    iMax2 = Math.max(iMax2, constraintWidget3.q() + constraintWidget3.n(ConstraintAnchor.Type.BOTTOM).c());
                                }
                                i23 = 1;
                            }
                            if (!constraintWidget3.T() || iO == constraintWidget3.o()) {
                                r16 = i23;
                            } else {
                                i24 = 1;
                                r16 = 1;
                            }
                        }
                        i24 = 1;
                    } else {
                        r15 = r18;
                        i21 = size2;
                        interfaceC0007b = interfaceC0007bX0;
                        i22 = i32;
                        r16 = r15;
                        i24 = 1;
                    }
                    i33 += i24;
                    size2 = i21;
                    interfaceC0007bX0 = interfaceC0007b;
                    i32 = i22;
                    r15 = r16;
                }
                r15 = r18;
                int i35 = size2;
                InterfaceC0007b interfaceC0007b2 = interfaceC0007bX0;
                int i36 = i32;
                if (r15 != 0) {
                    c(dVar, "intermediate pass", iQ, iW);
                    r15 = 0;
                }
                i32 = i36 + 1;
                size2 = i35;
                interfaceC0007bX0 = interfaceC0007b2;
                i31 = 2;
                r18 = r15;
            }
            if (r18 != 0) {
                c(dVar, "2nd pass", iQ, iW);
                if (dVar.Q() < iMax) {
                    dVar.F0(iMax);
                    z11 = true;
                } else {
                    z11 = false;
                }
                if (dVar.w() < iMax2) {
                    dVar.i0(iMax2);
                    z12 = true;
                } else {
                    z12 = z11;
                }
                if (z12) {
                    c(dVar, "3rd pass", iQ, iW);
                }
            }
            i20 = i30;
        } else {
            i20 = iY0;
        }
        dVar.j1(i20);
        return 0L;
    }

    /* JADX WARN: Code duplicated, block: B:12:0x0032  */
    public void e(androidx.constraintlayout.solver.widgets.d dVar) {
        this.f1778a.clear();
        int size = dVar.G0.size();
        for (int i10 = 0; i10 < size; i10++) {
            ConstraintWidget constraintWidget = dVar.G0.get(i10);
            ConstraintWidget.DimensionBehaviour dimensionBehaviourZ = constraintWidget.z();
            ConstraintWidget.DimensionBehaviour dimensionBehaviour = ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT;
            if (dimensionBehaviourZ != dimensionBehaviour) {
                ConstraintWidget.DimensionBehaviour dimensionBehaviourZ2 = constraintWidget.z();
                ConstraintWidget.DimensionBehaviour dimensionBehaviour2 = ConstraintWidget.DimensionBehaviour.MATCH_PARENT;
                if (dimensionBehaviourZ2 == dimensionBehaviour2 || constraintWidget.N() == dimensionBehaviour || constraintWidget.N() == dimensionBehaviour2) {
                    this.f1778a.add(constraintWidget);
                }
            } else {
                this.f1778a.add(constraintWidget);
            }
        }
        dVar.a1();
    }
}
