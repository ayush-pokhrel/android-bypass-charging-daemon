package androidx.constraintlayout.solver.widgets.analyzer;

/* JADX INFO: compiled from: BaselineDimensionDependency.java */
/* JADX INFO: loaded from: classes.dex */
class a extends e {
    public a(WidgetRun widgetRun) {
        super(widgetRun);
    }
}
