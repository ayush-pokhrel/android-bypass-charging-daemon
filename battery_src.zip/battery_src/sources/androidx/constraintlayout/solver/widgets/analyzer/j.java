package androidx.constraintlayout.solver.widgets.analyzer;

import androidx.constraintlayout.solver.widgets.ConstraintAnchor;
import androidx.constraintlayout.solver.widgets.ConstraintWidget;

/* JADX INFO: compiled from: VerticalWidgetRun.java */
/* JADX INFO: loaded from: classes.dex */
public class j extends WidgetRun {

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public DependencyNode f1813k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    e f1814l;

    /* JADX INFO: compiled from: VerticalWidgetRun.java */
    static /* synthetic */ class a {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        static final /* synthetic */ int[] f1815a;

        static {
            int[] iArr = new int[WidgetRun.RunType.values().length];
            f1815a = iArr;
            try {
                iArr[WidgetRun.RunType.START.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                f1815a[WidgetRun.RunType.END.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                f1815a[WidgetRun.RunType.CENTER.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
        }
    }

    public j(ConstraintWidget constraintWidget) {
        super(constraintWidget);
        DependencyNode dependencyNode = new DependencyNode(this);
        this.f1813k = dependencyNode;
        this.f1814l = null;
        this.f1769h.f1745e = DependencyNode.Type.TOP;
        this.f1770i.f1745e = DependencyNode.Type.BOTTOM;
        dependencyNode.f1745e = DependencyNode.Type.BASELINE;
        this.f1767f = 1;
    }

    @Override // androidx.constraintlayout.solver.widgets.analyzer.WidgetRun, v.a
    public void a(v.a aVar) {
        float f10;
        float fU;
        float fU2;
        int i10;
        int i11 = a.f1815a[this.f1771j.ordinal()];
        if (i11 == 1) {
            p(aVar);
        } else if (i11 == 2) {
            o(aVar);
        } else if (i11 == 3) {
            ConstraintWidget constraintWidget = this.f1763b;
            n(aVar, constraintWidget.E, constraintWidget.G, 1);
            return;
        }
        e eVar = this.f1766e;
        if (eVar.f1743c && !eVar.f1750j && this.f1765d == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT) {
            ConstraintWidget constraintWidget2 = this.f1763b;
            int i12 = constraintWidget2.f1706m;
            if (i12 == 2) {
                ConstraintWidget constraintWidgetH = constraintWidget2.H();
                if (constraintWidgetH != null) {
                    e eVar2 = constraintWidgetH.f1692f.f1766e;
                    if (eVar2.f1750j) {
                        this.f1766e.d((int) ((eVar2.f1747g * this.f1763b.f1720t) + 0.5f));
                    }
                }
            } else if (i12 == 3 && constraintWidget2.f1690e.f1766e.f1750j) {
                int iV = constraintWidget2.v();
                if (iV != -1) {
                    if (iV == 0) {
                        ConstraintWidget constraintWidget3 = this.f1763b;
                        fU2 = constraintWidget3.f1690e.f1766e.f1747g * constraintWidget3.u();
                        i10 = (int) (fU2 + 0.5f);
                    } else if (iV != 1) {
                        i10 = 0;
                    } else {
                        ConstraintWidget constraintWidget4 = this.f1763b;
                        f10 = constraintWidget4.f1690e.f1766e.f1747g;
                        fU = constraintWidget4.u();
                    }
                    this.f1766e.d(i10);
                } else {
                    ConstraintWidget constraintWidget5 = this.f1763b;
                    f10 = constraintWidget5.f1690e.f1766e.f1747g;
                    fU = constraintWidget5.u();
                }
                fU2 = f10 / fU;
                i10 = (int) (fU2 + 0.5f);
                this.f1766e.d(i10);
            }
        }
        DependencyNode dependencyNode = this.f1769h;
        if (dependencyNode.f1743c) {
            DependencyNode dependencyNode2 = this.f1770i;
            if (dependencyNode2.f1743c) {
                if (dependencyNode.f1750j && dependencyNode2.f1750j && this.f1766e.f1750j) {
                    return;
                }
                if (!this.f1766e.f1750j && this.f1765d == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT) {
                    ConstraintWidget constraintWidget6 = this.f1763b;
                    if (constraintWidget6.f1704l == 0 && !constraintWidget6.Y()) {
                        DependencyNode dependencyNode3 = this.f1769h.f1752l.get(0);
                        DependencyNode dependencyNode4 = this.f1770i.f1752l.get(0);
                        int i13 = dependencyNode3.f1747g;
                        DependencyNode dependencyNode5 = this.f1769h;
                        int i14 = i13 + dependencyNode5.f1746f;
                        int i15 = dependencyNode4.f1747g + this.f1770i.f1746f;
                        dependencyNode5.d(i14);
                        this.f1770i.d(i15);
                        this.f1766e.d(i15 - i14);
                        return;
                    }
                }
                if (!this.f1766e.f1750j && this.f1765d == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT && this.f1762a == 1 && this.f1769h.f1752l.size() > 0 && this.f1770i.f1752l.size() > 0) {
                    DependencyNode dependencyNode6 = this.f1769h.f1752l.get(0);
                    int i16 = (this.f1770i.f1752l.get(0).f1747g + this.f1770i.f1746f) - (dependencyNode6.f1747g + this.f1769h.f1746f);
                    e eVar3 = this.f1766e;
                    int i17 = eVar3.f1802m;
                    if (i16 < i17) {
                        eVar3.d(i16);
                    } else {
                        eVar3.d(i17);
                    }
                }
                if (this.f1766e.f1750j && this.f1769h.f1752l.size() > 0 && this.f1770i.f1752l.size() > 0) {
                    DependencyNode dependencyNode7 = this.f1769h.f1752l.get(0);
                    DependencyNode dependencyNode8 = this.f1770i.f1752l.get(0);
                    int i18 = dependencyNode7.f1747g + this.f1769h.f1746f;
                    int i19 = dependencyNode8.f1747g + this.f1770i.f1746f;
                    float fL = this.f1763b.L();
                    if (dependencyNode7 == dependencyNode8) {
                        i18 = dependencyNode7.f1747g;
                        i19 = dependencyNode8.f1747g;
                        fL = 0.5f;
                    }
                    this.f1769h.d((int) (i18 + 0.5f + (((i19 - i18) - this.f1766e.f1747g) * fL)));
                    this.f1770i.d(this.f1769h.f1747g + this.f1766e.f1747g);
                }
            }
        }
    }

    @Override // androidx.constraintlayout.solver.widgets.analyzer.WidgetRun
    void d() {
        ConstraintWidget constraintWidgetH;
        ConstraintWidget constraintWidgetH2;
        ConstraintWidget constraintWidget = this.f1763b;
        if (constraintWidget.f1682a) {
            this.f1766e.d(constraintWidget.w());
        }
        if (!this.f1766e.f1750j) {
            this.f1765d = this.f1763b.N();
            if (this.f1763b.T()) {
                this.f1814l = new androidx.constraintlayout.solver.widgets.analyzer.a(this);
            }
            ConstraintWidget.DimensionBehaviour dimensionBehaviour = this.f1765d;
            if (dimensionBehaviour != ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT) {
                if (dimensionBehaviour == ConstraintWidget.DimensionBehaviour.MATCH_PARENT && (constraintWidgetH2 = this.f1763b.H()) != null && constraintWidgetH2.N() == ConstraintWidget.DimensionBehaviour.FIXED) {
                    int iW = (constraintWidgetH2.w() - this.f1763b.E.c()) - this.f1763b.G.c();
                    b(this.f1769h, constraintWidgetH2.f1692f.f1769h, this.f1763b.E.c());
                    b(this.f1770i, constraintWidgetH2.f1692f.f1770i, -this.f1763b.G.c());
                    this.f1766e.d(iW);
                    return;
                }
                if (this.f1765d == ConstraintWidget.DimensionBehaviour.FIXED) {
                    this.f1766e.d(this.f1763b.w());
                }
            }
        } else if (this.f1765d == ConstraintWidget.DimensionBehaviour.MATCH_PARENT && (constraintWidgetH = this.f1763b.H()) != null && constraintWidgetH.N() == ConstraintWidget.DimensionBehaviour.FIXED) {
            b(this.f1769h, constraintWidgetH.f1692f.f1769h, this.f1763b.E.c());
            b(this.f1770i, constraintWidgetH.f1692f.f1770i, -this.f1763b.G.c());
            return;
        }
        e eVar = this.f1766e;
        boolean z10 = eVar.f1750j;
        if (z10) {
            ConstraintWidget constraintWidget2 = this.f1763b;
            if (constraintWidget2.f1682a) {
                ConstraintAnchor[] constraintAnchorArr = constraintWidget2.L;
                ConstraintAnchor constraintAnchor = constraintAnchorArr[2];
                ConstraintAnchor constraintAnchor2 = constraintAnchor.f1667d;
                if (constraintAnchor2 != null && constraintAnchorArr[3].f1667d != null) {
                    if (constraintWidget2.Y()) {
                        this.f1769h.f1746f = this.f1763b.L[2].c();
                        this.f1770i.f1746f = -this.f1763b.L[3].c();
                    } else {
                        DependencyNode dependencyNodeH = h(this.f1763b.L[2]);
                        if (dependencyNodeH != null) {
                            b(this.f1769h, dependencyNodeH, this.f1763b.L[2].c());
                        }
                        DependencyNode dependencyNodeH2 = h(this.f1763b.L[3]);
                        if (dependencyNodeH2 != null) {
                            b(this.f1770i, dependencyNodeH2, -this.f1763b.L[3].c());
                        }
                        this.f1769h.f1742b = true;
                        this.f1770i.f1742b = true;
                    }
                    if (this.f1763b.T()) {
                        b(this.f1813k, this.f1769h, this.f1763b.o());
                        return;
                    }
                    return;
                }
                if (constraintAnchor2 != null) {
                    DependencyNode dependencyNodeH3 = h(constraintAnchor);
                    if (dependencyNodeH3 != null) {
                        b(this.f1769h, dependencyNodeH3, this.f1763b.L[2].c());
                        b(this.f1770i, this.f1769h, this.f1766e.f1747g);
                        if (this.f1763b.T()) {
                            b(this.f1813k, this.f1769h, this.f1763b.o());
                            return;
                        }
                        return;
                    }
                    return;
                }
                ConstraintAnchor constraintAnchor3 = constraintAnchorArr[3];
                if (constraintAnchor3.f1667d != null) {
                    DependencyNode dependencyNodeH4 = h(constraintAnchor3);
                    if (dependencyNodeH4 != null) {
                        b(this.f1770i, dependencyNodeH4, -this.f1763b.L[3].c());
                        b(this.f1769h, this.f1770i, -this.f1766e.f1747g);
                    }
                    if (this.f1763b.T()) {
                        b(this.f1813k, this.f1769h, this.f1763b.o());
                        return;
                    }
                    return;
                }
                ConstraintAnchor constraintAnchor4 = constraintAnchorArr[4];
                if (constraintAnchor4.f1667d != null) {
                    DependencyNode dependencyNodeH5 = h(constraintAnchor4);
                    if (dependencyNodeH5 != null) {
                        b(this.f1813k, dependencyNodeH5, 0);
                        b(this.f1769h, this.f1813k, -this.f1763b.o());
                        b(this.f1770i, this.f1769h, this.f1766e.f1747g);
                        return;
                    }
                    return;
                }
                if ((constraintWidget2 instanceof u.a) || constraintWidget2.H() == null || this.f1763b.n(ConstraintAnchor.Type.CENTER).f1667d != null) {
                    return;
                }
                b(this.f1769h, this.f1763b.H().f1692f.f1769h, this.f1763b.S());
                b(this.f1770i, this.f1769h, this.f1766e.f1747g);
                if (this.f1763b.T()) {
                    b(this.f1813k, this.f1769h, this.f1763b.o());
                    return;
                }
                return;
            }
        }
        if (z10 || this.f1765d != ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT) {
            eVar.b(this);
        } else {
            ConstraintWidget constraintWidget3 = this.f1763b;
            int i10 = constraintWidget3.f1706m;
            if (i10 == 2) {
                ConstraintWidget constraintWidgetH3 = constraintWidget3.H();
                if (constraintWidgetH3 != null) {
                    e eVar2 = constraintWidgetH3.f1692f.f1766e;
                    this.f1766e.f1752l.add(eVar2);
                    eVar2.f1751k.add(this.f1766e);
                    e eVar3 = this.f1766e;
                    eVar3.f1742b = true;
                    eVar3.f1751k.add(this.f1769h);
                    this.f1766e.f1751k.add(this.f1770i);
                }
            } else if (i10 == 3 && !constraintWidget3.Y()) {
                ConstraintWidget constraintWidget4 = this.f1763b;
                if (constraintWidget4.f1704l != 3) {
                    e eVar4 = constraintWidget4.f1690e.f1766e;
                    this.f1766e.f1752l.add(eVar4);
                    eVar4.f1751k.add(this.f1766e);
                    e eVar5 = this.f1766e;
                    eVar5.f1742b = true;
                    eVar5.f1751k.add(this.f1769h);
                    this.f1766e.f1751k.add(this.f1770i);
                }
            }
        }
        ConstraintWidget constraintWidget5 = this.f1763b;
        ConstraintAnchor[] constraintAnchorArr2 = constraintWidget5.L;
        ConstraintAnchor constraintAnchor5 = constraintAnchorArr2[2];
        ConstraintAnchor constraintAnchor6 = constraintAnchor5.f1667d;
        if (constraintAnchor6 != null && constraintAnchorArr2[3].f1667d != null) {
            if (constraintWidget5.Y()) {
                this.f1769h.f1746f = this.f1763b.L[2].c();
                this.f1770i.f1746f = -this.f1763b.L[3].c();
            } else {
                DependencyNode dependencyNodeH6 = h(this.f1763b.L[2]);
                DependencyNode dependencyNodeH7 = h(this.f1763b.L[3]);
                dependencyNodeH6.b(this);
                dependencyNodeH7.b(this);
                this.f1771j = WidgetRun.RunType.CENTER;
            }
            if (this.f1763b.T()) {
                c(this.f1813k, this.f1769h, 1, this.f1814l);
            }
        } else if (constraintAnchor6 != null) {
            DependencyNode dependencyNodeH8 = h(constraintAnchor5);
            if (dependencyNodeH8 != null) {
                b(this.f1769h, dependencyNodeH8, this.f1763b.L[2].c());
                c(this.f1770i, this.f1769h, 1, this.f1766e);
                if (this.f1763b.T()) {
                    c(this.f1813k, this.f1769h, 1, this.f1814l);
                }
                ConstraintWidget.DimensionBehaviour dimensionBehaviour2 = this.f1765d;
                ConstraintWidget.DimensionBehaviour dimensionBehaviour3 = ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT;
                if (dimensionBehaviour2 == dimensionBehaviour3 && this.f1763b.u() > 0.0f) {
                    h hVar = this.f1763b.f1690e;
                    if (hVar.f1765d == dimensionBehaviour3) {
                        hVar.f1766e.f1751k.add(this.f1766e);
                        this.f1766e.f1752l.add(this.f1763b.f1690e.f1766e);
                        this.f1766e.f1741a = this;
                    }
                }
            }
        } else {
            ConstraintAnchor constraintAnchor7 = constraintAnchorArr2[3];
            if (constraintAnchor7.f1667d != null) {
                DependencyNode dependencyNodeH9 = h(constraintAnchor7);
                if (dependencyNodeH9 != null) {
                    b(this.f1770i, dependencyNodeH9, -this.f1763b.L[3].c());
                    c(this.f1769h, this.f1770i, -1, this.f1766e);
                    if (this.f1763b.T()) {
                        c(this.f1813k, this.f1769h, 1, this.f1814l);
                    }
                }
            } else {
                ConstraintAnchor constraintAnchor8 = constraintAnchorArr2[4];
                if (constraintAnchor8.f1667d != null) {
                    DependencyNode dependencyNodeH10 = h(constraintAnchor8);
                    if (dependencyNodeH10 != null) {
                        b(this.f1813k, dependencyNodeH10, 0);
                        c(this.f1769h, this.f1813k, -1, this.f1814l);
                        c(this.f1770i, this.f1769h, 1, this.f1766e);
                    }
                } else if (!(constraintWidget5 instanceof u.a) && constraintWidget5.H() != null) {
                    b(this.f1769h, this.f1763b.H().f1692f.f1769h, this.f1763b.S());
                    c(this.f1770i, this.f1769h, 1, this.f1766e);
                    if (this.f1763b.T()) {
                        c(this.f1813k, this.f1769h, 1, this.f1814l);
                    }
                    ConstraintWidget.DimensionBehaviour dimensionBehaviour4 = this.f1765d;
                    ConstraintWidget.DimensionBehaviour dimensionBehaviour5 = ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT;
                    if (dimensionBehaviour4 == dimensionBehaviour5 && this.f1763b.u() > 0.0f) {
                        h hVar2 = this.f1763b.f1690e;
                        if (hVar2.f1765d == dimensionBehaviour5) {
                            hVar2.f1766e.f1751k.add(this.f1766e);
                            this.f1766e.f1752l.add(this.f1763b.f1690e.f1766e);
                            this.f1766e.f1741a = this;
                        }
                    }
                }
            }
        }
        if (this.f1766e.f1752l.size() == 0) {
            this.f1766e.f1743c = true;
        }
    }

    @Override // androidx.constraintlayout.solver.widgets.analyzer.WidgetRun
    public void e() {
        DependencyNode dependencyNode = this.f1769h;
        if (dependencyNode.f1750j) {
            this.f1763b.H0(dependencyNode.f1747g);
        }
    }

    @Override // androidx.constraintlayout.solver.widgets.analyzer.WidgetRun
    void f() {
        this.f1764c = null;
        this.f1769h.c();
        this.f1770i.c();
        this.f1813k.c();
        this.f1766e.c();
        this.f1768g = false;
    }

    @Override // androidx.constraintlayout.solver.widgets.analyzer.WidgetRun
    boolean m() {
        return this.f1765d != ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT || this.f1763b.f1706m == 0;
    }

    void q() {
        this.f1768g = false;
        this.f1769h.c();
        this.f1769h.f1750j = false;
        this.f1770i.c();
        this.f1770i.f1750j = false;
        this.f1813k.c();
        this.f1813k.f1750j = false;
        this.f1766e.f1750j = false;
    }

    public String toString() {
        return "VerticalRun " + this.f1763b.s();
    }
}
