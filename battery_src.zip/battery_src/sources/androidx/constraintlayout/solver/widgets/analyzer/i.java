package androidx.constraintlayout.solver.widgets.analyzer;

import java.util.ArrayList;

/* JADX INFO: compiled from: RunGroup.java */
/* JADX INFO: loaded from: classes.dex */
class i {

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public static int f1805h;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    WidgetRun f1808c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    WidgetRun f1809d;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    int f1811f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    int f1812g;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f1806a = 0;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public boolean f1807b = false;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    ArrayList<WidgetRun> f1810e = new ArrayList<>();

    public i(WidgetRun widgetRun, int i10) {
        this.f1808c = null;
        this.f1809d = null;
        int i11 = f1805h;
        this.f1811f = i11;
        f1805h = i11 + 1;
        this.f1808c = widgetRun;
        this.f1809d = widgetRun;
        this.f1812g = i10;
    }

    private long c(DependencyNode dependencyNode, long j10) {
        WidgetRun widgetRun = dependencyNode.f1744d;
        if (widgetRun instanceof g) {
            return j10;
        }
        int size = dependencyNode.f1751k.size();
        long jMin = j10;
        for (int i10 = 0; i10 < size; i10++) {
            v.a aVar = dependencyNode.f1751k.get(i10);
            if (aVar instanceof DependencyNode) {
                DependencyNode dependencyNode2 = (DependencyNode) aVar;
                if (dependencyNode2.f1744d != widgetRun) {
                    jMin = Math.min(jMin, c(dependencyNode2, ((long) dependencyNode2.f1746f) + j10));
                }
            }
        }
        if (dependencyNode != widgetRun.f1770i) {
            return jMin;
        }
        long j11 = j10 - widgetRun.j();
        return Math.min(Math.min(jMin, c(widgetRun.f1769h, j11)), j11 - ((long) widgetRun.f1769h.f1746f));
    }

    private long d(DependencyNode dependencyNode, long j10) {
        WidgetRun widgetRun = dependencyNode.f1744d;
        if (widgetRun instanceof g) {
            return j10;
        }
        int size = dependencyNode.f1751k.size();
        long jMax = j10;
        for (int i10 = 0; i10 < size; i10++) {
            v.a aVar = dependencyNode.f1751k.get(i10);
            if (aVar instanceof DependencyNode) {
                DependencyNode dependencyNode2 = (DependencyNode) aVar;
                if (dependencyNode2.f1744d != widgetRun) {
                    jMax = Math.max(jMax, d(dependencyNode2, ((long) dependencyNode2.f1746f) + j10));
                }
            }
        }
        if (dependencyNode != widgetRun.f1769h) {
            return jMax;
        }
        long j11 = j10 + widgetRun.j();
        return Math.max(Math.max(jMax, d(widgetRun.f1770i, j11)), j11 - ((long) widgetRun.f1770i.f1746f));
    }

    public void a(WidgetRun widgetRun) {
        this.f1810e.add(widgetRun);
        this.f1809d = widgetRun;
    }

    public long b(androidx.constraintlayout.solver.widgets.d dVar, int i10) {
        WidgetRun widgetRun = this.f1808c;
        if (widgetRun instanceof c) {
            if (((c) widgetRun).f1767f != i10) {
                return 0L;
            }
        } else if (i10 == 0) {
            if (!(widgetRun instanceof h)) {
                return 0L;
            }
        } else if (!(widgetRun instanceof j)) {
            return 0L;
        }
        DependencyNode dependencyNode = (i10 == 0 ? dVar.f1690e : dVar.f1692f).f1769h;
        DependencyNode dependencyNode2 = (i10 == 0 ? dVar.f1690e : dVar.f1692f).f1770i;
        boolean zContains = widgetRun.f1769h.f1752l.contains(dependencyNode);
        boolean zContains2 = this.f1808c.f1770i.f1752l.contains(dependencyNode2);
        long j10 = this.f1808c.j();
        if (!zContains || !zContains2) {
            if (zContains) {
                DependencyNode dependencyNode3 = this.f1808c.f1769h;
                return Math.max(d(dependencyNode3, dependencyNode3.f1746f), ((long) this.f1808c.f1769h.f1746f) + j10);
            }
            if (!zContains2) {
                WidgetRun widgetRun2 = this.f1808c;
                return (((long) widgetRun2.f1769h.f1746f) + widgetRun2.j()) - ((long) this.f1808c.f1770i.f1746f);
            }
            DependencyNode dependencyNode4 = this.f1808c.f1770i;
            return Math.max(-c(dependencyNode4, dependencyNode4.f1746f), ((long) (-this.f1808c.f1770i.f1746f)) + j10);
        }
        long jD = d(this.f1808c.f1769h, 0L);
        long jC = c(this.f1808c.f1770i, 0L);
        long j11 = jD - j10;
        WidgetRun widgetRun3 = this.f1808c;
        int i11 = widgetRun3.f1770i.f1746f;
        if (j11 >= (-i11)) {
            j11 += (long) i11;
        }
        int i12 = widgetRun3.f1769h.f1746f;
        long j12 = ((-jC) - j10) - ((long) i12);
        if (j12 >= i12) {
            j12 -= (long) i12;
        }
        float fP = widgetRun3.f1763b.p(i10);
        float f10 = fP > 0.0f ? (long) ((j12 / fP) + (j11 / (1.0f - fP))) : 0L;
        long j13 = ((long) ((f10 * fP) + 0.5f)) + j10 + ((long) ((f10 * (1.0f - fP)) + 0.5f));
        WidgetRun widgetRun4 = this.f1808c;
        return (((long) widgetRun4.f1769h.f1746f) + j13) - ((long) widgetRun4.f1770i.f1746f);
    }
}
