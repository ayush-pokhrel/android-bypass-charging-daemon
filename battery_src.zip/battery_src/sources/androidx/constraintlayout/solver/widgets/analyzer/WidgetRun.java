package androidx.constraintlayout.solver.widgets.analyzer;

import androidx.constraintlayout.solver.widgets.ConstraintAnchor;
import androidx.constraintlayout.solver.widgets.ConstraintWidget;

/* JADX INFO: loaded from: classes.dex */
public abstract class WidgetRun implements v.a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public int f1762a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    ConstraintWidget f1763b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    i f1764c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    protected ConstraintWidget.DimensionBehaviour f1765d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    e f1766e = new e(this);

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public int f1767f = 0;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    boolean f1768g = false;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public DependencyNode f1769h = new DependencyNode(this);

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    public DependencyNode f1770i = new DependencyNode(this);

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    protected RunType f1771j = RunType.NONE;

    enum RunType {
        NONE,
        START,
        END,
        CENTER
    }

    static /* synthetic */ class a {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        static final /* synthetic */ int[] f1777a;

        static {
            int[] iArr = new int[ConstraintAnchor.Type.values().length];
            f1777a = iArr;
            try {
                iArr[ConstraintAnchor.Type.LEFT.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                f1777a[ConstraintAnchor.Type.RIGHT.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                f1777a[ConstraintAnchor.Type.TOP.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                f1777a[ConstraintAnchor.Type.BASELINE.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                f1777a[ConstraintAnchor.Type.BOTTOM.ordinal()] = 5;
            } catch (NoSuchFieldError unused5) {
            }
        }
    }

    public WidgetRun(ConstraintWidget constraintWidget) {
        this.f1763b = constraintWidget;
    }

    private void l(int i10, int i11) {
        int i12 = this.f1762a;
        if (i12 == 0) {
            this.f1766e.d(g(i11, i10));
            return;
        }
        if (i12 == 1) {
            this.f1766e.d(Math.min(g(this.f1766e.f1802m, i10), i11));
            return;
        }
        if (i12 == 2) {
            ConstraintWidget constraintWidgetH = this.f1763b.H();
            if (constraintWidgetH != null) {
                e eVar = (i10 == 0 ? constraintWidgetH.f1690e : constraintWidgetH.f1692f).f1766e;
                if (eVar.f1750j) {
                    ConstraintWidget constraintWidget = this.f1763b;
                    this.f1766e.d(g((int) ((eVar.f1747g * (i10 == 0 ? constraintWidget.f1714q : constraintWidget.f1720t)) + 0.5f), i10));
                    return;
                }
                return;
            }
            return;
        }
        if (i12 != 3) {
            return;
        }
        ConstraintWidget constraintWidget2 = this.f1763b;
        WidgetRun widgetRun = constraintWidget2.f1690e;
        ConstraintWidget.DimensionBehaviour dimensionBehaviour = widgetRun.f1765d;
        ConstraintWidget.DimensionBehaviour dimensionBehaviour2 = ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT;
        if (dimensionBehaviour == dimensionBehaviour2 && widgetRun.f1762a == 3) {
            j jVar = constraintWidget2.f1692f;
            if (jVar.f1765d == dimensionBehaviour2 && jVar.f1762a == 3) {
                return;
            }
        }
        if (i10 == 0) {
            widgetRun = constraintWidget2.f1692f;
        }
        if (widgetRun.f1766e.f1750j) {
            float fU = constraintWidget2.u();
            this.f1766e.d(i10 == 1 ? (int) ((widgetRun.f1766e.f1747g / fU) + 0.5f) : (int) ((fU * widgetRun.f1766e.f1747g) + 0.5f));
        }
    }

    protected final void b(DependencyNode dependencyNode, DependencyNode dependencyNode2, int i10) {
        dependencyNode.f1752l.add(dependencyNode2);
        dependencyNode.f1746f = i10;
        dependencyNode2.f1751k.add(dependencyNode);
    }

    protected final void c(DependencyNode dependencyNode, DependencyNode dependencyNode2, int i10, e eVar) {
        dependencyNode.f1752l.add(dependencyNode2);
        dependencyNode.f1752l.add(this.f1766e);
        dependencyNode.f1748h = i10;
        dependencyNode.f1749i = eVar;
        dependencyNode2.f1751k.add(dependencyNode);
        eVar.f1751k.add(dependencyNode);
    }

    abstract void d();

    abstract void e();

    abstract void f();

    protected final int g(int i10, int i11) {
        int iMax;
        if (i11 == 0) {
            ConstraintWidget constraintWidget = this.f1763b;
            int i12 = constraintWidget.f1712p;
            iMax = Math.max(constraintWidget.f1710o, i10);
            if (i12 > 0) {
                iMax = Math.min(i12, i10);
            }
            if (iMax == i10) {
                return i10;
            }
        } else {
            ConstraintWidget constraintWidget2 = this.f1763b;
            int i13 = constraintWidget2.f1718s;
            iMax = Math.max(constraintWidget2.f1716r, i10);
            if (i13 > 0) {
                iMax = Math.min(i13, i10);
            }
            if (iMax == i10) {
                return i10;
            }
        }
        return iMax;
    }

    protected final DependencyNode h(ConstraintAnchor constraintAnchor) {
        ConstraintAnchor constraintAnchor2 = constraintAnchor.f1667d;
        if (constraintAnchor2 == null) {
            return null;
        }
        ConstraintWidget constraintWidget = constraintAnchor2.f1665b;
        int i10 = a.f1777a[constraintAnchor2.f1666c.ordinal()];
        if (i10 == 1) {
            return constraintWidget.f1690e.f1769h;
        }
        if (i10 == 2) {
            return constraintWidget.f1690e.f1770i;
        }
        if (i10 == 3) {
            return constraintWidget.f1692f.f1769h;
        }
        if (i10 == 4) {
            return constraintWidget.f1692f.f1813k;
        }
        if (i10 != 5) {
            return null;
        }
        return constraintWidget.f1692f.f1770i;
    }

    protected final DependencyNode i(ConstraintAnchor constraintAnchor, int i10) {
        ConstraintAnchor constraintAnchor2 = constraintAnchor.f1667d;
        if (constraintAnchor2 == null) {
            return null;
        }
        ConstraintWidget constraintWidget = constraintAnchor2.f1665b;
        WidgetRun widgetRun = i10 == 0 ? constraintWidget.f1690e : constraintWidget.f1692f;
        int i11 = a.f1777a[constraintAnchor2.f1666c.ordinal()];
        if (i11 != 1) {
            if (i11 != 2) {
                if (i11 != 3) {
                    if (i11 != 5) {
                        return null;
                    }
                }
            }
            return widgetRun.f1770i;
        }
        return widgetRun.f1769h;
    }

    public long j() {
        e eVar = this.f1766e;
        if (eVar.f1750j) {
            return eVar.f1747g;
        }
        return 0L;
    }

    public boolean k() {
        return this.f1768g;
    }

    abstract boolean m();

    protected void n(v.a aVar, ConstraintAnchor constraintAnchor, ConstraintAnchor constraintAnchor2, int i10) {
        DependencyNode dependencyNodeH = h(constraintAnchor);
        DependencyNode dependencyNodeH2 = h(constraintAnchor2);
        if (dependencyNodeH.f1750j && dependencyNodeH2.f1750j) {
            int iC = dependencyNodeH.f1747g + constraintAnchor.c();
            int iC2 = dependencyNodeH2.f1747g - constraintAnchor2.c();
            int i11 = iC2 - iC;
            if (!this.f1766e.f1750j && this.f1765d == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT) {
                l(i10, i11);
            }
            e eVar = this.f1766e;
            if (eVar.f1750j) {
                if (eVar.f1747g == i11) {
                    this.f1769h.d(iC);
                    this.f1770i.d(iC2);
                    return;
                }
                ConstraintWidget constraintWidget = this.f1763b;
                float fX = i10 == 0 ? constraintWidget.x() : constraintWidget.L();
                if (dependencyNodeH == dependencyNodeH2) {
                    iC = dependencyNodeH.f1747g;
                    iC2 = dependencyNodeH2.f1747g;
                    fX = 0.5f;
                }
                this.f1769h.d((int) (iC + 0.5f + (((iC2 - iC) - this.f1766e.f1747g) * fX)));
                this.f1770i.d(this.f1769h.f1747g + this.f1766e.f1747g);
            }
        }
    }

    @Override // v.a
    public void a(v.a aVar) {
    }

    protected void o(v.a aVar) {
    }

    protected void p(v.a aVar) {
    }
}
