package androidx.constraintlayout.solver.widgets.analyzer;

import androidx.constraintlayout.solver.widgets.ConstraintAnchor;
import androidx.constraintlayout.solver.widgets.ConstraintWidget;

/* JADX INFO: compiled from: HorizontalWidgetRun.java */
/* JADX INFO: loaded from: classes.dex */
public class h extends WidgetRun {

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    private static int[] f1803k = new int[2];

    /* JADX INFO: compiled from: HorizontalWidgetRun.java */
    static /* synthetic */ class a {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        static final /* synthetic */ int[] f1804a;

        static {
            int[] iArr = new int[WidgetRun.RunType.values().length];
            f1804a = iArr;
            try {
                iArr[WidgetRun.RunType.START.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                f1804a[WidgetRun.RunType.END.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                f1804a[WidgetRun.RunType.CENTER.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
        }
    }

    public h(ConstraintWidget constraintWidget) {
        super(constraintWidget);
        this.f1769h.f1745e = DependencyNode.Type.LEFT;
        this.f1770i.f1745e = DependencyNode.Type.RIGHT;
        this.f1767f = 0;
    }

    private void q(int[] iArr, int i10, int i11, int i12, int i13, float f10, int i14) {
        int i15 = i11 - i10;
        int i16 = i13 - i12;
        if (i14 != -1) {
            if (i14 == 0) {
                iArr[0] = (int) ((i16 * f10) + 0.5f);
                iArr[1] = i16;
                return;
            } else {
                if (i14 != 1) {
                    return;
                }
                iArr[0] = i15;
                iArr[1] = (int) ((i15 * f10) + 0.5f);
                return;
            }
        }
        int i17 = (int) ((i16 * f10) + 0.5f);
        int i18 = (int) ((i15 / f10) + 0.5f);
        if (i17 <= i15) {
            iArr[0] = i17;
            iArr[1] = i16;
        } else if (i18 <= i16) {
            iArr[0] = i15;
            iArr[1] = i18;
        }
    }

    /* JADX WARN: Code duplicated, block: B:125:0x02df  */
    /* JADX WARN: Code duplicated, block: B:127:0x02ee  */
    @Override // androidx.constraintlayout.solver.widgets.analyzer.WidgetRun, v.a
    public void a(v.a aVar) {
        int iG;
        int i10;
        int iG2;
        float f10;
        float fU;
        float fU2;
        int i11;
        int i12 = a.f1804a[this.f1771j.ordinal()];
        if (i12 == 1) {
            p(aVar);
        } else if (i12 == 2) {
            o(aVar);
        } else if (i12 == 3) {
            ConstraintWidget constraintWidget = this.f1763b;
            n(aVar, constraintWidget.D, constraintWidget.F, 0);
            return;
        }
        if (!this.f1766e.f1750j && this.f1765d == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT) {
            ConstraintWidget constraintWidget2 = this.f1763b;
            int i13 = constraintWidget2.f1704l;
            if (i13 == 2) {
                ConstraintWidget constraintWidgetH = constraintWidget2.H();
                if (constraintWidgetH != null) {
                    e eVar = constraintWidgetH.f1690e.f1766e;
                    if (eVar.f1750j) {
                        this.f1766e.d((int) ((eVar.f1747g * this.f1763b.f1714q) + 0.5f));
                    }
                }
            } else if (i13 == 3) {
                int i14 = constraintWidget2.f1706m;
                if (i14 == 0 || i14 == 3) {
                    j jVar = constraintWidget2.f1692f;
                    DependencyNode dependencyNode = jVar.f1769h;
                    DependencyNode dependencyNode2 = jVar.f1770i;
                    boolean z10 = constraintWidget2.D.f1667d != null;
                    boolean z11 = constraintWidget2.E.f1667d != null;
                    boolean z12 = constraintWidget2.F.f1667d != null;
                    boolean z13 = constraintWidget2.G.f1667d != null;
                    int iV = constraintWidget2.v();
                    if (z10 && z11 && z12 && z13) {
                        float fU3 = this.f1763b.u();
                        if (dependencyNode.f1750j && dependencyNode2.f1750j) {
                            DependencyNode dependencyNode3 = this.f1769h;
                            if (dependencyNode3.f1743c && this.f1770i.f1743c) {
                                q(f1803k, dependencyNode3.f1752l.get(0).f1747g + this.f1769h.f1746f, this.f1770i.f1752l.get(0).f1747g - this.f1770i.f1746f, dependencyNode.f1747g + dependencyNode.f1746f, dependencyNode2.f1747g - dependencyNode2.f1746f, fU3, iV);
                                this.f1766e.d(f1803k[0]);
                                this.f1763b.f1692f.f1766e.d(f1803k[1]);
                                return;
                            }
                            return;
                        }
                        DependencyNode dependencyNode4 = this.f1769h;
                        if (dependencyNode4.f1750j) {
                            DependencyNode dependencyNode5 = this.f1770i;
                            if (dependencyNode5.f1750j) {
                                if (!dependencyNode.f1743c || !dependencyNode2.f1743c) {
                                    return;
                                }
                                q(f1803k, dependencyNode4.f1747g + dependencyNode4.f1746f, dependencyNode5.f1747g - dependencyNode5.f1746f, dependencyNode.f1752l.get(0).f1747g + dependencyNode.f1746f, dependencyNode2.f1752l.get(0).f1747g - dependencyNode2.f1746f, fU3, iV);
                                this.f1766e.d(f1803k[0]);
                                this.f1763b.f1692f.f1766e.d(f1803k[1]);
                            }
                        }
                        DependencyNode dependencyNode6 = this.f1769h;
                        if (!dependencyNode6.f1743c || !this.f1770i.f1743c || !dependencyNode.f1743c || !dependencyNode2.f1743c) {
                            return;
                        }
                        q(f1803k, dependencyNode6.f1752l.get(0).f1747g + this.f1769h.f1746f, this.f1770i.f1752l.get(0).f1747g - this.f1770i.f1746f, dependencyNode.f1752l.get(0).f1747g + dependencyNode.f1746f, dependencyNode2.f1752l.get(0).f1747g - dependencyNode2.f1746f, fU3, iV);
                        this.f1766e.d(f1803k[0]);
                        this.f1763b.f1692f.f1766e.d(f1803k[1]);
                    } else if (z10 && z12) {
                        if (!this.f1769h.f1743c || !this.f1770i.f1743c) {
                            return;
                        }
                        float fU4 = this.f1763b.u();
                        int i15 = this.f1769h.f1752l.get(0).f1747g + this.f1769h.f1746f;
                        int i16 = this.f1770i.f1752l.get(0).f1747g - this.f1770i.f1746f;
                        if (iV == -1 || iV == 0) {
                            int iG3 = g(i16 - i15, 0);
                            int i17 = (int) ((iG3 * fU4) + 0.5f);
                            int iG4 = g(i17, 1);
                            if (i17 != iG4) {
                                iG3 = (int) ((iG4 / fU4) + 0.5f);
                            }
                            this.f1766e.d(iG3);
                            this.f1763b.f1692f.f1766e.d(iG4);
                        } else if (iV == 1) {
                            int iG5 = g(i16 - i15, 0);
                            int i18 = (int) ((iG5 / fU4) + 0.5f);
                            int iG6 = g(i18, 1);
                            if (i18 != iG6) {
                                iG5 = (int) ((iG6 * fU4) + 0.5f);
                            }
                            this.f1766e.d(iG5);
                            this.f1763b.f1692f.f1766e.d(iG6);
                        }
                    } else if (z11 && z13) {
                        if (!dependencyNode.f1743c || !dependencyNode2.f1743c) {
                            return;
                        }
                        float fU5 = this.f1763b.u();
                        int i19 = dependencyNode.f1752l.get(0).f1747g + dependencyNode.f1746f;
                        int i20 = dependencyNode2.f1752l.get(0).f1747g - dependencyNode2.f1746f;
                        if (iV == -1) {
                            iG = g(i20 - i19, 1);
                            i10 = (int) ((iG / fU5) + 0.5f);
                            iG2 = g(i10, 0);
                            if (i10 != iG2) {
                                iG = (int) ((iG2 * fU5) + 0.5f);
                            }
                            this.f1766e.d(iG2);
                            this.f1763b.f1692f.f1766e.d(iG);
                        } else if (iV == 0) {
                            int iG7 = g(i20 - i19, 1);
                            int i21 = (int) ((iG7 * fU5) + 0.5f);
                            int iG8 = g(i21, 0);
                            if (i21 != iG8) {
                                iG7 = (int) ((iG8 / fU5) + 0.5f);
                            }
                            this.f1766e.d(iG8);
                            this.f1763b.f1692f.f1766e.d(iG7);
                        } else if (iV == 1) {
                            iG = g(i20 - i19, 1);
                            i10 = (int) ((iG / fU5) + 0.5f);
                            iG2 = g(i10, 0);
                            if (i10 != iG2) {
                                iG = (int) ((iG2 * fU5) + 0.5f);
                            }
                            this.f1766e.d(iG2);
                            this.f1763b.f1692f.f1766e.d(iG);
                        }
                    }
                } else {
                    int iV2 = constraintWidget2.v();
                    if (iV2 != -1) {
                        if (iV2 == 0) {
                            ConstraintWidget constraintWidget3 = this.f1763b;
                            fU2 = constraintWidget3.f1692f.f1766e.f1747g / constraintWidget3.u();
                            i11 = (int) (fU2 + 0.5f);
                        } else if (iV2 != 1) {
                            i11 = 0;
                        } else {
                            ConstraintWidget constraintWidget4 = this.f1763b;
                            f10 = constraintWidget4.f1692f.f1766e.f1747g;
                            fU = constraintWidget4.u();
                        }
                        this.f1766e.d(i11);
                    } else {
                        ConstraintWidget constraintWidget5 = this.f1763b;
                        f10 = constraintWidget5.f1692f.f1766e.f1747g;
                        fU = constraintWidget5.u();
                    }
                    fU2 = f10 * fU;
                    i11 = (int) (fU2 + 0.5f);
                    this.f1766e.d(i11);
                }
            }
        }
        DependencyNode dependencyNode7 = this.f1769h;
        if (dependencyNode7.f1743c) {
            DependencyNode dependencyNode8 = this.f1770i;
            if (dependencyNode8.f1743c) {
                if (dependencyNode7.f1750j && dependencyNode8.f1750j && this.f1766e.f1750j) {
                    return;
                }
                if (!this.f1766e.f1750j && this.f1765d == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT) {
                    ConstraintWidget constraintWidget6 = this.f1763b;
                    if (constraintWidget6.f1704l == 0 && !constraintWidget6.W()) {
                        DependencyNode dependencyNode9 = this.f1769h.f1752l.get(0);
                        DependencyNode dependencyNode10 = this.f1770i.f1752l.get(0);
                        int i22 = dependencyNode9.f1747g;
                        DependencyNode dependencyNode11 = this.f1769h;
                        int i23 = i22 + dependencyNode11.f1746f;
                        int i24 = dependencyNode10.f1747g + this.f1770i.f1746f;
                        dependencyNode11.d(i23);
                        this.f1770i.d(i24);
                        this.f1766e.d(i24 - i23);
                        return;
                    }
                }
                if (!this.f1766e.f1750j && this.f1765d == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT && this.f1762a == 1 && this.f1769h.f1752l.size() > 0 && this.f1770i.f1752l.size() > 0) {
                    int iMin = Math.min((this.f1770i.f1752l.get(0).f1747g + this.f1770i.f1746f) - (this.f1769h.f1752l.get(0).f1747g + this.f1769h.f1746f), this.f1766e.f1802m);
                    ConstraintWidget constraintWidget7 = this.f1763b;
                    int i25 = constraintWidget7.f1712p;
                    int iMax = Math.max(constraintWidget7.f1710o, iMin);
                    if (i25 > 0) {
                        iMax = Math.min(i25, iMax);
                    }
                    this.f1766e.d(iMax);
                }
                if (this.f1766e.f1750j) {
                    DependencyNode dependencyNode12 = this.f1769h.f1752l.get(0);
                    DependencyNode dependencyNode13 = this.f1770i.f1752l.get(0);
                    int i26 = dependencyNode12.f1747g + this.f1769h.f1746f;
                    int i27 = dependencyNode13.f1747g + this.f1770i.f1746f;
                    float fX = this.f1763b.x();
                    if (dependencyNode12 == dependencyNode13) {
                        i26 = dependencyNode12.f1747g;
                        i27 = dependencyNode13.f1747g;
                        fX = 0.5f;
                    }
                    this.f1769h.d((int) (i26 + 0.5f + (((i27 - i26) - this.f1766e.f1747g) * fX)));
                    this.f1770i.d(this.f1769h.f1747g + this.f1766e.f1747g);
                }
            }
        }
    }

    @Override // androidx.constraintlayout.solver.widgets.analyzer.WidgetRun
    void d() {
        ConstraintWidget constraintWidgetH;
        ConstraintWidget constraintWidgetH2;
        ConstraintWidget constraintWidget = this.f1763b;
        if (constraintWidget.f1682a) {
            this.f1766e.d(constraintWidget.Q());
        }
        if (this.f1766e.f1750j) {
            ConstraintWidget.DimensionBehaviour dimensionBehaviour = this.f1765d;
            ConstraintWidget.DimensionBehaviour dimensionBehaviour2 = ConstraintWidget.DimensionBehaviour.MATCH_PARENT;
            if (dimensionBehaviour == dimensionBehaviour2 && (((constraintWidgetH = this.f1763b.H()) != null && constraintWidgetH.z() == ConstraintWidget.DimensionBehaviour.FIXED) || constraintWidgetH.z() == dimensionBehaviour2)) {
                b(this.f1769h, constraintWidgetH.f1690e.f1769h, this.f1763b.D.c());
                b(this.f1770i, constraintWidgetH.f1690e.f1770i, -this.f1763b.F.c());
                return;
            }
        } else {
            ConstraintWidget.DimensionBehaviour dimensionBehaviourZ = this.f1763b.z();
            this.f1765d = dimensionBehaviourZ;
            if (dimensionBehaviourZ != ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT) {
                ConstraintWidget.DimensionBehaviour dimensionBehaviour3 = ConstraintWidget.DimensionBehaviour.MATCH_PARENT;
                if (dimensionBehaviourZ == dimensionBehaviour3 && (((constraintWidgetH2 = this.f1763b.H()) != null && constraintWidgetH2.z() == ConstraintWidget.DimensionBehaviour.FIXED) || constraintWidgetH2.z() == dimensionBehaviour3)) {
                    int iQ = (constraintWidgetH2.Q() - this.f1763b.D.c()) - this.f1763b.F.c();
                    b(this.f1769h, constraintWidgetH2.f1690e.f1769h, this.f1763b.D.c());
                    b(this.f1770i, constraintWidgetH2.f1690e.f1770i, -this.f1763b.F.c());
                    this.f1766e.d(iQ);
                    return;
                }
                if (this.f1765d == ConstraintWidget.DimensionBehaviour.FIXED) {
                    this.f1766e.d(this.f1763b.Q());
                }
            }
        }
        e eVar = this.f1766e;
        if (eVar.f1750j) {
            ConstraintWidget constraintWidget2 = this.f1763b;
            if (constraintWidget2.f1682a) {
                ConstraintAnchor[] constraintAnchorArr = constraintWidget2.L;
                ConstraintAnchor constraintAnchor = constraintAnchorArr[0];
                ConstraintAnchor constraintAnchor2 = constraintAnchor.f1667d;
                if (constraintAnchor2 != null && constraintAnchorArr[1].f1667d != null) {
                    if (constraintWidget2.W()) {
                        this.f1769h.f1746f = this.f1763b.L[0].c();
                        this.f1770i.f1746f = -this.f1763b.L[1].c();
                        return;
                    }
                    DependencyNode dependencyNodeH = h(this.f1763b.L[0]);
                    if (dependencyNodeH != null) {
                        b(this.f1769h, dependencyNodeH, this.f1763b.L[0].c());
                    }
                    DependencyNode dependencyNodeH2 = h(this.f1763b.L[1]);
                    if (dependencyNodeH2 != null) {
                        b(this.f1770i, dependencyNodeH2, -this.f1763b.L[1].c());
                    }
                    this.f1769h.f1742b = true;
                    this.f1770i.f1742b = true;
                    return;
                }
                if (constraintAnchor2 != null) {
                    DependencyNode dependencyNodeH3 = h(constraintAnchor);
                    if (dependencyNodeH3 != null) {
                        b(this.f1769h, dependencyNodeH3, this.f1763b.L[0].c());
                        b(this.f1770i, this.f1769h, this.f1766e.f1747g);
                        return;
                    }
                    return;
                }
                ConstraintAnchor constraintAnchor3 = constraintAnchorArr[1];
                if (constraintAnchor3.f1667d != null) {
                    DependencyNode dependencyNodeH4 = h(constraintAnchor3);
                    if (dependencyNodeH4 != null) {
                        b(this.f1770i, dependencyNodeH4, -this.f1763b.L[1].c());
                        b(this.f1769h, this.f1770i, -this.f1766e.f1747g);
                        return;
                    }
                    return;
                }
                if ((constraintWidget2 instanceof u.a) || constraintWidget2.H() == null || this.f1763b.n(ConstraintAnchor.Type.CENTER).f1667d != null) {
                    return;
                }
                b(this.f1769h, this.f1763b.H().f1690e.f1769h, this.f1763b.R());
                b(this.f1770i, this.f1769h, this.f1766e.f1747g);
                return;
            }
        }
        if (this.f1765d == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT) {
            ConstraintWidget constraintWidget3 = this.f1763b;
            int i10 = constraintWidget3.f1704l;
            if (i10 == 2) {
                ConstraintWidget constraintWidgetH3 = constraintWidget3.H();
                if (constraintWidgetH3 != null) {
                    e eVar2 = constraintWidgetH3.f1692f.f1766e;
                    this.f1766e.f1752l.add(eVar2);
                    eVar2.f1751k.add(this.f1766e);
                    e eVar3 = this.f1766e;
                    eVar3.f1742b = true;
                    eVar3.f1751k.add(this.f1769h);
                    this.f1766e.f1751k.add(this.f1770i);
                }
            } else if (i10 == 3) {
                if (constraintWidget3.f1706m == 3) {
                    this.f1769h.f1741a = this;
                    this.f1770i.f1741a = this;
                    j jVar = constraintWidget3.f1692f;
                    jVar.f1769h.f1741a = this;
                    jVar.f1770i.f1741a = this;
                    eVar.f1741a = this;
                    if (constraintWidget3.Y()) {
                        this.f1766e.f1752l.add(this.f1763b.f1692f.f1766e);
                        this.f1763b.f1692f.f1766e.f1751k.add(this.f1766e);
                        j jVar2 = this.f1763b.f1692f;
                        jVar2.f1766e.f1741a = this;
                        this.f1766e.f1752l.add(jVar2.f1769h);
                        this.f1766e.f1752l.add(this.f1763b.f1692f.f1770i);
                        this.f1763b.f1692f.f1769h.f1751k.add(this.f1766e);
                        this.f1763b.f1692f.f1770i.f1751k.add(this.f1766e);
                    } else if (this.f1763b.W()) {
                        this.f1763b.f1692f.f1766e.f1752l.add(this.f1766e);
                        this.f1766e.f1751k.add(this.f1763b.f1692f.f1766e);
                    } else {
                        this.f1763b.f1692f.f1766e.f1752l.add(this.f1766e);
                    }
                } else {
                    e eVar4 = constraintWidget3.f1692f.f1766e;
                    eVar.f1752l.add(eVar4);
                    eVar4.f1751k.add(this.f1766e);
                    this.f1763b.f1692f.f1769h.f1751k.add(this.f1766e);
                    this.f1763b.f1692f.f1770i.f1751k.add(this.f1766e);
                    e eVar5 = this.f1766e;
                    eVar5.f1742b = true;
                    eVar5.f1751k.add(this.f1769h);
                    this.f1766e.f1751k.add(this.f1770i);
                    this.f1769h.f1752l.add(this.f1766e);
                    this.f1770i.f1752l.add(this.f1766e);
                }
            }
        }
        ConstraintWidget constraintWidget4 = this.f1763b;
        ConstraintAnchor[] constraintAnchorArr2 = constraintWidget4.L;
        ConstraintAnchor constraintAnchor4 = constraintAnchorArr2[0];
        ConstraintAnchor constraintAnchor5 = constraintAnchor4.f1667d;
        if (constraintAnchor5 != null && constraintAnchorArr2[1].f1667d != null) {
            if (constraintWidget4.W()) {
                this.f1769h.f1746f = this.f1763b.L[0].c();
                this.f1770i.f1746f = -this.f1763b.L[1].c();
                return;
            }
            DependencyNode dependencyNodeH5 = h(this.f1763b.L[0]);
            DependencyNode dependencyNodeH6 = h(this.f1763b.L[1]);
            dependencyNodeH5.b(this);
            dependencyNodeH6.b(this);
            this.f1771j = WidgetRun.RunType.CENTER;
            return;
        }
        if (constraintAnchor5 != null) {
            DependencyNode dependencyNodeH7 = h(constraintAnchor4);
            if (dependencyNodeH7 != null) {
                b(this.f1769h, dependencyNodeH7, this.f1763b.L[0].c());
                c(this.f1770i, this.f1769h, 1, this.f1766e);
                return;
            }
            return;
        }
        ConstraintAnchor constraintAnchor6 = constraintAnchorArr2[1];
        if (constraintAnchor6.f1667d != null) {
            DependencyNode dependencyNodeH8 = h(constraintAnchor6);
            if (dependencyNodeH8 != null) {
                b(this.f1770i, dependencyNodeH8, -this.f1763b.L[1].c());
                c(this.f1769h, this.f1770i, -1, this.f1766e);
                return;
            }
            return;
        }
        if ((constraintWidget4 instanceof u.a) || constraintWidget4.H() == null) {
            return;
        }
        b(this.f1769h, this.f1763b.H().f1690e.f1769h, this.f1763b.R());
        c(this.f1770i, this.f1769h, 1, this.f1766e);
    }

    @Override // androidx.constraintlayout.solver.widgets.analyzer.WidgetRun
    public void e() {
        DependencyNode dependencyNode = this.f1769h;
        if (dependencyNode.f1750j) {
            this.f1763b.G0(dependencyNode.f1747g);
        }
    }

    @Override // androidx.constraintlayout.solver.widgets.analyzer.WidgetRun
    void f() {
        this.f1764c = null;
        this.f1769h.c();
        this.f1770i.c();
        this.f1766e.c();
        this.f1768g = false;
    }

    @Override // androidx.constraintlayout.solver.widgets.analyzer.WidgetRun
    boolean m() {
        return this.f1765d != ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT || this.f1763b.f1704l == 0;
    }

    void r() {
        this.f1768g = false;
        this.f1769h.c();
        this.f1769h.f1750j = false;
        this.f1770i.c();
        this.f1770i.f1750j = false;
        this.f1766e.f1750j = false;
    }

    public String toString() {
        return "HorizontalRun " + this.f1763b.s();
    }
}
