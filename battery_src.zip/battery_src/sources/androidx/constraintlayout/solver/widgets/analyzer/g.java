package androidx.constraintlayout.solver.widgets.analyzer;

import androidx.constraintlayout.solver.widgets.ConstraintWidget;
import java.util.Iterator;

/* JADX INFO: compiled from: HelperReferences.java */
/* JADX INFO: loaded from: classes.dex */
class g extends WidgetRun {
    public g(ConstraintWidget constraintWidget) {
        super(constraintWidget);
    }

    private void q(DependencyNode dependencyNode) {
        this.f1769h.f1751k.add(dependencyNode);
        dependencyNode.f1752l.add(this.f1769h);
    }

    @Override // androidx.constraintlayout.solver.widgets.analyzer.WidgetRun, v.a
    public void a(v.a aVar) {
        androidx.constraintlayout.solver.widgets.a aVar2 = (androidx.constraintlayout.solver.widgets.a) this.f1763b;
        int iM0 = aVar2.M0();
        Iterator<DependencyNode> it = this.f1769h.f1752l.iterator();
        int i10 = 0;
        int i11 = -1;
        while (it.hasNext()) {
            int i12 = it.next().f1747g;
            if (i11 == -1 || i12 < i11) {
                i11 = i12;
            }
            if (i10 < i12) {
                i10 = i12;
            }
        }
        if (iM0 == 0 || iM0 == 2) {
            this.f1769h.d(i11 + aVar2.N0());
        } else {
            this.f1769h.d(i10 + aVar2.N0());
        }
    }

    @Override // androidx.constraintlayout.solver.widgets.analyzer.WidgetRun
    void d() {
        ConstraintWidget constraintWidget = this.f1763b;
        if (constraintWidget instanceof androidx.constraintlayout.solver.widgets.a) {
            this.f1769h.f1742b = true;
            androidx.constraintlayout.solver.widgets.a aVar = (androidx.constraintlayout.solver.widgets.a) constraintWidget;
            int iM0 = aVar.M0();
            boolean zL0 = aVar.L0();
            int i10 = 0;
            if (iM0 == 0) {
                this.f1769h.f1745e = DependencyNode.Type.LEFT;
                while (i10 < aVar.H0) {
                    ConstraintWidget constraintWidget2 = aVar.G0[i10];
                    if (zL0 || constraintWidget2.P() != 8) {
                        DependencyNode dependencyNode = constraintWidget2.f1690e.f1769h;
                        dependencyNode.f1751k.add(this.f1769h);
                        this.f1769h.f1752l.add(dependencyNode);
                    }
                    i10++;
                }
                q(this.f1763b.f1690e.f1769h);
                q(this.f1763b.f1690e.f1770i);
                return;
            }
            if (iM0 == 1) {
                this.f1769h.f1745e = DependencyNode.Type.RIGHT;
                while (i10 < aVar.H0) {
                    ConstraintWidget constraintWidget3 = aVar.G0[i10];
                    if (zL0 || constraintWidget3.P() != 8) {
                        DependencyNode dependencyNode2 = constraintWidget3.f1690e.f1770i;
                        dependencyNode2.f1751k.add(this.f1769h);
                        this.f1769h.f1752l.add(dependencyNode2);
                    }
                    i10++;
                }
                q(this.f1763b.f1690e.f1769h);
                q(this.f1763b.f1690e.f1770i);
                return;
            }
            if (iM0 == 2) {
                this.f1769h.f1745e = DependencyNode.Type.TOP;
                while (i10 < aVar.H0) {
                    ConstraintWidget constraintWidget4 = aVar.G0[i10];
                    if (zL0 || constraintWidget4.P() != 8) {
                        DependencyNode dependencyNode3 = constraintWidget4.f1692f.f1769h;
                        dependencyNode3.f1751k.add(this.f1769h);
                        this.f1769h.f1752l.add(dependencyNode3);
                    }
                    i10++;
                }
                q(this.f1763b.f1692f.f1769h);
                q(this.f1763b.f1692f.f1770i);
                return;
            }
            if (iM0 != 3) {
                return;
            }
            this.f1769h.f1745e = DependencyNode.Type.BOTTOM;
            while (i10 < aVar.H0) {
                ConstraintWidget constraintWidget5 = aVar.G0[i10];
                if (zL0 || constraintWidget5.P() != 8) {
                    DependencyNode dependencyNode4 = constraintWidget5.f1692f.f1770i;
                    dependencyNode4.f1751k.add(this.f1769h);
                    this.f1769h.f1752l.add(dependencyNode4);
                }
                i10++;
            }
            q(this.f1763b.f1692f.f1769h);
            q(this.f1763b.f1692f.f1770i);
        }
    }

    @Override // androidx.constraintlayout.solver.widgets.analyzer.WidgetRun
    public void e() {
        ConstraintWidget constraintWidget = this.f1763b;
        if (constraintWidget instanceof androidx.constraintlayout.solver.widgets.a) {
            int iM0 = ((androidx.constraintlayout.solver.widgets.a) constraintWidget).M0();
            if (iM0 == 0 || iM0 == 1) {
                this.f1763b.G0(this.f1769h.f1747g);
            } else {
                this.f1763b.H0(this.f1769h.f1747g);
            }
        }
    }

    @Override // androidx.constraintlayout.solver.widgets.analyzer.WidgetRun
    void f() {
        this.f1764c = null;
        this.f1769h.c();
    }

    @Override // androidx.constraintlayout.solver.widgets.analyzer.WidgetRun
    boolean m() {
        return false;
    }
}
