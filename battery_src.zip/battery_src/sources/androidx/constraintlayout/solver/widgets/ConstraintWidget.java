package androidx.constraintlayout.solver.widgets;

import androidx.constraintlayout.solver.SolverVariable;
import androidx.constraintlayout.solver.widgets.analyzer.DependencyNode;
import androidx.constraintlayout.solver.widgets.analyzer.WidgetRun;
import androidx.constraintlayout.solver.widgets.analyzer.j;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

/* JADX INFO: loaded from: classes.dex */
public class ConstraintWidget {
    public static float F0 = 0.5f;
    public float[] A0;
    private boolean B;
    protected ConstraintWidget[] B0;
    protected ConstraintWidget[] C0;
    ConstraintWidget D0;
    ConstraintWidget E0;
    ConstraintAnchor K;
    public ConstraintAnchor[] L;
    protected ArrayList<ConstraintAnchor> M;
    private boolean[] N;
    public DimensionBehaviour[] O;
    public ConstraintWidget P;
    int Q;
    int R;
    public float S;
    protected int T;
    protected int U;
    protected int V;
    int W;
    int X;
    protected int Y;
    protected int Z;

    /* JADX INFO: renamed from: a0, reason: collision with root package name */
    int f1683a0;

    /* JADX INFO: renamed from: b0, reason: collision with root package name */
    protected int f1685b0;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public androidx.constraintlayout.solver.widgets.analyzer.c f1686c;

    /* JADX INFO: renamed from: c0, reason: collision with root package name */
    protected int f1687c0;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    public androidx.constraintlayout.solver.widgets.analyzer.c f1688d;

    /* JADX INFO: renamed from: d0, reason: collision with root package name */
    float f1689d0;

    /* JADX INFO: renamed from: e0, reason: collision with root package name */
    float f1691e0;

    /* JADX INFO: renamed from: f0, reason: collision with root package name */
    private Object f1693f0;

    /* JADX INFO: renamed from: g0, reason: collision with root package name */
    private int f1695g0;

    /* JADX INFO: renamed from: h0, reason: collision with root package name */
    private int f1697h0;

    /* JADX INFO: renamed from: i0, reason: collision with root package name */
    private String f1699i0;

    /* JADX INFO: renamed from: j0, reason: collision with root package name */
    private String f1701j0;

    /* JADX INFO: renamed from: k0, reason: collision with root package name */
    int f1703k0;

    /* JADX INFO: renamed from: l0, reason: collision with root package name */
    int f1705l0;

    /* JADX INFO: renamed from: m0, reason: collision with root package name */
    int f1707m0;

    /* JADX INFO: renamed from: n0, reason: collision with root package name */
    int f1709n0;

    /* JADX INFO: renamed from: o0, reason: collision with root package name */
    boolean f1711o0;

    /* JADX INFO: renamed from: p0, reason: collision with root package name */
    boolean f1713p0;

    /* JADX INFO: renamed from: q0, reason: collision with root package name */
    boolean f1715q0;

    /* JADX INFO: renamed from: r0, reason: collision with root package name */
    boolean f1717r0;

    /* JADX INFO: renamed from: s0, reason: collision with root package name */
    boolean f1719s0;

    /* JADX INFO: renamed from: t0, reason: collision with root package name */
    boolean f1721t0;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    public boolean f1722u;

    /* JADX INFO: renamed from: u0, reason: collision with root package name */
    boolean f1723u0;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    public boolean f1724v;

    /* JADX INFO: renamed from: v0, reason: collision with root package name */
    boolean f1725v0;

    /* JADX INFO: renamed from: w0, reason: collision with root package name */
    int f1727w0;

    /* JADX INFO: renamed from: x0, reason: collision with root package name */
    int f1729x0;

    /* JADX INFO: renamed from: y0, reason: collision with root package name */
    boolean f1731y0;

    /* JADX INFO: renamed from: z0, reason: collision with root package name */
    boolean f1733z0;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public boolean f1682a = false;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public WidgetRun[] f1684b = new WidgetRun[2];

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    public androidx.constraintlayout.solver.widgets.analyzer.h f1690e = new androidx.constraintlayout.solver.widgets.analyzer.h(this);

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public j f1692f = new j(this);

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    public boolean[] f1694g = {true, true};

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    public int[] f1696h = {0, 0, 0, 0};

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    boolean f1698i = false;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    public int f1700j = -1;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public int f1702k = -1;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    public int f1704l = 0;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    public int f1706m = 0;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    public int[] f1708n = new int[2];

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    public int f1710o = 0;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    public int f1712p = 0;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    public float f1714q = 1.0f;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    public int f1716r = 0;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    public int f1718s = 0;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    public float f1720t = 1.0f;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    int f1726w = -1;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    float f1728x = 1.0f;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    private int[] f1730y = {Integer.MAX_VALUE, Integer.MAX_VALUE};

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    private float f1732z = 0.0f;
    private boolean A = false;
    private boolean C = false;
    public ConstraintAnchor D = new ConstraintAnchor(this, ConstraintAnchor.Type.LEFT);
    public ConstraintAnchor E = new ConstraintAnchor(this, ConstraintAnchor.Type.TOP);
    public ConstraintAnchor F = new ConstraintAnchor(this, ConstraintAnchor.Type.RIGHT);
    public ConstraintAnchor G = new ConstraintAnchor(this, ConstraintAnchor.Type.BOTTOM);
    ConstraintAnchor H = new ConstraintAnchor(this, ConstraintAnchor.Type.BASELINE);
    ConstraintAnchor I = new ConstraintAnchor(this, ConstraintAnchor.Type.CENTER_X);
    ConstraintAnchor J = new ConstraintAnchor(this, ConstraintAnchor.Type.CENTER_Y);

    public enum DimensionBehaviour {
        FIXED,
        WRAP_CONTENT,
        MATCH_CONSTRAINT,
        MATCH_PARENT
    }

    static /* synthetic */ class a {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        static final /* synthetic */ int[] f1739a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        static final /* synthetic */ int[] f1740b;

        static {
            int[] iArr = new int[DimensionBehaviour.values().length];
            f1740b = iArr;
            try {
                iArr[DimensionBehaviour.FIXED.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                f1740b[DimensionBehaviour.WRAP_CONTENT.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                f1740b[DimensionBehaviour.MATCH_PARENT.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                f1740b[DimensionBehaviour.MATCH_CONSTRAINT.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            int[] iArr2 = new int[ConstraintAnchor.Type.values().length];
            f1739a = iArr2;
            try {
                iArr2[ConstraintAnchor.Type.LEFT.ordinal()] = 1;
            } catch (NoSuchFieldError unused5) {
            }
            try {
                f1739a[ConstraintAnchor.Type.TOP.ordinal()] = 2;
            } catch (NoSuchFieldError unused6) {
            }
            try {
                f1739a[ConstraintAnchor.Type.RIGHT.ordinal()] = 3;
            } catch (NoSuchFieldError unused7) {
            }
            try {
                f1739a[ConstraintAnchor.Type.BOTTOM.ordinal()] = 4;
            } catch (NoSuchFieldError unused8) {
            }
            try {
                f1739a[ConstraintAnchor.Type.BASELINE.ordinal()] = 5;
            } catch (NoSuchFieldError unused9) {
            }
            try {
                f1739a[ConstraintAnchor.Type.CENTER.ordinal()] = 6;
            } catch (NoSuchFieldError unused10) {
            }
            try {
                f1739a[ConstraintAnchor.Type.CENTER_X.ordinal()] = 7;
            } catch (NoSuchFieldError unused11) {
            }
            try {
                f1739a[ConstraintAnchor.Type.CENTER_Y.ordinal()] = 8;
            } catch (NoSuchFieldError unused12) {
            }
            try {
                f1739a[ConstraintAnchor.Type.NONE.ordinal()] = 9;
            } catch (NoSuchFieldError unused13) {
            }
        }
    }

    public ConstraintWidget() {
        ConstraintAnchor constraintAnchor = new ConstraintAnchor(this, ConstraintAnchor.Type.CENTER);
        this.K = constraintAnchor;
        this.L = new ConstraintAnchor[]{this.D, this.F, this.E, this.G, this.H, constraintAnchor};
        this.M = new ArrayList<>();
        this.N = new boolean[2];
        DimensionBehaviour dimensionBehaviour = DimensionBehaviour.FIXED;
        this.O = new DimensionBehaviour[]{dimensionBehaviour, dimensionBehaviour};
        this.P = null;
        this.Q = 0;
        this.R = 0;
        this.S = 0.0f;
        this.T = -1;
        this.U = 0;
        this.V = 0;
        this.W = 0;
        this.X = 0;
        this.Y = 0;
        this.Z = 0;
        this.f1683a0 = 0;
        float f10 = F0;
        this.f1689d0 = f10;
        this.f1691e0 = f10;
        this.f1695g0 = 0;
        this.f1697h0 = 0;
        this.f1699i0 = null;
        this.f1701j0 = null;
        this.f1723u0 = false;
        this.f1725v0 = false;
        this.f1727w0 = 0;
        this.f1729x0 = 0;
        this.A0 = new float[]{-1.0f, -1.0f};
        this.B0 = new ConstraintWidget[]{null, null};
        this.C0 = new ConstraintWidget[]{null, null};
        this.D0 = null;
        this.E0 = null;
        d();
    }

    private boolean V(int i10) {
        ConstraintAnchor constraintAnchor;
        ConstraintAnchor constraintAnchor2;
        int i11 = i10 * 2;
        ConstraintAnchor[] constraintAnchorArr = this.L;
        ConstraintAnchor constraintAnchor3 = constraintAnchorArr[i11];
        ConstraintAnchor constraintAnchor4 = constraintAnchor3.f1667d;
        return (constraintAnchor4 == null || constraintAnchor4.f1667d == constraintAnchor3 || (constraintAnchor2 = (constraintAnchor = constraintAnchorArr[i11 + 1]).f1667d) == null || constraintAnchor2.f1667d != constraintAnchor) ? false : true;
    }

    private void d() {
        this.M.add(this.D);
        this.M.add(this.E);
        this.M.add(this.F);
        this.M.add(this.G);
        this.M.add(this.I);
        this.M.add(this.J);
        this.M.add(this.K);
        this.M.add(this.H);
    }

    /* JADX WARN: Code duplicated, block: B:100:0x01a3  */
    /* JADX WARN: Code duplicated, block: B:102:0x01b3 A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:177:0x02e1  */
    /* JADX WARN: Code duplicated, block: B:179:0x02e7  */
    /* JADX WARN: Code duplicated, block: B:181:0x02ed  */
    /* JADX WARN: Code duplicated, block: B:182:0x02f0  */
    /* JADX WARN: Code duplicated, block: B:184:0x031d  */
    /* JADX WARN: Code duplicated, block: B:187:0x0331 A[RETURN] */
    /* JADX WARN: Code duplicated, block: B:188:0x0332 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:189:0x0334  */
    /* JADX WARN: Code duplicated, block: B:197:0x0347  */
    /* JADX WARN: Code duplicated, block: B:200:0x0361  */
    /* JADX WARN: Code duplicated, block: B:208:0x0379  */
    /* JADX WARN: Code duplicated, block: B:210:0x0381  */
    /* JADX WARN: Code duplicated, block: B:221:0x0396  */
    /* JADX WARN: Code duplicated, block: B:226:0x03a0  */
    /* JADX WARN: Code duplicated, block: B:228:0x03a4  */
    /* JADX WARN: Code duplicated, block: B:229:0x03a6  */
    /* JADX WARN: Code duplicated, block: B:233:0x03af  */
    /* JADX WARN: Code duplicated, block: B:241:0x03ce  */
    /* JADX WARN: Code duplicated, block: B:243:0x03d3  */
    /* JADX WARN: Code duplicated, block: B:244:0x03d8  */
    /* JADX WARN: Code duplicated, block: B:246:0x03db  */
    /* JADX WARN: Code duplicated, block: B:247:0x03e0  */
    /* JADX WARN: Code duplicated, block: B:256:0x03f5  */
    /* JADX WARN: Code duplicated, block: B:266:0x0415 A[ADDED_TO_REGION, REMOVE] */
    /* JADX WARN: Code duplicated, block: B:268:0x0423 A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:27:0x0077  */
    /* JADX WARN: Code duplicated, block: B:287:0x0457  */
    /* JADX WARN: Code duplicated, block: B:28:0x007b  */
    /* JADX WARN: Code duplicated, block: B:295:? A[ADDED_TO_REGION, RETURN, SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:30:0x007f  */
    /* JADX WARN: Code duplicated, block: B:34:0x008a  */
    /* JADX WARN: Code duplicated, block: B:35:0x008f A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:36:0x0091 A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:38:0x009f  */
    /* JADX WARN: Code duplicated, block: B:40:0x00a4 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:41:0x00a6  */
    /* JADX WARN: Code duplicated, block: B:43:0x00af  */
    /* JADX WARN: Code duplicated, block: B:46:0x00b7  */
    /* JADX WARN: Code duplicated, block: B:47:0x00bb  */
    /* JADX WARN: Code duplicated, block: B:51:0x00cd  */
    /* JADX WARN: Code duplicated, block: B:63:0x00f5  */
    /* JADX WARN: Code duplicated, block: B:64:0x00f7  */
    /* JADX WARN: Code duplicated, block: B:66:0x00fa  */
    /* JADX WARN: Code duplicated, block: B:67:0x00fc  */
    /* JADX WARN: Code duplicated, block: B:74:0x0107  */
    /* JADX WARN: Code duplicated, block: B:77:0x0111  */
    /* JADX WARN: Code duplicated, block: B:80:0x0116  */
    /* JADX WARN: Code duplicated, block: B:83:0x011f A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:84:0x0121  */
    /* JADX WARN: Code duplicated, block: B:85:0x0125 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:86:0x0127  */
    /* JADX WARN: Code duplicated, block: B:87:0x012f  */
    /* JADX WARN: Code duplicated, block: B:89:0x013b  */
    /* JADX WARN: Code duplicated, block: B:91:0x013e  */
    /* JADX WARN: Code duplicated, block: B:98:0x016b  */
    private void h(androidx.constraintlayout.solver.d dVar, boolean z10, boolean z11, boolean z12, boolean z13, SolverVariable solverVariable, SolverVariable solverVariable2, DimensionBehaviour dimensionBehaviour, boolean z14, ConstraintAnchor constraintAnchor, ConstraintAnchor constraintAnchor2, int i10, int i11, int i12, int i13, float f10, boolean z15, boolean z16, boolean z17, boolean z18, int i14, int i15, int i16, int i17, float f11, boolean z19) {
        int i18;
        boolean z20;
        int iMin;
        int i19;
        int i20;
        int i21;
        int i22;
        int i23;
        boolean z21;
        ConstraintAnchor.Type typeH;
        ConstraintAnchor.Type type;
        SolverVariable solverVariableQ;
        SolverVariable solverVariableQ2;
        int i24;
        char c10;
        char c11;
        ConstraintAnchor constraintAnchor3;
        boolean z22;
        boolean z23;
        boolean z24;
        int i25;
        boolean z25;
        int i26;
        boolean z26;
        boolean z27;
        SolverVariable solverVariable3;
        boolean z28;
        int i27;
        int i28;
        SolverVariable solverVariable4;
        ConstraintWidget constraintWidget;
        SolverVariable solverVariable5;
        int iMax;
        int i29;
        boolean z29;
        int i30;
        int i31;
        int iC;
        int iMin2;
        int i32;
        int i33;
        int i34;
        int i35;
        int i36;
        int i37;
        int i38;
        boolean z30;
        SolverVariable solverVariableQ3 = dVar.q(constraintAnchor);
        SolverVariable solverVariableQ4 = dVar.q(constraintAnchor2);
        SolverVariable solverVariableQ5 = dVar.q(constraintAnchor.g());
        SolverVariable solverVariableQ6 = dVar.q(constraintAnchor2.g());
        androidx.constraintlayout.solver.d.x();
        boolean zJ = constraintAnchor.j();
        boolean zJ2 = constraintAnchor2.j();
        boolean zJ3 = this.K.j();
        int i39 = zJ2 ? (zJ ? 1 : 0) + 1 : zJ ? 1 : 0;
        if (zJ3) {
            i39++;
        }
        int i40 = z15 ? 3 : i14;
        int i41 = a.f1740b[dimensionBehaviour.ordinal()];
        if (i41 != 1 && i41 != 2 && i41 != 3 && i41 == 4) {
            i18 = i40;
            if (i18 != 4) {
                z20 = true;
            }
            if (this.f1697h0 == 8) {
                iMin = 0;
                z20 = false;
            } else {
                iMin = i11;
            }
            if (!z19) {
                if (zJ && !zJ2 && !zJ3) {
                    dVar.f(solverVariableQ3, i10);
                } else if (zJ && !zJ2) {
                    i19 = 8;
                    dVar.e(solverVariableQ3, solverVariableQ5, constraintAnchor.c(), 8);
                }
                i19 = 8;
            } else {
                i19 = 8;
            }
            if (!z20) {
                if (i39 == 2 && !z15 && (i18 == 1 || i18 == 0)) {
                    int iMax2 = Math.max(i16, iMin);
                    if (i17 > 0) {
                        iMax2 = Math.min(i17, iMax2);
                    }
                    dVar.e(solverVariableQ4, solverVariableQ3, iMax2, 8);
                    i23 = i16;
                    i21 = i17;
                    solverVariableQ5 = solverVariableQ5;
                    solverVariableQ4 = solverVariableQ4;
                    z21 = false;
                    i22 = i39;
                } else {
                    if (i16 == -2) {
                        i20 = iMin;
                    } else {
                        i20 = i16;
                    }
                    if (i17 == -2) {
                        i21 = iMin;
                    } else {
                        i21 = i17;
                    }
                    if (iMin > 0 && i18 != 1) {
                        iMin = 0;
                    }
                    if (i20 > 0) {
                        dVar.h(solverVariableQ4, solverVariableQ3, i20, 8);
                        iMin = Math.max(iMin, i20);
                    }
                    if (i21 > 0) {
                        if (z11 || i18 != 1) {
                            dVar.j(solverVariableQ4, solverVariableQ3, i21, 8);
                        }
                        iMin = Math.min(iMin, i21);
                    }
                    if (i18 == 1) {
                        if (z11) {
                            dVar.e(solverVariableQ4, solverVariableQ3, iMin, 8);
                        } else if (z16) {
                            dVar.e(solverVariableQ4, solverVariableQ3, iMin, 5);
                            dVar.j(solverVariableQ4, solverVariableQ3, iMin, 8);
                        } else {
                            dVar.e(solverVariableQ4, solverVariableQ3, iMin, 5);
                            dVar.j(solverVariableQ4, solverVariableQ3, iMin, 8);
                        }
                        i23 = i20;
                    } else if (i18 == 2) {
                        typeH = constraintAnchor.h();
                        type = ConstraintAnchor.Type.TOP;
                        if (typeH != type || constraintAnchor.h() == ConstraintAnchor.Type.BOTTOM) {
                            solverVariableQ = dVar.q(this.P.n(type));
                            solverVariableQ2 = dVar.q(this.P.n(ConstraintAnchor.Type.BOTTOM));
                        } else {
                            solverVariableQ = dVar.q(this.P.n(ConstraintAnchor.Type.LEFT));
                            solverVariableQ2 = dVar.q(this.P.n(ConstraintAnchor.Type.RIGHT));
                        }
                        SolverVariable solverVariable6 = solverVariableQ;
                        SolverVariable solverVariable7 = solverVariableQ2;
                        androidx.constraintlayout.solver.b bVarR = dVar.r();
                        int i42 = i20;
                        solverVariableQ6 = solverVariableQ6;
                        solverVariableQ5 = solverVariableQ5;
                        i22 = i39 == true ? 1 : 0;
                        solverVariableQ4 = solverVariableQ4;
                        dVar.d(bVarR.k(solverVariableQ4, solverVariableQ3, solverVariable7, solverVariable6, f11));
                        z13 = z13;
                        i23 = i42;
                        z21 = false;
                    } else {
                        solverVariableQ5 = solverVariableQ5;
                        solverVariableQ4 = solverVariableQ4;
                        int i43 = i20;
                        solverVariableQ6 = solverVariableQ6;
                        i22 = i39;
                        i23 = i43;
                        z21 = z20;
                        z13 = true;
                    }
                }
                if (z19 || z16) {
                    i24 = 8;
                    c10 = 2;
                    c11 = 1;
                    if (i22 >= c10 && z11 && z13) {
                        dVar.h(solverVariableQ3, solverVariable, 0, i24);
                        char c12 = (z10 || this.H.f1667d == null) ? c11 : (char) 0;
                        if (z10 || (constraintAnchor3 = this.H.f1667d) == null) {
                            c11 = c12;
                        } else {
                            ConstraintWidget constraintWidget2 = constraintAnchor3.f1665b;
                            if (constraintWidget2.S != 0.0f) {
                                DimensionBehaviour[] dimensionBehaviourArr = constraintWidget2.O;
                                DimensionBehaviour dimensionBehaviour2 = dimensionBehaviourArr[0];
                                DimensionBehaviour dimensionBehaviour3 = DimensionBehaviour.MATCH_CONSTRAINT;
                                if (dimensionBehaviour2 != dimensionBehaviour3 || dimensionBehaviourArr[c11] != dimensionBehaviour3) {
                                    c11 = 0;
                                }
                            } else {
                                c11 = 0;
                            }
                        }
                        if (c11 != 0) {
                            dVar.h(solverVariable2, solverVariableQ4, 0, i24);
                            return;
                        }
                        return;
                    }
                    return;
                }
                if ((zJ || zJ2 || zJ3) && (!zJ || zJ2)) {
                    if (!zJ && zJ2) {
                        dVar.e(solverVariableQ4, solverVariableQ6, -constraintAnchor2.c(), 8);
                        if (z11) {
                            dVar.h(solverVariableQ3, solverVariable, 0, 5);
                        }
                    } else if (zJ && zJ2) {
                        ConstraintWidget constraintWidget3 = constraintAnchor.f1667d.f1665b;
                        ConstraintWidget constraintWidget4 = constraintAnchor2.f1667d.f1665b;
                        ConstraintWidget constraintWidgetH = H();
                        int i44 = 6;
                        if (z21) {
                            if (i18 == 0) {
                                if (i21 == 0 && i23 == 0) {
                                    z30 = false;
                                    i37 = 8;
                                    i38 = 8;
                                    z25 = true;
                                } else {
                                    z25 = false;
                                    i37 = 5;
                                    i38 = 5;
                                    z30 = true;
                                }
                                if ((constraintWidget3 instanceof androidx.constraintlayout.solver.widgets.a) || (constraintWidget4 instanceof androidx.constraintlayout.solver.widgets.a)) {
                                    i26 = i37;
                                    z24 = z30;
                                    z23 = false;
                                    z22 = true;
                                    i25 = 4;
                                } else {
                                    i26 = i37;
                                    i44 = 6;
                                    z24 = z30;
                                    z23 = false;
                                    z22 = true;
                                    i25 = i38;
                                }
                            } else if (i18 == 1) {
                                i26 = 8;
                                i44 = 6;
                                z23 = true;
                                z22 = true;
                                i25 = 4;
                                z25 = false;
                                z24 = true;
                            } else if (i18 != 3) {
                                z22 = true;
                                z23 = false;
                                i25 = 4;
                                z25 = false;
                                z24 = false;
                            } else if (this.f1726w == -1) {
                                if (z17) {
                                    i44 = z11 ? 5 : 4;
                                } else {
                                    i44 = 8;
                                }
                                z23 = true;
                                z22 = true;
                                i25 = 5;
                                z25 = true;
                                z24 = true;
                                i26 = 8;
                            } else if (z15) {
                                if (i15 != 2) {
                                    z22 = true;
                                    if (i15 != 1) {
                                        i35 = 8;
                                        i36 = 5;
                                    }
                                    i26 = i35;
                                    i25 = i36;
                                    z23 = z22;
                                    z25 = z23;
                                    z24 = z25;
                                    i44 = 6;
                                } else {
                                    z22 = true;
                                }
                                i35 = 5;
                                i36 = 4;
                                i26 = i35;
                                i25 = i36;
                                z23 = z22;
                                z25 = z23;
                                z24 = z25;
                                i44 = 6;
                            } else {
                                z22 = true;
                                if (i21 > 0) {
                                    z23 = true;
                                    z25 = true;
                                    z24 = true;
                                    i25 = 5;
                                } else if (i21 != 0 || i23 != 0) {
                                    z23 = true;
                                    z25 = true;
                                    z24 = true;
                                    i25 = 4;
                                } else if (z17) {
                                    i26 = (constraintWidget3 == constraintWidgetH || constraintWidget4 == constraintWidgetH) ? 5 : 4;
                                    z23 = true;
                                    z25 = true;
                                    z24 = true;
                                    i25 = 4;
                                } else {
                                    z23 = true;
                                    z25 = true;
                                    z24 = true;
                                    i25 = 8;
                                }
                            }
                            if (z23 || solverVariableQ5 != solverVariableQ6 || constraintWidget3 == constraintWidgetH) {
                                z26 = z23;
                                z27 = z22;
                            } else {
                                z26 = false;
                                z27 = false;
                            }
                            if (z24) {
                                if (this.f1697h0 == 8) {
                                    i34 = 4;
                                } else {
                                    i34 = i44;
                                }
                                solverVariable3 = solverVariableQ4;
                                i28 = 4;
                                z28 = true;
                                i27 = 8;
                                dVar.c(solverVariableQ3, solverVariableQ5, constraintAnchor.c(), f10, solverVariableQ6, solverVariable3, constraintAnchor2.c(), i34);
                            } else {
                                solverVariable3 = solverVariableQ4;
                                z28 = z22;
                                i27 = 8;
                                i28 = 4;
                            }
                            if (this.f1697h0 == i27) {
                                return;
                            }
                            if (z26) {
                                if (z11 || solverVariableQ5 == solverVariableQ6 || z21) {
                                    constraintWidget = constraintWidget3;
                                } else {
                                    constraintWidget = constraintWidget3;
                                    if ((constraintWidget instanceof androidx.constraintlayout.solver.widgets.a) || (constraintWidget4 instanceof androidx.constraintlayout.solver.widgets.a)) {
                                        i33 = 6;
                                    }
                                    solverVariable5 = solverVariableQ3;
                                    dVar.h(solverVariable5, solverVariableQ5, constraintAnchor.c(), i33);
                                    solverVariable4 = solverVariable3;
                                    dVar.j(solverVariable4, solverVariableQ6, -constraintAnchor2.c(), i33);
                                    i26 = i33;
                                }
                                i33 = i26;
                                solverVariable5 = solverVariableQ3;
                                dVar.h(solverVariable5, solverVariableQ5, constraintAnchor.c(), i33);
                                solverVariable4 = solverVariable3;
                                dVar.j(solverVariable4, solverVariableQ6, -constraintAnchor2.c(), i33);
                                i26 = i33;
                            } else {
                                solverVariable4 = solverVariable3;
                                constraintWidget = constraintWidget3;
                                solverVariable5 = solverVariableQ3;
                            }
                            if (z11 || !z18 || (constraintWidget instanceof androidx.constraintlayout.solver.widgets.a) || (constraintWidget4 instanceof androidx.constraintlayout.solver.widgets.a)) {
                                iMax = i25;
                                i29 = i26;
                                z29 = z27;
                            } else {
                                iMax = 6;
                                i29 = 6;
                                z29 = z28;
                            }
                            if (z29) {
                                if (z25 && (!z17 || z12)) {
                                    if (constraintWidget != constraintWidgetH && constraintWidget4 != constraintWidgetH) {
                                        i44 = iMax;
                                    }
                                    if ((constraintWidget instanceof f) || (constraintWidget4 instanceof f)) {
                                        i44 = 5;
                                    }
                                    if ((constraintWidget instanceof androidx.constraintlayout.solver.widgets.a) || (constraintWidget4 instanceof androidx.constraintlayout.solver.widgets.a)) {
                                        i44 = 5;
                                    }
                                    if (z17) {
                                        i32 = 5;
                                    } else {
                                        i32 = i44;
                                    }
                                    iMax = Math.max(i32, iMax);
                                }
                                iMin2 = iMax;
                                if (z11) {
                                    iMin2 = Math.min(i29, iMin2);
                                    if (z15 && !z17 && (constraintWidget == constraintWidgetH || constraintWidget4 == constraintWidgetH)) {
                                        iMin2 = i28;
                                    }
                                }
                                dVar.e(solverVariable5, solverVariableQ5, constraintAnchor.c(), iMin2);
                                dVar.e(solverVariable4, solverVariableQ6, -constraintAnchor2.c(), iMin2);
                            }
                            if (z11) {
                                i30 = i27;
                                if (solverVariable == solverVariableQ5) {
                                    iC = constraintAnchor.c();
                                } else {
                                    iC = 0;
                                }
                                if (solverVariableQ5 != solverVariable) {
                                    dVar.h(solverVariable5, solverVariable, iC, 5);
                                }
                            } else {
                                i30 = i27;
                            }
                            if (z11 && z21 && i12 == 0 && i23 == 0) {
                                if (z21 || i31 != 3) {
                                    i31 = i18;
                                    dVar.h(solverVariable4, solverVariable5, 0, 5);
                                } else {
                                    dVar.h(solverVariable4, solverVariable5, 0, i30);
                                }
                            }
                        } else {
                            z22 = true;
                            z23 = true;
                            z24 = true;
                            i25 = 4;
                            z25 = false;
                        }
                        i26 = 5;
                        if (z23) {
                            z26 = z23;
                            z27 = z22;
                        } else {
                            z26 = z23;
                            z27 = z22;
                        }
                        if (z24) {
                            if (this.f1697h0 == 8) {
                                i34 = 4;
                            } else {
                                i34 = i44;
                            }
                            solverVariable3 = solverVariableQ4;
                            i28 = 4;
                            z28 = true;
                            i27 = 8;
                            dVar.c(solverVariableQ3, solverVariableQ5, constraintAnchor.c(), f10, solverVariableQ6, solverVariable3, constraintAnchor2.c(), i34);
                        } else {
                            solverVariable3 = solverVariableQ4;
                            z28 = z22;
                            i27 = 8;
                            i28 = 4;
                        }
                        if (this.f1697h0 == i27) {
                            return;
                        }
                        if (z26) {
                            if (z11) {
                                constraintWidget = constraintWidget3;
                                i33 = i26;
                            } else {
                                constraintWidget = constraintWidget3;
                                i33 = i26;
                            }
                            solverVariable5 = solverVariableQ3;
                            dVar.h(solverVariable5, solverVariableQ5, constraintAnchor.c(), i33);
                            solverVariable4 = solverVariable3;
                            dVar.j(solverVariable4, solverVariableQ6, -constraintAnchor2.c(), i33);
                            i26 = i33;
                        } else {
                            solverVariable4 = solverVariable3;
                            constraintWidget = constraintWidget3;
                            solverVariable5 = solverVariableQ3;
                        }
                        if (z11) {
                            iMax = i25;
                            i29 = i26;
                            z29 = z27;
                        } else {
                            iMax = i25;
                            i29 = i26;
                            z29 = z27;
                        }
                        if (z29) {
                            if (z25) {
                                if (constraintWidget != constraintWidgetH) {
                                    i44 = iMax;
                                }
                                if (constraintWidget instanceof f) {
                                    i44 = 5;
                                } else {
                                    i44 = 5;
                                }
                                if (constraintWidget instanceof androidx.constraintlayout.solver.widgets.a) {
                                    i44 = 5;
                                } else {
                                    i44 = 5;
                                }
                                if (z17) {
                                    i32 = 5;
                                } else {
                                    i32 = i44;
                                }
                                iMax = Math.max(i32, iMax);
                            }
                            iMin2 = iMax;
                            if (z11) {
                                iMin2 = Math.min(i29, iMin2);
                                if (z15) {
                                    iMin2 = i28;
                                }
                            }
                            dVar.e(solverVariable5, solverVariableQ5, constraintAnchor.c(), iMin2);
                            dVar.e(solverVariable4, solverVariableQ6, -constraintAnchor2.c(), iMin2);
                        }
                        if (z11) {
                            i30 = i27;
                            if (solverVariable == solverVariableQ5) {
                                iC = constraintAnchor.c();
                            } else {
                                iC = 0;
                            }
                            if (solverVariableQ5 != solverVariable) {
                                dVar.h(solverVariable5, solverVariable, iC, 5);
                            }
                        } else {
                            i30 = i27;
                        }
                        if (z11) {
                            if (z21) {
                                i31 = i18;
                                dVar.h(solverVariable4, solverVariable5, 0, 5);
                            } else {
                                i31 = i18;
                                dVar.h(solverVariable4, solverVariable5, 0, 5);
                            }
                        }
                    }
                    solverVariable4 = solverVariableQ4;
                } else {
                    solverVariable4 = solverVariableQ4;
                }
                if (!z11) {
                    i31 = i18;
                    return;
                }
                if (z13) {
                    int iC2 = constraintAnchor2.f1667d != null ? constraintAnchor2.c() : 0;
                    if (solverVariableQ6 != solverVariable2) {
                        dVar.h(solverVariable2, solverVariable4, iC2, 5);
                        return;
                    }
                    return;
                }
                return;
            }
            if (z14) {
                dVar.e(solverVariableQ4, solverVariableQ3, 0, 3);
                if (i12 > 0) {
                    dVar.h(solverVariableQ4, solverVariableQ3, i12, 8);
                }
                if (i13 < Integer.MAX_VALUE) {
                    dVar.j(solverVariableQ4, solverVariableQ3, i13, 8);
                }
            } else {
                dVar.e(solverVariableQ4, solverVariableQ3, iMin, i19);
            }
            i23 = i16;
            i21 = i17;
            z21 = z20;
            i22 = i39;
            if (z19) {
                i24 = 8;
                c10 = 2;
                c11 = 1;
            } else {
                i24 = 8;
                c10 = 2;
                c11 = 1;
            }
            if (i22 >= c10) {
            }
        }
        i18 = i40;
        z20 = false;
        if (this.f1697h0 == 8) {
            iMin = 0;
            z20 = false;
        } else {
            iMin = i11;
        }
        if (!z19) {
            i19 = 8;
        } else if (zJ) {
            if (zJ) {
                i19 = 8;
            } else {
                i19 = 8;
            }
        } else if (zJ) {
            i19 = 8;
        } else {
            i19 = 8;
        }
        if (!z20) {
            if (i39 == 2) {
            }
            if (i16 == -2) {
                i20 = iMin;
            } else {
                i20 = i16;
            }
            if (i17 == -2) {
                i21 = iMin;
            } else {
                i21 = i17;
            }
            if (iMin > 0) {
                iMin = 0;
            }
            if (i20 > 0) {
                dVar.h(solverVariableQ4, solverVariableQ3, i20, 8);
                iMin = Math.max(iMin, i20);
            }
            if (i21 > 0) {
                if (z11) {
                    dVar.j(solverVariableQ4, solverVariableQ3, i21, 8);
                } else {
                    dVar.j(solverVariableQ4, solverVariableQ3, i21, 8);
                }
                iMin = Math.min(iMin, i21);
            }
            if (i18 == 1) {
                if (z11) {
                    dVar.e(solverVariableQ4, solverVariableQ3, iMin, 8);
                } else if (z16) {
                    dVar.e(solverVariableQ4, solverVariableQ3, iMin, 5);
                    dVar.j(solverVariableQ4, solverVariableQ3, iMin, 8);
                } else {
                    dVar.e(solverVariableQ4, solverVariableQ3, iMin, 5);
                    dVar.j(solverVariableQ4, solverVariableQ3, iMin, 8);
                }
                i23 = i20;
            } else if (i18 == 2) {
                typeH = constraintAnchor.h();
                type = ConstraintAnchor.Type.TOP;
                if (typeH != type) {
                    solverVariableQ = dVar.q(this.P.n(type));
                    solverVariableQ2 = dVar.q(this.P.n(ConstraintAnchor.Type.BOTTOM));
                } else {
                    solverVariableQ = dVar.q(this.P.n(type));
                    solverVariableQ2 = dVar.q(this.P.n(ConstraintAnchor.Type.BOTTOM));
                }
                SolverVariable solverVariable8 = solverVariableQ;
                SolverVariable solverVariable9 = solverVariableQ2;
                androidx.constraintlayout.solver.b bVarR2 = dVar.r();
                int i45 = i20;
                solverVariableQ6 = solverVariableQ6;
                solverVariableQ5 = solverVariableQ5;
                i22 = i39 == true ? 1 : 0;
                solverVariableQ4 = solverVariableQ4;
                dVar.d(bVarR2.k(solverVariableQ4, solverVariableQ3, solverVariable9, solverVariable8, f11));
                z13 = z13;
                i23 = i45;
                z21 = false;
            } else {
                solverVariableQ5 = solverVariableQ5;
                solverVariableQ4 = solverVariableQ4;
                int i46 = i20;
                solverVariableQ6 = solverVariableQ6;
                i22 = i39;
                i23 = i46;
                z21 = z20;
                z13 = true;
            }
            if (z19) {
                i24 = 8;
                c10 = 2;
                c11 = 1;
            } else {
                i24 = 8;
                c10 = 2;
                c11 = 1;
            }
            if (i22 >= c10) {
            }
        }
        if (z14) {
            dVar.e(solverVariableQ4, solverVariableQ3, 0, 3);
            if (i12 > 0) {
                dVar.h(solverVariableQ4, solverVariableQ3, i12, 8);
            }
            if (i13 < Integer.MAX_VALUE) {
                dVar.j(solverVariableQ4, solverVariableQ3, i13, 8);
            }
        } else {
            dVar.e(solverVariableQ4, solverVariableQ3, iMin, i19);
        }
        i23 = i16;
        i21 = i17;
        z21 = z20;
        i22 = i39;
        if (z19) {
            i24 = 8;
            c10 = 2;
            c11 = 1;
        } else {
            i24 = 8;
            c10 = 2;
            c11 = 1;
        }
        if (i22 >= c10) {
        }
    }

    public int A() {
        ConstraintAnchor constraintAnchor = this.D;
        int i10 = constraintAnchor != null ? constraintAnchor.f1668e : 0;
        ConstraintAnchor constraintAnchor2 = this.F;
        return constraintAnchor2 != null ? i10 + constraintAnchor2.f1668e : i10;
    }

    public void A0(int i10, int i11) {
        this.V = i10;
        int i12 = i11 - i10;
        this.R = i12;
        int i13 = this.f1687c0;
        if (i12 < i13) {
            this.R = i13;
        }
    }

    public int B(int i10) {
        if (i10 == 0) {
            return Q();
        }
        if (i10 == 1) {
            return w();
        }
        return 0;
    }

    public void B0(DimensionBehaviour dimensionBehaviour) {
        this.O[1] = dimensionBehaviour;
    }

    public int C() {
        return this.f1730y[1];
    }

    public void C0(int i10, int i11, int i12, float f10) {
        this.f1706m = i10;
        this.f1716r = i11;
        if (i12 == Integer.MAX_VALUE) {
            i12 = 0;
        }
        this.f1718s = i12;
        this.f1720t = f10;
        if (f10 <= 0.0f || f10 >= 1.0f || i10 != 0) {
            return;
        }
        this.f1706m = 2;
    }

    public int D() {
        return this.f1730y[0];
    }

    public void D0(float f10) {
        this.A0[1] = f10;
    }

    public int E() {
        return this.f1687c0;
    }

    public void E0(int i10) {
        this.f1697h0 = i10;
    }

    public int F() {
        return this.f1685b0;
    }

    public void F0(int i10) {
        this.Q = i10;
        int i11 = this.f1685b0;
        if (i10 < i11) {
            this.Q = i11;
        }
    }

    public ConstraintWidget G(int i10) {
        ConstraintAnchor constraintAnchor;
        ConstraintAnchor constraintAnchor2;
        if (i10 != 0) {
            if (i10 == 1 && (constraintAnchor2 = (constraintAnchor = this.G).f1667d) != null && constraintAnchor2.f1667d == constraintAnchor) {
                return constraintAnchor2.f1665b;
            }
            return null;
        }
        ConstraintAnchor constraintAnchor3 = this.F;
        ConstraintAnchor constraintAnchor4 = constraintAnchor3.f1667d;
        if (constraintAnchor4 == null || constraintAnchor4.f1667d != constraintAnchor3) {
            return null;
        }
        return constraintAnchor4.f1665b;
    }

    public void G0(int i10) {
        this.U = i10;
    }

    public ConstraintWidget H() {
        return this.P;
    }

    public void H0(int i10) {
        this.V = i10;
    }

    public ConstraintWidget I(int i10) {
        ConstraintAnchor constraintAnchor;
        ConstraintAnchor constraintAnchor2;
        if (i10 != 0) {
            if (i10 == 1 && (constraintAnchor2 = (constraintAnchor = this.E).f1667d) != null && constraintAnchor2.f1667d == constraintAnchor) {
                return constraintAnchor2.f1665b;
            }
            return null;
        }
        ConstraintAnchor constraintAnchor3 = this.D;
        ConstraintAnchor constraintAnchor4 = constraintAnchor3.f1667d;
        if (constraintAnchor4 == null || constraintAnchor4.f1667d != constraintAnchor3) {
            return null;
        }
        return constraintAnchor4.f1665b;
    }

    public void I0(boolean z10, boolean z11, boolean z12, boolean z13) {
        if (this.f1726w == -1) {
            if (z12 && !z13) {
                this.f1726w = 0;
            } else if (!z12 && z13) {
                this.f1726w = 1;
                if (this.T == -1) {
                    this.f1728x = 1.0f / this.f1728x;
                }
            }
        }
        if (this.f1726w == 0 && (!this.E.j() || !this.G.j())) {
            this.f1726w = 1;
        } else if (this.f1726w == 1 && (!this.D.j() || !this.F.j())) {
            this.f1726w = 0;
        }
        if (this.f1726w == -1 && (!this.E.j() || !this.G.j() || !this.D.j() || !this.F.j())) {
            if (this.E.j() && this.G.j()) {
                this.f1726w = 0;
            } else if (this.D.j() && this.F.j()) {
                this.f1728x = 1.0f / this.f1728x;
                this.f1726w = 1;
            }
        }
        if (this.f1726w == -1) {
            int i10 = this.f1710o;
            if (i10 > 0 && this.f1716r == 0) {
                this.f1726w = 0;
            } else {
                if (i10 != 0 || this.f1716r <= 0) {
                    return;
                }
                this.f1728x = 1.0f / this.f1728x;
                this.f1726w = 1;
            }
        }
    }

    public int J() {
        return R() + this.Q;
    }

    public void J0(boolean z10, boolean z11) {
        int i10;
        int i11;
        boolean zK = z10 & this.f1690e.k();
        boolean zK2 = z11 & this.f1692f.k();
        androidx.constraintlayout.solver.widgets.analyzer.h hVar = this.f1690e;
        int i12 = hVar.f1769h.f1747g;
        j jVar = this.f1692f;
        int i13 = jVar.f1769h.f1747g;
        int i14 = hVar.f1770i.f1747g;
        int i15 = jVar.f1770i.f1747g;
        int i16 = i15 - i13;
        if (i14 - i12 < 0 || i16 < 0 || i12 == Integer.MIN_VALUE || i12 == Integer.MAX_VALUE || i13 == Integer.MIN_VALUE || i13 == Integer.MAX_VALUE || i14 == Integer.MIN_VALUE || i14 == Integer.MAX_VALUE || i15 == Integer.MIN_VALUE || i15 == Integer.MAX_VALUE) {
            i14 = 0;
            i12 = 0;
            i15 = 0;
            i13 = 0;
        }
        int i17 = i14 - i12;
        int i18 = i15 - i13;
        if (zK) {
            this.U = i12;
        }
        if (zK2) {
            this.V = i13;
        }
        if (this.f1697h0 == 8) {
            this.Q = 0;
            this.R = 0;
            return;
        }
        if (zK) {
            if (this.O[0] == DimensionBehaviour.FIXED && i17 < (i11 = this.Q)) {
                i17 = i11;
            }
            this.Q = i17;
            int i19 = this.f1685b0;
            if (i17 < i19) {
                this.Q = i19;
            }
        }
        if (zK2) {
            if (this.O[1] == DimensionBehaviour.FIXED && i18 < (i10 = this.R)) {
                i18 = i10;
            }
            this.R = i18;
            int i20 = this.f1687c0;
            if (i18 < i20) {
                this.R = i20;
            }
        }
    }

    public WidgetRun K(int i10) {
        if (i10 == 0) {
            return this.f1690e;
        }
        if (i10 == 1) {
            return this.f1692f;
        }
        return null;
    }

    public void K0(androidx.constraintlayout.solver.d dVar) {
        int iY = dVar.y(this.D);
        int iY2 = dVar.y(this.E);
        int iY3 = dVar.y(this.F);
        int iY4 = dVar.y(this.G);
        androidx.constraintlayout.solver.widgets.analyzer.h hVar = this.f1690e;
        DependencyNode dependencyNode = hVar.f1769h;
        if (dependencyNode.f1750j) {
            DependencyNode dependencyNode2 = hVar.f1770i;
            if (dependencyNode2.f1750j) {
                iY = dependencyNode.f1747g;
                iY3 = dependencyNode2.f1747g;
            }
        }
        j jVar = this.f1692f;
        DependencyNode dependencyNode3 = jVar.f1769h;
        if (dependencyNode3.f1750j) {
            DependencyNode dependencyNode4 = jVar.f1770i;
            if (dependencyNode4.f1750j) {
                iY2 = dependencyNode3.f1747g;
                iY4 = dependencyNode4.f1747g;
            }
        }
        int i10 = iY4 - iY2;
        if (iY3 - iY < 0 || i10 < 0 || iY == Integer.MIN_VALUE || iY == Integer.MAX_VALUE || iY2 == Integer.MIN_VALUE || iY2 == Integer.MAX_VALUE || iY3 == Integer.MIN_VALUE || iY3 == Integer.MAX_VALUE || iY4 == Integer.MIN_VALUE || iY4 == Integer.MAX_VALUE) {
            iY = 0;
            iY4 = 0;
            iY2 = 0;
            iY3 = 0;
        }
        g0(iY, iY2, iY3, iY4);
    }

    public float L() {
        return this.f1691e0;
    }

    public int M() {
        return this.f1729x0;
    }

    public DimensionBehaviour N() {
        return this.O[1];
    }

    public int O() {
        int i10 = this.D != null ? this.E.f1668e : 0;
        return this.F != null ? i10 + this.G.f1668e : i10;
    }

    public int P() {
        return this.f1697h0;
    }

    public int Q() {
        if (this.f1697h0 == 8) {
            return 0;
        }
        return this.Q;
    }

    public int R() {
        ConstraintWidget constraintWidget = this.P;
        return (constraintWidget == null || !(constraintWidget instanceof d)) ? this.U : ((d) constraintWidget).M0 + this.U;
    }

    public int S() {
        ConstraintWidget constraintWidget = this.P;
        return (constraintWidget == null || !(constraintWidget instanceof d)) ? this.V : ((d) constraintWidget).N0 + this.V;
    }

    public boolean T() {
        return this.A;
    }

    public void U(ConstraintAnchor.Type type, ConstraintWidget constraintWidget, ConstraintAnchor.Type type2, int i10, int i11) {
        n(type).b(constraintWidget.n(type2), i10, i11, true);
    }

    public boolean W() {
        ConstraintAnchor constraintAnchor = this.D;
        ConstraintAnchor constraintAnchor2 = constraintAnchor.f1667d;
        if (constraintAnchor2 != null && constraintAnchor2.f1667d == constraintAnchor) {
            return true;
        }
        ConstraintAnchor constraintAnchor3 = this.F;
        ConstraintAnchor constraintAnchor4 = constraintAnchor3.f1667d;
        return constraintAnchor4 != null && constraintAnchor4.f1667d == constraintAnchor3;
    }

    public boolean X() {
        return this.B;
    }

    public boolean Y() {
        ConstraintAnchor constraintAnchor = this.E;
        ConstraintAnchor constraintAnchor2 = constraintAnchor.f1667d;
        if (constraintAnchor2 != null && constraintAnchor2.f1667d == constraintAnchor) {
            return true;
        }
        ConstraintAnchor constraintAnchor3 = this.G;
        ConstraintAnchor constraintAnchor4 = constraintAnchor3.f1667d;
        return constraintAnchor4 != null && constraintAnchor4.f1667d == constraintAnchor3;
    }

    public void Z() {
        this.D.l();
        this.E.l();
        this.F.l();
        this.G.l();
        this.H.l();
        this.I.l();
        this.J.l();
        this.K.l();
        this.P = null;
        this.f1732z = 0.0f;
        this.Q = 0;
        this.R = 0;
        this.S = 0.0f;
        this.T = -1;
        this.U = 0;
        this.V = 0;
        this.Y = 0;
        this.Z = 0;
        this.f1683a0 = 0;
        this.f1685b0 = 0;
        this.f1687c0 = 0;
        float f10 = F0;
        this.f1689d0 = f10;
        this.f1691e0 = f10;
        DimensionBehaviour[] dimensionBehaviourArr = this.O;
        DimensionBehaviour dimensionBehaviour = DimensionBehaviour.FIXED;
        dimensionBehaviourArr[0] = dimensionBehaviour;
        dimensionBehaviourArr[1] = dimensionBehaviour;
        this.f1693f0 = null;
        this.f1695g0 = 0;
        this.f1697h0 = 0;
        this.f1701j0 = null;
        this.f1719s0 = false;
        this.f1721t0 = false;
        this.f1727w0 = 0;
        this.f1729x0 = 0;
        this.f1731y0 = false;
        this.f1733z0 = false;
        float[] fArr = this.A0;
        fArr[0] = -1.0f;
        fArr[1] = -1.0f;
        this.f1700j = -1;
        this.f1702k = -1;
        int[] iArr = this.f1730y;
        iArr[0] = Integer.MAX_VALUE;
        iArr[1] = Integer.MAX_VALUE;
        this.f1704l = 0;
        this.f1706m = 0;
        this.f1714q = 1.0f;
        this.f1720t = 1.0f;
        this.f1712p = Integer.MAX_VALUE;
        this.f1718s = Integer.MAX_VALUE;
        this.f1710o = 0;
        this.f1716r = 0;
        this.f1698i = false;
        this.f1726w = -1;
        this.f1728x = 1.0f;
        this.f1723u0 = false;
        this.f1725v0 = false;
        boolean[] zArr = this.f1694g;
        zArr[0] = true;
        zArr[1] = true;
        this.C = false;
        boolean[] zArr2 = this.N;
        zArr2[0] = false;
        zArr2[1] = false;
    }

    public void a0() {
        ConstraintWidget constraintWidgetH = H();
        if (constraintWidgetH != null && (constraintWidgetH instanceof d) && ((d) H()).Z0()) {
            return;
        }
        int size = this.M.size();
        for (int i10 = 0; i10 < size; i10++) {
            this.M.get(i10).l();
        }
    }

    public void b0(androidx.constraintlayout.solver.c cVar) {
        this.D.m(cVar);
        this.E.m(cVar);
        this.F.m(cVar);
        this.G.m(cVar);
        this.H.m(cVar);
        this.K.m(cVar);
        this.I.m(cVar);
        this.J.m(cVar);
    }

    public void c0(int i10) {
        this.f1683a0 = i10;
        this.A = i10 > 0;
    }

    public void d0(Object obj) {
        this.f1693f0 = obj;
    }

    boolean e() {
        return (this instanceof h) || (this instanceof f);
    }

    public void e0(String str) {
        this.f1699i0 = str;
    }

    /* JADX WARN: Code duplicated, block: B:134:0x0210  */
    /* JADX WARN: Code duplicated, block: B:138:0x021a A[ADDED_TO_REGION] */
    /* JADX WARN: Code duplicated, block: B:142:0x0226  */
    /* JADX WARN: Code duplicated, block: B:145:0x022d  */
    /* JADX WARN: Code duplicated, block: B:147:0x0231  */
    /* JADX WARN: Code duplicated, block: B:148:0x0234  */
    /* JADX WARN: Code duplicated, block: B:151:0x024d  */
    /* JADX WARN: Code duplicated, block: B:153:0x0255  */
    /* JADX WARN: Code duplicated, block: B:167:0x02b0  */
    /* JADX WARN: Code duplicated, block: B:168:0x02b9  */
    /* JADX WARN: Code duplicated, block: B:171:0x02bf  */
    /* JADX WARN: Code duplicated, block: B:172:0x02c8  */
    /* JADX WARN: Code duplicated, block: B:175:0x0330  */
    /* JADX WARN: Code duplicated, block: B:178:0x034b  */
    /* JADX WARN: Code duplicated, block: B:190:0x0396  */
    /* JADX WARN: Code duplicated, block: B:193:0x03a8  */
    /* JADX WARN: Code duplicated, block: B:194:0x03aa  */
    /* JADX WARN: Code duplicated, block: B:196:0x03ad  */
    /* JADX WARN: Code duplicated, block: B:198:0x03b5  */
    /* JADX WARN: Code duplicated, block: B:201:0x03bc  */
    /* JADX WARN: Code duplicated, block: B:203:0x03c0  */
    /* JADX WARN: Code duplicated, block: B:205:0x03c4  */
    /* JADX WARN: Code duplicated, block: B:210:0x03ce  */
    /* JADX WARN: Code duplicated, block: B:213:0x03d4  */
    /* JADX WARN: Code duplicated, block: B:214:0x03db  */
    /* JADX WARN: Code duplicated, block: B:217:0x03e1  */
    /* JADX WARN: Code duplicated, block: B:220:0x03ed  */
    /* JADX WARN: Code duplicated, block: B:222:0x03f1  */
    /* JADX WARN: Code duplicated, block: B:224:0x03fe  */
    /* JADX WARN: Code duplicated, block: B:226:0x0407  */
    /* JADX WARN: Code duplicated, block: B:228:0x0414  */
    /* JADX WARN: Code duplicated, block: B:230:0x0418  */
    /* JADX WARN: Code duplicated, block: B:233:0x0468  */
    /* JADX WARN: Code duplicated, block: B:236:0x0470  */
    /* JADX WARN: Code duplicated, block: B:238:0x0477  */
    /* JADX WARN: Code duplicated, block: B:239:0x0487  */
    /* JADX WARN: Code duplicated, block: B:242:0x049e  */
    /* JADX WARN: Code duplicated, block: B:248:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Multi-variable type inference failed */
    public void f(androidx.constraintlayout.solver.d dVar) {
        boolean z10;
        boolean z11;
        boolean z12;
        boolean z13;
        int i10;
        int i11;
        boolean z14;
        boolean z15;
        DimensionBehaviour dimensionBehaviour;
        DimensionBehaviour dimensionBehaviour2;
        boolean z16;
        int i12;
        boolean z17;
        boolean z18;
        boolean z19;
        boolean z20;
        SolverVariable solverVariable;
        SolverVariable solverVariable2;
        boolean z21;
        ConstraintWidget constraintWidget;
        DependencyNode dependencyNode;
        androidx.constraintlayout.solver.d dVar2;
        SolverVariable solverVariable3;
        SolverVariable solverVariable4;
        SolverVariable solverVariable5;
        int i13;
        int i14;
        int i15;
        int i16;
        int i17;
        int i18;
        int i19;
        ConstraintWidget constraintWidget2;
        SolverVariable solverVariableQ;
        ConstraintAnchor constraintAnchor;
        boolean z22;
        int i20;
        DependencyNode dependencyNode2;
        ConstraintWidget constraintWidget3;
        SolverVariable solverVariableQ2;
        ConstraintWidget constraintWidget4;
        SolverVariable solverVariableQ3;
        int i21;
        boolean zW;
        boolean zY;
        ConstraintWidget constraintWidget5 = this;
        SolverVariable solverVariableQ4 = dVar.q(constraintWidget5.D);
        SolverVariable solverVariableQ5 = dVar.q(constraintWidget5.F);
        SolverVariable solverVariableQ6 = dVar.q(constraintWidget5.E);
        SolverVariable solverVariableQ7 = dVar.q(constraintWidget5.G);
        SolverVariable solverVariableQ8 = dVar.q(constraintWidget5.H);
        boolean z23 = androidx.constraintlayout.solver.d.f1618r;
        androidx.constraintlayout.solver.widgets.analyzer.h hVar = constraintWidget5.f1690e;
        DependencyNode dependencyNode3 = hVar.f1769h;
        if (dependencyNode3.f1750j && hVar.f1770i.f1750j) {
            j jVar = constraintWidget5.f1692f;
            if (jVar.f1769h.f1750j && jVar.f1770i.f1750j) {
                dVar.f(solverVariableQ4, dependencyNode3.f1747g);
                dVar.f(solverVariableQ5, constraintWidget5.f1690e.f1770i.f1747g);
                dVar.f(solverVariableQ6, constraintWidget5.f1692f.f1769h.f1747g);
                dVar.f(solverVariableQ7, constraintWidget5.f1692f.f1770i.f1747g);
                dVar.f(solverVariableQ8, constraintWidget5.f1692f.f1813k.f1747g);
                ConstraintWidget constraintWidget6 = constraintWidget5.P;
                if (constraintWidget6 != null) {
                    boolean z24 = constraintWidget6 != null && constraintWidget6.O[0] == DimensionBehaviour.WRAP_CONTENT;
                    boolean z25 = constraintWidget6 != null && constraintWidget6.O[1] == DimensionBehaviour.WRAP_CONTENT;
                    if (z24 && constraintWidget5.f1694g[0] && !W()) {
                        dVar.h(dVar.q(constraintWidget5.P.F), solverVariableQ5, 0, 8);
                    }
                    if (z25 && constraintWidget5.f1694g[1] && !Y()) {
                        dVar.h(dVar.q(constraintWidget5.P.G), solverVariableQ7, 0, 8);
                        return;
                    }
                    return;
                }
                return;
            }
        }
        ConstraintWidget constraintWidget7 = constraintWidget5.P;
        if (constraintWidget7 != null) {
            z11 = constraintWidget7 != null && constraintWidget7.O[0] == DimensionBehaviour.WRAP_CONTENT;
            z10 = constraintWidget7 != null && constraintWidget7.O[1] == DimensionBehaviour.WRAP_CONTENT;
            if (constraintWidget5.V(0)) {
                ((d) constraintWidget5.P).P0(constraintWidget5, 0);
                zW = true;
            } else {
                zW = W();
            }
            if (constraintWidget5.V(1)) {
                ((d) constraintWidget5.P).P0(constraintWidget5, 1);
                zY = true;
            } else {
                zY = Y();
            }
            if (!zW && z11 && constraintWidget5.f1697h0 != 8 && constraintWidget5.D.f1667d == null && constraintWidget5.F.f1667d == null) {
                dVar.h(dVar.q(constraintWidget5.P.F), solverVariableQ5, 0, 1);
            }
            if (!zY && z10 && constraintWidget5.f1697h0 != 8 && constraintWidget5.E.f1667d == null && constraintWidget5.G.f1667d == null && constraintWidget5.H == null) {
                dVar.h(dVar.q(constraintWidget5.P.G), solverVariableQ7, 0, 1);
            }
            z13 = zW;
            z12 = zY;
        } else {
            z10 = false;
            z11 = false;
            z12 = false;
            z13 = false;
        }
        int i22 = constraintWidget5.Q;
        int i23 = constraintWidget5.f1685b0;
        if (i22 >= i23) {
            i23 = i22;
        }
        int i24 = constraintWidget5.R;
        int i25 = constraintWidget5.f1687c0;
        if (i24 >= i25) {
            i25 = i24;
        }
        DimensionBehaviour[] dimensionBehaviourArr = constraintWidget5.O;
        DimensionBehaviour dimensionBehaviour3 = dimensionBehaviourArr[0];
        DimensionBehaviour dimensionBehaviour4 = DimensionBehaviour.MATCH_CONSTRAINT;
        SolverVariable solverVariable6 = solverVariableQ8;
        boolean z26 = dimensionBehaviour3 != dimensionBehaviour4;
        DimensionBehaviour dimensionBehaviour5 = dimensionBehaviourArr[1];
        SolverVariable solverVariable7 = solverVariableQ7;
        SolverVariable solverVariable8 = solverVariableQ6;
        boolean z27 = dimensionBehaviour5 != dimensionBehaviour4;
        int i26 = constraintWidget5.T;
        constraintWidget5.f1726w = i26;
        int i27 = i23;
        float f10 = constraintWidget5.S;
        constraintWidget5.f1728x = f10;
        int i28 = i25;
        int i29 = constraintWidget5.f1704l;
        int i30 = constraintWidget5.f1706m;
        if (f10 > 0.0f && constraintWidget5.f1697h0 != 8) {
            if (dimensionBehaviour3 == dimensionBehaviour4 && i29 == 0) {
                i29 = 3;
            }
            if (dimensionBehaviour5 == dimensionBehaviour4 && i30 == 0) {
                i30 = 3;
            }
            if (dimensionBehaviour3 == dimensionBehaviour4 && dimensionBehaviour5 == dimensionBehaviour4 && i29 == 3 && i30 == 3) {
                constraintWidget5.I0(z11, z10, z26, z27);
            } else {
                if (dimensionBehaviour3 != dimensionBehaviour4 || i29 != 3) {
                    if (dimensionBehaviour5 == dimensionBehaviour4 && i30 == 3) {
                        constraintWidget5.f1726w = 1;
                        if (i26 == -1) {
                            constraintWidget5.f1728x = 1.0f / f10;
                        }
                        int i31 = (int) (constraintWidget5.f1728x * i22);
                        if (dimensionBehaviour3 != dimensionBehaviour4) {
                            i30 = 4;
                            i11 = i31;
                            i29 = i29;
                            i10 = i27;
                            z14 = false;
                            int[] iArr = constraintWidget5.f1708n;
                            iArr[0] = i29;
                            iArr[1] = i30;
                            constraintWidget5.f1698i = z14;
                            z15 = !z14 && ((i21 = constraintWidget5.f1726w) == 0 || i21 == -1);
                            dimensionBehaviour = constraintWidget5.O[0];
                            dimensionBehaviour2 = DimensionBehaviour.WRAP_CONTENT;
                            if (dimensionBehaviour == dimensionBehaviour2 || !(constraintWidget5 instanceof d)) {
                                z16 = false;
                            } else {
                                z16 = true;
                            }
                            if (z16) {
                                i12 = 0;
                            } else {
                                i12 = i10;
                            }
                            z17 = !constraintWidget5.K.j();
                            boolean[] zArr = constraintWidget5.N;
                            z18 = zArr[0];
                            z19 = zArr[1];
                            if (constraintWidget5.f1700j != 2) {
                                androidx.constraintlayout.solver.widgets.analyzer.h hVar2 = constraintWidget5.f1690e;
                                dependencyNode2 = hVar2.f1769h;
                                if (dependencyNode2.f1750j || !hVar2.f1770i.f1750j) {
                                    constraintWidget3 = constraintWidget5.P;
                                    if (constraintWidget3 != null) {
                                        solverVariableQ2 = dVar.q(constraintWidget3.F);
                                    } else {
                                        solverVariableQ2 = null;
                                    }
                                    constraintWidget4 = constraintWidget5.P;
                                    if (constraintWidget4 != null) {
                                        solverVariableQ3 = dVar.q(constraintWidget4.D);
                                    } else {
                                        solverVariableQ3 = null;
                                    }
                                    z21 = z11;
                                    solverVariable = solverVariableQ5;
                                    solverVariable2 = solverVariableQ4;
                                    z20 = z10;
                                    h(dVar, true, z21, z20, constraintWidget5.f1694g[0], solverVariableQ3, solverVariableQ2, constraintWidget5.O[0], z16, constraintWidget5.D, constraintWidget5.F, constraintWidget5.U, i12, constraintWidget5.f1685b0, constraintWidget5.f1730y[0], constraintWidget5.f1689d0, z15, z13, z12, z18, i29, i30, constraintWidget5.f1710o, constraintWidget5.f1712p, constraintWidget5.f1714q, z17);
                                } else {
                                    dVar.f(solverVariableQ4, dependencyNode2.f1747g);
                                    dVar.f(solverVariableQ5, constraintWidget5.f1690e.f1770i.f1747g);
                                    if (constraintWidget5.P != null && z11 && constraintWidget5.f1694g[0] && !W()) {
                                        dVar.h(dVar.q(constraintWidget5.P.F), solverVariableQ5, 0, 8);
                                    }
                                    z20 = z10;
                                    z21 = z11;
                                    dimensionBehaviour2 = dimensionBehaviour2;
                                    z14 = z14;
                                    solverVariable = solverVariableQ5;
                                    solverVariable2 = solverVariableQ4;
                                    solverVariable6 = solverVariable6;
                                    solverVariable7 = solverVariable7;
                                    solverVariable8 = solverVariable8;
                                    constraintWidget = constraintWidget5;
                                }
                                j jVar2 = constraintWidget.f1692f;
                                dependencyNode = jVar2.f1769h;
                                if (dependencyNode.f1750j || !jVar2.f1770i.f1750j) {
                                    dVar2 = dVar;
                                    solverVariable3 = solverVariable6;
                                    solverVariable4 = solverVariable7;
                                    solverVariable5 = solverVariable8;
                                    i13 = 8;
                                    i14 = 0;
                                    i15 = 1;
                                    i16 = 1;
                                } else {
                                    dVar2 = dVar;
                                    solverVariable5 = solverVariable8;
                                    dVar2.f(solverVariable5, dependencyNode.f1747g);
                                    solverVariable4 = solverVariable7;
                                    dVar2.f(solverVariable4, constraintWidget.f1692f.f1770i.f1747g);
                                    solverVariable3 = solverVariable6;
                                    dVar2.f(solverVariable3, constraintWidget.f1692f.f1813k.f1747g);
                                    ConstraintWidget constraintWidget8 = constraintWidget.P;
                                    if (constraintWidget8 == null || z12 || !z20) {
                                        i13 = 8;
                                        i14 = 0;
                                        i15 = 1;
                                    } else {
                                        i15 = 1;
                                        if (constraintWidget.f1694g[1]) {
                                            i13 = 8;
                                            i14 = 0;
                                            dVar2.h(dVar2.q(constraintWidget8.G), solverVariable4, 0, 8);
                                        } else {
                                            i13 = 8;
                                            i14 = 0;
                                        }
                                    }
                                    i16 = i14;
                                }
                                if (constraintWidget.f1702k == 2) {
                                    i17 = i14;
                                } else {
                                    i17 = i16;
                                }
                                if (i17 == 0) {
                                    if (constraintWidget.O[i15] == dimensionBehaviour2 || !(constraintWidget instanceof d)) {
                                        i18 = i14;
                                    } else {
                                        i18 = i15;
                                    }
                                    if (i18 != 0) {
                                        i11 = i14;
                                    }
                                    if (z14 || !((i20 = constraintWidget.f1726w) == i15 || i20 == -1)) {
                                        i19 = i14;
                                    } else {
                                        i19 = i15;
                                    }
                                    constraintWidget2 = constraintWidget.P;
                                    if (constraintWidget2 != null) {
                                        solverVariableQ = dVar2.q(constraintWidget2.G);
                                    } else {
                                        solverVariableQ = null;
                                    }
                                    ConstraintWidget constraintWidget9 = constraintWidget.P;
                                    SolverVariable solverVariableQ9 = constraintWidget9 != null ? dVar2.q(constraintWidget9.E) : null;
                                    if (constraintWidget.f1683a0 <= 0 || constraintWidget.f1697h0 == i13) {
                                        dVar2.e(solverVariable3, solverVariable5, o(), i13);
                                        constraintAnchor = constraintWidget.H.f1667d;
                                        if (constraintAnchor != null) {
                                            dVar2.e(solverVariable3, dVar2.q(constraintAnchor), i14, i13);
                                            if (z20) {
                                                dVar2.h(solverVariableQ, dVar2.q(constraintWidget.G), i14, 5);
                                            }
                                            z22 = i14;
                                        } else {
                                            if (constraintWidget.f1697h0 == i13) {
                                                dVar2.e(solverVariable3, solverVariable5, i14, i13);
                                            }
                                            z22 = z17;
                                        }
                                    } else {
                                        z22 = z17;
                                    }
                                    h(dVar, false, z20, z21, constraintWidget.f1694g[i15], solverVariableQ9, solverVariableQ, constraintWidget.O[i15], i18, constraintWidget.E, constraintWidget.G, constraintWidget.V, i11, constraintWidget.f1687c0, constraintWidget.f1730y[i15], constraintWidget.f1691e0, i19, z12, z13, z19, i30, i29, constraintWidget.f1716r, constraintWidget.f1718s, constraintWidget.f1720t, z22);
                                }
                                if (z14) {
                                    if (this.f1726w == 1) {
                                        dVar.k(solverVariable4, solverVariable5, solverVariable, solverVariable2, this.f1728x, 8);
                                    } else {
                                        dVar.k(solverVariable, solverVariable2, solverVariable4, solverVariable5, this.f1728x, 8);
                                    }
                                }
                                if (this.K.j()) {
                                    dVar.b(this, this.K.g().e(), (float) Math.toRadians(this.f1732z + 90.0f), this.K.c());
                                }
                            }
                            z20 = z10;
                            solverVariable = solverVariableQ5;
                            solverVariable2 = solverVariableQ4;
                            z21 = z11;
                            constraintWidget = this;
                            j jVar3 = constraintWidget.f1692f;
                            dependencyNode = jVar3.f1769h;
                            if (dependencyNode.f1750j) {
                                dVar2 = dVar;
                                solverVariable3 = solverVariable6;
                                solverVariable4 = solverVariable7;
                                solverVariable5 = solverVariable8;
                                i13 = 8;
                                i14 = 0;
                                i15 = 1;
                                i16 = 1;
                            } else {
                                dVar2 = dVar;
                                solverVariable3 = solverVariable6;
                                solverVariable4 = solverVariable7;
                                solverVariable5 = solverVariable8;
                                i13 = 8;
                                i14 = 0;
                                i15 = 1;
                                i16 = 1;
                            }
                            if (constraintWidget.f1702k == 2) {
                                i17 = i14;
                            } else {
                                i17 = i16;
                            }
                            if (i17 == 0) {
                                if (constraintWidget.O[i15] == dimensionBehaviour2) {
                                    i18 = i14;
                                } else {
                                    i18 = i14;
                                }
                                if (i18 != 0) {
                                    i11 = i14;
                                }
                                if (z14) {
                                    i19 = i14;
                                } else {
                                    i19 = i14;
                                }
                                constraintWidget2 = constraintWidget.P;
                                if (constraintWidget2 != null) {
                                    solverVariableQ = dVar2.q(constraintWidget2.G);
                                } else {
                                    solverVariableQ = null;
                                }
                                ConstraintWidget constraintWidget10 = constraintWidget.P;
                                if (constraintWidget10 != null) {
                                }
                                if (constraintWidget.f1683a0 <= 0) {
                                    dVar2.e(solverVariable3, solverVariable5, o(), i13);
                                    constraintAnchor = constraintWidget.H.f1667d;
                                    if (constraintAnchor != null) {
                                        dVar2.e(solverVariable3, dVar2.q(constraintAnchor), i14, i13);
                                        if (z20) {
                                            dVar2.h(solverVariableQ, dVar2.q(constraintWidget.G), i14, 5);
                                        }
                                        z22 = i14;
                                    } else {
                                        if (constraintWidget.f1697h0 == i13) {
                                            dVar2.e(solverVariable3, solverVariable5, i14, i13);
                                        }
                                        z22 = z17;
                                    }
                                } else {
                                    dVar2.e(solverVariable3, solverVariable5, o(), i13);
                                    constraintAnchor = constraintWidget.H.f1667d;
                                    if (constraintAnchor != null) {
                                        dVar2.e(solverVariable3, dVar2.q(constraintAnchor), i14, i13);
                                        if (z20) {
                                            dVar2.h(solverVariableQ, dVar2.q(constraintWidget.G), i14, 5);
                                        }
                                        z22 = i14;
                                    } else {
                                        if (constraintWidget.f1697h0 == i13) {
                                            dVar2.e(solverVariable3, solverVariable5, i14, i13);
                                        }
                                        z22 = z17;
                                    }
                                }
                                h(dVar, false, z20, z21, constraintWidget.f1694g[i15], solverVariableQ9, solverVariableQ, constraintWidget.O[i15], i18, constraintWidget.E, constraintWidget.G, constraintWidget.V, i11, constraintWidget.f1687c0, constraintWidget.f1730y[i15], constraintWidget.f1691e0, i19, z12, z13, z19, i30, i29, constraintWidget.f1716r, constraintWidget.f1718s, constraintWidget.f1720t, z22);
                            }
                            if (z14) {
                                if (this.f1726w == 1) {
                                    dVar.k(solverVariable4, solverVariable5, solverVariable, solverVariable2, this.f1728x, 8);
                                } else {
                                    dVar.k(solverVariable, solverVariable2, solverVariable4, solverVariable5, this.f1728x, 8);
                                }
                            }
                            if (this.K.j()) {
                                dVar.b(this, this.K.g().e(), (float) Math.toRadians(this.f1732z + 90.0f), this.K.c());
                            }
                        }
                        i11 = i31;
                        i30 = i30;
                        i29 = i29;
                        i10 = i27;
                    }
                    z14 = true;
                    int[] iArr2 = constraintWidget5.f1708n;
                    iArr2[0] = i29;
                    iArr2[1] = i30;
                    constraintWidget5.f1698i = z14;
                    if (z14) {
                    }
                    dimensionBehaviour = constraintWidget5.O[0];
                    dimensionBehaviour2 = DimensionBehaviour.WRAP_CONTENT;
                    if (dimensionBehaviour == dimensionBehaviour2) {
                        z16 = false;
                    } else {
                        z16 = false;
                    }
                    if (z16) {
                        i12 = 0;
                    } else {
                        i12 = i10;
                    }
                    z17 = !constraintWidget5.K.j();
                    boolean[] zArr2 = constraintWidget5.N;
                    z18 = zArr2[0];
                    z19 = zArr2[1];
                    if (constraintWidget5.f1700j != 2) {
                        androidx.constraintlayout.solver.widgets.analyzer.h hVar3 = constraintWidget5.f1690e;
                        dependencyNode2 = hVar3.f1769h;
                        if (dependencyNode2.f1750j) {
                        }
                        constraintWidget3 = constraintWidget5.P;
                        if (constraintWidget3 != null) {
                            solverVariableQ2 = dVar.q(constraintWidget3.F);
                        } else {
                            solverVariableQ2 = null;
                        }
                        constraintWidget4 = constraintWidget5.P;
                        if (constraintWidget4 != null) {
                            solverVariableQ3 = dVar.q(constraintWidget4.D);
                        } else {
                            solverVariableQ3 = null;
                        }
                        z21 = z11;
                        solverVariable = solverVariableQ5;
                        solverVariable2 = solverVariableQ4;
                        z20 = z10;
                        h(dVar, true, z21, z20, constraintWidget5.f1694g[0], solverVariableQ3, solverVariableQ2, constraintWidget5.O[0], z16, constraintWidget5.D, constraintWidget5.F, constraintWidget5.U, i12, constraintWidget5.f1685b0, constraintWidget5.f1730y[0], constraintWidget5.f1689d0, z15, z13, z12, z18, i29, i30, constraintWidget5.f1710o, constraintWidget5.f1712p, constraintWidget5.f1714q, z17);
                    } else {
                        z20 = z10;
                        solverVariable = solverVariableQ5;
                        solverVariable2 = solverVariableQ4;
                        z21 = z11;
                    }
                    constraintWidget = this;
                    j jVar4 = constraintWidget.f1692f;
                    dependencyNode = jVar4.f1769h;
                    if (dependencyNode.f1750j) {
                        dVar2 = dVar;
                        solverVariable3 = solverVariable6;
                        solverVariable4 = solverVariable7;
                        solverVariable5 = solverVariable8;
                        i13 = 8;
                        i14 = 0;
                        i15 = 1;
                        i16 = 1;
                    } else {
                        dVar2 = dVar;
                        solverVariable3 = solverVariable6;
                        solverVariable4 = solverVariable7;
                        solverVariable5 = solverVariable8;
                        i13 = 8;
                        i14 = 0;
                        i15 = 1;
                        i16 = 1;
                    }
                    if (constraintWidget.f1702k == 2) {
                        i17 = i14;
                    } else {
                        i17 = i16;
                    }
                    if (i17 == 0) {
                        if (constraintWidget.O[i15] == dimensionBehaviour2) {
                            i18 = i14;
                        } else {
                            i18 = i14;
                        }
                        if (i18 != 0) {
                            i11 = i14;
                        }
                        if (z14) {
                            i19 = i14;
                        } else {
                            i19 = i14;
                        }
                        constraintWidget2 = constraintWidget.P;
                        if (constraintWidget2 != null) {
                            solverVariableQ = dVar2.q(constraintWidget2.G);
                        } else {
                            solverVariableQ = null;
                        }
                        ConstraintWidget constraintWidget11 = constraintWidget.P;
                        if (constraintWidget11 != null) {
                        }
                        if (constraintWidget.f1683a0 <= 0) {
                            dVar2.e(solverVariable3, solverVariable5, o(), i13);
                            constraintAnchor = constraintWidget.H.f1667d;
                            if (constraintAnchor != null) {
                                dVar2.e(solverVariable3, dVar2.q(constraintAnchor), i14, i13);
                                if (z20) {
                                    dVar2.h(solverVariableQ, dVar2.q(constraintWidget.G), i14, 5);
                                }
                                z22 = i14;
                            } else {
                                if (constraintWidget.f1697h0 == i13) {
                                    dVar2.e(solverVariable3, solverVariable5, i14, i13);
                                }
                                z22 = z17;
                            }
                        } else {
                            dVar2.e(solverVariable3, solverVariable5, o(), i13);
                            constraintAnchor = constraintWidget.H.f1667d;
                            if (constraintAnchor != null) {
                                dVar2.e(solverVariable3, dVar2.q(constraintAnchor), i14, i13);
                                if (z20) {
                                    dVar2.h(solverVariableQ, dVar2.q(constraintWidget.G), i14, 5);
                                }
                                z22 = i14;
                            } else {
                                if (constraintWidget.f1697h0 == i13) {
                                    dVar2.e(solverVariable3, solverVariable5, i14, i13);
                                }
                                z22 = z17;
                            }
                        }
                        h(dVar, false, z20, z21, constraintWidget.f1694g[i15], solverVariableQ9, solverVariableQ, constraintWidget.O[i15], i18, constraintWidget.E, constraintWidget.G, constraintWidget.V, i11, constraintWidget.f1687c0, constraintWidget.f1730y[i15], constraintWidget.f1691e0, i19, z12, z13, z19, i30, i29, constraintWidget.f1716r, constraintWidget.f1718s, constraintWidget.f1720t, z22);
                    }
                    if (z14) {
                        if (this.f1726w == 1) {
                            dVar.k(solverVariable4, solverVariable5, solverVariable, solverVariable2, this.f1728x, 8);
                        } else {
                            dVar.k(solverVariable, solverVariable2, solverVariable4, solverVariable5, this.f1728x, 8);
                        }
                    }
                    if (this.K.j()) {
                        dVar.b(this, this.K.g().e(), (float) Math.toRadians(this.f1732z + 90.0f), this.K.c());
                    }
                }
                constraintWidget5.f1726w = 0;
                i10 = (int) (f10 * i24);
                if (dimensionBehaviour5 == dimensionBehaviour4) {
                    i11 = i28;
                    z14 = true;
                    int[] iArr3 = constraintWidget5.f1708n;
                    iArr3[0] = i29;
                    iArr3[1] = i30;
                    constraintWidget5.f1698i = z14;
                    if (z14) {
                    }
                    dimensionBehaviour = constraintWidget5.O[0];
                    dimensionBehaviour2 = DimensionBehaviour.WRAP_CONTENT;
                    if (dimensionBehaviour == dimensionBehaviour2) {
                        z16 = false;
                    } else {
                        z16 = false;
                    }
                    if (z16) {
                        i12 = 0;
                    } else {
                        i12 = i10;
                    }
                    z17 = !constraintWidget5.K.j();
                    boolean[] zArr3 = constraintWidget5.N;
                    z18 = zArr3[0];
                    z19 = zArr3[1];
                    if (constraintWidget5.f1700j != 2) {
                        androidx.constraintlayout.solver.widgets.analyzer.h hVar4 = constraintWidget5.f1690e;
                        dependencyNode2 = hVar4.f1769h;
                        if (dependencyNode2.f1750j) {
                        }
                        constraintWidget3 = constraintWidget5.P;
                        if (constraintWidget3 != null) {
                            solverVariableQ2 = dVar.q(constraintWidget3.F);
                        } else {
                            solverVariableQ2 = null;
                        }
                        constraintWidget4 = constraintWidget5.P;
                        if (constraintWidget4 != null) {
                            solverVariableQ3 = dVar.q(constraintWidget4.D);
                        } else {
                            solverVariableQ3 = null;
                        }
                        z21 = z11;
                        solverVariable = solverVariableQ5;
                        solverVariable2 = solverVariableQ4;
                        z20 = z10;
                        h(dVar, true, z21, z20, constraintWidget5.f1694g[0], solverVariableQ3, solverVariableQ2, constraintWidget5.O[0], z16, constraintWidget5.D, constraintWidget5.F, constraintWidget5.U, i12, constraintWidget5.f1685b0, constraintWidget5.f1730y[0], constraintWidget5.f1689d0, z15, z13, z12, z18, i29, i30, constraintWidget5.f1710o, constraintWidget5.f1712p, constraintWidget5.f1714q, z17);
                    } else {
                        z20 = z10;
                        solverVariable = solverVariableQ5;
                        solverVariable2 = solverVariableQ4;
                        z21 = z11;
                    }
                    constraintWidget = this;
                    j jVar5 = constraintWidget.f1692f;
                    dependencyNode = jVar5.f1769h;
                    if (dependencyNode.f1750j) {
                        dVar2 = dVar;
                        solverVariable3 = solverVariable6;
                        solverVariable4 = solverVariable7;
                        solverVariable5 = solverVariable8;
                        i13 = 8;
                        i14 = 0;
                        i15 = 1;
                        i16 = 1;
                    } else {
                        dVar2 = dVar;
                        solverVariable3 = solverVariable6;
                        solverVariable4 = solverVariable7;
                        solverVariable5 = solverVariable8;
                        i13 = 8;
                        i14 = 0;
                        i15 = 1;
                        i16 = 1;
                    }
                    if (constraintWidget.f1702k == 2) {
                        i17 = i14;
                    } else {
                        i17 = i16;
                    }
                    if (i17 == 0) {
                        if (constraintWidget.O[i15] == dimensionBehaviour2) {
                            i18 = i14;
                        } else {
                            i18 = i14;
                        }
                        if (i18 != 0) {
                            i11 = i14;
                        }
                        if (z14) {
                            i19 = i14;
                        } else {
                            i19 = i14;
                        }
                        constraintWidget2 = constraintWidget.P;
                        if (constraintWidget2 != null) {
                            solverVariableQ = dVar2.q(constraintWidget2.G);
                        } else {
                            solverVariableQ = null;
                        }
                        ConstraintWidget constraintWidget12 = constraintWidget.P;
                        if (constraintWidget12 != null) {
                        }
                        if (constraintWidget.f1683a0 <= 0) {
                            dVar2.e(solverVariable3, solverVariable5, o(), i13);
                            constraintAnchor = constraintWidget.H.f1667d;
                            if (constraintAnchor != null) {
                                dVar2.e(solverVariable3, dVar2.q(constraintAnchor), i14, i13);
                                if (z20) {
                                    dVar2.h(solverVariableQ, dVar2.q(constraintWidget.G), i14, 5);
                                }
                                z22 = i14;
                            } else {
                                if (constraintWidget.f1697h0 == i13) {
                                    dVar2.e(solverVariable3, solverVariable5, i14, i13);
                                }
                                z22 = z17;
                            }
                        } else {
                            dVar2.e(solverVariable3, solverVariable5, o(), i13);
                            constraintAnchor = constraintWidget.H.f1667d;
                            if (constraintAnchor != null) {
                                dVar2.e(solverVariable3, dVar2.q(constraintAnchor), i14, i13);
                                if (z20) {
                                    dVar2.h(solverVariableQ, dVar2.q(constraintWidget.G), i14, 5);
                                }
                                z22 = i14;
                            } else {
                                if (constraintWidget.f1697h0 == i13) {
                                    dVar2.e(solverVariable3, solverVariable5, i14, i13);
                                }
                                z22 = z17;
                            }
                        }
                        h(dVar, false, z20, z21, constraintWidget.f1694g[i15], solverVariableQ9, solverVariableQ, constraintWidget.O[i15], i18, constraintWidget.E, constraintWidget.G, constraintWidget.V, i11, constraintWidget.f1687c0, constraintWidget.f1730y[i15], constraintWidget.f1691e0, i19, z12, z13, z19, i30, i29, constraintWidget.f1716r, constraintWidget.f1718s, constraintWidget.f1720t, z22);
                    }
                    if (z14) {
                        if (this.f1726w == 1) {
                            dVar.k(solverVariable4, solverVariable5, solverVariable, solverVariable2, this.f1728x, 8);
                        } else {
                            dVar.k(solverVariable, solverVariable2, solverVariable4, solverVariable5, this.f1728x, 8);
                        }
                    }
                    if (this.K.j()) {
                        dVar.b(this, this.K.g().e(), (float) Math.toRadians(this.f1732z + 90.0f), this.K.c());
                    }
                }
                i29 = 4;
                i30 = i30;
            }
            i10 = i27;
            i11 = i28;
            z14 = true;
            int[] iArr4 = constraintWidget5.f1708n;
            iArr4[0] = i29;
            iArr4[1] = i30;
            constraintWidget5.f1698i = z14;
            if (z14) {
            }
            dimensionBehaviour = constraintWidget5.O[0];
            dimensionBehaviour2 = DimensionBehaviour.WRAP_CONTENT;
            if (dimensionBehaviour == dimensionBehaviour2) {
                z16 = false;
            } else {
                z16 = false;
            }
            if (z16) {
                i12 = 0;
            } else {
                i12 = i10;
            }
            z17 = !constraintWidget5.K.j();
            boolean[] zArr4 = constraintWidget5.N;
            z18 = zArr4[0];
            z19 = zArr4[1];
            if (constraintWidget5.f1700j != 2) {
                androidx.constraintlayout.solver.widgets.analyzer.h hVar5 = constraintWidget5.f1690e;
                dependencyNode2 = hVar5.f1769h;
                if (dependencyNode2.f1750j) {
                }
                constraintWidget3 = constraintWidget5.P;
                if (constraintWidget3 != null) {
                    solverVariableQ2 = dVar.q(constraintWidget3.F);
                } else {
                    solverVariableQ2 = null;
                }
                constraintWidget4 = constraintWidget5.P;
                if (constraintWidget4 != null) {
                    solverVariableQ3 = dVar.q(constraintWidget4.D);
                } else {
                    solverVariableQ3 = null;
                }
                z21 = z11;
                solverVariable = solverVariableQ5;
                solverVariable2 = solverVariableQ4;
                z20 = z10;
                h(dVar, true, z21, z20, constraintWidget5.f1694g[0], solverVariableQ3, solverVariableQ2, constraintWidget5.O[0], z16, constraintWidget5.D, constraintWidget5.F, constraintWidget5.U, i12, constraintWidget5.f1685b0, constraintWidget5.f1730y[0], constraintWidget5.f1689d0, z15, z13, z12, z18, i29, i30, constraintWidget5.f1710o, constraintWidget5.f1712p, constraintWidget5.f1714q, z17);
            } else {
                z20 = z10;
                solverVariable = solverVariableQ5;
                solverVariable2 = solverVariableQ4;
                z21 = z11;
            }
            constraintWidget = this;
            j jVar6 = constraintWidget.f1692f;
            dependencyNode = jVar6.f1769h;
            if (dependencyNode.f1750j) {
                dVar2 = dVar;
                solverVariable3 = solverVariable6;
                solverVariable4 = solverVariable7;
                solverVariable5 = solverVariable8;
                i13 = 8;
                i14 = 0;
                i15 = 1;
                i16 = 1;
            } else {
                dVar2 = dVar;
                solverVariable3 = solverVariable6;
                solverVariable4 = solverVariable7;
                solverVariable5 = solverVariable8;
                i13 = 8;
                i14 = 0;
                i15 = 1;
                i16 = 1;
            }
            if (constraintWidget.f1702k == 2) {
                i17 = i14;
            } else {
                i17 = i16;
            }
            if (i17 == 0) {
                if (constraintWidget.O[i15] == dimensionBehaviour2) {
                    i18 = i14;
                } else {
                    i18 = i14;
                }
                if (i18 != 0) {
                    i11 = i14;
                }
                if (z14) {
                    i19 = i14;
                } else {
                    i19 = i14;
                }
                constraintWidget2 = constraintWidget.P;
                if (constraintWidget2 != null) {
                    solverVariableQ = dVar2.q(constraintWidget2.G);
                } else {
                    solverVariableQ = null;
                }
                ConstraintWidget constraintWidget13 = constraintWidget.P;
                if (constraintWidget13 != null) {
                }
                if (constraintWidget.f1683a0 <= 0) {
                    dVar2.e(solverVariable3, solverVariable5, o(), i13);
                    constraintAnchor = constraintWidget.H.f1667d;
                    if (constraintAnchor != null) {
                        dVar2.e(solverVariable3, dVar2.q(constraintAnchor), i14, i13);
                        if (z20) {
                            dVar2.h(solverVariableQ, dVar2.q(constraintWidget.G), i14, 5);
                        }
                        z22 = i14;
                    } else {
                        if (constraintWidget.f1697h0 == i13) {
                            dVar2.e(solverVariable3, solverVariable5, i14, i13);
                        }
                        z22 = z17;
                    }
                } else {
                    dVar2.e(solverVariable3, solverVariable5, o(), i13);
                    constraintAnchor = constraintWidget.H.f1667d;
                    if (constraintAnchor != null) {
                        dVar2.e(solverVariable3, dVar2.q(constraintAnchor), i14, i13);
                        if (z20) {
                            dVar2.h(solverVariableQ, dVar2.q(constraintWidget.G), i14, 5);
                        }
                        z22 = i14;
                    } else {
                        if (constraintWidget.f1697h0 == i13) {
                            dVar2.e(solverVariable3, solverVariable5, i14, i13);
                        }
                        z22 = z17;
                    }
                }
                h(dVar, false, z20, z21, constraintWidget.f1694g[i15], solverVariableQ9, solverVariableQ, constraintWidget.O[i15], i18, constraintWidget.E, constraintWidget.G, constraintWidget.V, i11, constraintWidget.f1687c0, constraintWidget.f1730y[i15], constraintWidget.f1691e0, i19, z12, z13, z19, i30, i29, constraintWidget.f1716r, constraintWidget.f1718s, constraintWidget.f1720t, z22);
            }
            if (z14) {
                if (this.f1726w == 1) {
                    dVar.k(solverVariable4, solverVariable5, solverVariable, solverVariable2, this.f1728x, 8);
                } else {
                    dVar.k(solverVariable, solverVariable2, solverVariable4, solverVariable5, this.f1728x, 8);
                }
            }
            if (this.K.j()) {
                dVar.b(this, this.K.g().e(), (float) Math.toRadians(this.f1732z + 90.0f), this.K.c());
            }
        }
        i30 = i30;
        i29 = i29;
        i10 = i27;
        i11 = i28;
        z14 = false;
        int[] iArr5 = constraintWidget5.f1708n;
        iArr5[0] = i29;
        iArr5[1] = i30;
        constraintWidget5.f1698i = z14;
        if (z14) {
        }
        dimensionBehaviour = constraintWidget5.O[0];
        dimensionBehaviour2 = DimensionBehaviour.WRAP_CONTENT;
        if (dimensionBehaviour == dimensionBehaviour2) {
            z16 = false;
        } else {
            z16 = false;
        }
        if (z16) {
            i12 = 0;
        } else {
            i12 = i10;
        }
        z17 = !constraintWidget5.K.j();
        boolean[] zArr5 = constraintWidget5.N;
        z18 = zArr5[0];
        z19 = zArr5[1];
        if (constraintWidget5.f1700j != 2) {
            androidx.constraintlayout.solver.widgets.analyzer.h hVar6 = constraintWidget5.f1690e;
            dependencyNode2 = hVar6.f1769h;
            if (dependencyNode2.f1750j) {
            }
            constraintWidget3 = constraintWidget5.P;
            if (constraintWidget3 != null) {
                solverVariableQ2 = dVar.q(constraintWidget3.F);
            } else {
                solverVariableQ2 = null;
            }
            constraintWidget4 = constraintWidget5.P;
            if (constraintWidget4 != null) {
                solverVariableQ3 = dVar.q(constraintWidget4.D);
            } else {
                solverVariableQ3 = null;
            }
            z21 = z11;
            solverVariable = solverVariableQ5;
            solverVariable2 = solverVariableQ4;
            z20 = z10;
            h(dVar, true, z21, z20, constraintWidget5.f1694g[0], solverVariableQ3, solverVariableQ2, constraintWidget5.O[0], z16, constraintWidget5.D, constraintWidget5.F, constraintWidget5.U, i12, constraintWidget5.f1685b0, constraintWidget5.f1730y[0], constraintWidget5.f1689d0, z15, z13, z12, z18, i29, i30, constraintWidget5.f1710o, constraintWidget5.f1712p, constraintWidget5.f1714q, z17);
        } else {
            z20 = z10;
            solverVariable = solverVariableQ5;
            solverVariable2 = solverVariableQ4;
            z21 = z11;
        }
        constraintWidget = this;
        j jVar7 = constraintWidget.f1692f;
        dependencyNode = jVar7.f1769h;
        if (dependencyNode.f1750j) {
            dVar2 = dVar;
            solverVariable3 = solverVariable6;
            solverVariable4 = solverVariable7;
            solverVariable5 = solverVariable8;
            i13 = 8;
            i14 = 0;
            i15 = 1;
            i16 = 1;
        } else {
            dVar2 = dVar;
            solverVariable3 = solverVariable6;
            solverVariable4 = solverVariable7;
            solverVariable5 = solverVariable8;
            i13 = 8;
            i14 = 0;
            i15 = 1;
            i16 = 1;
        }
        if (constraintWidget.f1702k == 2) {
            i17 = i14;
        } else {
            i17 = i16;
        }
        if (i17 == 0) {
            if (constraintWidget.O[i15] == dimensionBehaviour2) {
                i18 = i14;
            } else {
                i18 = i14;
            }
            if (i18 != 0) {
                i11 = i14;
            }
            if (z14) {
                i19 = i14;
            } else {
                i19 = i14;
            }
            constraintWidget2 = constraintWidget.P;
            if (constraintWidget2 != null) {
                solverVariableQ = dVar2.q(constraintWidget2.G);
            } else {
                solverVariableQ = null;
            }
            ConstraintWidget constraintWidget14 = constraintWidget.P;
            if (constraintWidget14 != null) {
            }
            if (constraintWidget.f1683a0 <= 0) {
                dVar2.e(solverVariable3, solverVariable5, o(), i13);
                constraintAnchor = constraintWidget.H.f1667d;
                if (constraintAnchor != null) {
                    dVar2.e(solverVariable3, dVar2.q(constraintAnchor), i14, i13);
                    if (z20) {
                        dVar2.h(solverVariableQ, dVar2.q(constraintWidget.G), i14, 5);
                    }
                    z22 = i14;
                } else {
                    if (constraintWidget.f1697h0 == i13) {
                        dVar2.e(solverVariable3, solverVariable5, i14, i13);
                    }
                    z22 = z17;
                }
            } else {
                dVar2.e(solverVariable3, solverVariable5, o(), i13);
                constraintAnchor = constraintWidget.H.f1667d;
                if (constraintAnchor != null) {
                    dVar2.e(solverVariable3, dVar2.q(constraintAnchor), i14, i13);
                    if (z20) {
                        dVar2.h(solverVariableQ, dVar2.q(constraintWidget.G), i14, 5);
                    }
                    z22 = i14;
                } else {
                    if (constraintWidget.f1697h0 == i13) {
                        dVar2.e(solverVariable3, solverVariable5, i14, i13);
                    }
                    z22 = z17;
                }
            }
            h(dVar, false, z20, z21, constraintWidget.f1694g[i15], solverVariableQ9, solverVariableQ, constraintWidget.O[i15], i18, constraintWidget.E, constraintWidget.G, constraintWidget.V, i11, constraintWidget.f1687c0, constraintWidget.f1730y[i15], constraintWidget.f1691e0, i19, z12, z13, z19, i30, i29, constraintWidget.f1716r, constraintWidget.f1718s, constraintWidget.f1720t, z22);
        }
        if (z14) {
            if (this.f1726w == 1) {
                dVar.k(solverVariable4, solverVariable5, solverVariable, solverVariable2, this.f1728x, 8);
            } else {
                dVar.k(solverVariable, solverVariable2, solverVariable4, solverVariable5, this.f1728x, 8);
            }
        }
        if (this.K.j()) {
            dVar.b(this, this.K.g().e(), (float) Math.toRadians(this.f1732z + 90.0f), this.K.c());
        }
    }

    /* JADX WARN: Code duplicated, block: B:39:0x0086 A[PHI: r0
      0x0086: PHI (r0v2 int) = (r0v1 int), (r0v0 int), (r0v0 int), (r0v0 int), (r0v0 int), (r0v0 int) binds: [B:46:0x0086, B:36:0x007f, B:24:0x0051, B:26:0x0057, B:28:0x0063, B:30:0x0067] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:39:0x0086 -> B:40:0x0087). Please report as a decompilation issue!!! */
    public void f0(String str) {
        float fAbs;
        int i10 = 0;
        if (str == null || str.length() == 0) {
            this.S = 0.0f;
            return;
        }
        int length = str.length();
        int iIndexOf = str.indexOf(44);
        int i11 = 0;
        int i12 = -1;
        if (iIndexOf > 0 && iIndexOf < length - 1) {
            String strSubstring = str.substring(0, iIndexOf);
            if (!strSubstring.equalsIgnoreCase("W")) {
                i11 = strSubstring.equalsIgnoreCase("H") ? 1 : -1;
            }
            i12 = i11;
            i11 = iIndexOf + 1;
        }
        int iIndexOf2 = str.indexOf(58);
        try {
            if (iIndexOf2 < 0 || iIndexOf2 >= length - 1) {
                String strSubstring2 = str.substring(i11);
                if (strSubstring2.length() > 0) {
                    fAbs = Float.parseFloat(strSubstring2);
                } else {
                    fAbs = i10;
                }
            } else {
                String strSubstring3 = str.substring(i11, iIndexOf2);
                String strSubstring4 = str.substring(iIndexOf2 + 1);
                if (strSubstring3.length() <= 0 || strSubstring4.length() <= 0) {
                    fAbs = i10;
                } else {
                    float f10 = Float.parseFloat(strSubstring3);
                    float f11 = Float.parseFloat(strSubstring4);
                    if (f10 <= 0.0f || f11 <= 0.0f) {
                        fAbs = i10;
                    } else {
                        fAbs = i12 == 1 ? Math.abs(f11 / f10) : Math.abs(f10 / f11);
                    }
                }
            }
        } catch (NumberFormatException unused) {
        }
        i10 = (fAbs > i10 ? 1 : (fAbs == i10 ? 0 : -1));
        if (i10 > 0) {
            this.S = fAbs;
            this.T = i12;
        }
    }

    public boolean g() {
        return this.f1697h0 != 8;
    }

    public void g0(int i10, int i11, int i12, int i13) {
        int i14;
        int i15;
        int i16 = i12 - i10;
        int i17 = i13 - i11;
        this.U = i10;
        this.V = i11;
        if (this.f1697h0 == 8) {
            this.Q = 0;
            this.R = 0;
            return;
        }
        DimensionBehaviour[] dimensionBehaviourArr = this.O;
        DimensionBehaviour dimensionBehaviour = dimensionBehaviourArr[0];
        DimensionBehaviour dimensionBehaviour2 = DimensionBehaviour.FIXED;
        if (dimensionBehaviour == dimensionBehaviour2 && i16 < (i15 = this.Q)) {
            i16 = i15;
        }
        if (dimensionBehaviourArr[1] == dimensionBehaviour2 && i17 < (i14 = this.R)) {
            i17 = i14;
        }
        this.Q = i16;
        this.R = i17;
        int i18 = this.f1687c0;
        if (i17 < i18) {
            this.R = i18;
        }
        int i19 = this.f1685b0;
        if (i16 < i19) {
            this.Q = i19;
        }
    }

    public void h0(boolean z10) {
        this.A = z10;
    }

    public void i(ConstraintAnchor.Type type, ConstraintWidget constraintWidget, ConstraintAnchor.Type type2, int i10) {
        ConstraintAnchor.Type type3;
        ConstraintAnchor.Type type4;
        boolean z10;
        ConstraintAnchor.Type type5 = ConstraintAnchor.Type.CENTER;
        if (type == type5) {
            if (type2 != type5) {
                ConstraintAnchor.Type type6 = ConstraintAnchor.Type.LEFT;
                if (type2 == type6 || type2 == ConstraintAnchor.Type.RIGHT) {
                    i(type6, constraintWidget, type2, 0);
                    i(ConstraintAnchor.Type.RIGHT, constraintWidget, type2, 0);
                    n(type5).a(constraintWidget.n(type2), 0);
                    return;
                }
                ConstraintAnchor.Type type7 = ConstraintAnchor.Type.TOP;
                if (type2 == type7 || type2 == ConstraintAnchor.Type.BOTTOM) {
                    i(type7, constraintWidget, type2, 0);
                    i(ConstraintAnchor.Type.BOTTOM, constraintWidget, type2, 0);
                    n(type5).a(constraintWidget.n(type2), 0);
                    return;
                }
                return;
            }
            ConstraintAnchor.Type type8 = ConstraintAnchor.Type.LEFT;
            ConstraintAnchor constraintAnchorN = n(type8);
            ConstraintAnchor.Type type9 = ConstraintAnchor.Type.RIGHT;
            ConstraintAnchor constraintAnchorN2 = n(type9);
            ConstraintAnchor.Type type10 = ConstraintAnchor.Type.TOP;
            ConstraintAnchor constraintAnchorN3 = n(type10);
            ConstraintAnchor.Type type11 = ConstraintAnchor.Type.BOTTOM;
            ConstraintAnchor constraintAnchorN4 = n(type11);
            boolean z11 = true;
            if ((constraintAnchorN == null || !constraintAnchorN.j()) && (constraintAnchorN2 == null || !constraintAnchorN2.j())) {
                i(type8, constraintWidget, type8, 0);
                i(type9, constraintWidget, type9, 0);
                z10 = true;
            } else {
                z10 = false;
            }
            if ((constraintAnchorN3 == null || !constraintAnchorN3.j()) && (constraintAnchorN4 == null || !constraintAnchorN4.j())) {
                i(type10, constraintWidget, type10, 0);
                i(type11, constraintWidget, type11, 0);
            } else {
                z11 = false;
            }
            if (z10 && z11) {
                n(type5).a(constraintWidget.n(type5), 0);
                return;
            }
            if (z10) {
                ConstraintAnchor.Type type12 = ConstraintAnchor.Type.CENTER_X;
                n(type12).a(constraintWidget.n(type12), 0);
                return;
            } else {
                if (z11) {
                    ConstraintAnchor.Type type13 = ConstraintAnchor.Type.CENTER_Y;
                    n(type13).a(constraintWidget.n(type13), 0);
                    return;
                }
                return;
            }
        }
        ConstraintAnchor.Type type14 = ConstraintAnchor.Type.CENTER_X;
        if (type == type14 && (type2 == (type4 = ConstraintAnchor.Type.LEFT) || type2 == ConstraintAnchor.Type.RIGHT)) {
            ConstraintAnchor constraintAnchorN5 = n(type4);
            ConstraintAnchor constraintAnchorN6 = constraintWidget.n(type2);
            ConstraintAnchor constraintAnchorN7 = n(ConstraintAnchor.Type.RIGHT);
            constraintAnchorN5.a(constraintAnchorN6, 0);
            constraintAnchorN7.a(constraintAnchorN6, 0);
            n(type14).a(constraintAnchorN6, 0);
            return;
        }
        ConstraintAnchor.Type type15 = ConstraintAnchor.Type.CENTER_Y;
        if (type == type15 && (type2 == (type3 = ConstraintAnchor.Type.TOP) || type2 == ConstraintAnchor.Type.BOTTOM)) {
            ConstraintAnchor constraintAnchorN8 = constraintWidget.n(type2);
            n(type3).a(constraintAnchorN8, 0);
            n(ConstraintAnchor.Type.BOTTOM).a(constraintAnchorN8, 0);
            n(type15).a(constraintAnchorN8, 0);
            return;
        }
        if (type == type14 && type2 == type14) {
            ConstraintAnchor.Type type16 = ConstraintAnchor.Type.LEFT;
            n(type16).a(constraintWidget.n(type16), 0);
            ConstraintAnchor.Type type17 = ConstraintAnchor.Type.RIGHT;
            n(type17).a(constraintWidget.n(type17), 0);
            n(type14).a(constraintWidget.n(type2), 0);
            return;
        }
        if (type == type15 && type2 == type15) {
            ConstraintAnchor.Type type18 = ConstraintAnchor.Type.TOP;
            n(type18).a(constraintWidget.n(type18), 0);
            ConstraintAnchor.Type type19 = ConstraintAnchor.Type.BOTTOM;
            n(type19).a(constraintWidget.n(type19), 0);
            n(type15).a(constraintWidget.n(type2), 0);
            return;
        }
        ConstraintAnchor constraintAnchorN9 = n(type);
        ConstraintAnchor constraintAnchorN10 = constraintWidget.n(type2);
        if (constraintAnchorN9.k(constraintAnchorN10)) {
            ConstraintAnchor.Type type20 = ConstraintAnchor.Type.BASELINE;
            if (type == type20) {
                ConstraintAnchor constraintAnchorN11 = n(ConstraintAnchor.Type.TOP);
                ConstraintAnchor constraintAnchorN12 = n(ConstraintAnchor.Type.BOTTOM);
                if (constraintAnchorN11 != null) {
                    constraintAnchorN11.l();
                }
                if (constraintAnchorN12 != null) {
                    constraintAnchorN12.l();
                }
                i10 = 0;
            } else if (type == ConstraintAnchor.Type.TOP || type == ConstraintAnchor.Type.BOTTOM) {
                ConstraintAnchor constraintAnchorN13 = n(type20);
                if (constraintAnchorN13 != null) {
                    constraintAnchorN13.l();
                }
                ConstraintAnchor constraintAnchorN14 = n(type5);
                if (constraintAnchorN14.g() != constraintAnchorN10) {
                    constraintAnchorN14.l();
                }
                ConstraintAnchor constraintAnchorD = n(type).d();
                ConstraintAnchor constraintAnchorN15 = n(type15);
                if (constraintAnchorN15.j()) {
                    constraintAnchorD.l();
                    constraintAnchorN15.l();
                }
            } else if (type == ConstraintAnchor.Type.LEFT || type == ConstraintAnchor.Type.RIGHT) {
                ConstraintAnchor constraintAnchorN16 = n(type5);
                if (constraintAnchorN16.g() != constraintAnchorN10) {
                    constraintAnchorN16.l();
                }
                ConstraintAnchor constraintAnchorD2 = n(type).d();
                ConstraintAnchor constraintAnchorN17 = n(type14);
                if (constraintAnchorN17.j()) {
                    constraintAnchorD2.l();
                    constraintAnchorN17.l();
                }
            }
            constraintAnchorN9.a(constraintAnchorN10, i10);
        }
    }

    public void i0(int i10) {
        this.R = i10;
        int i11 = this.f1687c0;
        if (i10 < i11) {
            this.R = i11;
        }
    }

    public void j(ConstraintAnchor constraintAnchor, ConstraintAnchor constraintAnchor2, int i10) {
        if (constraintAnchor.e() == this) {
            i(constraintAnchor.h(), constraintAnchor2.e(), constraintAnchor2.h(), i10);
        }
    }

    public void j0(float f10) {
        this.f1689d0 = f10;
    }

    public void k(ConstraintWidget constraintWidget, float f10, int i10) {
        ConstraintAnchor.Type type = ConstraintAnchor.Type.CENTER;
        U(type, constraintWidget, type, i10, 0);
        this.f1732z = f10;
    }

    public void k0(int i10) {
        this.f1727w0 = i10;
    }

    public void l(ConstraintWidget constraintWidget, HashMap<ConstraintWidget, ConstraintWidget> map) {
        this.f1700j = constraintWidget.f1700j;
        this.f1702k = constraintWidget.f1702k;
        this.f1704l = constraintWidget.f1704l;
        this.f1706m = constraintWidget.f1706m;
        int[] iArr = this.f1708n;
        int[] iArr2 = constraintWidget.f1708n;
        iArr[0] = iArr2[0];
        iArr[1] = iArr2[1];
        this.f1710o = constraintWidget.f1710o;
        this.f1712p = constraintWidget.f1712p;
        this.f1716r = constraintWidget.f1716r;
        this.f1718s = constraintWidget.f1718s;
        this.f1720t = constraintWidget.f1720t;
        this.f1722u = constraintWidget.f1722u;
        this.f1724v = constraintWidget.f1724v;
        this.f1726w = constraintWidget.f1726w;
        this.f1728x = constraintWidget.f1728x;
        int[] iArr3 = constraintWidget.f1730y;
        this.f1730y = Arrays.copyOf(iArr3, iArr3.length);
        this.f1732z = constraintWidget.f1732z;
        this.A = constraintWidget.A;
        this.B = constraintWidget.B;
        this.D.l();
        this.E.l();
        this.F.l();
        this.G.l();
        this.H.l();
        this.I.l();
        this.J.l();
        this.K.l();
        this.O = (DimensionBehaviour[]) Arrays.copyOf(this.O, 2);
        this.P = this.P == null ? null : map.get(constraintWidget.P);
        this.Q = constraintWidget.Q;
        this.R = constraintWidget.R;
        this.S = constraintWidget.S;
        this.T = constraintWidget.T;
        this.U = constraintWidget.U;
        this.V = constraintWidget.V;
        this.W = constraintWidget.W;
        this.X = constraintWidget.X;
        this.Y = constraintWidget.Y;
        this.Z = constraintWidget.Z;
        this.f1683a0 = constraintWidget.f1683a0;
        this.f1685b0 = constraintWidget.f1685b0;
        this.f1687c0 = constraintWidget.f1687c0;
        this.f1689d0 = constraintWidget.f1689d0;
        this.f1691e0 = constraintWidget.f1691e0;
        this.f1693f0 = constraintWidget.f1693f0;
        this.f1695g0 = constraintWidget.f1695g0;
        this.f1697h0 = constraintWidget.f1697h0;
        this.f1699i0 = constraintWidget.f1699i0;
        this.f1701j0 = constraintWidget.f1701j0;
        this.f1703k0 = constraintWidget.f1703k0;
        this.f1705l0 = constraintWidget.f1705l0;
        this.f1707m0 = constraintWidget.f1707m0;
        this.f1709n0 = constraintWidget.f1709n0;
        this.f1711o0 = constraintWidget.f1711o0;
        this.f1713p0 = constraintWidget.f1713p0;
        this.f1715q0 = constraintWidget.f1715q0;
        this.f1717r0 = constraintWidget.f1717r0;
        this.f1719s0 = constraintWidget.f1719s0;
        this.f1721t0 = constraintWidget.f1721t0;
        this.f1723u0 = constraintWidget.f1723u0;
        this.f1725v0 = constraintWidget.f1725v0;
        this.f1727w0 = constraintWidget.f1727w0;
        this.f1729x0 = constraintWidget.f1729x0;
        this.f1731y0 = constraintWidget.f1731y0;
        this.f1733z0 = constraintWidget.f1733z0;
        float[] fArr = this.A0;
        float[] fArr2 = constraintWidget.A0;
        fArr[0] = fArr2[0];
        fArr[1] = fArr2[1];
        ConstraintWidget[] constraintWidgetArr = this.B0;
        ConstraintWidget[] constraintWidgetArr2 = constraintWidget.B0;
        constraintWidgetArr[0] = constraintWidgetArr2[0];
        constraintWidgetArr[1] = constraintWidgetArr2[1];
        ConstraintWidget[] constraintWidgetArr3 = this.C0;
        ConstraintWidget[] constraintWidgetArr4 = constraintWidget.C0;
        constraintWidgetArr3[0] = constraintWidgetArr4[0];
        constraintWidgetArr3[1] = constraintWidgetArr4[1];
        ConstraintWidget constraintWidget2 = constraintWidget.D0;
        this.D0 = constraintWidget2 == null ? null : map.get(constraintWidget2);
        ConstraintWidget constraintWidget3 = constraintWidget.E0;
        this.E0 = constraintWidget3 != null ? map.get(constraintWidget3) : null;
    }

    public void l0(int i10, int i11) {
        this.U = i10;
        int i12 = i11 - i10;
        this.Q = i12;
        int i13 = this.f1685b0;
        if (i12 < i13) {
            this.Q = i13;
        }
    }

    public void m(androidx.constraintlayout.solver.d dVar) {
        dVar.q(this.D);
        dVar.q(this.E);
        dVar.q(this.F);
        dVar.q(this.G);
        if (this.f1683a0 > 0) {
            dVar.q(this.H);
        }
    }

    public void m0(DimensionBehaviour dimensionBehaviour) {
        this.O[0] = dimensionBehaviour;
    }

    public ConstraintAnchor n(ConstraintAnchor.Type type) {
        switch (a.f1739a[type.ordinal()]) {
            case 1:
                return this.D;
            case 2:
                return this.E;
            case 3:
                return this.F;
            case 4:
                return this.G;
            case 5:
                return this.H;
            case 6:
                return this.K;
            case 7:
                return this.I;
            case 8:
                return this.J;
            case 9:
                return null;
            default:
                throw new AssertionError(type.name());
        }
    }

    public void n0(int i10, int i11, int i12, float f10) {
        this.f1704l = i10;
        this.f1710o = i11;
        if (i12 == Integer.MAX_VALUE) {
            i12 = 0;
        }
        this.f1712p = i12;
        this.f1714q = f10;
        if (f10 <= 0.0f || f10 >= 1.0f || i10 != 0) {
            return;
        }
        this.f1704l = 2;
    }

    public int o() {
        return this.f1683a0;
    }

    public void o0(float f10) {
        this.A0[0] = f10;
    }

    public float p(int i10) {
        if (i10 == 0) {
            return this.f1689d0;
        }
        if (i10 == 1) {
            return this.f1691e0;
        }
        return -1.0f;
    }

    protected void p0(int i10, boolean z10) {
        this.N[i10] = z10;
    }

    public int q() {
        return S() + this.R;
    }

    public void q0(boolean z10) {
        this.B = z10;
    }

    public Object r() {
        return this.f1693f0;
    }

    public void r0(boolean z10) {
        this.C = z10;
    }

    public String s() {
        return this.f1699i0;
    }

    public void s0(int i10) {
        this.f1730y[1] = i10;
    }

    public DimensionBehaviour t(int i10) {
        if (i10 == 0) {
            return z();
        }
        if (i10 == 1) {
            return N();
        }
        return null;
    }

    public void t0(int i10) {
        this.f1730y[0] = i10;
    }

    public String toString() {
        String str;
        StringBuilder sb2 = new StringBuilder();
        String str2 = "";
        if (this.f1701j0 != null) {
            str = "type: " + this.f1701j0 + " ";
        } else {
            str = "";
        }
        sb2.append(str);
        if (this.f1699i0 != null) {
            str2 = "id: " + this.f1699i0 + " ";
        }
        sb2.append(str2);
        sb2.append("(");
        sb2.append(this.U);
        sb2.append(", ");
        sb2.append(this.V);
        sb2.append(") - (");
        sb2.append(this.Q);
        sb2.append(" x ");
        sb2.append(this.R);
        sb2.append(")");
        return sb2.toString();
    }

    public float u() {
        return this.S;
    }

    public void u0(int i10) {
        if (i10 < 0) {
            this.f1687c0 = 0;
        } else {
            this.f1687c0 = i10;
        }
    }

    public int v() {
        return this.T;
    }

    public void v0(int i10) {
        if (i10 < 0) {
            this.f1685b0 = 0;
        } else {
            this.f1685b0 = i10;
        }
    }

    public int w() {
        if (this.f1697h0 == 8) {
            return 0;
        }
        return this.R;
    }

    public void w0(int i10, int i11) {
        this.U = i10;
        this.V = i11;
    }

    public float x() {
        return this.f1689d0;
    }

    public void x0(ConstraintWidget constraintWidget) {
        this.P = constraintWidget;
    }

    public int y() {
        return this.f1727w0;
    }

    public void y0(float f10) {
        this.f1691e0 = f10;
    }

    public DimensionBehaviour z() {
        return this.O[0];
    }

    public void z0(int i10) {
        this.f1729x0 = i10;
    }
}
