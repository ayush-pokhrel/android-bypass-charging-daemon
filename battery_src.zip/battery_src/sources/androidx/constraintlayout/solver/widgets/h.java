package androidx.constraintlayout.solver.widgets;

/* JADX INFO: compiled from: VirtualLayout.java */
/* JADX INFO: loaded from: classes.dex */
public class h extends u.b {
    private int I0 = 0;
    private int J0 = 0;
    private int K0 = 0;
    private int L0 = 0;
    private int M0 = 0;
    private int N0 = 0;
    private int O0 = 0;
    private int P0 = 0;
    private boolean Q0 = false;
    private int R0 = 0;
    private int S0 = 0;
    protected androidx.constraintlayout.solver.widgets.analyzer.b.a T0 = new androidx.constraintlayout.solver.widgets.analyzer.b.a();
    androidx.constraintlayout.solver.widgets.analyzer.b.InterfaceC0007b U0 = null;

    public void L0(boolean z10) {
        int i10 = this.M0;
        if (i10 > 0 || this.N0 > 0) {
            if (z10) {
                this.O0 = this.N0;
                this.P0 = i10;
            } else {
                this.O0 = i10;
                this.P0 = this.N0;
            }
        }
    }

    public void M0() {
        for (int i10 = 0; i10 < this.H0; i10++) {
            ConstraintWidget constraintWidget = this.G0[i10];
            if (constraintWidget != null) {
                constraintWidget.r0(true);
            }
        }
    }

    public int N0() {
        return this.S0;
    }

    public int O0() {
        return this.R0;
    }

    public int P0() {
        return this.J0;
    }

    public int Q0() {
        return this.O0;
    }

    public int R0() {
        return this.P0;
    }

    public int S0() {
        return this.I0;
    }

    protected void U0(ConstraintWidget constraintWidget, ConstraintWidget.DimensionBehaviour dimensionBehaviour, int i10, ConstraintWidget.DimensionBehaviour dimensionBehaviour2, int i11) {
        while (this.U0 == null && H() != null) {
            this.U0 = ((d) H()).X0();
        }
        androidx.constraintlayout.solver.widgets.analyzer.b.a aVar = this.T0;
        aVar.f1781a = dimensionBehaviour;
        aVar.f1782b = dimensionBehaviour2;
        aVar.f1783c = i10;
        aVar.f1784d = i11;
        this.U0.a(constraintWidget, aVar);
        constraintWidget.F0(this.T0.f1785e);
        constraintWidget.i0(this.T0.f1786f);
        constraintWidget.h0(this.T0.f1788h);
        constraintWidget.c0(this.T0.f1787g);
    }

    protected boolean V0() {
        ConstraintWidget constraintWidget = this.P;
        androidx.constraintlayout.solver.widgets.analyzer.b.InterfaceC0007b interfaceC0007bX0 = constraintWidget != null ? ((d) constraintWidget).X0() : null;
        if (interfaceC0007bX0 == null) {
            return false;
        }
        for (int i10 = 0; i10 < this.H0; i10++) {
            ConstraintWidget constraintWidget2 = this.G0[i10];
            if (constraintWidget2 != null && !(constraintWidget2 instanceof f)) {
                ConstraintWidget.DimensionBehaviour dimensionBehaviourT = constraintWidget2.t(0);
                ConstraintWidget.DimensionBehaviour dimensionBehaviourT2 = constraintWidget2.t(1);
                ConstraintWidget.DimensionBehaviour dimensionBehaviour = ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT;
                if (dimensionBehaviourT != dimensionBehaviour || constraintWidget2.f1704l == 1 || dimensionBehaviourT2 != dimensionBehaviour || constraintWidget2.f1706m == 1) {
                    if (dimensionBehaviourT == dimensionBehaviour) {
                        dimensionBehaviourT = ConstraintWidget.DimensionBehaviour.WRAP_CONTENT;
                    }
                    if (dimensionBehaviourT2 == dimensionBehaviour) {
                        dimensionBehaviourT2 = ConstraintWidget.DimensionBehaviour.WRAP_CONTENT;
                    }
                    androidx.constraintlayout.solver.widgets.analyzer.b.a aVar = this.T0;
                    aVar.f1781a = dimensionBehaviourT;
                    aVar.f1782b = dimensionBehaviourT2;
                    aVar.f1783c = constraintWidget2.Q();
                    this.T0.f1784d = constraintWidget2.w();
                    interfaceC0007bX0.a(constraintWidget2, this.T0);
                    constraintWidget2.F0(this.T0.f1785e);
                    constraintWidget2.i0(this.T0.f1786f);
                    constraintWidget2.c0(this.T0.f1787g);
                }
            }
        }
        return true;
    }

    public boolean W0() {
        return this.Q0;
    }

    protected void X0(boolean z10) {
        this.Q0 = z10;
    }

    public void Y0(int i10, int i11) {
        this.R0 = i10;
        this.S0 = i11;
    }

    public void Z0(int i10) {
        this.K0 = i10;
        this.I0 = i10;
        this.L0 = i10;
        this.J0 = i10;
        this.M0 = i10;
        this.N0 = i10;
    }

    public void a1(int i10) {
        this.J0 = i10;
    }

    @Override // u.b, u.a
    public void b(d dVar) {
        M0();
    }

    public void b1(int i10) {
        this.N0 = i10;
    }

    public void c1(int i10) {
        this.K0 = i10;
        this.O0 = i10;
    }

    public void d1(int i10) {
        this.L0 = i10;
        this.P0 = i10;
    }

    public void e1(int i10) {
        this.M0 = i10;
        this.O0 = i10;
        this.P0 = i10;
    }

    public void f1(int i10) {
        this.I0 = i10;
    }

    public void T0(int i10, int i11, int i12, int i13) {
    }
}
