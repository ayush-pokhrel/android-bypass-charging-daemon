package androidx.constraintlayout.solver.widgets;

import androidx.constraintlayout.solver.SolverVariable;
import java.util.ArrayList;

/* JADX INFO: compiled from: Chain.java */
/* JADX INFO: loaded from: classes.dex */
class b {
    static void a(d dVar, androidx.constraintlayout.solver.d dVar2, int i10) {
        int i11;
        c[] cVarArr;
        int i12;
        if (i10 == 0) {
            i11 = dVar.Q0;
            cVarArr = dVar.T0;
            i12 = 0;
        } else {
            i11 = dVar.R0;
            cVarArr = dVar.S0;
            i12 = 2;
        }
        for (int i13 = 0; i13 < i11; i13++) {
            c cVar = cVarArr[i13];
            cVar.a();
            b(dVar, dVar2, i10, i12, cVar);
        }
    }

    /* JADX WARN: Code duplicated, block: B:16:0x002f A[PHI: r8 r15
      0x002f: PHI (r8v43 boolean) = (r8v1 boolean), (r8v45 boolean) binds: [B:26:0x0044, B:15:0x002d] A[DONT_GENERATE, DONT_INLINE]
      0x002f: PHI (r15v31 boolean) = (r15v1 boolean), (r15v33 boolean) binds: [B:26:0x0044, B:15:0x002d] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Code duplicated, block: B:171:0x02d3  */
    /* JADX WARN: Code duplicated, block: B:17:0x0031 A[PHI: r8 r15
      0x0031: PHI (r8v3 boolean) = (r8v1 boolean), (r8v45 boolean) binds: [B:26:0x0044, B:15:0x002d] A[DONT_GENERATE, DONT_INLINE]
      0x0031: PHI (r15v3 boolean) = (r15v1 boolean), (r15v33 boolean) binds: [B:26:0x0044, B:15:0x002d] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Code duplicated, block: B:93:0x015f  */
    /* JADX WARN: Code duplicated, block: B:95:0x0162  */
    /* JADX WARN: Code duplicated, block: B:97:0x0168  */
    /* JADX WARN: Code duplicated, block: B:99:0x0189  */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r38v0, types: [androidx.constraintlayout.solver.d] */
    /* JADX WARN: Type inference failed for: r5v25 */
    /* JADX WARN: Type inference failed for: r5v26 */
    /* JADX WARN: Type inference failed for: r5v27, types: [androidx.constraintlayout.solver.SolverVariable] */
    /* JADX WARN: Type inference failed for: r5v31 */
    /* JADX WARN: Type inference failed for: r5v38 */
    /* JADX WARN: Type inference failed for: r8v41 */
    /* JADX WARN: Type inference failed for: r8v42 */
    /* JADX WARN: Type inference failed for: r8v47 */
    /* JADX WARN: Type inference failed for: r8v5 */
    /* JADX WARN: Type inference failed for: r8v6, types: [androidx.constraintlayout.solver.widgets.ConstraintWidget] */
    static void b(d dVar, androidx.constraintlayout.solver.d dVar2, int i10, int i11, c cVar) {
        boolean z10;
        boolean z11;
        boolean z12;
        Object obj;
        int i12;
        ConstraintAnchor constraintAnchor;
        SolverVariable solverVariable;
        SolverVariable solverVariable2;
        ConstraintAnchor constraintAnchor2;
        SolverVariable solverVariable3;
        SolverVariable solverVariable4;
        ?? r10;
        SolverVariable solverVariable5;
        int size;
        ConstraintAnchor constraintAnchor3;
        int i13;
        ConstraintWidget constraintWidget = cVar.f1816a;
        ConstraintWidget constraintWidget2 = cVar.f1818c;
        ConstraintWidget constraintWidget3 = cVar.f1817b;
        ConstraintWidget constraintWidget4 = cVar.f1819d;
        ConstraintWidget constraintWidget5 = cVar.f1820e;
        float f10 = cVar.f1826k;
        boolean z13 = dVar.O[i10] == ConstraintWidget.DimensionBehaviour.WRAP_CONTENT;
        if (i10 == 0) {
            int i14 = constraintWidget5.f1727w0;
            z10 = i14 == 0;
            z11 = i14 == 1;
            if (i14 == 2) {
                z12 = true;
            } else {
                z12 = false;
            }
        } else {
            int i15 = constraintWidget5.f1729x0;
            z10 = i15 == 0;
            z11 = i15 == 1;
            if (i15 == 2) {
                z12 = true;
            } else {
                z12 = false;
            }
        }
        boolean z14 = z11;
        boolean z15 = false;
        boolean z16 = z10;
        ?? r11 = constraintWidget;
        while (true) {
            obj = null;
            if (z15) {
                break;
            }
            ConstraintAnchor constraintAnchor4 = r11.L[i11];
            int i16 = z12 ? 1 : 4;
            int iC = constraintAnchor4.c();
            ConstraintWidget.DimensionBehaviour dimensionBehaviour = r11.O[i10];
            float f11 = f10;
            ConstraintWidget.DimensionBehaviour dimensionBehaviour2 = ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT;
            boolean z17 = dimensionBehaviour == dimensionBehaviour2 && r11.f1708n[i10] == 0;
            ConstraintAnchor constraintAnchor5 = constraintAnchor4.f1667d;
            if (constraintAnchor5 != null && r11 != constraintWidget) {
                iC += constraintAnchor5.c();
            }
            int i17 = iC;
            if (z12 && r11 != constraintWidget && r11 != constraintWidget3) {
                i16 = 5;
            }
            ConstraintAnchor constraintAnchor6 = constraintAnchor4.f1667d;
            if (constraintAnchor6 != null) {
                if (r11 == constraintWidget3) {
                    dVar2.h(constraintAnchor4.f1670g, constraintAnchor6.f1670g, i17, 6);
                } else {
                    dVar2.h(constraintAnchor4.f1670g, constraintAnchor6.f1670g, i17, 8);
                }
                dVar2.e(constraintAnchor4.f1670g, constraintAnchor4.f1667d.f1670g, i17, (!z17 || z12) ? i16 : 5);
            } else {
                constraintWidget5 = constraintWidget5;
                constraintWidget = constraintWidget;
            }
            if (z13) {
                if (r11.P() == 8 || r11.O[i10] != dimensionBehaviour2) {
                    i13 = 0;
                } else {
                    ConstraintAnchor[] constraintAnchorArr = r11.L;
                    i13 = 0;
                    dVar2.h(constraintAnchorArr[i11 + 1].f1670g, constraintAnchorArr[i11].f1670g, 0, 5);
                }
                dVar2.h(r11.L[i11].f1670g, dVar.L[i11].f1670g, i13, 8);
            }
            ConstraintAnchor constraintAnchor7 = r11.L[i11 + 1].f1667d;
            if (constraintAnchor7 != null) {
                ConstraintWidget constraintWidget6 = constraintAnchor7.f1665b;
                ConstraintAnchor constraintAnchor8 = constraintWidget6.L[i11].f1667d;
                if (constraintAnchor8 != null && constraintAnchor8.f1665b == r11) {
                    obj = constraintWidget6;
                }
            }
            if (obj != null) {
                r11 = obj;
                z15 = z15;
            } else {
                z15 = true;
            }
            z16 = z16;
            f10 = f11;
            constraintWidget5 = constraintWidget5;
            constraintWidget = constraintWidget;
            r11 = r11;
        }
        ConstraintWidget constraintWidget7 = constraintWidget5;
        float f12 = f10;
        ConstraintWidget constraintWidget8 = constraintWidget;
        boolean z18 = z16;
        if (constraintWidget4 != null) {
            int i18 = i11 + 1;
            if (constraintWidget2.L[i18].f1667d != null) {
                ConstraintAnchor constraintAnchor9 = constraintWidget4.L[i18];
                if (constraintWidget4.O[i10] == ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT && constraintWidget4.f1708n[i10] == 0 && !z12) {
                    ConstraintAnchor constraintAnchor10 = constraintAnchor9.f1667d;
                    if (constraintAnchor10.f1665b == dVar) {
                        dVar2.e(constraintAnchor9.f1670g, constraintAnchor10.f1670g, -constraintAnchor9.c(), 5);
                    } else if (z12) {
                        constraintAnchor3 = constraintAnchor9.f1667d;
                        if (constraintAnchor3.f1665b == dVar) {
                            dVar2.e(constraintAnchor9.f1670g, constraintAnchor3.f1670g, -constraintAnchor9.c(), 4);
                        }
                    }
                } else if (z12) {
                    constraintAnchor3 = constraintAnchor9.f1667d;
                    if (constraintAnchor3.f1665b == dVar) {
                        dVar2.e(constraintAnchor9.f1670g, constraintAnchor3.f1670g, -constraintAnchor9.c(), 4);
                    }
                }
                dVar2.j(constraintAnchor9.f1670g, constraintWidget2.L[i18].f1667d.f1670g, -constraintAnchor9.c(), 6);
            }
        }
        if (z13) {
            int i19 = i11 + 1;
            SolverVariable solverVariable6 = dVar.L[i19].f1670g;
            ConstraintAnchor constraintAnchor11 = constraintWidget2.L[i19];
            dVar2.h(solverVariable6, constraintAnchor11.f1670g, constraintAnchor11.c(), 8);
        }
        ArrayList<ConstraintWidget> arrayList = cVar.f1823h;
        if (arrayList != null && (size = arrayList.size()) > 1) {
            float f13 = (!cVar.f1833r || cVar.f1835t) ? f12 : cVar.f1825j;
            float f14 = 0.0f;
            float f15 = 0.0f;
            ConstraintWidget constraintWidget9 = null;
            int i20 = 0;
            while (i20 < size) {
                ConstraintWidget constraintWidget10 = arrayList.get(i20);
                float f16 = constraintWidget10.A0[i10];
                if (f16 < f14) {
                    if (cVar.f1835t) {
                        ConstraintAnchor[] constraintAnchorArr2 = constraintWidget10.L;
                        dVar2.e(constraintAnchorArr2[i11 + 1].f1670g, constraintAnchorArr2[i11].f1670g, 0, 4);
                    } else {
                        f16 = 1.0f;
                    }
                    arrayList = arrayList;
                    i20++;
                    arrayList = arrayList;
                    f14 = 0.0f;
                }
                if (f16 == f14) {
                    ConstraintAnchor[] constraintAnchorArr3 = constraintWidget10.L;
                    dVar2.e(constraintAnchorArr3[i11 + 1].f1670g, constraintAnchorArr3[i11].f1670g, 0, 8);
                    arrayList = arrayList;
                } else {
                    if (constraintWidget9 != null) {
                        ConstraintAnchor[] constraintAnchorArr4 = constraintWidget9.L;
                        SolverVariable solverVariable7 = constraintAnchorArr4[i11].f1670g;
                        int i21 = i11 + 1;
                        SolverVariable solverVariable8 = constraintAnchorArr4[i21].f1670g;
                        ConstraintAnchor[] constraintAnchorArr5 = constraintWidget10.L;
                        SolverVariable solverVariable9 = constraintAnchorArr5[i11].f1670g;
                        SolverVariable solverVariable10 = constraintAnchorArr5[i21].f1670g;
                        androidx.constraintlayout.solver.b bVarR = dVar2.r();
                        bVarR.l(f15, f13, f16, solverVariable7, solverVariable8, solverVariable9, solverVariable10);
                        dVar2.d(bVarR);
                    }
                    constraintWidget9 = constraintWidget10;
                    f15 = f16;
                }
                i20++;
                arrayList = arrayList;
                f14 = 0.0f;
            }
        }
        if (constraintWidget3 != null && (constraintWidget3 == constraintWidget4 || z12)) {
            ConstraintAnchor constraintAnchor12 = constraintWidget8.L[i11];
            int i22 = i11 + 1;
            ConstraintAnchor constraintAnchor13 = constraintWidget2.L[i22];
            ConstraintAnchor constraintAnchor14 = constraintAnchor12.f1667d;
            SolverVariable solverVariable11 = constraintAnchor14 != null ? constraintAnchor14.f1670g : null;
            ConstraintAnchor constraintAnchor15 = constraintAnchor13.f1667d;
            SolverVariable solverVariable12 = constraintAnchor15 != null ? constraintAnchor15.f1670g : null;
            ConstraintAnchor constraintAnchor16 = constraintWidget3.L[i11];
            ConstraintAnchor constraintAnchor17 = constraintWidget4.L[i22];
            if (solverVariable11 != null && solverVariable12 != null) {
                dVar2.c(constraintAnchor16.f1670g, solverVariable11, constraintAnchor16.c(), i10 == 0 ? constraintWidget7.f1689d0 : constraintWidget7.f1691e0, solverVariable12, constraintAnchor17.f1670g, constraintAnchor17.c(), 7);
            }
        } else if (!z18 || constraintWidget3 == null) {
            int i23 = 8;
            if (z14 && constraintWidget3 != null) {
                int i24 = cVar.f1825j;
                boolean z19 = i24 > 0 && cVar.f1824i == i24;
                ConstraintWidget constraintWidget11 = constraintWidget3;
                ConstraintWidget constraintWidget12 = constraintWidget11;
                while (constraintWidget11 != null) {
                    ConstraintWidget constraintWidget13 = constraintWidget11.C0[i10];
                    while (constraintWidget13 != null && constraintWidget13.P() == i23) {
                        constraintWidget13 = constraintWidget13.C0[i10];
                    }
                    if (constraintWidget11 == constraintWidget3 || constraintWidget11 == constraintWidget4 || constraintWidget13 == null) {
                        constraintWidget12 = constraintWidget12;
                        i12 = i23;
                    } else {
                        ConstraintWidget constraintWidget14 = constraintWidget13 == constraintWidget4 ? null : constraintWidget13;
                        ConstraintAnchor constraintAnchor18 = constraintWidget11.L[i11];
                        SolverVariable solverVariable13 = constraintAnchor18.f1670g;
                        ConstraintAnchor constraintAnchor19 = constraintAnchor18.f1667d;
                        if (constraintAnchor19 != null) {
                            SolverVariable solverVariable14 = constraintAnchor19.f1670g;
                        }
                        int i25 = i11 + 1;
                        SolverVariable solverVariable15 = constraintWidget12.L[i25].f1670g;
                        int iC2 = constraintAnchor18.c();
                        int iC3 = constraintWidget11.L[i25].c();
                        if (constraintWidget14 != null) {
                            constraintAnchor = constraintWidget14.L[i11];
                            solverVariable = constraintAnchor.f1670g;
                            ConstraintAnchor constraintAnchor20 = constraintAnchor.f1667d;
                            solverVariable2 = constraintAnchor20 != null ? constraintAnchor20.f1670g : null;
                        } else {
                            constraintAnchor = constraintWidget4.L[i11];
                            solverVariable = constraintAnchor != null ? constraintAnchor.f1670g : null;
                            solverVariable2 = constraintWidget11.L[i25].f1670g;
                        }
                        if (constraintAnchor != null) {
                            iC3 += constraintAnchor.c();
                        }
                        int i26 = iC3;
                        int iC4 = constraintWidget12.L[i25].c() + iC2;
                        int i27 = z19 ? 8 : 4;
                        if (solverVariable13 == null || solverVariable15 == null || solverVariable == null || solverVariable2 == null) {
                            i12 = 8;
                        } else {
                            i12 = 8;
                            dVar2.c(solverVariable13, solverVariable15, iC4, 0.5f, solverVariable, solverVariable2, i26, i27);
                        }
                        constraintWidget13 = constraintWidget14;
                    }
                    if (constraintWidget11.P() == i12) {
                        constraintWidget11 = constraintWidget12;
                    }
                    i23 = i12;
                    constraintWidget12 = constraintWidget11;
                    constraintWidget11 = constraintWidget13;
                }
                ConstraintAnchor constraintAnchor21 = constraintWidget3.L[i11];
                ConstraintAnchor constraintAnchor22 = constraintWidget8.L[i11].f1667d;
                int i28 = i11 + 1;
                ConstraintAnchor constraintAnchor23 = constraintWidget4.L[i28];
                ConstraintAnchor constraintAnchor24 = constraintWidget2.L[i28].f1667d;
                if (constraintAnchor22 != null) {
                    if (constraintWidget3 != constraintWidget4) {
                        dVar2.e(constraintAnchor21.f1670g, constraintAnchor22.f1670g, constraintAnchor21.c(), 5);
                    } else if (constraintAnchor24 != null) {
                        dVar2.c(constraintAnchor21.f1670g, constraintAnchor22.f1670g, constraintAnchor21.c(), 0.5f, constraintAnchor23.f1670g, constraintAnchor24.f1670g, constraintAnchor23.c(), 5);
                    }
                }
                if (constraintAnchor24 != null && constraintWidget3 != constraintWidget4) {
                    dVar2.e(constraintAnchor23.f1670g, constraintAnchor24.f1670g, -constraintAnchor23.c(), 5);
                }
            }
        } else {
            int i29 = cVar.f1825j;
            boolean z20 = i29 > 0 && cVar.f1824i == i29;
            ConstraintWidget constraintWidget15 = constraintWidget3;
            ConstraintWidget constraintWidget16 = constraintWidget15;
            while (constraintWidget15 != null) {
                ConstraintWidget constraintWidget17 = constraintWidget15.C0[i10];
                while (constraintWidget17 != null && constraintWidget17.P() == 8) {
                    constraintWidget17 = constraintWidget17.C0[i10];
                }
                if (constraintWidget17 != null || constraintWidget15 == constraintWidget4) {
                    ConstraintAnchor constraintAnchor25 = constraintWidget15.L[i11];
                    SolverVariable solverVariable16 = constraintAnchor25.f1670g;
                    ConstraintAnchor constraintAnchor26 = constraintAnchor25.f1667d;
                    SolverVariable solverVariable17 = constraintAnchor26 != null ? constraintAnchor26.f1670g : null;
                    if (constraintWidget16 != constraintWidget15) {
                        solverVariable17 = constraintWidget16.L[i11 + 1].f1670g;
                    } else if (constraintWidget15 == constraintWidget3 && constraintWidget16 == constraintWidget15) {
                        ConstraintAnchor constraintAnchor27 = constraintWidget8.L[i11].f1667d;
                        solverVariable17 = constraintAnchor27 != null ? constraintAnchor27.f1670g : null;
                    }
                    int iC5 = constraintAnchor25.c();
                    int i30 = i11 + 1;
                    int iC6 = constraintWidget15.L[i30].c();
                    if (constraintWidget17 != null) {
                        constraintAnchor2 = constraintWidget17.L[i11];
                        SolverVariable solverVariable18 = constraintAnchor2.f1670g;
                        solverVariable4 = constraintWidget15.L[i30].f1670g;
                        solverVariable3 = solverVariable18;
                    } else {
                        constraintAnchor2 = constraintWidget2.L[i30].f1667d;
                        solverVariable3 = constraintAnchor2 != null ? constraintAnchor2.f1670g : null;
                        solverVariable4 = constraintWidget15.L[i30].f1670g;
                    }
                    if (constraintAnchor2 != null) {
                        iC6 += constraintAnchor2.c();
                    }
                    if (constraintWidget16 != null) {
                        iC5 += constraintWidget16.L[i30].c();
                    }
                    if (solverVariable16 != null && solverVariable17 != null && solverVariable3 != null && solverVariable4 != null) {
                        if (constraintWidget15 == constraintWidget3) {
                            iC5 = constraintWidget3.L[i11].c();
                        }
                        dVar2.c(solverVariable16, solverVariable17, iC5, 0.5f, solverVariable3, solverVariable4, constraintWidget15 == constraintWidget4 ? constraintWidget4.L[i30].c() : iC6, z20 ? 8 : 5);
                    }
                }
                if (constraintWidget15.P() != 8) {
                    constraintWidget16 = constraintWidget15;
                }
                constraintWidget15 = constraintWidget17;
            }
        }
        if ((!z18 && !z14) || constraintWidget3 == null || constraintWidget3 == constraintWidget4) {
            return;
        }
        ConstraintAnchor[] constraintAnchorArr6 = constraintWidget3.L;
        ConstraintAnchor constraintAnchor28 = constraintAnchorArr6[i11];
        int i31 = i11 + 1;
        ConstraintAnchor constraintAnchor29 = constraintWidget4.L[i31];
        ConstraintAnchor constraintAnchor30 = constraintAnchor28.f1667d;
        SolverVariable solverVariable19 = constraintAnchor30 != null ? constraintAnchor30.f1670g : null;
        ConstraintAnchor constraintAnchor31 = constraintAnchor29.f1667d;
        if (constraintAnchor31 != null) {
            solverVariable5 = constraintAnchor31.f1670g;
        } else {
            r10 = 0;
        }
        if (constraintWidget2 != constraintWidget4) {
            ConstraintAnchor constraintAnchor32 = constraintWidget2.L[i31].f1667d;
            if (constraintAnchor32 != null) {
                r10 = solverVariable5;
                obj = constraintAnchor32.f1670g;
            }
            r10 = solverVariable5;
            r10 = obj;
        }
        if (constraintWidget3 == constraintWidget4) {
            constraintAnchor29 = constraintAnchorArr6[i31];
        }
        if (solverVariable19 == null || r10 == 0) {
            return;
        }
        dVar2.c(constraintAnchor28.f1670g, solverVariable19, constraintAnchor28.c(), 0.5f, r10, constraintAnchor29.f1670g, constraintWidget4.L[i31].c(), 5);
    }
}
