package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import androidx.constraintlayout.solver.widgets.ConstraintWidget;
import java.util.Arrays;
import java.util.HashMap;

/* JADX INFO: loaded from: classes.dex */
public abstract class ConstraintHelper extends View {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    protected int[] f1950a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    protected int f1951b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    protected Context f1952c;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    protected u.a f1953g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    protected boolean f1954h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    protected String f1955i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private View[] f1956j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    private HashMap<Integer, String> f1957k;

    public ConstraintHelper(Context context) {
        super(context);
        this.f1950a = new int[32];
        this.f1954h = false;
        this.f1956j = null;
        this.f1957k = new HashMap<>();
        this.f1952c = context;
        m(null);
    }

    private void e(String str) {
        if (str == null || str.length() == 0 || this.f1952c == null) {
            return;
        }
        String strTrim = str.trim();
        if (getParent() instanceof ConstraintLayout) {
        }
        int iK = k(strTrim);
        if (iK != 0) {
            this.f1957k.put(Integer.valueOf(iK), strTrim);
            f(iK);
            return;
        }
        Log.w("ConstraintHelper", "Could not find id of \"" + strTrim + "\"");
    }

    private void f(int i10) {
        if (i10 == getId()) {
            return;
        }
        int i11 = this.f1951b + 1;
        int[] iArr = this.f1950a;
        if (i11 > iArr.length) {
            this.f1950a = Arrays.copyOf(iArr, iArr.length * 2);
        }
        int[] iArr2 = this.f1950a;
        int i12 = this.f1951b;
        iArr2[i12] = i10;
        this.f1951b = i12 + 1;
    }

    private int[] i(View view, String str) {
        String[] strArrSplit = str.split(",");
        view.getContext();
        int[] iArr = new int[strArrSplit.length];
        int i10 = 0;
        for (String str2 : strArrSplit) {
            int iK = k(str2.trim());
            if (iK != 0) {
                iArr[i10] = iK;
                i10++;
            }
        }
        return i10 != strArrSplit.length ? Arrays.copyOf(iArr, i10) : iArr;
    }

    private int j(ConstraintLayout constraintLayout, String str) {
        Resources resources;
        String resourceEntryName;
        if (str == null || constraintLayout == null || (resources = this.f1952c.getResources()) == null) {
            return 0;
        }
        int childCount = constraintLayout.getChildCount();
        for (int i10 = 0; i10 < childCount; i10++) {
            View childAt = constraintLayout.getChildAt(i10);
            if (childAt.getId() != -1) {
                try {
                    resourceEntryName = resources.getResourceEntryName(childAt.getId());
                } catch (Resources.NotFoundException unused) {
                    resourceEntryName = null;
                }
                if (str.equals(resourceEntryName)) {
                    return childAt.getId();
                }
            }
        }
        return 0;
    }

    private int k(String str) {
        ConstraintLayout constraintLayout = getParent() instanceof ConstraintLayout ? (ConstraintLayout) getParent() : null;
        int iJ = 0;
        if (isInEditMode() && constraintLayout != null) {
            Object designInformation = constraintLayout.getDesignInformation(0, str);
            if (designInformation instanceof Integer) {
                iJ = ((Integer) designInformation).intValue();
            }
        }
        if (iJ == 0 && constraintLayout != null) {
            iJ = j(constraintLayout, str);
        }
        if (iJ == 0) {
            try {
                iJ = R$id.class.getField(str).getInt(null);
            } catch (Exception unused) {
            }
        }
        return iJ == 0 ? this.f1952c.getResources().getIdentifier(str, "id", this.f1952c.getPackageName()) : iJ;
    }

    protected void g() {
        ViewParent parent = getParent();
        if (parent == null || !(parent instanceof ConstraintLayout)) {
            return;
        }
        h((ConstraintLayout) parent);
    }

    public int[] getReferencedIds() {
        return Arrays.copyOf(this.f1950a, this.f1951b);
    }

    protected void h(ConstraintLayout constraintLayout) {
        int visibility = getVisibility();
        float elevation = getElevation();
        for (int i10 = 0; i10 < this.f1951b; i10++) {
            View viewById = constraintLayout.getViewById(this.f1950a[i10]);
            if (viewById != null) {
                viewById.setVisibility(visibility);
                if (elevation > 0.0f) {
                    viewById.setTranslationZ(viewById.getTranslationZ() + elevation);
                }
            }
        }
    }

    protected View[] l(ConstraintLayout constraintLayout) {
        View[] viewArr = this.f1956j;
        if (viewArr == null || viewArr.length != this.f1951b) {
            this.f1956j = new View[this.f1951b];
        }
        for (int i10 = 0; i10 < this.f1951b; i10++) {
            this.f1956j[i10] = constraintLayout.getViewById(this.f1950a[i10]);
        }
        return this.f1956j;
    }

    protected void m(AttributeSet attributeSet) {
        if (attributeSet != null) {
            TypedArray typedArrayObtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, R$styleable.ConstraintLayout_Layout);
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            for (int i10 = 0; i10 < indexCount; i10++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i10);
                if (index == R$styleable.ConstraintLayout_Layout_constraint_referenced_ids) {
                    String string = typedArrayObtainStyledAttributes.getString(index);
                    this.f1955i = string;
                    setIds(string);
                }
            }
        }
    }

    public void n(b.a aVar, u.b bVar, ConstraintLayout.LayoutParams layoutParams, SparseArray<ConstraintWidget> sparseArray) {
        b.C0009b c0009b = aVar.f2012d;
        int[] iArr = c0009b.f2025e0;
        if (iArr != null) {
            setReferencedIds(iArr);
        } else {
            String str = c0009b.f2027f0;
            if (str != null && str.length() > 0) {
                b.C0009b c0009b2 = aVar.f2012d;
                c0009b2.f2025e0 = i(this, c0009b2.f2027f0);
            }
        }
        bVar.c();
        if (aVar.f2012d.f2025e0 == null) {
            return;
        }
        int i10 = 0;
        while (true) {
            int[] iArr2 = aVar.f2012d.f2025e0;
            if (i10 >= iArr2.length) {
                return;
            }
            ConstraintWidget constraintWidget = sparseArray.get(iArr2[i10]);
            if (constraintWidget != null) {
                bVar.a(constraintWidget);
            }
            i10++;
        }
    }

    @Override // android.view.View
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        String str = this.f1955i;
        if (str != null) {
            setIds(str);
        }
    }

    @Override // android.view.View
    protected void onMeasure(int i10, int i11) {
        if (this.f1954h) {
            super.onMeasure(i10, i11);
        } else {
            setMeasuredDimension(0, 0);
        }
    }

    public void s(androidx.constraintlayout.solver.widgets.d dVar, u.a aVar, SparseArray<ConstraintWidget> sparseArray) {
        aVar.c();
        for (int i10 = 0; i10 < this.f1951b; i10++) {
            aVar.a(sparseArray.get(this.f1950a[i10]));
        }
    }

    protected void setIds(String str) {
        this.f1955i = str;
        if (str == null) {
            return;
        }
        int i10 = 0;
        this.f1951b = 0;
        while (true) {
            int iIndexOf = str.indexOf(44, i10);
            if (iIndexOf == -1) {
                e(str.substring(i10));
                return;
            } else {
                e(str.substring(i10, iIndexOf));
                i10 = iIndexOf + 1;
            }
        }
    }

    public void setReferencedIds(int[] iArr) {
        this.f1955i = null;
        this.f1951b = 0;
        for (int i10 : iArr) {
            f(i10);
        }
    }

    public void t(ConstraintLayout constraintLayout) {
        String str;
        int iJ;
        if (isInEditMode()) {
            setIds(this.f1955i);
        }
        u.a aVar = this.f1953g;
        if (aVar == null) {
            return;
        }
        aVar.c();
        for (int i10 = 0; i10 < this.f1951b; i10++) {
            int i11 = this.f1950a[i10];
            View viewById = constraintLayout.getViewById(i11);
            if (viewById == null && (iJ = j(constraintLayout, (str = this.f1957k.get(Integer.valueOf(i11))))) != 0) {
                this.f1950a[i10] = iJ;
                this.f1957k.put(Integer.valueOf(iJ), str);
                viewById = constraintLayout.getViewById(iJ);
            }
            if (viewById != null) {
                this.f1953g.a(constraintLayout.getViewWidget(viewById));
            }
        }
        this.f1953g.b(constraintLayout.mLayoutWidget);
    }

    public void u() {
        if (this.f1953g == null) {
            return;
        }
        ViewGroup.LayoutParams layoutParams = getLayoutParams();
        if (layoutParams instanceof ConstraintLayout.LayoutParams) {
            ((ConstraintLayout.LayoutParams) layoutParams).widget = (ConstraintWidget) this.f1953g;
        }
    }

    public ConstraintHelper(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f1950a = new int[32];
        this.f1954h = false;
        this.f1956j = null;
        this.f1957k = new HashMap<>();
        this.f1952c = context;
        m(attributeSet);
    }

    public ConstraintHelper(Context context, AttributeSet attributeSet, int i10) {
        super(context, attributeSet, i10);
        this.f1950a = new int[32];
        this.f1954h = false;
        this.f1956j = null;
        this.f1957k = new HashMap<>();
        this.f1952c = context;
        m(attributeSet);
    }

    @Override // android.view.View
    public void onDraw(Canvas canvas) {
    }

    public void p(ConstraintLayout constraintLayout) {
    }

    public void q(ConstraintLayout constraintLayout) {
    }

    public void r(ConstraintLayout constraintLayout) {
    }

    public void o(ConstraintWidget constraintWidget, boolean z10) {
    }
}
