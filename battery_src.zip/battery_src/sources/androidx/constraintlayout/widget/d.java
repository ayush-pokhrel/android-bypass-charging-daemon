package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.Log;
import android.util.SparseArray;
import android.util.Xml;
import com.oplus.smartenginehelper.ParserTag;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

/* JADX INFO: compiled from: StateSet.java */
/* JADX INFO: loaded from: classes.dex */
public class d {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    int f2079a = -1;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    int f2080b = -1;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    int f2081c = -1;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private SparseArray<a> f2082d = new SparseArray<>();

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private SparseArray<androidx.constraintlayout.widget.b> f2083e = new SparseArray<>();

    /* JADX INFO: compiled from: StateSet.java */
    static class a {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        int f2084a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        ArrayList<b> f2085b = new ArrayList<>();

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        int f2086c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        boolean f2087d;

        public a(Context context, XmlPullParser xmlPullParser) {
            this.f2086c = -1;
            this.f2087d = false;
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(Xml.asAttributeSet(xmlPullParser), R$styleable.State);
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            for (int i10 = 0; i10 < indexCount; i10++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i10);
                if (index == R$styleable.State_android_id) {
                    this.f2084a = typedArrayObtainStyledAttributes.getResourceId(index, this.f2084a);
                } else if (index == R$styleable.State_constraints) {
                    this.f2086c = typedArrayObtainStyledAttributes.getResourceId(index, this.f2086c);
                    String resourceTypeName = context.getResources().getResourceTypeName(this.f2086c);
                    context.getResources().getResourceName(this.f2086c);
                    if (ParserTag.CHILD_LAYOUT.equals(resourceTypeName)) {
                        this.f2087d = true;
                    }
                }
            }
            typedArrayObtainStyledAttributes.recycle();
        }

        void a(b bVar) {
            this.f2085b.add(bVar);
        }

        public int b(float f10, float f11) {
            for (int i10 = 0; i10 < this.f2085b.size(); i10++) {
                if (this.f2085b.get(i10).a(f10, f11)) {
                    return i10;
                }
            }
            return -1;
        }
    }

    /* JADX INFO: compiled from: StateSet.java */
    static class b {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        float f2088a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        float f2089b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        float f2090c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        float f2091d;

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        int f2092e;

        /* JADX INFO: renamed from: f, reason: collision with root package name */
        boolean f2093f;

        public b(Context context, XmlPullParser xmlPullParser) {
            this.f2088a = Float.NaN;
            this.f2089b = Float.NaN;
            this.f2090c = Float.NaN;
            this.f2091d = Float.NaN;
            this.f2092e = -1;
            this.f2093f = false;
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(Xml.asAttributeSet(xmlPullParser), R$styleable.Variant);
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            for (int i10 = 0; i10 < indexCount; i10++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i10);
                if (index == R$styleable.Variant_constraints) {
                    this.f2092e = typedArrayObtainStyledAttributes.getResourceId(index, this.f2092e);
                    String resourceTypeName = context.getResources().getResourceTypeName(this.f2092e);
                    context.getResources().getResourceName(this.f2092e);
                    if (ParserTag.CHILD_LAYOUT.equals(resourceTypeName)) {
                        this.f2093f = true;
                    }
                } else if (index == R$styleable.Variant_region_heightLessThan) {
                    this.f2091d = typedArrayObtainStyledAttributes.getDimension(index, this.f2091d);
                } else if (index == R$styleable.Variant_region_heightMoreThan) {
                    this.f2089b = typedArrayObtainStyledAttributes.getDimension(index, this.f2089b);
                } else if (index == R$styleable.Variant_region_widthLessThan) {
                    this.f2090c = typedArrayObtainStyledAttributes.getDimension(index, this.f2090c);
                } else if (index == R$styleable.Variant_region_widthMoreThan) {
                    this.f2088a = typedArrayObtainStyledAttributes.getDimension(index, this.f2088a);
                } else {
                    Log.v("ConstraintLayoutStates", "Unknown tag");
                }
            }
            typedArrayObtainStyledAttributes.recycle();
        }

        boolean a(float f10, float f11) {
            if (!Float.isNaN(this.f2088a) && f10 < this.f2088a) {
                return false;
            }
            if (!Float.isNaN(this.f2089b) && f11 < this.f2089b) {
                return false;
            }
            if (Float.isNaN(this.f2090c) || f10 <= this.f2090c) {
                return Float.isNaN(this.f2091d) || f11 <= this.f2091d;
            }
            return false;
        }
    }

    public d(Context context, XmlPullParser xmlPullParser) {
        b(context, xmlPullParser);
    }

    /* JADX WARN: Code duplicated, block: B:39:0x007c  */
    /* JADX WARN: Failed to restore switch over string. Please report as a decompilation issue */
    private void b(Context context, XmlPullParser xmlPullParser) {
        byte b10;
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(Xml.asAttributeSet(xmlPullParser), R$styleable.StateSet);
        int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
        for (int i10 = 0; i10 < indexCount; i10++) {
            int index = typedArrayObtainStyledAttributes.getIndex(i10);
            if (index == R$styleable.StateSet_defaultState) {
                this.f2079a = typedArrayObtainStyledAttributes.getResourceId(index, this.f2079a);
            }
        }
        try {
            int eventType = xmlPullParser.getEventType();
            a aVar = null;
            while (eventType != 1) {
                if (eventType == 0) {
                    xmlPullParser.getName();
                } else if (eventType == 2) {
                    String name = xmlPullParser.getName();
                    switch (name.hashCode()) {
                        case 80204913:
                            if (name.equals("State")) {
                                b10 = 2;
                            } else {
                                b10 = -1;
                            }
                            break;
                        case 1301459538:
                            if (name.equals("LayoutDescription")) {
                                b10 = 0;
                            } else {
                                b10 = -1;
                            }
                            break;
                        case 1382829617:
                            if (name.equals("StateSet")) {
                                b10 = 1;
                            } else {
                                b10 = -1;
                            }
                            break;
                        case 1901439077:
                            if (name.equals("Variant")) {
                                b10 = 3;
                            } else {
                                b10 = -1;
                            }
                            break;
                        default:
                            b10 = -1;
                            break;
                    }
                    if (b10 != 0 && b10 != 1) {
                        if (b10 == 2) {
                            aVar = new a(context, xmlPullParser);
                            this.f2082d.put(aVar.f2084a, aVar);
                        } else if (b10 != 3) {
                            Log.v("ConstraintLayoutStates", "unknown tag " + name);
                        } else {
                            b bVar = new b(context, xmlPullParser);
                            if (aVar != null) {
                                aVar.a(bVar);
                            }
                        }
                    }
                } else if (eventType == 3 && "StateSet".equals(xmlPullParser.getName())) {
                    return;
                }
                eventType = xmlPullParser.next();
            }
        } catch (IOException e10) {
            e10.printStackTrace();
        } catch (XmlPullParserException e11) {
            e11.printStackTrace();
        }
    }

    public int a(int i10, int i11, float f10, float f11) {
        a aVar = this.f2082d.get(i11);
        if (aVar == null) {
            return i11;
        }
        if (f10 == -1.0f || f11 == -1.0f) {
            if (aVar.f2086c == i10) {
                return i10;
            }
            Iterator<b> it = aVar.f2085b.iterator();
            while (it.hasNext()) {
                if (i10 == it.next().f2092e) {
                    return i10;
                }
            }
            return aVar.f2086c;
        }
        b bVar = null;
        for (b bVar2 : aVar.f2085b) {
            if (bVar2.a(f10, f11)) {
                if (i10 == bVar2.f2092e) {
                    return i10;
                }
                bVar = bVar2;
            }
        }
        return bVar != null ? bVar.f2092e : aVar.f2086c;
    }

    public int c(int i10, int i11, int i12) {
        return d(-1, i10, i11, i12);
    }

    public int d(int i10, int i11, float f10, float f11) {
        int iB;
        if (i10 != i11) {
            a aVar = this.f2082d.get(i11);
            if (aVar == null) {
                return -1;
            }
            int iB2 = aVar.b(f10, f11);
            return iB2 == -1 ? aVar.f2086c : aVar.f2085b.get(iB2).f2092e;
        }
        a aVarValueAt = i11 == -1 ? this.f2082d.valueAt(0) : this.f2082d.get(this.f2080b);
        if (aVarValueAt == null) {
            return -1;
        }
        if ((this.f2081c == -1 || !aVarValueAt.f2085b.get(i10).a(f10, f11)) && i10 != (iB = aVarValueAt.b(f10, f11))) {
            return iB == -1 ? aVarValueAt.f2086c : aVarValueAt.f2085b.get(iB).f2092e;
        }
        return i10;
    }
}
