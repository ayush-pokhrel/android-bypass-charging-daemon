package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.SparseArray;
import androidx.constraintlayout.solver.widgets.ConstraintWidget;

/* JADX INFO: loaded from: classes.dex */
public class Barrier extends ConstraintHelper {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private int f1931l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    private int f1932m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    private androidx.constraintlayout.solver.widgets.a f1933n;

    public Barrier(Context context) {
        super(context);
        super.setVisibility(8);
    }

    private void w(ConstraintWidget constraintWidget, int i10, boolean z10) {
        this.f1932m = i10;
        if (z10) {
            int i11 = this.f1931l;
            if (i11 == 5) {
                this.f1932m = 1;
            } else if (i11 == 6) {
                this.f1932m = 0;
            }
        } else {
            int i12 = this.f1931l;
            if (i12 == 5) {
                this.f1932m = 0;
            } else if (i12 == 6) {
                this.f1932m = 1;
            }
        }
        if (constraintWidget instanceof androidx.constraintlayout.solver.widgets.a) {
            ((androidx.constraintlayout.solver.widgets.a) constraintWidget).Q0(this.f1932m);
        }
    }

    public int getMargin() {
        return this.f1933n.N0();
    }

    public int getType() {
        return this.f1931l;
    }

    @Override // androidx.constraintlayout.widget.ConstraintHelper
    protected void m(AttributeSet attributeSet) {
        super.m(attributeSet);
        this.f1933n = new androidx.constraintlayout.solver.widgets.a();
        if (attributeSet != null) {
            TypedArray typedArrayObtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, R$styleable.ConstraintLayout_Layout);
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            for (int i10 = 0; i10 < indexCount; i10++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i10);
                if (index == R$styleable.ConstraintLayout_Layout_barrierDirection) {
                    setType(typedArrayObtainStyledAttributes.getInt(index, 0));
                } else if (index == R$styleable.ConstraintLayout_Layout_barrierAllowsGoneWidgets) {
                    this.f1933n.P0(typedArrayObtainStyledAttributes.getBoolean(index, true));
                } else if (index == R$styleable.ConstraintLayout_Layout_barrierMargin) {
                    this.f1933n.R0(typedArrayObtainStyledAttributes.getDimensionPixelSize(index, 0));
                }
            }
        }
        this.f1953g = this.f1933n;
        u();
    }

    @Override // androidx.constraintlayout.widget.ConstraintHelper
    public void n(b.a aVar, u.b bVar, ConstraintLayout.LayoutParams layoutParams, SparseArray<ConstraintWidget> sparseArray) {
        super.n(aVar, bVar, layoutParams, sparseArray);
        if (bVar instanceof androidx.constraintlayout.solver.widgets.a) {
            androidx.constraintlayout.solver.widgets.a aVar2 = (androidx.constraintlayout.solver.widgets.a) bVar;
            w(aVar2, aVar.f2012d.f2019b0, ((androidx.constraintlayout.solver.widgets.d) bVar.H()).d1());
            aVar2.P0(aVar.f2012d.f2035j0);
            aVar2.R0(aVar.f2012d.f2021c0);
        }
    }

    @Override // androidx.constraintlayout.widget.ConstraintHelper
    public void o(ConstraintWidget constraintWidget, boolean z10) {
        w(constraintWidget, this.f1931l, z10);
    }

    public void setAllowsGoneWidget(boolean z10) {
        this.f1933n.P0(z10);
    }

    public void setDpMargin(int i10) {
        this.f1933n.R0((int) ((i10 * getResources().getDisplayMetrics().density) + 0.5f));
    }

    public void setMargin(int i10) {
        this.f1933n.R0(i10);
    }

    public void setType(int i10) {
        this.f1931l = i10;
    }

    public boolean v() {
        return this.f1933n.L0();
    }

    public Barrier(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        super.setVisibility(8);
    }

    public Barrier(Context context, AttributeSet attributeSet, int i10) {
        super(context, attributeSet, i10);
        super.setVisibility(8);
    }
}
