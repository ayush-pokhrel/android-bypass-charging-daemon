package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.view.View;
import androidx.constraintlayout.solver.widgets.ConstraintWidget;
import com.oplus.deepthinker.sdk.app.aidl.eventfountain.EventType;

/* JADX INFO: loaded from: classes.dex */
public class Placeholder extends View {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private int f1982a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private View f1983b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private int f1984c;

    public Placeholder(Context context) {
        super(context);
        this.f1982a = -1;
        this.f1983b = null;
        this.f1984c = 4;
        a(null);
    }

    private void a(AttributeSet attributeSet) {
        super.setVisibility(this.f1984c);
        this.f1982a = -1;
        if (attributeSet != null) {
            TypedArray typedArrayObtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, R$styleable.ConstraintLayout_placeholder);
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            for (int i10 = 0; i10 < indexCount; i10++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i10);
                if (index == R$styleable.ConstraintLayout_placeholder_content) {
                    this.f1982a = typedArrayObtainStyledAttributes.getResourceId(index, this.f1982a);
                } else if (index == R$styleable.ConstraintLayout_placeholder_placeholder_emptyVisibility) {
                    this.f1984c = typedArrayObtainStyledAttributes.getInt(index, this.f1984c);
                }
            }
        }
    }

    public void b(ConstraintLayout constraintLayout) {
        if (this.f1983b == null) {
            return;
        }
        ConstraintLayout.LayoutParams layoutParams = (ConstraintLayout.LayoutParams) getLayoutParams();
        ConstraintLayout.LayoutParams layoutParams2 = (ConstraintLayout.LayoutParams) this.f1983b.getLayoutParams();
        layoutParams2.widget.E0(0);
        ConstraintWidget.DimensionBehaviour dimensionBehaviourZ = layoutParams.widget.z();
        ConstraintWidget.DimensionBehaviour dimensionBehaviour = ConstraintWidget.DimensionBehaviour.FIXED;
        if (dimensionBehaviourZ != dimensionBehaviour) {
            layoutParams.widget.F0(layoutParams2.widget.Q());
        }
        if (layoutParams.widget.N() != dimensionBehaviour) {
            layoutParams.widget.i0(layoutParams2.widget.w());
        }
        layoutParams2.widget.E0(8);
    }

    public void c(ConstraintLayout constraintLayout) {
        if (this.f1982a == -1 && !isInEditMode()) {
            setVisibility(this.f1984c);
        }
        View viewFindViewById = constraintLayout.findViewById(this.f1982a);
        this.f1983b = viewFindViewById;
        if (viewFindViewById != null) {
            ((ConstraintLayout.LayoutParams) viewFindViewById.getLayoutParams()).isInPlaceholder = true;
            this.f1983b.setVisibility(0);
            setVisibility(0);
        }
    }

    public View getContent() {
        return this.f1983b;
    }

    public int getEmptyVisibility() {
        return this.f1984c;
    }

    @Override // android.view.View
    public void onDraw(Canvas canvas) {
        if (isInEditMode()) {
            canvas.drawRGB(223, 223, 223);
            Paint paint = new Paint();
            paint.setARGB(255, EventType.SCENE_MODE_FILE_DOWNLOAD, EventType.SCENE_MODE_FILE_DOWNLOAD, EventType.SCENE_MODE_FILE_DOWNLOAD);
            paint.setTextAlign(Paint.Align.CENTER);
            paint.setTypeface(Typeface.create(Typeface.DEFAULT, 0));
            Rect rect = new Rect();
            canvas.getClipBounds(rect);
            paint.setTextSize(rect.height());
            int iHeight = rect.height();
            int iWidth = rect.width();
            paint.setTextAlign(Paint.Align.LEFT);
            paint.getTextBounds("?", 0, 1, rect);
            canvas.drawText("?", ((iWidth / 2.0f) - (rect.width() / 2.0f)) - rect.left, ((iHeight / 2.0f) + (rect.height() / 2.0f)) - rect.bottom, paint);
        }
    }

    public void setContentId(int i10) {
        View viewFindViewById;
        if (this.f1982a == i10) {
            return;
        }
        View view = this.f1983b;
        if (view != null) {
            view.setVisibility(0);
            ((ConstraintLayout.LayoutParams) this.f1983b.getLayoutParams()).isInPlaceholder = false;
            this.f1983b = null;
        }
        this.f1982a = i10;
        if (i10 == -1 || (viewFindViewById = ((View) getParent()).findViewById(i10)) == null) {
            return;
        }
        viewFindViewById.setVisibility(8);
    }

    public void setEmptyVisibility(int i10) {
        this.f1984c = i10;
    }

    public Placeholder(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f1982a = -1;
        this.f1983b = null;
        this.f1984c = 4;
        a(attributeSet);
    }

    public Placeholder(Context context, AttributeSet attributeSet, int i10) {
        super(context, attributeSet, i10);
        this.f1982a = -1;
        this.f1983b = null;
        this.f1984c = 4;
        a(attributeSet);
    }
}
