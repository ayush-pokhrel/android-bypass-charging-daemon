package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.util.Log;
import android.util.SparseArray;
import android.util.Xml;
import com.oplus.smartenginehelper.ParserTag;
import java.io.IOException;
import java.util.ArrayList;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

/* JADX INFO: compiled from: ConstraintLayoutStates.java */
/* JADX INFO: loaded from: classes.dex */
public class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final ConstraintLayout f1987a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    androidx.constraintlayout.widget.b f1988b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    int f1989c = -1;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    int f1990d = -1;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private SparseArray<C0008a> f1991e = new SparseArray<>();

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private SparseArray<androidx.constraintlayout.widget.b> f1992f = new SparseArray<>();

    /* JADX INFO: renamed from: androidx.constraintlayout.widget.a$a, reason: collision with other inner class name */
    /* JADX INFO: compiled from: ConstraintLayoutStates.java */
    static class C0008a {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        int f1993a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        ArrayList<b> f1994b = new ArrayList<>();

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        int f1995c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        androidx.constraintlayout.widget.b f1996d;

        public C0008a(Context context, XmlPullParser xmlPullParser) {
            this.f1995c = -1;
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(Xml.asAttributeSet(xmlPullParser), R$styleable.State);
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            for (int i10 = 0; i10 < indexCount; i10++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i10);
                if (index == R$styleable.State_android_id) {
                    this.f1993a = typedArrayObtainStyledAttributes.getResourceId(index, this.f1993a);
                } else if (index == R$styleable.State_constraints) {
                    this.f1995c = typedArrayObtainStyledAttributes.getResourceId(index, this.f1995c);
                    String resourceTypeName = context.getResources().getResourceTypeName(this.f1995c);
                    context.getResources().getResourceName(this.f1995c);
                    if (ParserTag.CHILD_LAYOUT.equals(resourceTypeName)) {
                        androidx.constraintlayout.widget.b bVar = new androidx.constraintlayout.widget.b();
                        this.f1996d = bVar;
                        bVar.h(context, this.f1995c);
                    }
                }
            }
            typedArrayObtainStyledAttributes.recycle();
        }

        void a(b bVar) {
            this.f1994b.add(bVar);
        }

        public int b(float f10, float f11) {
            for (int i10 = 0; i10 < this.f1994b.size(); i10++) {
                if (this.f1994b.get(i10).a(f10, f11)) {
                    return i10;
                }
            }
            return -1;
        }
    }

    /* JADX INFO: compiled from: ConstraintLayoutStates.java */
    static class b {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        float f1997a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        float f1998b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        float f1999c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        float f2000d;

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        int f2001e;

        /* JADX INFO: renamed from: f, reason: collision with root package name */
        androidx.constraintlayout.widget.b f2002f;

        public b(Context context, XmlPullParser xmlPullParser) {
            this.f1997a = Float.NaN;
            this.f1998b = Float.NaN;
            this.f1999c = Float.NaN;
            this.f2000d = Float.NaN;
            this.f2001e = -1;
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(Xml.asAttributeSet(xmlPullParser), R$styleable.Variant);
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            for (int i10 = 0; i10 < indexCount; i10++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i10);
                if (index == R$styleable.Variant_constraints) {
                    this.f2001e = typedArrayObtainStyledAttributes.getResourceId(index, this.f2001e);
                    String resourceTypeName = context.getResources().getResourceTypeName(this.f2001e);
                    context.getResources().getResourceName(this.f2001e);
                    if (ParserTag.CHILD_LAYOUT.equals(resourceTypeName)) {
                        androidx.constraintlayout.widget.b bVar = new androidx.constraintlayout.widget.b();
                        this.f2002f = bVar;
                        bVar.h(context, this.f2001e);
                    }
                } else if (index == R$styleable.Variant_region_heightLessThan) {
                    this.f2000d = typedArrayObtainStyledAttributes.getDimension(index, this.f2000d);
                } else if (index == R$styleable.Variant_region_heightMoreThan) {
                    this.f1998b = typedArrayObtainStyledAttributes.getDimension(index, this.f1998b);
                } else if (index == R$styleable.Variant_region_widthLessThan) {
                    this.f1999c = typedArrayObtainStyledAttributes.getDimension(index, this.f1999c);
                } else if (index == R$styleable.Variant_region_widthMoreThan) {
                    this.f1997a = typedArrayObtainStyledAttributes.getDimension(index, this.f1997a);
                } else {
                    Log.v("ConstraintLayoutStates", "Unknown tag");
                }
            }
            typedArrayObtainStyledAttributes.recycle();
        }

        boolean a(float f10, float f11) {
            if (!Float.isNaN(this.f1997a) && f10 < this.f1997a) {
                return false;
            }
            if (!Float.isNaN(this.f1998b) && f11 < this.f1998b) {
                return false;
            }
            if (Float.isNaN(this.f1999c) || f10 <= this.f1999c) {
                return Float.isNaN(this.f2000d) || f11 <= this.f2000d;
            }
            return false;
        }
    }

    a(Context context, ConstraintLayout constraintLayout, int i10) {
        this.f1987a = constraintLayout;
        a(context, i10);
    }

    /* JADX WARN: Code duplicated, block: B:32:0x005d  */
    /* JADX WARN: Failed to restore switch over string. Please report as a decompilation issue */
    private void a(Context context, int i10) {
        byte b10;
        XmlResourceParser xml = context.getResources().getXml(i10);
        try {
            C0008a c0008a = null;
            for (int eventType = xml.getEventType(); eventType != 1; eventType = xml.next()) {
                if (eventType == 0) {
                    xml.getName();
                } else if (eventType == 2) {
                    String name = xml.getName();
                    switch (name.hashCode()) {
                        case -1349929691:
                            if (name.equals("ConstraintSet")) {
                                b10 = 4;
                            } else {
                                b10 = -1;
                            }
                            break;
                        case 80204913:
                            if (name.equals("State")) {
                                b10 = 2;
                            } else {
                                b10 = -1;
                            }
                            break;
                        case 1382829617:
                            if (name.equals("StateSet")) {
                                b10 = 1;
                            } else {
                                b10 = -1;
                            }
                            break;
                        case 1657696882:
                            if (name.equals("layoutDescription")) {
                                b10 = 0;
                            } else {
                                b10 = -1;
                            }
                            break;
                        case 1901439077:
                            if (name.equals("Variant")) {
                                b10 = 3;
                            } else {
                                b10 = -1;
                            }
                            break;
                        default:
                            b10 = -1;
                            break;
                    }
                    if (b10 != 0 && b10 != 1) {
                        if (b10 == 2) {
                            c0008a = new C0008a(context, xml);
                            this.f1991e.put(c0008a.f1993a, c0008a);
                        } else if (b10 == 3) {
                            b bVar = new b(context, xml);
                            if (c0008a != null) {
                                c0008a.a(bVar);
                            }
                        } else if (b10 != 4) {
                            Log.v("ConstraintLayoutStates", "unknown tag " + name);
                        } else {
                            b(context, xml);
                        }
                    }
                }
            }
        } catch (IOException e10) {
            e10.printStackTrace();
        } catch (XmlPullParserException e11) {
            e11.printStackTrace();
        }
    }

    private void b(Context context, XmlPullParser xmlPullParser) {
        androidx.constraintlayout.widget.b bVar = new androidx.constraintlayout.widget.b();
        int attributeCount = xmlPullParser.getAttributeCount();
        for (int i10 = 0; i10 < attributeCount; i10++) {
            if ("id".equals(xmlPullParser.getAttributeName(i10))) {
                String attributeValue = xmlPullParser.getAttributeValue(i10);
                int identifier = attributeValue.contains("/") ? context.getResources().getIdentifier(attributeValue.substring(attributeValue.indexOf(47) + 1), "id", context.getPackageName()) : -1;
                if (identifier == -1) {
                    if (attributeValue.length() > 1) {
                        identifier = Integer.parseInt(attributeValue.substring(1));
                    } else {
                        Log.e("ConstraintLayoutStates", "error in parsing id");
                    }
                }
                bVar.x(context, xmlPullParser);
                this.f1992f.put(identifier, bVar);
                return;
            }
        }
    }

    public void d(int i10, float f10, float f11) {
        int iB;
        int i11 = this.f1989c;
        if (i11 == i10) {
            C0008a c0008aValueAt = i10 == -1 ? this.f1991e.valueAt(0) : this.f1991e.get(i11);
            int i12 = this.f1990d;
            if ((i12 == -1 || !c0008aValueAt.f1994b.get(i12).a(f10, f11)) && this.f1990d != (iB = c0008aValueAt.b(f10, f11))) {
                androidx.constraintlayout.widget.b bVar = iB == -1 ? this.f1988b : c0008aValueAt.f1994b.get(iB).f2002f;
                if (iB != -1) {
                    int i13 = c0008aValueAt.f1994b.get(iB).f2001e;
                }
                if (bVar == null) {
                    return;
                }
                this.f1990d = iB;
                bVar.d(this.f1987a);
                return;
            }
            return;
        }
        this.f1989c = i10;
        C0008a c0008a = this.f1991e.get(i10);
        int iB2 = c0008a.b(f10, f11);
        androidx.constraintlayout.widget.b bVar2 = iB2 == -1 ? c0008a.f1996d : c0008a.f1994b.get(iB2).f2002f;
        if (iB2 != -1) {
            int i14 = c0008a.f1994b.get(iB2).f2001e;
        }
        if (bVar2 != null) {
            this.f1990d = iB2;
            bVar2.d(this.f1987a);
            return;
        }
        Log.v("ConstraintLayoutStates", "NO Constraint set found ! id=" + i10 + ", dim =" + f10 + ", " + f11);
    }

    public void c(c cVar) {
    }
}
