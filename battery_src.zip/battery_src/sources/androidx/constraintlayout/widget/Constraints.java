package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.Log;
import android.view.ViewGroup;

/* JADX INFO: loaded from: classes.dex */
public class Constraints extends ViewGroup {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    b f1968a;

    public Constraints(Context context) {
        super(context);
        super.setVisibility(8);
    }

    private void c(AttributeSet attributeSet) {
        Log.v("Constraints", " ################# init");
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.view.ViewGroup
    /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
    public LayoutParams generateDefaultLayoutParams() {
        return new LayoutParams(-2, -2);
    }

    @Override // android.view.ViewGroup
    /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
    public LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new LayoutParams(getContext(), attributeSet);
    }

    public b getConstraintSet() {
        if (this.f1968a == null) {
            this.f1968a = new b();
        }
        this.f1968a.j(this);
        return this.f1968a;
    }

    @Override // android.view.ViewGroup
    protected ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return new ConstraintLayout.LayoutParams(layoutParams);
    }

    public Constraints(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        c(attributeSet);
        super.setVisibility(8);
    }

    public Constraints(Context context, AttributeSet attributeSet, int i10) {
        super(context, attributeSet, i10);
        c(attributeSet);
        super.setVisibility(8);
    }

    public static class LayoutParams extends ConstraintLayout.LayoutParams {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public float f1969a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public boolean f1970b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        public float f1971c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        public float f1972d;

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        public float f1973e;

        /* JADX INFO: renamed from: f, reason: collision with root package name */
        public float f1974f;

        /* JADX INFO: renamed from: g, reason: collision with root package name */
        public float f1975g;

        /* JADX INFO: renamed from: h, reason: collision with root package name */
        public float f1976h;

        /* JADX INFO: renamed from: i, reason: collision with root package name */
        public float f1977i;

        /* JADX INFO: renamed from: j, reason: collision with root package name */
        public float f1978j;

        /* JADX INFO: renamed from: k, reason: collision with root package name */
        public float f1979k;

        /* JADX INFO: renamed from: l, reason: collision with root package name */
        public float f1980l;

        /* JADX INFO: renamed from: m, reason: collision with root package name */
        public float f1981m;

        public LayoutParams(int i10, int i11) {
            super(i10, i11);
            this.f1969a = 1.0f;
            this.f1970b = false;
            this.f1971c = 0.0f;
            this.f1972d = 0.0f;
            this.f1973e = 0.0f;
            this.f1974f = 0.0f;
            this.f1975g = 1.0f;
            this.f1976h = 1.0f;
            this.f1977i = 0.0f;
            this.f1978j = 0.0f;
            this.f1979k = 0.0f;
            this.f1980l = 0.0f;
            this.f1981m = 0.0f;
        }

        public LayoutParams(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            this.f1969a = 1.0f;
            this.f1970b = false;
            this.f1971c = 0.0f;
            this.f1972d = 0.0f;
            this.f1973e = 0.0f;
            this.f1974f = 0.0f;
            this.f1975g = 1.0f;
            this.f1976h = 1.0f;
            this.f1977i = 0.0f;
            this.f1978j = 0.0f;
            this.f1979k = 0.0f;
            this.f1980l = 0.0f;
            this.f1981m = 0.0f;
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R$styleable.ConstraintSet);
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            for (int i10 = 0; i10 < indexCount; i10++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i10);
                if (index == R$styleable.ConstraintSet_android_alpha) {
                    this.f1969a = typedArrayObtainStyledAttributes.getFloat(index, this.f1969a);
                } else if (index == R$styleable.ConstraintSet_android_elevation) {
                    this.f1971c = typedArrayObtainStyledAttributes.getFloat(index, this.f1971c);
                    this.f1970b = true;
                } else if (index == R$styleable.ConstraintSet_android_rotationX) {
                    this.f1973e = typedArrayObtainStyledAttributes.getFloat(index, this.f1973e);
                } else if (index == R$styleable.ConstraintSet_android_rotationY) {
                    this.f1974f = typedArrayObtainStyledAttributes.getFloat(index, this.f1974f);
                } else if (index == R$styleable.ConstraintSet_android_rotation) {
                    this.f1972d = typedArrayObtainStyledAttributes.getFloat(index, this.f1972d);
                } else if (index == R$styleable.ConstraintSet_android_scaleX) {
                    this.f1975g = typedArrayObtainStyledAttributes.getFloat(index, this.f1975g);
                } else if (index == R$styleable.ConstraintSet_android_scaleY) {
                    this.f1976h = typedArrayObtainStyledAttributes.getFloat(index, this.f1976h);
                } else if (index == R$styleable.ConstraintSet_android_transformPivotX) {
                    this.f1977i = typedArrayObtainStyledAttributes.getFloat(index, this.f1977i);
                } else if (index == R$styleable.ConstraintSet_android_transformPivotY) {
                    this.f1978j = typedArrayObtainStyledAttributes.getFloat(index, this.f1978j);
                } else if (index == R$styleable.ConstraintSet_android_translationX) {
                    this.f1979k = typedArrayObtainStyledAttributes.getFloat(index, this.f1979k);
                } else if (index == R$styleable.ConstraintSet_android_translationY) {
                    this.f1980l = typedArrayObtainStyledAttributes.getFloat(index, this.f1980l);
                } else if (index == R$styleable.ConstraintSet_android_translationZ) {
                    this.f1981m = typedArrayObtainStyledAttributes.getFloat(index, this.f1981m);
                }
            }
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onLayout(boolean z10, int i10, int i11, int i12, int i13) {
    }
}
