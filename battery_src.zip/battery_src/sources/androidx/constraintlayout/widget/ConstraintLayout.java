package androidx.constraintlayout.widget;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.util.SparseIntArray;
import android.view.View;
import android.view.ViewGroup;
import androidx.constraintlayout.solver.widgets.ConstraintAnchor;
import androidx.constraintlayout.solver.widgets.ConstraintWidget;
import androidx.constraintlayout.solver.widgets.f;
import androidx.constraintlayout.solver.widgets.h;
import java.util.ArrayList;
import java.util.HashMap;

/* JADX INFO: loaded from: classes.dex */
public class ConstraintLayout extends ViewGroup {
    private static final boolean DEBUG = false;
    private static final boolean DEBUG_DRAW_CONSTRAINTS = false;
    public static final int DESIGN_INFO_ID = 0;
    private static final boolean MEASURE = false;
    private static final String TAG = "ConstraintLayout";
    private static final boolean USE_CONSTRAINTS_HELPER = true;
    public static final String VERSION = "ConstraintLayout-2.0.1";
    SparseArray<View> mChildrenByIds;
    private ArrayList<ConstraintHelper> mConstraintHelpers;
    protected androidx.constraintlayout.widget.a mConstraintLayoutSpec;
    private androidx.constraintlayout.widget.b mConstraintSet;
    private int mConstraintSetId;
    private c mConstraintsChangedListener;
    private HashMap<String, Integer> mDesignIds;
    protected boolean mDirtyHierarchy;
    private int mLastMeasureHeight;
    int mLastMeasureHeightMode;
    int mLastMeasureHeightSize;
    private int mLastMeasureWidth;
    int mLastMeasureWidthMode;
    int mLastMeasureWidthSize;
    protected androidx.constraintlayout.solver.widgets.d mLayoutWidget;
    private int mMaxHeight;
    private int mMaxWidth;
    b mMeasurer;
    private t.a mMetrics;
    private int mMinHeight;
    private int mMinWidth;
    private int mOnMeasureHeightMeasureSpec;
    private int mOnMeasureWidthMeasureSpec;
    private int mOptimizationLevel;
    private SparseArray<ConstraintWidget> mTempMapIdToWidget;

    static /* synthetic */ class a {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        static final /* synthetic */ int[] f1959a;

        static {
            int[] iArr = new int[ConstraintWidget.DimensionBehaviour.values().length];
            f1959a = iArr;
            try {
                iArr[ConstraintWidget.DimensionBehaviour.FIXED.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                f1959a[ConstraintWidget.DimensionBehaviour.WRAP_CONTENT.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                f1959a[ConstraintWidget.DimensionBehaviour.MATCH_PARENT.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                f1959a[ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
        }
    }

    class b implements androidx.constraintlayout.solver.widgets.analyzer.b.InterfaceC0007b {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        ConstraintLayout f1960a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        int f1961b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        int f1962c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        int f1963d;

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        int f1964e;

        /* JADX INFO: renamed from: f, reason: collision with root package name */
        int f1965f;

        /* JADX INFO: renamed from: g, reason: collision with root package name */
        int f1966g;

        public b(ConstraintLayout constraintLayout) {
            this.f1960a = constraintLayout;
        }

        /* JADX WARN: Code duplicated, block: B:101:0x0166  */
        /* JADX WARN: Code duplicated, block: B:104:0x0171 A[ADDED_TO_REGION] */
        /* JADX WARN: Code duplicated, block: B:112:0x0186  */
        /* JADX WARN: Code duplicated, block: B:114:0x018a  */
        /* JADX WARN: Code duplicated, block: B:117:0x0198  */
        /* JADX WARN: Code duplicated, block: B:120:0x01a9  */
        /* JADX WARN: Code duplicated, block: B:121:0x01b2  */
        /* JADX WARN: Code duplicated, block: B:123:0x01bc  */
        /* JADX WARN: Code duplicated, block: B:124:0x01c5  */
        /* JADX WARN: Code duplicated, block: B:127:0x01d1  */
        /* JADX WARN: Code duplicated, block: B:128:0x01d6  */
        /* JADX WARN: Code duplicated, block: B:131:0x01db  */
        /* JADX WARN: Code duplicated, block: B:134:0x01e3  */
        /* JADX WARN: Code duplicated, block: B:135:0x01e8  */
        /* JADX WARN: Code duplicated, block: B:138:0x01ed  */
        /* JADX WARN: Code duplicated, block: B:141:0x01f5 A[ADDED_TO_REGION] */
        /* JADX WARN: Code duplicated, block: B:143:0x01fe A[DONT_INVERT] */
        /* JADX WARN: Code duplicated, block: B:144:0x0200 A[ADDED_TO_REGION] */
        /* JADX WARN: Code duplicated, block: B:147:0x020b A[ADDED_TO_REGION] */
        /* JADX WARN: Code duplicated, block: B:151:0x0211  */
        /* JADX WARN: Code duplicated, block: B:153:0x0215  */
        /* JADX WARN: Code duplicated, block: B:155:0x021b  */
        /* JADX WARN: Code duplicated, block: B:158:0x0232  */
        /* JADX WARN: Code duplicated, block: B:159:0x0234  */
        /* JADX WARN: Code duplicated, block: B:162:0x023a  */
        /* JADX WARN: Code duplicated, block: B:166:0x0242  */
        /* JADX WARN: Code duplicated, block: B:169:0x0249  */
        /* JADX WARN: Code duplicated, block: B:170:0x024b  */
        /* JADX WARN: Code duplicated, block: B:172:0x024e  */
        /* JADX WARN: Code duplicated, block: B:42:0x00bb A[DONT_INVERT] */
        /* JADX WARN: Code duplicated, block: B:43:0x00bd A[DONT_INVERT] */
        /* JADX WARN: Code duplicated, block: B:44:0x00bf  */
        /* JADX WARN: Code duplicated, block: B:46:0x00c2  */
        /* JADX WARN: Code duplicated, block: B:47:0x00c6  */
        /* JADX WARN: Code duplicated, block: B:49:0x00d1  */
        /* JADX WARN: Code duplicated, block: B:50:0x00d3  */
        /* JADX WARN: Code duplicated, block: B:53:0x00dd  */
        /* JADX WARN: Code duplicated, block: B:54:0x00df  */
        /* JADX WARN: Code duplicated, block: B:58:0x00eb  */
        /* JADX WARN: Code duplicated, block: B:63:0x00f4 A[ADDED_TO_REGION] */
        /* JADX WARN: Code duplicated, block: B:68:0x0106  */
        /* JADX WARN: Code duplicated, block: B:69:0x0117  */
        /* JADX WARN: Code duplicated, block: B:70:0x0123  */
        /* JADX WARN: Code duplicated, block: B:73:0x0132  */
        /* JADX WARN: Code duplicated, block: B:74:0x0134  */
        /* JADX WARN: Code duplicated, block: B:76:0x0137  */
        /* JADX WARN: Code duplicated, block: B:77:0x0139  */
        /* JADX WARN: Code duplicated, block: B:80:0x013e  */
        /* JADX WARN: Code duplicated, block: B:84:0x0145  */
        /* JADX WARN: Code duplicated, block: B:86:0x0148  */
        /* JADX WARN: Code duplicated, block: B:90:0x014f  */
        /* JADX WARN: Code duplicated, block: B:93:0x0153  */
        /* JADX WARN: Code duplicated, block: B:96:0x015b  */
        /* JADX WARN: Code duplicated, block: B:98:0x015e  */
        /* JADX WARN: Multi-variable type inference failed */
        @Override // androidx.constraintlayout.solver.widgets.analyzer.b.InterfaceC0007b
        @SuppressLint({"WrongCall"})
        public final void a(ConstraintWidget constraintWidget, androidx.constraintlayout.solver.widgets.analyzer.b.a aVar) {
            int iMakeMeasureSpec;
            boolean z10;
            int i10;
            int iMakeMeasureSpec2;
            boolean z11;
            ConstraintWidget.DimensionBehaviour dimensionBehaviour;
            boolean z12;
            boolean z13;
            ConstraintWidget.DimensionBehaviour dimensionBehaviour2;
            boolean z14;
            boolean z15;
            boolean z16;
            boolean z17;
            LayoutParams layoutParams;
            int measuredWidth;
            int measuredHeight;
            int baseline;
            int i11;
            int i12;
            int measuredWidth2;
            int i13;
            int i14;
            int iMin;
            int i15;
            int measuredHeight2;
            int i16;
            int i17;
            boolean z18;
            boolean z19;
            int childMeasureSpec;
            int childMeasureSpec2;
            boolean z20;
            int[] iArr;
            if (constraintWidget == null) {
                return;
            }
            if (constraintWidget.P() == 8 && !constraintWidget.X()) {
                aVar.f1785e = 0;
                aVar.f1786f = 0;
                aVar.f1787g = 0;
                return;
            }
            ConstraintWidget.DimensionBehaviour dimensionBehaviour3 = aVar.f1781a;
            ConstraintWidget.DimensionBehaviour dimensionBehaviour4 = aVar.f1782b;
            int i18 = aVar.f1783c;
            int i19 = aVar.f1784d;
            int i20 = this.f1961b + this.f1962c;
            int i21 = this.f1963d;
            View view = (View) constraintWidget.r();
            int[] iArr2 = a.f1959a;
            int i22 = iArr2[dimensionBehaviour3.ordinal()];
            if (i22 != 1) {
                if (i22 == 2) {
                    iMakeMeasureSpec = ViewGroup.getChildMeasureSpec(this.f1965f, i21, -2);
                    constraintWidget.f1696h[2] = -2;
                } else if (i22 == 3) {
                    iMakeMeasureSpec = ViewGroup.getChildMeasureSpec(this.f1965f, i21 + constraintWidget.A(), -1);
                    constraintWidget.f1696h[2] = -1;
                } else if (i22 != 4) {
                    iMakeMeasureSpec = 0;
                } else {
                    iMakeMeasureSpec = ViewGroup.getChildMeasureSpec(this.f1965f, i21, -2);
                    boolean z21 = constraintWidget.f1704l == 1;
                    int[] iArr3 = constraintWidget.f1696h;
                    iArr3[2] = 0;
                    if (aVar.f1790j) {
                        boolean z22 = !(!z21 || iArr3[3] == 0 || iArr3[0] == constraintWidget.Q()) || (view instanceof Placeholder);
                        if (!z21 || z22) {
                            iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(constraintWidget.Q(), 1073741824);
                        }
                        i10 = iArr2[dimensionBehaviour4.ordinal()];
                        if (i10 != 1) {
                            if (i10 != 2) {
                                if (i10 != 3) {
                                    if (i10 != 4) {
                                        z11 = false;
                                        iMakeMeasureSpec2 = 0;
                                    } else {
                                        childMeasureSpec = ViewGroup.getChildMeasureSpec(this.f1966g, i20, -2);
                                        if (constraintWidget.f1706m == 1) {
                                            z20 = true;
                                        } else {
                                            z20 = false;
                                        }
                                        iArr = constraintWidget.f1696h;
                                        iArr[3] = 0;
                                        if (aVar.f1790j) {
                                            boolean z23 = !(z20 || iArr[2] == 0 || iArr[1] == constraintWidget.w()) || (view instanceof Placeholder);
                                            if (z20 || z23) {
                                                childMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(constraintWidget.w(), 1073741824);
                                            }
                                        }
                                    }
                                    dimensionBehaviour = ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT;
                                    if (dimensionBehaviour3 == dimensionBehaviour) {
                                        z12 = true;
                                    } else {
                                        z12 = false;
                                    }
                                    if (dimensionBehaviour4 == dimensionBehaviour) {
                                        z13 = true;
                                    } else {
                                        z13 = false;
                                    }
                                    dimensionBehaviour2 = ConstraintWidget.DimensionBehaviour.MATCH_PARENT;
                                    if (dimensionBehaviour4 != dimensionBehaviour2 || dimensionBehaviour4 == ConstraintWidget.DimensionBehaviour.FIXED) {
                                        z14 = true;
                                    } else {
                                        z14 = false;
                                    }
                                    if (dimensionBehaviour3 != dimensionBehaviour2 || dimensionBehaviour3 == ConstraintWidget.DimensionBehaviour.FIXED) {
                                        z15 = true;
                                    } else {
                                        z15 = false;
                                    }
                                    if (z12 || constraintWidget.S <= 0.0f) {
                                        z16 = false;
                                    } else {
                                        z16 = true;
                                    }
                                    if (z13 || constraintWidget.S <= 0.0f) {
                                        z17 = false;
                                    } else {
                                        z17 = true;
                                    }
                                    layoutParams = (LayoutParams) view.getLayoutParams();
                                    if (aVar.f1790j && z12 && constraintWidget.f1704l == 0 && z13 && constraintWidget.f1706m == 0) {
                                        measuredWidth2 = 0;
                                        measuredHeight2 = 0;
                                        i16 = -1;
                                        baseline = 0;
                                        i11 = 0;
                                    } else {
                                        if ((view instanceof VirtualLayout) || !(constraintWidget instanceof h)) {
                                            view.measure(iMakeMeasureSpec, iMakeMeasureSpec2);
                                        } else {
                                            ((VirtualLayout) view).v((h) constraintWidget, iMakeMeasureSpec, iMakeMeasureSpec2);
                                        }
                                        measuredWidth = view.getMeasuredWidth();
                                        measuredHeight = view.getMeasuredHeight();
                                        baseline = view.getBaseline();
                                        if (z10) {
                                            int[] iArr4 = constraintWidget.f1696h;
                                            i11 = 0;
                                            iArr4[0] = measuredWidth;
                                            iArr4[2] = measuredHeight;
                                        } else {
                                            i11 = 0;
                                            int[] iArr5 = constraintWidget.f1696h;
                                            iArr5[0] = 0;
                                            iArr5[2] = 0;
                                        }
                                        if (z11) {
                                            int[] iArr6 = constraintWidget.f1696h;
                                            iArr6[1] = measuredHeight;
                                            iArr6[3] = measuredWidth;
                                        } else {
                                            int[] iArr7 = constraintWidget.f1696h;
                                            iArr7[1] = i11;
                                            iArr7[3] = i11;
                                        }
                                        i12 = constraintWidget.f1710o;
                                        if (i12 > 0) {
                                            measuredWidth2 = Math.max(i12, measuredWidth);
                                        } else {
                                            measuredWidth2 = measuredWidth;
                                        }
                                        i13 = constraintWidget.f1712p;
                                        if (i13 > 0) {
                                            measuredWidth2 = Math.min(i13, measuredWidth2);
                                        }
                                        i14 = constraintWidget.f1716r;
                                        if (i14 > 0) {
                                            iMin = Math.max(i14, measuredHeight);
                                        } else {
                                            iMin = measuredHeight;
                                        }
                                        i15 = constraintWidget.f1718s;
                                        if (i15 > 0) {
                                            iMin = Math.min(i15, iMin);
                                        }
                                        if (!z16 && z14) {
                                            measuredWidth2 = (int) ((iMin * constraintWidget.S) + 0.5f);
                                        } else if (z17 && z15) {
                                            iMin = (int) ((measuredWidth2 / constraintWidget.S) + 0.5f);
                                        }
                                        if (measuredWidth == measuredWidth2 || measuredHeight != iMin) {
                                            if (measuredWidth != measuredWidth2) {
                                                iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(measuredWidth2, 1073741824);
                                            }
                                            if (measuredHeight != iMin) {
                                                iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(iMin, 1073741824);
                                            }
                                            view.measure(iMakeMeasureSpec, iMakeMeasureSpec2);
                                            measuredWidth2 = view.getMeasuredWidth();
                                            measuredHeight2 = view.getMeasuredHeight();
                                            baseline = view.getBaseline();
                                        } else {
                                            measuredHeight2 = iMin;
                                        }
                                        i16 = -1;
                                    }
                                    if (baseline != i16) {
                                        i17 = 1;
                                    } else {
                                        i17 = i11;
                                    }
                                    if (measuredWidth2 == aVar.f1783c || measuredHeight2 != aVar.f1784d) {
                                        z18 = 1;
                                    } else {
                                        z18 = i11;
                                    }
                                    aVar.f1789i = z18;
                                    if (layoutParams.needsBaseline) {
                                        z19 = 1;
                                    } else {
                                        z19 = i17;
                                    }
                                    if (z19 != 0 && baseline != -1 && constraintWidget.o() != baseline) {
                                        aVar.f1789i = true;
                                    }
                                    aVar.f1785e = measuredWidth2;
                                    aVar.f1786f = measuredHeight2;
                                    aVar.f1788h = z19;
                                    aVar.f1787g = baseline;
                                }
                                childMeasureSpec2 = ViewGroup.getChildMeasureSpec(this.f1966g, i20 + constraintWidget.O(), -1);
                                constraintWidget.f1696h[3] = -1;
                                iMakeMeasureSpec2 = childMeasureSpec2;
                            } else {
                                childMeasureSpec = ViewGroup.getChildMeasureSpec(this.f1966g, i20, -2);
                                constraintWidget.f1696h[3] = -2;
                            }
                            iMakeMeasureSpec2 = childMeasureSpec;
                            z11 = true;
                            dimensionBehaviour = ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT;
                            if (dimensionBehaviour3 == dimensionBehaviour) {
                                z12 = true;
                            } else {
                                z12 = false;
                            }
                            if (dimensionBehaviour4 == dimensionBehaviour) {
                                z13 = true;
                            } else {
                                z13 = false;
                            }
                            dimensionBehaviour2 = ConstraintWidget.DimensionBehaviour.MATCH_PARENT;
                            if (dimensionBehaviour4 != dimensionBehaviour2) {
                                z14 = true;
                            } else {
                                z14 = true;
                            }
                            if (dimensionBehaviour3 != dimensionBehaviour2) {
                                z15 = true;
                            } else {
                                z15 = true;
                            }
                            if (z12) {
                                z16 = false;
                            } else {
                                z16 = false;
                            }
                            if (z13) {
                                z17 = false;
                            } else {
                                z17 = false;
                            }
                            layoutParams = (LayoutParams) view.getLayoutParams();
                            if (aVar.f1790j) {
                                if (view instanceof VirtualLayout) {
                                    view.measure(iMakeMeasureSpec, iMakeMeasureSpec2);
                                } else {
                                    view.measure(iMakeMeasureSpec, iMakeMeasureSpec2);
                                }
                                measuredWidth = view.getMeasuredWidth();
                                measuredHeight = view.getMeasuredHeight();
                                baseline = view.getBaseline();
                                if (z10) {
                                    int[] iArr8 = constraintWidget.f1696h;
                                    i11 = 0;
                                    iArr8[0] = measuredWidth;
                                    iArr8[2] = measuredHeight;
                                } else {
                                    i11 = 0;
                                    int[] iArr9 = constraintWidget.f1696h;
                                    iArr9[0] = 0;
                                    iArr9[2] = 0;
                                }
                                if (z11) {
                                    int[] iArr10 = constraintWidget.f1696h;
                                    iArr10[1] = measuredHeight;
                                    iArr10[3] = measuredWidth;
                                } else {
                                    int[] iArr11 = constraintWidget.f1696h;
                                    iArr11[1] = i11;
                                    iArr11[3] = i11;
                                }
                                i12 = constraintWidget.f1710o;
                                if (i12 > 0) {
                                    measuredWidth2 = Math.max(i12, measuredWidth);
                                } else {
                                    measuredWidth2 = measuredWidth;
                                }
                                i13 = constraintWidget.f1712p;
                                if (i13 > 0) {
                                    measuredWidth2 = Math.min(i13, measuredWidth2);
                                }
                                i14 = constraintWidget.f1716r;
                                if (i14 > 0) {
                                    iMin = Math.max(i14, measuredHeight);
                                } else {
                                    iMin = measuredHeight;
                                }
                                i15 = constraintWidget.f1718s;
                                if (i15 > 0) {
                                    iMin = Math.min(i15, iMin);
                                }
                                if (!z16) {
                                    if (z17) {
                                        iMin = (int) ((measuredWidth2 / constraintWidget.S) + 0.5f);
                                    }
                                } else if (z17) {
                                    iMin = (int) ((measuredWidth2 / constraintWidget.S) + 0.5f);
                                }
                                if (measuredWidth == measuredWidth2) {
                                    if (measuredWidth != measuredWidth2) {
                                        iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(measuredWidth2, 1073741824);
                                    }
                                    if (measuredHeight != iMin) {
                                        iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(iMin, 1073741824);
                                    }
                                    view.measure(iMakeMeasureSpec, iMakeMeasureSpec2);
                                    measuredWidth2 = view.getMeasuredWidth();
                                    measuredHeight2 = view.getMeasuredHeight();
                                    baseline = view.getBaseline();
                                } else {
                                    if (measuredWidth != measuredWidth2) {
                                        iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(measuredWidth2, 1073741824);
                                    }
                                    if (measuredHeight != iMin) {
                                        iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(iMin, 1073741824);
                                    }
                                    view.measure(iMakeMeasureSpec, iMakeMeasureSpec2);
                                    measuredWidth2 = view.getMeasuredWidth();
                                    measuredHeight2 = view.getMeasuredHeight();
                                    baseline = view.getBaseline();
                                }
                                i16 = -1;
                            } else {
                                if (view instanceof VirtualLayout) {
                                    view.measure(iMakeMeasureSpec, iMakeMeasureSpec2);
                                } else {
                                    view.measure(iMakeMeasureSpec, iMakeMeasureSpec2);
                                }
                                measuredWidth = view.getMeasuredWidth();
                                measuredHeight = view.getMeasuredHeight();
                                baseline = view.getBaseline();
                                if (z10) {
                                    int[] iArr12 = constraintWidget.f1696h;
                                    i11 = 0;
                                    iArr12[0] = measuredWidth;
                                    iArr12[2] = measuredHeight;
                                } else {
                                    i11 = 0;
                                    int[] iArr13 = constraintWidget.f1696h;
                                    iArr13[0] = 0;
                                    iArr13[2] = 0;
                                }
                                if (z11) {
                                    int[] iArr14 = constraintWidget.f1696h;
                                    iArr14[1] = measuredHeight;
                                    iArr14[3] = measuredWidth;
                                } else {
                                    int[] iArr15 = constraintWidget.f1696h;
                                    iArr15[1] = i11;
                                    iArr15[3] = i11;
                                }
                                i12 = constraintWidget.f1710o;
                                if (i12 > 0) {
                                    measuredWidth2 = Math.max(i12, measuredWidth);
                                } else {
                                    measuredWidth2 = measuredWidth;
                                }
                                i13 = constraintWidget.f1712p;
                                if (i13 > 0) {
                                    measuredWidth2 = Math.min(i13, measuredWidth2);
                                }
                                i14 = constraintWidget.f1716r;
                                if (i14 > 0) {
                                    iMin = Math.max(i14, measuredHeight);
                                } else {
                                    iMin = measuredHeight;
                                }
                                i15 = constraintWidget.f1718s;
                                if (i15 > 0) {
                                    iMin = Math.min(i15, iMin);
                                }
                                if (!z16) {
                                    if (z17) {
                                        iMin = (int) ((measuredWidth2 / constraintWidget.S) + 0.5f);
                                    }
                                } else if (z17) {
                                    iMin = (int) ((measuredWidth2 / constraintWidget.S) + 0.5f);
                                }
                                if (measuredWidth == measuredWidth2) {
                                    if (measuredWidth != measuredWidth2) {
                                        iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(measuredWidth2, 1073741824);
                                    }
                                    if (measuredHeight != iMin) {
                                        iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(iMin, 1073741824);
                                    }
                                    view.measure(iMakeMeasureSpec, iMakeMeasureSpec2);
                                    measuredWidth2 = view.getMeasuredWidth();
                                    measuredHeight2 = view.getMeasuredHeight();
                                    baseline = view.getBaseline();
                                } else {
                                    if (measuredWidth != measuredWidth2) {
                                        iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(measuredWidth2, 1073741824);
                                    }
                                    if (measuredHeight != iMin) {
                                        iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(iMin, 1073741824);
                                    }
                                    view.measure(iMakeMeasureSpec, iMakeMeasureSpec2);
                                    measuredWidth2 = view.getMeasuredWidth();
                                    measuredHeight2 = view.getMeasuredHeight();
                                    baseline = view.getBaseline();
                                }
                                i16 = -1;
                            }
                            if (baseline != i16) {
                                i17 = 1;
                            } else {
                                i17 = i11;
                            }
                            if (measuredWidth2 == aVar.f1783c) {
                                z18 = 1;
                            } else {
                                z18 = 1;
                            }
                            aVar.f1789i = z18;
                            if (layoutParams.needsBaseline) {
                                z19 = 1;
                            } else {
                                z19 = i17;
                            }
                            if (z19 != 0) {
                                aVar.f1789i = true;
                            }
                            aVar.f1785e = measuredWidth2;
                            aVar.f1786f = measuredHeight2;
                            aVar.f1788h = z19;
                            aVar.f1787g = baseline;
                        }
                        iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(i19, 1073741824);
                        constraintWidget.f1696h[3] = i19;
                        z11 = false;
                        dimensionBehaviour = ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT;
                        if (dimensionBehaviour3 == dimensionBehaviour) {
                            z12 = true;
                        } else {
                            z12 = false;
                        }
                        if (dimensionBehaviour4 == dimensionBehaviour) {
                            z13 = true;
                        } else {
                            z13 = false;
                        }
                        dimensionBehaviour2 = ConstraintWidget.DimensionBehaviour.MATCH_PARENT;
                        if (dimensionBehaviour4 != dimensionBehaviour2) {
                            z14 = true;
                        } else {
                            z14 = true;
                        }
                        if (dimensionBehaviour3 != dimensionBehaviour2) {
                            z15 = true;
                        } else {
                            z15 = true;
                        }
                        if (z12) {
                            z16 = false;
                        } else {
                            z16 = false;
                        }
                        if (z13) {
                            z17 = false;
                        } else {
                            z17 = false;
                        }
                        layoutParams = (LayoutParams) view.getLayoutParams();
                        if (aVar.f1790j) {
                            if (view instanceof VirtualLayout) {
                                view.measure(iMakeMeasureSpec, iMakeMeasureSpec2);
                            } else {
                                view.measure(iMakeMeasureSpec, iMakeMeasureSpec2);
                            }
                            measuredWidth = view.getMeasuredWidth();
                            measuredHeight = view.getMeasuredHeight();
                            baseline = view.getBaseline();
                            if (z10) {
                                int[] iArr16 = constraintWidget.f1696h;
                                i11 = 0;
                                iArr16[0] = measuredWidth;
                                iArr16[2] = measuredHeight;
                            } else {
                                i11 = 0;
                                int[] iArr17 = constraintWidget.f1696h;
                                iArr17[0] = 0;
                                iArr17[2] = 0;
                            }
                            if (z11) {
                                int[] iArr18 = constraintWidget.f1696h;
                                iArr18[1] = measuredHeight;
                                iArr18[3] = measuredWidth;
                            } else {
                                int[] iArr19 = constraintWidget.f1696h;
                                iArr19[1] = i11;
                                iArr19[3] = i11;
                            }
                            i12 = constraintWidget.f1710o;
                            if (i12 > 0) {
                                measuredWidth2 = Math.max(i12, measuredWidth);
                            } else {
                                measuredWidth2 = measuredWidth;
                            }
                            i13 = constraintWidget.f1712p;
                            if (i13 > 0) {
                                measuredWidth2 = Math.min(i13, measuredWidth2);
                            }
                            i14 = constraintWidget.f1716r;
                            if (i14 > 0) {
                                iMin = Math.max(i14, measuredHeight);
                            } else {
                                iMin = measuredHeight;
                            }
                            i15 = constraintWidget.f1718s;
                            if (i15 > 0) {
                                iMin = Math.min(i15, iMin);
                            }
                            if (!z16) {
                                if (z17) {
                                    iMin = (int) ((measuredWidth2 / constraintWidget.S) + 0.5f);
                                }
                            } else if (z17) {
                                iMin = (int) ((measuredWidth2 / constraintWidget.S) + 0.5f);
                            }
                            if (measuredWidth == measuredWidth2) {
                                if (measuredWidth != measuredWidth2) {
                                    iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(measuredWidth2, 1073741824);
                                }
                                if (measuredHeight != iMin) {
                                    iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(iMin, 1073741824);
                                }
                                view.measure(iMakeMeasureSpec, iMakeMeasureSpec2);
                                measuredWidth2 = view.getMeasuredWidth();
                                measuredHeight2 = view.getMeasuredHeight();
                                baseline = view.getBaseline();
                            } else {
                                if (measuredWidth != measuredWidth2) {
                                    iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(measuredWidth2, 1073741824);
                                }
                                if (measuredHeight != iMin) {
                                    iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(iMin, 1073741824);
                                }
                                view.measure(iMakeMeasureSpec, iMakeMeasureSpec2);
                                measuredWidth2 = view.getMeasuredWidth();
                                measuredHeight2 = view.getMeasuredHeight();
                                baseline = view.getBaseline();
                            }
                            i16 = -1;
                        } else {
                            if (view instanceof VirtualLayout) {
                                view.measure(iMakeMeasureSpec, iMakeMeasureSpec2);
                            } else {
                                view.measure(iMakeMeasureSpec, iMakeMeasureSpec2);
                            }
                            measuredWidth = view.getMeasuredWidth();
                            measuredHeight = view.getMeasuredHeight();
                            baseline = view.getBaseline();
                            if (z10) {
                                int[] iArr110 = constraintWidget.f1696h;
                                i11 = 0;
                                iArr110[0] = measuredWidth;
                                iArr110[2] = measuredHeight;
                            } else {
                                i11 = 0;
                                int[] iArr111 = constraintWidget.f1696h;
                                iArr111[0] = 0;
                                iArr111[2] = 0;
                            }
                            if (z11) {
                                int[] iArr112 = constraintWidget.f1696h;
                                iArr112[1] = measuredHeight;
                                iArr112[3] = measuredWidth;
                            } else {
                                int[] iArr113 = constraintWidget.f1696h;
                                iArr113[1] = i11;
                                iArr113[3] = i11;
                            }
                            i12 = constraintWidget.f1710o;
                            if (i12 > 0) {
                                measuredWidth2 = Math.max(i12, measuredWidth);
                            } else {
                                measuredWidth2 = measuredWidth;
                            }
                            i13 = constraintWidget.f1712p;
                            if (i13 > 0) {
                                measuredWidth2 = Math.min(i13, measuredWidth2);
                            }
                            i14 = constraintWidget.f1716r;
                            if (i14 > 0) {
                                iMin = Math.max(i14, measuredHeight);
                            } else {
                                iMin = measuredHeight;
                            }
                            i15 = constraintWidget.f1718s;
                            if (i15 > 0) {
                                iMin = Math.min(i15, iMin);
                            }
                            if (!z16) {
                                if (z17) {
                                    iMin = (int) ((measuredWidth2 / constraintWidget.S) + 0.5f);
                                }
                            } else if (z17) {
                                iMin = (int) ((measuredWidth2 / constraintWidget.S) + 0.5f);
                            }
                            if (measuredWidth == measuredWidth2) {
                                if (measuredWidth != measuredWidth2) {
                                    iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(measuredWidth2, 1073741824);
                                }
                                if (measuredHeight != iMin) {
                                    iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(iMin, 1073741824);
                                }
                                view.measure(iMakeMeasureSpec, iMakeMeasureSpec2);
                                measuredWidth2 = view.getMeasuredWidth();
                                measuredHeight2 = view.getMeasuredHeight();
                                baseline = view.getBaseline();
                            } else {
                                if (measuredWidth != measuredWidth2) {
                                    iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(measuredWidth2, 1073741824);
                                }
                                if (measuredHeight != iMin) {
                                    iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(iMin, 1073741824);
                                }
                                view.measure(iMakeMeasureSpec, iMakeMeasureSpec2);
                                measuredWidth2 = view.getMeasuredWidth();
                                measuredHeight2 = view.getMeasuredHeight();
                                baseline = view.getBaseline();
                            }
                            i16 = -1;
                        }
                        if (baseline != i16) {
                            i17 = 1;
                        } else {
                            i17 = i11;
                        }
                        if (measuredWidth2 == aVar.f1783c) {
                            z18 = 1;
                        } else {
                            z18 = 1;
                        }
                        aVar.f1789i = z18;
                        if (layoutParams.needsBaseline) {
                            z19 = 1;
                        } else {
                            z19 = i17;
                        }
                        if (z19 != 0) {
                            aVar.f1789i = true;
                        }
                        aVar.f1785e = measuredWidth2;
                        aVar.f1786f = measuredHeight2;
                        aVar.f1788h = z19;
                        aVar.f1787g = baseline;
                    }
                }
                z10 = true;
                i10 = iArr2[dimensionBehaviour4.ordinal()];
                if (i10 != 1) {
                    if (i10 != 2) {
                        if (i10 != 3) {
                            if (i10 != 4) {
                                z11 = false;
                                iMakeMeasureSpec2 = 0;
                            } else {
                                childMeasureSpec = ViewGroup.getChildMeasureSpec(this.f1966g, i20, -2);
                                if (constraintWidget.f1706m == 1) {
                                    z20 = true;
                                } else {
                                    z20 = false;
                                }
                                iArr = constraintWidget.f1696h;
                                iArr[3] = 0;
                                if (aVar.f1790j) {
                                    if (z20) {
                                    }
                                    if (z20) {
                                    }
                                    childMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(constraintWidget.w(), 1073741824);
                                }
                            }
                            dimensionBehaviour = ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT;
                            if (dimensionBehaviour3 == dimensionBehaviour) {
                                z12 = true;
                            } else {
                                z12 = false;
                            }
                            if (dimensionBehaviour4 == dimensionBehaviour) {
                                z13 = true;
                            } else {
                                z13 = false;
                            }
                            dimensionBehaviour2 = ConstraintWidget.DimensionBehaviour.MATCH_PARENT;
                            if (dimensionBehaviour4 != dimensionBehaviour2) {
                                z14 = true;
                            } else {
                                z14 = true;
                            }
                            if (dimensionBehaviour3 != dimensionBehaviour2) {
                                z15 = true;
                            } else {
                                z15 = true;
                            }
                            if (z12) {
                                z16 = false;
                            } else {
                                z16 = false;
                            }
                            if (z13) {
                                z17 = false;
                            } else {
                                z17 = false;
                            }
                            layoutParams = (LayoutParams) view.getLayoutParams();
                            if (aVar.f1790j) {
                                if (view instanceof VirtualLayout) {
                                    view.measure(iMakeMeasureSpec, iMakeMeasureSpec2);
                                } else {
                                    view.measure(iMakeMeasureSpec, iMakeMeasureSpec2);
                                }
                                measuredWidth = view.getMeasuredWidth();
                                measuredHeight = view.getMeasuredHeight();
                                baseline = view.getBaseline();
                                if (z10) {
                                    int[] iArr114 = constraintWidget.f1696h;
                                    i11 = 0;
                                    iArr114[0] = measuredWidth;
                                    iArr114[2] = measuredHeight;
                                } else {
                                    i11 = 0;
                                    int[] iArr115 = constraintWidget.f1696h;
                                    iArr115[0] = 0;
                                    iArr115[2] = 0;
                                }
                                if (z11) {
                                    int[] iArr116 = constraintWidget.f1696h;
                                    iArr116[1] = measuredHeight;
                                    iArr116[3] = measuredWidth;
                                } else {
                                    int[] iArr117 = constraintWidget.f1696h;
                                    iArr117[1] = i11;
                                    iArr117[3] = i11;
                                }
                                i12 = constraintWidget.f1710o;
                                if (i12 > 0) {
                                    measuredWidth2 = Math.max(i12, measuredWidth);
                                } else {
                                    measuredWidth2 = measuredWidth;
                                }
                                i13 = constraintWidget.f1712p;
                                if (i13 > 0) {
                                    measuredWidth2 = Math.min(i13, measuredWidth2);
                                }
                                i14 = constraintWidget.f1716r;
                                if (i14 > 0) {
                                    iMin = Math.max(i14, measuredHeight);
                                } else {
                                    iMin = measuredHeight;
                                }
                                i15 = constraintWidget.f1718s;
                                if (i15 > 0) {
                                    iMin = Math.min(i15, iMin);
                                }
                                if (!z16) {
                                    if (z17) {
                                        iMin = (int) ((measuredWidth2 / constraintWidget.S) + 0.5f);
                                    }
                                } else if (z17) {
                                    iMin = (int) ((measuredWidth2 / constraintWidget.S) + 0.5f);
                                }
                                if (measuredWidth == measuredWidth2) {
                                    if (measuredWidth != measuredWidth2) {
                                        iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(measuredWidth2, 1073741824);
                                    }
                                    if (measuredHeight != iMin) {
                                        iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(iMin, 1073741824);
                                    }
                                    view.measure(iMakeMeasureSpec, iMakeMeasureSpec2);
                                    measuredWidth2 = view.getMeasuredWidth();
                                    measuredHeight2 = view.getMeasuredHeight();
                                    baseline = view.getBaseline();
                                } else {
                                    if (measuredWidth != measuredWidth2) {
                                        iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(measuredWidth2, 1073741824);
                                    }
                                    if (measuredHeight != iMin) {
                                        iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(iMin, 1073741824);
                                    }
                                    view.measure(iMakeMeasureSpec, iMakeMeasureSpec2);
                                    measuredWidth2 = view.getMeasuredWidth();
                                    measuredHeight2 = view.getMeasuredHeight();
                                    baseline = view.getBaseline();
                                }
                                i16 = -1;
                            } else {
                                if (view instanceof VirtualLayout) {
                                    view.measure(iMakeMeasureSpec, iMakeMeasureSpec2);
                                } else {
                                    view.measure(iMakeMeasureSpec, iMakeMeasureSpec2);
                                }
                                measuredWidth = view.getMeasuredWidth();
                                measuredHeight = view.getMeasuredHeight();
                                baseline = view.getBaseline();
                                if (z10) {
                                    int[] iArr118 = constraintWidget.f1696h;
                                    i11 = 0;
                                    iArr118[0] = measuredWidth;
                                    iArr118[2] = measuredHeight;
                                } else {
                                    i11 = 0;
                                    int[] iArr119 = constraintWidget.f1696h;
                                    iArr119[0] = 0;
                                    iArr119[2] = 0;
                                }
                                if (z11) {
                                    int[] iArr1110 = constraintWidget.f1696h;
                                    iArr1110[1] = measuredHeight;
                                    iArr1110[3] = measuredWidth;
                                } else {
                                    int[] iArr1111 = constraintWidget.f1696h;
                                    iArr1111[1] = i11;
                                    iArr1111[3] = i11;
                                }
                                i12 = constraintWidget.f1710o;
                                if (i12 > 0) {
                                    measuredWidth2 = Math.max(i12, measuredWidth);
                                } else {
                                    measuredWidth2 = measuredWidth;
                                }
                                i13 = constraintWidget.f1712p;
                                if (i13 > 0) {
                                    measuredWidth2 = Math.min(i13, measuredWidth2);
                                }
                                i14 = constraintWidget.f1716r;
                                if (i14 > 0) {
                                    iMin = Math.max(i14, measuredHeight);
                                } else {
                                    iMin = measuredHeight;
                                }
                                i15 = constraintWidget.f1718s;
                                if (i15 > 0) {
                                    iMin = Math.min(i15, iMin);
                                }
                                if (!z16) {
                                    if (z17) {
                                        iMin = (int) ((measuredWidth2 / constraintWidget.S) + 0.5f);
                                    }
                                } else if (z17) {
                                    iMin = (int) ((measuredWidth2 / constraintWidget.S) + 0.5f);
                                }
                                if (measuredWidth == measuredWidth2) {
                                    if (measuredWidth != measuredWidth2) {
                                        iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(measuredWidth2, 1073741824);
                                    }
                                    if (measuredHeight != iMin) {
                                        iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(iMin, 1073741824);
                                    }
                                    view.measure(iMakeMeasureSpec, iMakeMeasureSpec2);
                                    measuredWidth2 = view.getMeasuredWidth();
                                    measuredHeight2 = view.getMeasuredHeight();
                                    baseline = view.getBaseline();
                                } else {
                                    if (measuredWidth != measuredWidth2) {
                                        iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(measuredWidth2, 1073741824);
                                    }
                                    if (measuredHeight != iMin) {
                                        iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(iMin, 1073741824);
                                    }
                                    view.measure(iMakeMeasureSpec, iMakeMeasureSpec2);
                                    measuredWidth2 = view.getMeasuredWidth();
                                    measuredHeight2 = view.getMeasuredHeight();
                                    baseline = view.getBaseline();
                                }
                                i16 = -1;
                            }
                            if (baseline != i16) {
                                i17 = 1;
                            } else {
                                i17 = i11;
                            }
                            if (measuredWidth2 == aVar.f1783c) {
                                z18 = 1;
                            } else {
                                z18 = 1;
                            }
                            aVar.f1789i = z18;
                            if (layoutParams.needsBaseline) {
                                z19 = 1;
                            } else {
                                z19 = i17;
                            }
                            if (z19 != 0) {
                                aVar.f1789i = true;
                            }
                            aVar.f1785e = measuredWidth2;
                            aVar.f1786f = measuredHeight2;
                            aVar.f1788h = z19;
                            aVar.f1787g = baseline;
                        }
                        childMeasureSpec2 = ViewGroup.getChildMeasureSpec(this.f1966g, i20 + constraintWidget.O(), -1);
                        constraintWidget.f1696h[3] = -1;
                        iMakeMeasureSpec2 = childMeasureSpec2;
                    } else {
                        childMeasureSpec = ViewGroup.getChildMeasureSpec(this.f1966g, i20, -2);
                        constraintWidget.f1696h[3] = -2;
                    }
                    iMakeMeasureSpec2 = childMeasureSpec;
                    z11 = true;
                    dimensionBehaviour = ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT;
                    if (dimensionBehaviour3 == dimensionBehaviour) {
                        z12 = true;
                    } else {
                        z12 = false;
                    }
                    if (dimensionBehaviour4 == dimensionBehaviour) {
                        z13 = true;
                    } else {
                        z13 = false;
                    }
                    dimensionBehaviour2 = ConstraintWidget.DimensionBehaviour.MATCH_PARENT;
                    if (dimensionBehaviour4 != dimensionBehaviour2) {
                        z14 = true;
                    } else {
                        z14 = true;
                    }
                    if (dimensionBehaviour3 != dimensionBehaviour2) {
                        z15 = true;
                    } else {
                        z15 = true;
                    }
                    if (z12) {
                        z16 = false;
                    } else {
                        z16 = false;
                    }
                    if (z13) {
                        z17 = false;
                    } else {
                        z17 = false;
                    }
                    layoutParams = (LayoutParams) view.getLayoutParams();
                    if (aVar.f1790j) {
                        if (view instanceof VirtualLayout) {
                            view.measure(iMakeMeasureSpec, iMakeMeasureSpec2);
                        } else {
                            view.measure(iMakeMeasureSpec, iMakeMeasureSpec2);
                        }
                        measuredWidth = view.getMeasuredWidth();
                        measuredHeight = view.getMeasuredHeight();
                        baseline = view.getBaseline();
                        if (z10) {
                            int[] iArr1112 = constraintWidget.f1696h;
                            i11 = 0;
                            iArr1112[0] = measuredWidth;
                            iArr1112[2] = measuredHeight;
                        } else {
                            i11 = 0;
                            int[] iArr1113 = constraintWidget.f1696h;
                            iArr1113[0] = 0;
                            iArr1113[2] = 0;
                        }
                        if (z11) {
                            int[] iArr1114 = constraintWidget.f1696h;
                            iArr1114[1] = measuredHeight;
                            iArr1114[3] = measuredWidth;
                        } else {
                            int[] iArr1115 = constraintWidget.f1696h;
                            iArr1115[1] = i11;
                            iArr1115[3] = i11;
                        }
                        i12 = constraintWidget.f1710o;
                        if (i12 > 0) {
                            measuredWidth2 = Math.max(i12, measuredWidth);
                        } else {
                            measuredWidth2 = measuredWidth;
                        }
                        i13 = constraintWidget.f1712p;
                        if (i13 > 0) {
                            measuredWidth2 = Math.min(i13, measuredWidth2);
                        }
                        i14 = constraintWidget.f1716r;
                        if (i14 > 0) {
                            iMin = Math.max(i14, measuredHeight);
                        } else {
                            iMin = measuredHeight;
                        }
                        i15 = constraintWidget.f1718s;
                        if (i15 > 0) {
                            iMin = Math.min(i15, iMin);
                        }
                        if (!z16) {
                            if (z17) {
                                iMin = (int) ((measuredWidth2 / constraintWidget.S) + 0.5f);
                            }
                        } else if (z17) {
                            iMin = (int) ((measuredWidth2 / constraintWidget.S) + 0.5f);
                        }
                        if (measuredWidth == measuredWidth2) {
                            if (measuredWidth != measuredWidth2) {
                                iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(measuredWidth2, 1073741824);
                            }
                            if (measuredHeight != iMin) {
                                iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(iMin, 1073741824);
                            }
                            view.measure(iMakeMeasureSpec, iMakeMeasureSpec2);
                            measuredWidth2 = view.getMeasuredWidth();
                            measuredHeight2 = view.getMeasuredHeight();
                            baseline = view.getBaseline();
                        } else {
                            if (measuredWidth != measuredWidth2) {
                                iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(measuredWidth2, 1073741824);
                            }
                            if (measuredHeight != iMin) {
                                iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(iMin, 1073741824);
                            }
                            view.measure(iMakeMeasureSpec, iMakeMeasureSpec2);
                            measuredWidth2 = view.getMeasuredWidth();
                            measuredHeight2 = view.getMeasuredHeight();
                            baseline = view.getBaseline();
                        }
                        i16 = -1;
                    } else {
                        if (view instanceof VirtualLayout) {
                            view.measure(iMakeMeasureSpec, iMakeMeasureSpec2);
                        } else {
                            view.measure(iMakeMeasureSpec, iMakeMeasureSpec2);
                        }
                        measuredWidth = view.getMeasuredWidth();
                        measuredHeight = view.getMeasuredHeight();
                        baseline = view.getBaseline();
                        if (z10) {
                            int[] iArr1116 = constraintWidget.f1696h;
                            i11 = 0;
                            iArr1116[0] = measuredWidth;
                            iArr1116[2] = measuredHeight;
                        } else {
                            i11 = 0;
                            int[] iArr1117 = constraintWidget.f1696h;
                            iArr1117[0] = 0;
                            iArr1117[2] = 0;
                        }
                        if (z11) {
                            int[] iArr1118 = constraintWidget.f1696h;
                            iArr1118[1] = measuredHeight;
                            iArr1118[3] = measuredWidth;
                        } else {
                            int[] iArr1119 = constraintWidget.f1696h;
                            iArr1119[1] = i11;
                            iArr1119[3] = i11;
                        }
                        i12 = constraintWidget.f1710o;
                        if (i12 > 0) {
                            measuredWidth2 = Math.max(i12, measuredWidth);
                        } else {
                            measuredWidth2 = measuredWidth;
                        }
                        i13 = constraintWidget.f1712p;
                        if (i13 > 0) {
                            measuredWidth2 = Math.min(i13, measuredWidth2);
                        }
                        i14 = constraintWidget.f1716r;
                        if (i14 > 0) {
                            iMin = Math.max(i14, measuredHeight);
                        } else {
                            iMin = measuredHeight;
                        }
                        i15 = constraintWidget.f1718s;
                        if (i15 > 0) {
                            iMin = Math.min(i15, iMin);
                        }
                        if (!z16) {
                            if (z17) {
                                iMin = (int) ((measuredWidth2 / constraintWidget.S) + 0.5f);
                            }
                        } else if (z17) {
                            iMin = (int) ((measuredWidth2 / constraintWidget.S) + 0.5f);
                        }
                        if (measuredWidth == measuredWidth2) {
                            if (measuredWidth != measuredWidth2) {
                                iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(measuredWidth2, 1073741824);
                            }
                            if (measuredHeight != iMin) {
                                iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(iMin, 1073741824);
                            }
                            view.measure(iMakeMeasureSpec, iMakeMeasureSpec2);
                            measuredWidth2 = view.getMeasuredWidth();
                            measuredHeight2 = view.getMeasuredHeight();
                            baseline = view.getBaseline();
                        } else {
                            if (measuredWidth != measuredWidth2) {
                                iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(measuredWidth2, 1073741824);
                            }
                            if (measuredHeight != iMin) {
                                iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(iMin, 1073741824);
                            }
                            view.measure(iMakeMeasureSpec, iMakeMeasureSpec2);
                            measuredWidth2 = view.getMeasuredWidth();
                            measuredHeight2 = view.getMeasuredHeight();
                            baseline = view.getBaseline();
                        }
                        i16 = -1;
                    }
                    if (baseline != i16) {
                        i17 = 1;
                    } else {
                        i17 = i11;
                    }
                    if (measuredWidth2 == aVar.f1783c) {
                        z18 = 1;
                    } else {
                        z18 = 1;
                    }
                    aVar.f1789i = z18;
                    if (layoutParams.needsBaseline) {
                        z19 = 1;
                    } else {
                        z19 = i17;
                    }
                    if (z19 != 0) {
                        aVar.f1789i = true;
                    }
                    aVar.f1785e = measuredWidth2;
                    aVar.f1786f = measuredHeight2;
                    aVar.f1788h = z19;
                    aVar.f1787g = baseline;
                }
                iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(i19, 1073741824);
                constraintWidget.f1696h[3] = i19;
                z11 = false;
                dimensionBehaviour = ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT;
                if (dimensionBehaviour3 == dimensionBehaviour) {
                    z12 = true;
                } else {
                    z12 = false;
                }
                if (dimensionBehaviour4 == dimensionBehaviour) {
                    z13 = true;
                } else {
                    z13 = false;
                }
                dimensionBehaviour2 = ConstraintWidget.DimensionBehaviour.MATCH_PARENT;
                if (dimensionBehaviour4 != dimensionBehaviour2) {
                    z14 = true;
                } else {
                    z14 = true;
                }
                if (dimensionBehaviour3 != dimensionBehaviour2) {
                    z15 = true;
                } else {
                    z15 = true;
                }
                if (z12) {
                    z16 = false;
                } else {
                    z16 = false;
                }
                if (z13) {
                    z17 = false;
                } else {
                    z17 = false;
                }
                layoutParams = (LayoutParams) view.getLayoutParams();
                if (aVar.f1790j) {
                    if (view instanceof VirtualLayout) {
                        view.measure(iMakeMeasureSpec, iMakeMeasureSpec2);
                    } else {
                        view.measure(iMakeMeasureSpec, iMakeMeasureSpec2);
                    }
                    measuredWidth = view.getMeasuredWidth();
                    measuredHeight = view.getMeasuredHeight();
                    baseline = view.getBaseline();
                    if (z10) {
                        int[] iArr11110 = constraintWidget.f1696h;
                        i11 = 0;
                        iArr11110[0] = measuredWidth;
                        iArr11110[2] = measuredHeight;
                    } else {
                        i11 = 0;
                        int[] iArr11111 = constraintWidget.f1696h;
                        iArr11111[0] = 0;
                        iArr11111[2] = 0;
                    }
                    if (z11) {
                        int[] iArr11112 = constraintWidget.f1696h;
                        iArr11112[1] = measuredHeight;
                        iArr11112[3] = measuredWidth;
                    } else {
                        int[] iArr11113 = constraintWidget.f1696h;
                        iArr11113[1] = i11;
                        iArr11113[3] = i11;
                    }
                    i12 = constraintWidget.f1710o;
                    if (i12 > 0) {
                        measuredWidth2 = Math.max(i12, measuredWidth);
                    } else {
                        measuredWidth2 = measuredWidth;
                    }
                    i13 = constraintWidget.f1712p;
                    if (i13 > 0) {
                        measuredWidth2 = Math.min(i13, measuredWidth2);
                    }
                    i14 = constraintWidget.f1716r;
                    if (i14 > 0) {
                        iMin = Math.max(i14, measuredHeight);
                    } else {
                        iMin = measuredHeight;
                    }
                    i15 = constraintWidget.f1718s;
                    if (i15 > 0) {
                        iMin = Math.min(i15, iMin);
                    }
                    if (!z16) {
                        if (z17) {
                            iMin = (int) ((measuredWidth2 / constraintWidget.S) + 0.5f);
                        }
                    } else if (z17) {
                        iMin = (int) ((measuredWidth2 / constraintWidget.S) + 0.5f);
                    }
                    if (measuredWidth == measuredWidth2) {
                        if (measuredWidth != measuredWidth2) {
                            iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(measuredWidth2, 1073741824);
                        }
                        if (measuredHeight != iMin) {
                            iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(iMin, 1073741824);
                        }
                        view.measure(iMakeMeasureSpec, iMakeMeasureSpec2);
                        measuredWidth2 = view.getMeasuredWidth();
                        measuredHeight2 = view.getMeasuredHeight();
                        baseline = view.getBaseline();
                    } else {
                        if (measuredWidth != measuredWidth2) {
                            iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(measuredWidth2, 1073741824);
                        }
                        if (measuredHeight != iMin) {
                            iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(iMin, 1073741824);
                        }
                        view.measure(iMakeMeasureSpec, iMakeMeasureSpec2);
                        measuredWidth2 = view.getMeasuredWidth();
                        measuredHeight2 = view.getMeasuredHeight();
                        baseline = view.getBaseline();
                    }
                    i16 = -1;
                } else {
                    if (view instanceof VirtualLayout) {
                        view.measure(iMakeMeasureSpec, iMakeMeasureSpec2);
                    } else {
                        view.measure(iMakeMeasureSpec, iMakeMeasureSpec2);
                    }
                    measuredWidth = view.getMeasuredWidth();
                    measuredHeight = view.getMeasuredHeight();
                    baseline = view.getBaseline();
                    if (z10) {
                        int[] iArr11114 = constraintWidget.f1696h;
                        i11 = 0;
                        iArr11114[0] = measuredWidth;
                        iArr11114[2] = measuredHeight;
                    } else {
                        i11 = 0;
                        int[] iArr11115 = constraintWidget.f1696h;
                        iArr11115[0] = 0;
                        iArr11115[2] = 0;
                    }
                    if (z11) {
                        int[] iArr11116 = constraintWidget.f1696h;
                        iArr11116[1] = measuredHeight;
                        iArr11116[3] = measuredWidth;
                    } else {
                        int[] iArr11117 = constraintWidget.f1696h;
                        iArr11117[1] = i11;
                        iArr11117[3] = i11;
                    }
                    i12 = constraintWidget.f1710o;
                    if (i12 > 0) {
                        measuredWidth2 = Math.max(i12, measuredWidth);
                    } else {
                        measuredWidth2 = measuredWidth;
                    }
                    i13 = constraintWidget.f1712p;
                    if (i13 > 0) {
                        measuredWidth2 = Math.min(i13, measuredWidth2);
                    }
                    i14 = constraintWidget.f1716r;
                    if (i14 > 0) {
                        iMin = Math.max(i14, measuredHeight);
                    } else {
                        iMin = measuredHeight;
                    }
                    i15 = constraintWidget.f1718s;
                    if (i15 > 0) {
                        iMin = Math.min(i15, iMin);
                    }
                    if (!z16) {
                        if (z17) {
                            iMin = (int) ((measuredWidth2 / constraintWidget.S) + 0.5f);
                        }
                    } else if (z17) {
                        iMin = (int) ((measuredWidth2 / constraintWidget.S) + 0.5f);
                    }
                    if (measuredWidth == measuredWidth2) {
                        if (measuredWidth != measuredWidth2) {
                            iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(measuredWidth2, 1073741824);
                        }
                        if (measuredHeight != iMin) {
                            iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(iMin, 1073741824);
                        }
                        view.measure(iMakeMeasureSpec, iMakeMeasureSpec2);
                        measuredWidth2 = view.getMeasuredWidth();
                        measuredHeight2 = view.getMeasuredHeight();
                        baseline = view.getBaseline();
                    } else {
                        if (measuredWidth != measuredWidth2) {
                            iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(measuredWidth2, 1073741824);
                        }
                        if (measuredHeight != iMin) {
                            iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(iMin, 1073741824);
                        }
                        view.measure(iMakeMeasureSpec, iMakeMeasureSpec2);
                        measuredWidth2 = view.getMeasuredWidth();
                        measuredHeight2 = view.getMeasuredHeight();
                        baseline = view.getBaseline();
                    }
                    i16 = -1;
                }
                if (baseline != i16) {
                    i17 = 1;
                } else {
                    i17 = i11;
                }
                if (measuredWidth2 == aVar.f1783c) {
                    z18 = 1;
                } else {
                    z18 = 1;
                }
                aVar.f1789i = z18;
                if (layoutParams.needsBaseline) {
                    z19 = 1;
                } else {
                    z19 = i17;
                }
                if (z19 != 0) {
                    aVar.f1789i = true;
                }
                aVar.f1785e = measuredWidth2;
                aVar.f1786f = measuredHeight2;
                aVar.f1788h = z19;
                aVar.f1787g = baseline;
            }
            int iMakeMeasureSpec3 = View.MeasureSpec.makeMeasureSpec(i18, 1073741824);
            constraintWidget.f1696h[2] = i18;
            iMakeMeasureSpec = iMakeMeasureSpec3;
            z10 = false;
            i10 = iArr2[dimensionBehaviour4.ordinal()];
            if (i10 != 1) {
                if (i10 != 2) {
                    if (i10 != 3) {
                        if (i10 != 4) {
                            z11 = false;
                            iMakeMeasureSpec2 = 0;
                        } else {
                            childMeasureSpec = ViewGroup.getChildMeasureSpec(this.f1966g, i20, -2);
                            if (constraintWidget.f1706m == 1) {
                                z20 = true;
                            } else {
                                z20 = false;
                            }
                            iArr = constraintWidget.f1696h;
                            iArr[3] = 0;
                            if (aVar.f1790j) {
                                if (z20) {
                                }
                                if (z20) {
                                }
                                childMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(constraintWidget.w(), 1073741824);
                            }
                        }
                        dimensionBehaviour = ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT;
                        if (dimensionBehaviour3 == dimensionBehaviour) {
                            z12 = true;
                        } else {
                            z12 = false;
                        }
                        if (dimensionBehaviour4 == dimensionBehaviour) {
                            z13 = true;
                        } else {
                            z13 = false;
                        }
                        dimensionBehaviour2 = ConstraintWidget.DimensionBehaviour.MATCH_PARENT;
                        if (dimensionBehaviour4 != dimensionBehaviour2) {
                            z14 = true;
                        } else {
                            z14 = true;
                        }
                        if (dimensionBehaviour3 != dimensionBehaviour2) {
                            z15 = true;
                        } else {
                            z15 = true;
                        }
                        if (z12) {
                            z16 = false;
                        } else {
                            z16 = false;
                        }
                        if (z13) {
                            z17 = false;
                        } else {
                            z17 = false;
                        }
                        layoutParams = (LayoutParams) view.getLayoutParams();
                        if (aVar.f1790j) {
                            if (view instanceof VirtualLayout) {
                                view.measure(iMakeMeasureSpec, iMakeMeasureSpec2);
                            } else {
                                view.measure(iMakeMeasureSpec, iMakeMeasureSpec2);
                            }
                            measuredWidth = view.getMeasuredWidth();
                            measuredHeight = view.getMeasuredHeight();
                            baseline = view.getBaseline();
                            if (z10) {
                                int[] iArr11118 = constraintWidget.f1696h;
                                i11 = 0;
                                iArr11118[0] = measuredWidth;
                                iArr11118[2] = measuredHeight;
                            } else {
                                i11 = 0;
                                int[] iArr11119 = constraintWidget.f1696h;
                                iArr11119[0] = 0;
                                iArr11119[2] = 0;
                            }
                            if (z11) {
                                int[] iArr111110 = constraintWidget.f1696h;
                                iArr111110[1] = measuredHeight;
                                iArr111110[3] = measuredWidth;
                            } else {
                                int[] iArr111111 = constraintWidget.f1696h;
                                iArr111111[1] = i11;
                                iArr111111[3] = i11;
                            }
                            i12 = constraintWidget.f1710o;
                            if (i12 > 0) {
                                measuredWidth2 = Math.max(i12, measuredWidth);
                            } else {
                                measuredWidth2 = measuredWidth;
                            }
                            i13 = constraintWidget.f1712p;
                            if (i13 > 0) {
                                measuredWidth2 = Math.min(i13, measuredWidth2);
                            }
                            i14 = constraintWidget.f1716r;
                            if (i14 > 0) {
                                iMin = Math.max(i14, measuredHeight);
                            } else {
                                iMin = measuredHeight;
                            }
                            i15 = constraintWidget.f1718s;
                            if (i15 > 0) {
                                iMin = Math.min(i15, iMin);
                            }
                            if (!z16) {
                                if (z17) {
                                    iMin = (int) ((measuredWidth2 / constraintWidget.S) + 0.5f);
                                }
                            } else if (z17) {
                                iMin = (int) ((measuredWidth2 / constraintWidget.S) + 0.5f);
                            }
                            if (measuredWidth == measuredWidth2) {
                                if (measuredWidth != measuredWidth2) {
                                    iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(measuredWidth2, 1073741824);
                                }
                                if (measuredHeight != iMin) {
                                    iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(iMin, 1073741824);
                                }
                                view.measure(iMakeMeasureSpec, iMakeMeasureSpec2);
                                measuredWidth2 = view.getMeasuredWidth();
                                measuredHeight2 = view.getMeasuredHeight();
                                baseline = view.getBaseline();
                            } else {
                                if (measuredWidth != measuredWidth2) {
                                    iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(measuredWidth2, 1073741824);
                                }
                                if (measuredHeight != iMin) {
                                    iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(iMin, 1073741824);
                                }
                                view.measure(iMakeMeasureSpec, iMakeMeasureSpec2);
                                measuredWidth2 = view.getMeasuredWidth();
                                measuredHeight2 = view.getMeasuredHeight();
                                baseline = view.getBaseline();
                            }
                            i16 = -1;
                        } else {
                            if (view instanceof VirtualLayout) {
                                view.measure(iMakeMeasureSpec, iMakeMeasureSpec2);
                            } else {
                                view.measure(iMakeMeasureSpec, iMakeMeasureSpec2);
                            }
                            measuredWidth = view.getMeasuredWidth();
                            measuredHeight = view.getMeasuredHeight();
                            baseline = view.getBaseline();
                            if (z10) {
                                int[] iArr111112 = constraintWidget.f1696h;
                                i11 = 0;
                                iArr111112[0] = measuredWidth;
                                iArr111112[2] = measuredHeight;
                            } else {
                                i11 = 0;
                                int[] iArr111113 = constraintWidget.f1696h;
                                iArr111113[0] = 0;
                                iArr111113[2] = 0;
                            }
                            if (z11) {
                                int[] iArr111114 = constraintWidget.f1696h;
                                iArr111114[1] = measuredHeight;
                                iArr111114[3] = measuredWidth;
                            } else {
                                int[] iArr111115 = constraintWidget.f1696h;
                                iArr111115[1] = i11;
                                iArr111115[3] = i11;
                            }
                            i12 = constraintWidget.f1710o;
                            if (i12 > 0) {
                                measuredWidth2 = Math.max(i12, measuredWidth);
                            } else {
                                measuredWidth2 = measuredWidth;
                            }
                            i13 = constraintWidget.f1712p;
                            if (i13 > 0) {
                                measuredWidth2 = Math.min(i13, measuredWidth2);
                            }
                            i14 = constraintWidget.f1716r;
                            if (i14 > 0) {
                                iMin = Math.max(i14, measuredHeight);
                            } else {
                                iMin = measuredHeight;
                            }
                            i15 = constraintWidget.f1718s;
                            if (i15 > 0) {
                                iMin = Math.min(i15, iMin);
                            }
                            if (!z16) {
                                if (z17) {
                                    iMin = (int) ((measuredWidth2 / constraintWidget.S) + 0.5f);
                                }
                            } else if (z17) {
                                iMin = (int) ((measuredWidth2 / constraintWidget.S) + 0.5f);
                            }
                            if (measuredWidth == measuredWidth2) {
                                if (measuredWidth != measuredWidth2) {
                                    iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(measuredWidth2, 1073741824);
                                }
                                if (measuredHeight != iMin) {
                                    iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(iMin, 1073741824);
                                }
                                view.measure(iMakeMeasureSpec, iMakeMeasureSpec2);
                                measuredWidth2 = view.getMeasuredWidth();
                                measuredHeight2 = view.getMeasuredHeight();
                                baseline = view.getBaseline();
                            } else {
                                if (measuredWidth != measuredWidth2) {
                                    iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(measuredWidth2, 1073741824);
                                }
                                if (measuredHeight != iMin) {
                                    iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(iMin, 1073741824);
                                }
                                view.measure(iMakeMeasureSpec, iMakeMeasureSpec2);
                                measuredWidth2 = view.getMeasuredWidth();
                                measuredHeight2 = view.getMeasuredHeight();
                                baseline = view.getBaseline();
                            }
                            i16 = -1;
                        }
                        if (baseline != i16) {
                            i17 = 1;
                        } else {
                            i17 = i11;
                        }
                        if (measuredWidth2 == aVar.f1783c) {
                            z18 = 1;
                        } else {
                            z18 = 1;
                        }
                        aVar.f1789i = z18;
                        if (layoutParams.needsBaseline) {
                            z19 = 1;
                        } else {
                            z19 = i17;
                        }
                        if (z19 != 0) {
                            aVar.f1789i = true;
                        }
                        aVar.f1785e = measuredWidth2;
                        aVar.f1786f = measuredHeight2;
                        aVar.f1788h = z19;
                        aVar.f1787g = baseline;
                    }
                    childMeasureSpec2 = ViewGroup.getChildMeasureSpec(this.f1966g, i20 + constraintWidget.O(), -1);
                    constraintWidget.f1696h[3] = -1;
                    iMakeMeasureSpec2 = childMeasureSpec2;
                } else {
                    childMeasureSpec = ViewGroup.getChildMeasureSpec(this.f1966g, i20, -2);
                    constraintWidget.f1696h[3] = -2;
                }
                iMakeMeasureSpec2 = childMeasureSpec;
                z11 = true;
                dimensionBehaviour = ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT;
                if (dimensionBehaviour3 == dimensionBehaviour) {
                    z12 = true;
                } else {
                    z12 = false;
                }
                if (dimensionBehaviour4 == dimensionBehaviour) {
                    z13 = true;
                } else {
                    z13 = false;
                }
                dimensionBehaviour2 = ConstraintWidget.DimensionBehaviour.MATCH_PARENT;
                if (dimensionBehaviour4 != dimensionBehaviour2) {
                    z14 = true;
                } else {
                    z14 = true;
                }
                if (dimensionBehaviour3 != dimensionBehaviour2) {
                    z15 = true;
                } else {
                    z15 = true;
                }
                if (z12) {
                    z16 = false;
                } else {
                    z16 = false;
                }
                if (z13) {
                    z17 = false;
                } else {
                    z17 = false;
                }
                layoutParams = (LayoutParams) view.getLayoutParams();
                if (aVar.f1790j) {
                    if (view instanceof VirtualLayout) {
                        view.measure(iMakeMeasureSpec, iMakeMeasureSpec2);
                    } else {
                        view.measure(iMakeMeasureSpec, iMakeMeasureSpec2);
                    }
                    measuredWidth = view.getMeasuredWidth();
                    measuredHeight = view.getMeasuredHeight();
                    baseline = view.getBaseline();
                    if (z10) {
                        int[] iArr111116 = constraintWidget.f1696h;
                        i11 = 0;
                        iArr111116[0] = measuredWidth;
                        iArr111116[2] = measuredHeight;
                    } else {
                        i11 = 0;
                        int[] iArr111117 = constraintWidget.f1696h;
                        iArr111117[0] = 0;
                        iArr111117[2] = 0;
                    }
                    if (z11) {
                        int[] iArr111118 = constraintWidget.f1696h;
                        iArr111118[1] = measuredHeight;
                        iArr111118[3] = measuredWidth;
                    } else {
                        int[] iArr111119 = constraintWidget.f1696h;
                        iArr111119[1] = i11;
                        iArr111119[3] = i11;
                    }
                    i12 = constraintWidget.f1710o;
                    if (i12 > 0) {
                        measuredWidth2 = Math.max(i12, measuredWidth);
                    } else {
                        measuredWidth2 = measuredWidth;
                    }
                    i13 = constraintWidget.f1712p;
                    if (i13 > 0) {
                        measuredWidth2 = Math.min(i13, measuredWidth2);
                    }
                    i14 = constraintWidget.f1716r;
                    if (i14 > 0) {
                        iMin = Math.max(i14, measuredHeight);
                    } else {
                        iMin = measuredHeight;
                    }
                    i15 = constraintWidget.f1718s;
                    if (i15 > 0) {
                        iMin = Math.min(i15, iMin);
                    }
                    if (!z16) {
                        if (z17) {
                            iMin = (int) ((measuredWidth2 / constraintWidget.S) + 0.5f);
                        }
                    } else if (z17) {
                        iMin = (int) ((measuredWidth2 / constraintWidget.S) + 0.5f);
                    }
                    if (measuredWidth == measuredWidth2) {
                        if (measuredWidth != measuredWidth2) {
                            iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(measuredWidth2, 1073741824);
                        }
                        if (measuredHeight != iMin) {
                            iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(iMin, 1073741824);
                        }
                        view.measure(iMakeMeasureSpec, iMakeMeasureSpec2);
                        measuredWidth2 = view.getMeasuredWidth();
                        measuredHeight2 = view.getMeasuredHeight();
                        baseline = view.getBaseline();
                    } else {
                        if (measuredWidth != measuredWidth2) {
                            iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(measuredWidth2, 1073741824);
                        }
                        if (measuredHeight != iMin) {
                            iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(iMin, 1073741824);
                        }
                        view.measure(iMakeMeasureSpec, iMakeMeasureSpec2);
                        measuredWidth2 = view.getMeasuredWidth();
                        measuredHeight2 = view.getMeasuredHeight();
                        baseline = view.getBaseline();
                    }
                    i16 = -1;
                } else {
                    if (view instanceof VirtualLayout) {
                        view.measure(iMakeMeasureSpec, iMakeMeasureSpec2);
                    } else {
                        view.measure(iMakeMeasureSpec, iMakeMeasureSpec2);
                    }
                    measuredWidth = view.getMeasuredWidth();
                    measuredHeight = view.getMeasuredHeight();
                    baseline = view.getBaseline();
                    if (z10) {
                        int[] iArr1111110 = constraintWidget.f1696h;
                        i11 = 0;
                        iArr1111110[0] = measuredWidth;
                        iArr1111110[2] = measuredHeight;
                    } else {
                        i11 = 0;
                        int[] iArr1111111 = constraintWidget.f1696h;
                        iArr1111111[0] = 0;
                        iArr1111111[2] = 0;
                    }
                    if (z11) {
                        int[] iArr1111112 = constraintWidget.f1696h;
                        iArr1111112[1] = measuredHeight;
                        iArr1111112[3] = measuredWidth;
                    } else {
                        int[] iArr1111113 = constraintWidget.f1696h;
                        iArr1111113[1] = i11;
                        iArr1111113[3] = i11;
                    }
                    i12 = constraintWidget.f1710o;
                    if (i12 > 0) {
                        measuredWidth2 = Math.max(i12, measuredWidth);
                    } else {
                        measuredWidth2 = measuredWidth;
                    }
                    i13 = constraintWidget.f1712p;
                    if (i13 > 0) {
                        measuredWidth2 = Math.min(i13, measuredWidth2);
                    }
                    i14 = constraintWidget.f1716r;
                    if (i14 > 0) {
                        iMin = Math.max(i14, measuredHeight);
                    } else {
                        iMin = measuredHeight;
                    }
                    i15 = constraintWidget.f1718s;
                    if (i15 > 0) {
                        iMin = Math.min(i15, iMin);
                    }
                    if (!z16) {
                        if (z17) {
                            iMin = (int) ((measuredWidth2 / constraintWidget.S) + 0.5f);
                        }
                    } else if (z17) {
                        iMin = (int) ((measuredWidth2 / constraintWidget.S) + 0.5f);
                    }
                    if (measuredWidth == measuredWidth2) {
                        if (measuredWidth != measuredWidth2) {
                            iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(measuredWidth2, 1073741824);
                        }
                        if (measuredHeight != iMin) {
                            iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(iMin, 1073741824);
                        }
                        view.measure(iMakeMeasureSpec, iMakeMeasureSpec2);
                        measuredWidth2 = view.getMeasuredWidth();
                        measuredHeight2 = view.getMeasuredHeight();
                        baseline = view.getBaseline();
                    } else {
                        if (measuredWidth != measuredWidth2) {
                            iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(measuredWidth2, 1073741824);
                        }
                        if (measuredHeight != iMin) {
                            iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(iMin, 1073741824);
                        }
                        view.measure(iMakeMeasureSpec, iMakeMeasureSpec2);
                        measuredWidth2 = view.getMeasuredWidth();
                        measuredHeight2 = view.getMeasuredHeight();
                        baseline = view.getBaseline();
                    }
                    i16 = -1;
                }
                if (baseline != i16) {
                    i17 = 1;
                } else {
                    i17 = i11;
                }
                if (measuredWidth2 == aVar.f1783c) {
                    z18 = 1;
                } else {
                    z18 = 1;
                }
                aVar.f1789i = z18;
                if (layoutParams.needsBaseline) {
                    z19 = 1;
                } else {
                    z19 = i17;
                }
                if (z19 != 0) {
                    aVar.f1789i = true;
                }
                aVar.f1785e = measuredWidth2;
                aVar.f1786f = measuredHeight2;
                aVar.f1788h = z19;
                aVar.f1787g = baseline;
            }
            iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(i19, 1073741824);
            constraintWidget.f1696h[3] = i19;
            z11 = false;
            dimensionBehaviour = ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT;
            if (dimensionBehaviour3 == dimensionBehaviour) {
                z12 = true;
            } else {
                z12 = false;
            }
            if (dimensionBehaviour4 == dimensionBehaviour) {
                z13 = true;
            } else {
                z13 = false;
            }
            dimensionBehaviour2 = ConstraintWidget.DimensionBehaviour.MATCH_PARENT;
            if (dimensionBehaviour4 != dimensionBehaviour2) {
                z14 = true;
            } else {
                z14 = true;
            }
            if (dimensionBehaviour3 != dimensionBehaviour2) {
                z15 = true;
            } else {
                z15 = true;
            }
            if (z12) {
                z16 = false;
            } else {
                z16 = false;
            }
            if (z13) {
                z17 = false;
            } else {
                z17 = false;
            }
            layoutParams = (LayoutParams) view.getLayoutParams();
            if (aVar.f1790j) {
                if (view instanceof VirtualLayout) {
                    view.measure(iMakeMeasureSpec, iMakeMeasureSpec2);
                } else {
                    view.measure(iMakeMeasureSpec, iMakeMeasureSpec2);
                }
                measuredWidth = view.getMeasuredWidth();
                measuredHeight = view.getMeasuredHeight();
                baseline = view.getBaseline();
                if (z10) {
                    int[] iArr1111114 = constraintWidget.f1696h;
                    i11 = 0;
                    iArr1111114[0] = measuredWidth;
                    iArr1111114[2] = measuredHeight;
                } else {
                    i11 = 0;
                    int[] iArr1111115 = constraintWidget.f1696h;
                    iArr1111115[0] = 0;
                    iArr1111115[2] = 0;
                }
                if (z11) {
                    int[] iArr1111116 = constraintWidget.f1696h;
                    iArr1111116[1] = measuredHeight;
                    iArr1111116[3] = measuredWidth;
                } else {
                    int[] iArr1111117 = constraintWidget.f1696h;
                    iArr1111117[1] = i11;
                    iArr1111117[3] = i11;
                }
                i12 = constraintWidget.f1710o;
                if (i12 > 0) {
                    measuredWidth2 = Math.max(i12, measuredWidth);
                } else {
                    measuredWidth2 = measuredWidth;
                }
                i13 = constraintWidget.f1712p;
                if (i13 > 0) {
                    measuredWidth2 = Math.min(i13, measuredWidth2);
                }
                i14 = constraintWidget.f1716r;
                if (i14 > 0) {
                    iMin = Math.max(i14, measuredHeight);
                } else {
                    iMin = measuredHeight;
                }
                i15 = constraintWidget.f1718s;
                if (i15 > 0) {
                    iMin = Math.min(i15, iMin);
                }
                if (!z16) {
                    if (z17) {
                        iMin = (int) ((measuredWidth2 / constraintWidget.S) + 0.5f);
                    }
                } else if (z17) {
                    iMin = (int) ((measuredWidth2 / constraintWidget.S) + 0.5f);
                }
                if (measuredWidth == measuredWidth2) {
                    if (measuredWidth != measuredWidth2) {
                        iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(measuredWidth2, 1073741824);
                    }
                    if (measuredHeight != iMin) {
                        iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(iMin, 1073741824);
                    }
                    view.measure(iMakeMeasureSpec, iMakeMeasureSpec2);
                    measuredWidth2 = view.getMeasuredWidth();
                    measuredHeight2 = view.getMeasuredHeight();
                    baseline = view.getBaseline();
                } else {
                    if (measuredWidth != measuredWidth2) {
                        iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(measuredWidth2, 1073741824);
                    }
                    if (measuredHeight != iMin) {
                        iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(iMin, 1073741824);
                    }
                    view.measure(iMakeMeasureSpec, iMakeMeasureSpec2);
                    measuredWidth2 = view.getMeasuredWidth();
                    measuredHeight2 = view.getMeasuredHeight();
                    baseline = view.getBaseline();
                }
                i16 = -1;
            } else {
                if (view instanceof VirtualLayout) {
                    view.measure(iMakeMeasureSpec, iMakeMeasureSpec2);
                } else {
                    view.measure(iMakeMeasureSpec, iMakeMeasureSpec2);
                }
                measuredWidth = view.getMeasuredWidth();
                measuredHeight = view.getMeasuredHeight();
                baseline = view.getBaseline();
                if (z10) {
                    int[] iArr1111118 = constraintWidget.f1696h;
                    i11 = 0;
                    iArr1111118[0] = measuredWidth;
                    iArr1111118[2] = measuredHeight;
                } else {
                    i11 = 0;
                    int[] iArr1111119 = constraintWidget.f1696h;
                    iArr1111119[0] = 0;
                    iArr1111119[2] = 0;
                }
                if (z11) {
                    int[] iArr11111110 = constraintWidget.f1696h;
                    iArr11111110[1] = measuredHeight;
                    iArr11111110[3] = measuredWidth;
                } else {
                    int[] iArr11111111 = constraintWidget.f1696h;
                    iArr11111111[1] = i11;
                    iArr11111111[3] = i11;
                }
                i12 = constraintWidget.f1710o;
                if (i12 > 0) {
                    measuredWidth2 = Math.max(i12, measuredWidth);
                } else {
                    measuredWidth2 = measuredWidth;
                }
                i13 = constraintWidget.f1712p;
                if (i13 > 0) {
                    measuredWidth2 = Math.min(i13, measuredWidth2);
                }
                i14 = constraintWidget.f1716r;
                if (i14 > 0) {
                    iMin = Math.max(i14, measuredHeight);
                } else {
                    iMin = measuredHeight;
                }
                i15 = constraintWidget.f1718s;
                if (i15 > 0) {
                    iMin = Math.min(i15, iMin);
                }
                if (!z16) {
                    if (z17) {
                        iMin = (int) ((measuredWidth2 / constraintWidget.S) + 0.5f);
                    }
                } else if (z17) {
                    iMin = (int) ((measuredWidth2 / constraintWidget.S) + 0.5f);
                }
                if (measuredWidth == measuredWidth2) {
                    if (measuredWidth != measuredWidth2) {
                        iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(measuredWidth2, 1073741824);
                    }
                    if (measuredHeight != iMin) {
                        iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(iMin, 1073741824);
                    }
                    view.measure(iMakeMeasureSpec, iMakeMeasureSpec2);
                    measuredWidth2 = view.getMeasuredWidth();
                    measuredHeight2 = view.getMeasuredHeight();
                    baseline = view.getBaseline();
                } else {
                    if (measuredWidth != measuredWidth2) {
                        iMakeMeasureSpec = View.MeasureSpec.makeMeasureSpec(measuredWidth2, 1073741824);
                    }
                    if (measuredHeight != iMin) {
                        iMakeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(iMin, 1073741824);
                    }
                    view.measure(iMakeMeasureSpec, iMakeMeasureSpec2);
                    measuredWidth2 = view.getMeasuredWidth();
                    measuredHeight2 = view.getMeasuredHeight();
                    baseline = view.getBaseline();
                }
                i16 = -1;
            }
            if (baseline != i16) {
                i17 = 1;
            } else {
                i17 = i11;
            }
            if (measuredWidth2 == aVar.f1783c) {
                z18 = 1;
            } else {
                z18 = 1;
            }
            aVar.f1789i = z18;
            if (layoutParams.needsBaseline) {
                z19 = 1;
            } else {
                z19 = i17;
            }
            if (z19 != 0) {
                aVar.f1789i = true;
            }
            aVar.f1785e = measuredWidth2;
            aVar.f1786f = measuredHeight2;
            aVar.f1788h = z19;
            aVar.f1787g = baseline;
        }

        @Override // androidx.constraintlayout.solver.widgets.analyzer.b.InterfaceC0007b
        public final void b() {
            int childCount = this.f1960a.getChildCount();
            for (int i10 = 0; i10 < childCount; i10++) {
                View childAt = this.f1960a.getChildAt(i10);
                if (childAt instanceof Placeholder) {
                    ((Placeholder) childAt).b(this.f1960a);
                }
            }
            int size = this.f1960a.mConstraintHelpers.size();
            if (size > 0) {
                for (int i11 = 0; i11 < size; i11++) {
                    ((ConstraintHelper) this.f1960a.mConstraintHelpers.get(i11)).q(this.f1960a);
                }
            }
        }

        public void c(int i10, int i11, int i12, int i13, int i14, int i15) {
            this.f1961b = i12;
            this.f1962c = i13;
            this.f1963d = i14;
            this.f1964e = i15;
            this.f1965f = i10;
            this.f1966g = i11;
        }
    }

    public ConstraintLayout(Context context) {
        super(context);
        this.mChildrenByIds = new SparseArray<>();
        this.mConstraintHelpers = new ArrayList<>(4);
        this.mLayoutWidget = new androidx.constraintlayout.solver.widgets.d();
        this.mMinWidth = 0;
        this.mMinHeight = 0;
        this.mMaxWidth = Integer.MAX_VALUE;
        this.mMaxHeight = Integer.MAX_VALUE;
        this.mDirtyHierarchy = true;
        this.mOptimizationLevel = 263;
        this.mConstraintSet = null;
        this.mConstraintLayoutSpec = null;
        this.mConstraintSetId = -1;
        this.mDesignIds = new HashMap<>();
        this.mLastMeasureWidth = -1;
        this.mLastMeasureHeight = -1;
        this.mLastMeasureWidthSize = -1;
        this.mLastMeasureHeightSize = -1;
        this.mLastMeasureWidthMode = 0;
        this.mLastMeasureHeightMode = 0;
        this.mTempMapIdToWidget = new SparseArray<>();
        this.mMeasurer = new b(this);
        this.mOnMeasureWidthMeasureSpec = 0;
        this.mOnMeasureHeightMeasureSpec = 0;
        init(null, 0, 0);
    }

    private int getPaddingWidth() {
        int iMax = Math.max(0, getPaddingLeft()) + Math.max(0, getPaddingRight());
        int iMax2 = Math.max(0, getPaddingStart()) + Math.max(0, getPaddingEnd());
        return iMax2 > 0 ? iMax2 : iMax;
    }

    private final ConstraintWidget getTargetWidget(int i10) {
        if (i10 == 0) {
            return this.mLayoutWidget;
        }
        View viewFindViewById = this.mChildrenByIds.get(i10);
        if (viewFindViewById == null && (viewFindViewById = findViewById(i10)) != null && viewFindViewById != this && viewFindViewById.getParent() == this) {
            onViewAdded(viewFindViewById);
        }
        if (viewFindViewById == this) {
            return this.mLayoutWidget;
        }
        if (viewFindViewById == null) {
            return null;
        }
        return ((LayoutParams) viewFindViewById.getLayoutParams()).widget;
    }

    private void init(AttributeSet attributeSet, int i10, int i11) {
        this.mLayoutWidget.d0(this);
        this.mLayoutWidget.i1(this.mMeasurer);
        this.mChildrenByIds.put(getId(), this);
        this.mConstraintSet = null;
        if (attributeSet != null) {
            TypedArray typedArrayObtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, R$styleable.ConstraintLayout_Layout, i10, i11);
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            for (int i12 = 0; i12 < indexCount; i12++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i12);
                if (index == R$styleable.ConstraintLayout_Layout_android_minWidth) {
                    this.mMinWidth = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, this.mMinWidth);
                } else if (index == R$styleable.ConstraintLayout_Layout_android_minHeight) {
                    this.mMinHeight = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, this.mMinHeight);
                } else if (index == R$styleable.ConstraintLayout_Layout_android_maxWidth) {
                    this.mMaxWidth = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, this.mMaxWidth);
                } else if (index == R$styleable.ConstraintLayout_Layout_android_maxHeight) {
                    this.mMaxHeight = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, this.mMaxHeight);
                } else if (index == R$styleable.ConstraintLayout_Layout_layout_optimizationLevel) {
                    this.mOptimizationLevel = typedArrayObtainStyledAttributes.getInt(index, this.mOptimizationLevel);
                } else if (index == R$styleable.ConstraintLayout_Layout_layoutDescription) {
                    int resourceId = typedArrayObtainStyledAttributes.getResourceId(index, 0);
                    if (resourceId != 0) {
                        try {
                            parseLayoutDescription(resourceId);
                        } catch (Resources.NotFoundException unused) {
                            this.mConstraintLayoutSpec = null;
                        }
                    }
                } else if (index == R$styleable.ConstraintLayout_Layout_constraintSet) {
                    int resourceId2 = typedArrayObtainStyledAttributes.getResourceId(index, 0);
                    try {
                        androidx.constraintlayout.widget.b bVar = new androidx.constraintlayout.widget.b();
                        this.mConstraintSet = bVar;
                        bVar.w(getContext(), resourceId2);
                    } catch (Resources.NotFoundException unused2) {
                        this.mConstraintSet = null;
                    }
                    this.mConstraintSetId = resourceId2;
                }
            }
            typedArrayObtainStyledAttributes.recycle();
        }
        this.mLayoutWidget.j1(this.mOptimizationLevel);
    }

    private void markHierarchyDirty() {
        this.mDirtyHierarchy = true;
        this.mLastMeasureWidth = -1;
        this.mLastMeasureHeight = -1;
        this.mLastMeasureWidthSize = -1;
        this.mLastMeasureHeightSize = -1;
        this.mLastMeasureWidthMode = 0;
        this.mLastMeasureHeightMode = 0;
    }

    private void setChildrenConstraints() {
        boolean zIsInEditMode = isInEditMode();
        int childCount = getChildCount();
        for (int i10 = 0; i10 < childCount; i10++) {
            ConstraintWidget viewWidget = getViewWidget(getChildAt(i10));
            if (viewWidget != null) {
                viewWidget.Z();
            }
        }
        if (zIsInEditMode) {
            for (int i11 = 0; i11 < childCount; i11++) {
                View childAt = getChildAt(i11);
                try {
                    String resourceName = getResources().getResourceName(childAt.getId());
                    setDesignInformation(0, resourceName, Integer.valueOf(childAt.getId()));
                    int iIndexOf = resourceName.indexOf(47);
                    if (iIndexOf != -1) {
                        resourceName = resourceName.substring(iIndexOf + 1);
                    }
                    getTargetWidget(childAt.getId()).e0(resourceName);
                } catch (Resources.NotFoundException unused) {
                }
            }
        }
        if (this.mConstraintSetId != -1) {
            for (int i12 = 0; i12 < childCount; i12++) {
                View childAt2 = getChildAt(i12);
                if (childAt2.getId() == this.mConstraintSetId && (childAt2 instanceof Constraints)) {
                    this.mConstraintSet = ((Constraints) childAt2).getConstraintSet();
                }
            }
        }
        androidx.constraintlayout.widget.b bVar = this.mConstraintSet;
        if (bVar != null) {
            bVar.f(this, true);
        }
        this.mLayoutWidget.O0();
        int size = this.mConstraintHelpers.size();
        if (size > 0) {
            for (int i13 = 0; i13 < size; i13++) {
                this.mConstraintHelpers.get(i13).t(this);
            }
        }
        for (int i14 = 0; i14 < childCount; i14++) {
            View childAt3 = getChildAt(i14);
            if (childAt3 instanceof Placeholder) {
                ((Placeholder) childAt3).c(this);
            }
        }
        this.mTempMapIdToWidget.clear();
        this.mTempMapIdToWidget.put(0, this.mLayoutWidget);
        this.mTempMapIdToWidget.put(getId(), this.mLayoutWidget);
        for (int i15 = 0; i15 < childCount; i15++) {
            View childAt4 = getChildAt(i15);
            this.mTempMapIdToWidget.put(childAt4.getId(), getViewWidget(childAt4));
        }
        for (int i16 = 0; i16 < childCount; i16++) {
            View childAt5 = getChildAt(i16);
            ConstraintWidget viewWidget2 = getViewWidget(childAt5);
            if (viewWidget2 != null) {
                LayoutParams layoutParams = (LayoutParams) childAt5.getLayoutParams();
                this.mLayoutWidget.a(viewWidget2);
                applyConstraintsFromLayoutParams(zIsInEditMode, childAt5, viewWidget2, layoutParams, this.mTempMapIdToWidget);
            }
        }
    }

    private boolean updateHierarchy() {
        int childCount = getChildCount();
        boolean z10 = false;
        for (int i10 = 0; i10 < childCount; i10++) {
            if (getChildAt(i10).isLayoutRequested()) {
                z10 = true;
                break;
            }
        }
        if (z10) {
            setChildrenConstraints();
        }
        return z10;
    }

    @Override // android.view.ViewGroup
    public void addView(View view, int i10, ViewGroup.LayoutParams layoutParams) {
        super.addView(view, i10, layoutParams);
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public void applyConstraintsFromLayoutParams(boolean z10, View view, ConstraintWidget constraintWidget, LayoutParams layoutParams, SparseArray<ConstraintWidget> sparseArray) {
        float f10;
        ConstraintWidget constraintWidget2;
        ConstraintWidget constraintWidget3;
        ConstraintWidget constraintWidget4;
        ConstraintWidget constraintWidget5;
        int i10;
        layoutParams.validate();
        layoutParams.helped = false;
        constraintWidget.E0(view.getVisibility());
        if (layoutParams.isInPlaceholder) {
            constraintWidget.q0(true);
            constraintWidget.E0(8);
        }
        constraintWidget.d0(view);
        if (view instanceof ConstraintHelper) {
            ((ConstraintHelper) view).o(constraintWidget, this.mLayoutWidget.d1());
        }
        if (layoutParams.isGuideline) {
            f fVar = (f) constraintWidget;
            int i11 = layoutParams.resolvedGuideBegin;
            int i12 = layoutParams.resolvedGuideEnd;
            float f11 = layoutParams.resolvedGuidePercent;
            if (f11 != -1.0f) {
                fVar.R0(f11);
                return;
            } else if (i11 != -1) {
                fVar.P0(i11);
                return;
            } else {
                if (i12 != -1) {
                    fVar.Q0(i12);
                    return;
                }
                return;
            }
        }
        int i13 = layoutParams.resolvedLeftToLeft;
        int i14 = layoutParams.resolvedLeftToRight;
        int i15 = layoutParams.resolvedRightToLeft;
        int i16 = layoutParams.resolvedRightToRight;
        int i17 = layoutParams.resolveGoneLeftMargin;
        int i18 = layoutParams.resolveGoneRightMargin;
        float f12 = layoutParams.resolvedHorizontalBias;
        int i19 = layoutParams.circleConstraint;
        if (i19 != -1) {
            ConstraintWidget constraintWidget6 = sparseArray.get(i19);
            if (constraintWidget6 != null) {
                constraintWidget.k(constraintWidget6, layoutParams.circleAngle, layoutParams.circleRadius);
            }
        } else {
            if (i13 != -1) {
                ConstraintWidget constraintWidget7 = sparseArray.get(i13);
                if (constraintWidget7 != null) {
                    ConstraintAnchor.Type type = ConstraintAnchor.Type.LEFT;
                    f10 = f12;
                    constraintWidget.U(type, constraintWidget7, type, ((ViewGroup.MarginLayoutParams) layoutParams).leftMargin, i17);
                } else {
                    f10 = f12;
                }
            } else {
                f10 = f12;
                if (i14 != -1 && (constraintWidget2 = sparseArray.get(i14)) != null) {
                    constraintWidget.U(ConstraintAnchor.Type.LEFT, constraintWidget2, ConstraintAnchor.Type.RIGHT, ((ViewGroup.MarginLayoutParams) layoutParams).leftMargin, i17);
                }
            }
            if (i15 != -1) {
                ConstraintWidget constraintWidget8 = sparseArray.get(i15);
                if (constraintWidget8 != null) {
                    constraintWidget.U(ConstraintAnchor.Type.RIGHT, constraintWidget8, ConstraintAnchor.Type.LEFT, ((ViewGroup.MarginLayoutParams) layoutParams).rightMargin, i18);
                }
            } else if (i16 != -1 && (constraintWidget3 = sparseArray.get(i16)) != null) {
                ConstraintAnchor.Type type2 = ConstraintAnchor.Type.RIGHT;
                constraintWidget.U(type2, constraintWidget3, type2, ((ViewGroup.MarginLayoutParams) layoutParams).rightMargin, i18);
            }
            int i20 = layoutParams.topToTop;
            if (i20 != -1) {
                ConstraintWidget constraintWidget9 = sparseArray.get(i20);
                if (constraintWidget9 != null) {
                    ConstraintAnchor.Type type3 = ConstraintAnchor.Type.TOP;
                    constraintWidget.U(type3, constraintWidget9, type3, ((ViewGroup.MarginLayoutParams) layoutParams).topMargin, layoutParams.goneTopMargin);
                }
            } else {
                int i21 = layoutParams.topToBottom;
                if (i21 != -1 && (constraintWidget4 = sparseArray.get(i21)) != null) {
                    constraintWidget.U(ConstraintAnchor.Type.TOP, constraintWidget4, ConstraintAnchor.Type.BOTTOM, ((ViewGroup.MarginLayoutParams) layoutParams).topMargin, layoutParams.goneTopMargin);
                }
            }
            int i22 = layoutParams.bottomToTop;
            if (i22 != -1) {
                ConstraintWidget constraintWidget10 = sparseArray.get(i22);
                if (constraintWidget10 != null) {
                    constraintWidget.U(ConstraintAnchor.Type.BOTTOM, constraintWidget10, ConstraintAnchor.Type.TOP, ((ViewGroup.MarginLayoutParams) layoutParams).bottomMargin, layoutParams.goneBottomMargin);
                }
            } else {
                int i23 = layoutParams.bottomToBottom;
                if (i23 != -1 && (constraintWidget5 = sparseArray.get(i23)) != null) {
                    ConstraintAnchor.Type type4 = ConstraintAnchor.Type.BOTTOM;
                    constraintWidget.U(type4, constraintWidget5, type4, ((ViewGroup.MarginLayoutParams) layoutParams).bottomMargin, layoutParams.goneBottomMargin);
                }
            }
            int i24 = layoutParams.baselineToBaseline;
            if (i24 != -1) {
                View view2 = this.mChildrenByIds.get(i24);
                ConstraintWidget constraintWidget11 = sparseArray.get(layoutParams.baselineToBaseline);
                if (constraintWidget11 != null && view2 != null && (view2.getLayoutParams() instanceof LayoutParams)) {
                    LayoutParams layoutParams2 = (LayoutParams) view2.getLayoutParams();
                    layoutParams.needsBaseline = true;
                    layoutParams2.needsBaseline = true;
                    ConstraintAnchor.Type type5 = ConstraintAnchor.Type.BASELINE;
                    constraintWidget.n(type5).b(constraintWidget11.n(type5), 0, -1, true);
                    constraintWidget.h0(true);
                    layoutParams2.widget.h0(true);
                    constraintWidget.n(ConstraintAnchor.Type.TOP).l();
                    constraintWidget.n(ConstraintAnchor.Type.BOTTOM).l();
                }
            }
            float f13 = f10;
            if (f13 >= 0.0f) {
                constraintWidget.j0(f13);
            }
            float f14 = layoutParams.verticalBias;
            if (f14 >= 0.0f) {
                constraintWidget.y0(f14);
            }
        }
        if (z10 && ((i10 = layoutParams.editorAbsoluteX) != -1 || layoutParams.editorAbsoluteY != -1)) {
            constraintWidget.w0(i10, layoutParams.editorAbsoluteY);
        }
        if (layoutParams.horizontalDimensionFixed) {
            constraintWidget.m0(ConstraintWidget.DimensionBehaviour.FIXED);
            constraintWidget.F0(((ViewGroup.MarginLayoutParams) layoutParams).width);
            if (((ViewGroup.MarginLayoutParams) layoutParams).width == -2) {
                constraintWidget.m0(ConstraintWidget.DimensionBehaviour.WRAP_CONTENT);
            }
        } else if (((ViewGroup.MarginLayoutParams) layoutParams).width == -1) {
            if (layoutParams.constrainedWidth) {
                constraintWidget.m0(ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT);
            } else {
                constraintWidget.m0(ConstraintWidget.DimensionBehaviour.MATCH_PARENT);
            }
            constraintWidget.n(ConstraintAnchor.Type.LEFT).f1668e = ((ViewGroup.MarginLayoutParams) layoutParams).leftMargin;
            constraintWidget.n(ConstraintAnchor.Type.RIGHT).f1668e = ((ViewGroup.MarginLayoutParams) layoutParams).rightMargin;
        } else {
            constraintWidget.m0(ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT);
            constraintWidget.F0(0);
        }
        if (layoutParams.verticalDimensionFixed) {
            constraintWidget.B0(ConstraintWidget.DimensionBehaviour.FIXED);
            constraintWidget.i0(((ViewGroup.MarginLayoutParams) layoutParams).height);
            if (((ViewGroup.MarginLayoutParams) layoutParams).height == -2) {
                constraintWidget.B0(ConstraintWidget.DimensionBehaviour.WRAP_CONTENT);
            }
        } else if (((ViewGroup.MarginLayoutParams) layoutParams).height == -1) {
            if (layoutParams.constrainedHeight) {
                constraintWidget.B0(ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT);
            } else {
                constraintWidget.B0(ConstraintWidget.DimensionBehaviour.MATCH_PARENT);
            }
            constraintWidget.n(ConstraintAnchor.Type.TOP).f1668e = ((ViewGroup.MarginLayoutParams) layoutParams).topMargin;
            constraintWidget.n(ConstraintAnchor.Type.BOTTOM).f1668e = ((ViewGroup.MarginLayoutParams) layoutParams).bottomMargin;
        } else {
            constraintWidget.B0(ConstraintWidget.DimensionBehaviour.MATCH_CONSTRAINT);
            constraintWidget.i0(0);
        }
        constraintWidget.f0(layoutParams.dimensionRatio);
        constraintWidget.o0(layoutParams.horizontalWeight);
        constraintWidget.D0(layoutParams.verticalWeight);
        constraintWidget.k0(layoutParams.horizontalChainStyle);
        constraintWidget.z0(layoutParams.verticalChainStyle);
        constraintWidget.n0(layoutParams.matchConstraintDefaultWidth, layoutParams.matchConstraintMinWidth, layoutParams.matchConstraintMaxWidth, layoutParams.matchConstraintPercentWidth);
        constraintWidget.C0(layoutParams.matchConstraintDefaultHeight, layoutParams.matchConstraintMinHeight, layoutParams.matchConstraintMaxHeight, layoutParams.matchConstraintPercentHeight);
    }

    @Override // android.view.ViewGroup
    protected boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof LayoutParams;
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void dispatchDraw(Canvas canvas) {
        Object tag;
        int size;
        ArrayList<ConstraintHelper> arrayList = this.mConstraintHelpers;
        if (arrayList != null && (size = arrayList.size()) > 0) {
            for (int i10 = 0; i10 < size; i10++) {
                this.mConstraintHelpers.get(i10).r(this);
            }
        }
        super.dispatchDraw(canvas);
        if (isInEditMode()) {
            int childCount = getChildCount();
            float width = getWidth();
            float height = getHeight();
            for (int i11 = 0; i11 < childCount; i11++) {
                View childAt = getChildAt(i11);
                if (childAt.getVisibility() != 8 && (tag = childAt.getTag()) != null && (tag instanceof String)) {
                    String[] strArrSplit = ((String) tag).split(",");
                    if (strArrSplit.length == 4) {
                        int i12 = Integer.parseInt(strArrSplit[0]);
                        int i13 = Integer.parseInt(strArrSplit[1]);
                        int i14 = Integer.parseInt(strArrSplit[2]);
                        int i15 = (int) ((i12 / 1080.0f) * width);
                        int i16 = (int) ((i13 / 1920.0f) * height);
                        int i17 = (int) ((Integer.parseInt(strArrSplit[3]) / 1920.0f) * height);
                        Paint paint = new Paint();
                        paint.setColor(-65536);
                        float f10 = i15;
                        float f11 = i16;
                        float f12 = i15 + ((int) ((i14 / 1080.0f) * width));
                        canvas.drawLine(f10, f11, f12, f11, paint);
                        float f13 = i16 + i17;
                        canvas.drawLine(f12, f11, f12, f13, paint);
                        canvas.drawLine(f12, f13, f10, f13, paint);
                        canvas.drawLine(f10, f13, f10, f11, paint);
                        paint.setColor(-16711936);
                        canvas.drawLine(f10, f11, f12, f13, paint);
                        canvas.drawLine(f10, f13, f12, f11, paint);
                    }
                }
            }
        }
    }

    public void fillMetrics(t.a aVar) {
        this.mLayoutWidget.W0(aVar);
    }

    @Override // android.view.View
    public void forceLayout() {
        markHierarchyDirty();
        super.forceLayout();
    }

    public Object getDesignInformation(int i10, Object obj) {
        if (i10 != 0 || !(obj instanceof String)) {
            return null;
        }
        String str = (String) obj;
        HashMap<String, Integer> map = this.mDesignIds;
        if (map == null || !map.containsKey(str)) {
            return null;
        }
        return this.mDesignIds.get(str);
    }

    public int getMaxHeight() {
        return this.mMaxHeight;
    }

    public int getMaxWidth() {
        return this.mMaxWidth;
    }

    public int getMinHeight() {
        return this.mMinHeight;
    }

    public int getMinWidth() {
        return this.mMinWidth;
    }

    public int getOptimizationLevel() {
        return this.mLayoutWidget.Y0();
    }

    public View getViewById(int i10) {
        return this.mChildrenByIds.get(i10);
    }

    public final ConstraintWidget getViewWidget(View view) {
        if (view == this) {
            return this.mLayoutWidget;
        }
        if (view == null) {
            return null;
        }
        return ((LayoutParams) view.getLayoutParams()).widget;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public boolean isRtl() {
        return (getContext().getApplicationInfo().flags & 4194304) != 0 && 1 == getLayoutDirection();
    }

    public void loadLayoutDescription(int i10) {
        if (i10 == 0) {
            this.mConstraintLayoutSpec = null;
            return;
        }
        try {
            this.mConstraintLayoutSpec = new androidx.constraintlayout.widget.a(getContext(), this, i10);
        } catch (Resources.NotFoundException unused) {
            this.mConstraintLayoutSpec = null;
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onLayout(boolean z10, int i10, int i11, int i12, int i13) {
        View content;
        int childCount = getChildCount();
        boolean zIsInEditMode = isInEditMode();
        for (int i14 = 0; i14 < childCount; i14++) {
            View childAt = getChildAt(i14);
            LayoutParams layoutParams = (LayoutParams) childAt.getLayoutParams();
            ConstraintWidget constraintWidget = layoutParams.widget;
            if ((childAt.getVisibility() != 8 || layoutParams.isGuideline || layoutParams.isHelper || layoutParams.isVirtualGroup || zIsInEditMode) && !layoutParams.isInPlaceholder) {
                int iR = constraintWidget.R();
                int iS = constraintWidget.S();
                int iQ = constraintWidget.Q() + iR;
                int iW = constraintWidget.w() + iS;
                childAt.layout(iR, iS, iQ, iW);
                if ((childAt instanceof Placeholder) && (content = ((Placeholder) childAt).getContent()) != null) {
                    content.setVisibility(0);
                    content.layout(iR, iS, iQ, iW);
                }
            }
        }
        int size = this.mConstraintHelpers.size();
        if (size > 0) {
            for (int i15 = 0; i15 < size; i15++) {
                this.mConstraintHelpers.get(i15).p(this);
            }
        }
    }

    @Override // android.view.View
    protected void onMeasure(int i10, int i11) {
        this.mOnMeasureWidthMeasureSpec = i10;
        this.mOnMeasureHeightMeasureSpec = i11;
        this.mLayoutWidget.k1(isRtl());
        if (this.mDirtyHierarchy) {
            this.mDirtyHierarchy = false;
            if (updateHierarchy()) {
                this.mLayoutWidget.m1();
            }
        }
        resolveSystem(this.mLayoutWidget, this.mOptimizationLevel, i10, i11);
        resolveMeasuredDimension(i10, i11, this.mLayoutWidget.Q(), this.mLayoutWidget.w(), this.mLayoutWidget.e1(), this.mLayoutWidget.c1());
    }

    @Override // android.view.ViewGroup
    public void onViewAdded(View view) {
        super.onViewAdded(view);
        ConstraintWidget viewWidget = getViewWidget(view);
        if ((view instanceof Guideline) && !(viewWidget instanceof f)) {
            LayoutParams layoutParams = (LayoutParams) view.getLayoutParams();
            f fVar = new f();
            layoutParams.widget = fVar;
            layoutParams.isGuideline = true;
            fVar.S0(layoutParams.orientation);
        }
        if (view instanceof ConstraintHelper) {
            ConstraintHelper constraintHelper = (ConstraintHelper) view;
            constraintHelper.u();
            ((LayoutParams) view.getLayoutParams()).isHelper = true;
            if (!this.mConstraintHelpers.contains(constraintHelper)) {
                this.mConstraintHelpers.add(constraintHelper);
            }
        }
        this.mChildrenByIds.put(view.getId(), view);
        this.mDirtyHierarchy = true;
    }

    @Override // android.view.ViewGroup
    public void onViewRemoved(View view) {
        super.onViewRemoved(view);
        this.mChildrenByIds.remove(view.getId());
        this.mLayoutWidget.N0(getViewWidget(view));
        this.mConstraintHelpers.remove(view);
        this.mDirtyHierarchy = true;
    }

    protected void parseLayoutDescription(int i10) {
        this.mConstraintLayoutSpec = new androidx.constraintlayout.widget.a(getContext(), this, i10);
    }

    @Override // android.view.ViewGroup, android.view.ViewManager
    public void removeView(View view) {
        super.removeView(view);
    }

    @Override // android.view.View, android.view.ViewParent
    public void requestLayout() {
        markHierarchyDirty();
        super.requestLayout();
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public void resolveMeasuredDimension(int i10, int i11, int i12, int i13, boolean z10, boolean z11) {
        b bVar = this.mMeasurer;
        int i14 = bVar.f1964e;
        int iResolveSizeAndState = View.resolveSizeAndState(i12 + bVar.f1963d, i10, 0);
        int iResolveSizeAndState2 = View.resolveSizeAndState(i13 + i14, i11, 0) & 16777215;
        int iMin = Math.min(this.mMaxWidth, iResolveSizeAndState & 16777215);
        int iMin2 = Math.min(this.mMaxHeight, iResolveSizeAndState2);
        if (z10) {
            iMin |= 16777216;
        }
        if (z11) {
            iMin2 |= 16777216;
        }
        setMeasuredDimension(iMin, iMin2);
        this.mLastMeasureWidth = iMin;
        this.mLastMeasureHeight = iMin2;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    public void resolveSystem(androidx.constraintlayout.solver.widgets.d dVar, int i10, int i11, int i12) {
        int mode = View.MeasureSpec.getMode(i11);
        int size = View.MeasureSpec.getSize(i11);
        int mode2 = View.MeasureSpec.getMode(i12);
        int size2 = View.MeasureSpec.getSize(i12);
        int iMax = Math.max(0, getPaddingTop());
        int iMax2 = Math.max(0, getPaddingBottom());
        int i13 = iMax + iMax2;
        int paddingWidth = getPaddingWidth();
        this.mMeasurer.c(i11, i12, iMax, iMax2, paddingWidth, i13);
        int iMax3 = Math.max(0, getPaddingStart());
        int iMax4 = Math.max(0, getPaddingEnd());
        if (iMax3 <= 0 && iMax4 <= 0) {
            iMax4 = Math.max(0, getPaddingLeft());
        } else if (!isRtl()) {
            iMax4 = iMax3;
        }
        int i14 = size - paddingWidth;
        int i15 = size2 - i13;
        setSelfDimensionBehaviour(dVar, mode, i14, mode2, i15);
        dVar.f1(i10, mode, i14, mode2, i15, this.mLastMeasureWidth, this.mLastMeasureHeight, iMax4, iMax);
    }

    public void setConstraintSet(androidx.constraintlayout.widget.b bVar) {
        this.mConstraintSet = bVar;
    }

    public void setDesignInformation(int i10, Object obj, Object obj2) {
        if (i10 == 0 && (obj instanceof String) && (obj2 instanceof Integer)) {
            if (this.mDesignIds == null) {
                this.mDesignIds = new HashMap<>();
            }
            String strSubstring = (String) obj;
            int iIndexOf = strSubstring.indexOf("/");
            if (iIndexOf != -1) {
                strSubstring = strSubstring.substring(iIndexOf + 1);
            }
            Integer num = (Integer) obj2;
            num.intValue();
            this.mDesignIds.put(strSubstring, num);
        }
    }

    @Override // android.view.View
    public void setId(int i10) {
        this.mChildrenByIds.remove(getId());
        super.setId(i10);
        this.mChildrenByIds.put(getId(), this);
    }

    public void setMaxHeight(int i10) {
        if (i10 == this.mMaxHeight) {
            return;
        }
        this.mMaxHeight = i10;
        requestLayout();
    }

    public void setMaxWidth(int i10) {
        if (i10 == this.mMaxWidth) {
            return;
        }
        this.mMaxWidth = i10;
        requestLayout();
    }

    public void setMinHeight(int i10) {
        if (i10 == this.mMinHeight) {
            return;
        }
        this.mMinHeight = i10;
        requestLayout();
    }

    public void setMinWidth(int i10) {
        if (i10 == this.mMinWidth) {
            return;
        }
        this.mMinWidth = i10;
        requestLayout();
    }

    public void setOnConstraintsChanged(c cVar) {
        androidx.constraintlayout.widget.a aVar = this.mConstraintLayoutSpec;
        if (aVar != null) {
            aVar.c(cVar);
        }
    }

    public void setOptimizationLevel(int i10) {
        this.mOptimizationLevel = i10;
        this.mLayoutWidget.j1(i10);
    }

    /* JADX WARN: Code duplicated, block: B:18:0x003e A[PHI: r2
      0x003e: PHI (r2v4 androidx.constraintlayout.solver.widgets.ConstraintWidget$DimensionBehaviour) = 
      (r2v3 androidx.constraintlayout.solver.widgets.ConstraintWidget$DimensionBehaviour)
      (r2v0 androidx.constraintlayout.solver.widgets.ConstraintWidget$DimensionBehaviour)
     binds: [B:21:0x004a, B:17:0x003c] A[DONT_GENERATE, DONT_INLINE]] */
    protected void setSelfDimensionBehaviour(androidx.constraintlayout.solver.widgets.d dVar, int i10, int i11, int i12, int i13) {
        ConstraintWidget.DimensionBehaviour dimensionBehaviour;
        b bVar = this.mMeasurer;
        int i14 = bVar.f1964e;
        int i15 = bVar.f1963d;
        ConstraintWidget.DimensionBehaviour dimensionBehaviour2 = ConstraintWidget.DimensionBehaviour.FIXED;
        int childCount = getChildCount();
        if (i10 == Integer.MIN_VALUE) {
            dimensionBehaviour = ConstraintWidget.DimensionBehaviour.WRAP_CONTENT;
            if (childCount == 0) {
                i11 = Math.max(0, this.mMinWidth);
            }
        } else if (i10 == 0) {
            dimensionBehaviour = ConstraintWidget.DimensionBehaviour.WRAP_CONTENT;
            i11 = childCount == 0 ? Math.max(0, this.mMinWidth) : 0;
        } else if (i10 != 1073741824) {
            dimensionBehaviour = dimensionBehaviour2;
        } else {
            i11 = Math.min(this.mMaxWidth - i15, i11);
            dimensionBehaviour = dimensionBehaviour2;
        }
        if (i12 == Integer.MIN_VALUE) {
            dimensionBehaviour2 = ConstraintWidget.DimensionBehaviour.WRAP_CONTENT;
            if (childCount == 0) {
                i13 = Math.max(0, this.mMinHeight);
            }
        } else if (i12 == 0) {
            dimensionBehaviour2 = ConstraintWidget.DimensionBehaviour.WRAP_CONTENT;
            if (childCount == 0) {
                i13 = Math.max(0, this.mMinHeight);
            } else {
                i13 = 0;
            }
        } else if (i12 != 1073741824) {
            i13 = 0;
        } else {
            i13 = Math.min(this.mMaxHeight - i14, i13);
        }
        if (i11 != dVar.Q() || i13 != dVar.w()) {
            dVar.b1();
        }
        dVar.G0(0);
        dVar.H0(0);
        dVar.t0(this.mMaxWidth - i15);
        dVar.s0(this.mMaxHeight - i14);
        dVar.v0(0);
        dVar.u0(0);
        dVar.m0(dimensionBehaviour);
        dVar.F0(i11);
        dVar.B0(dimensionBehaviour2);
        dVar.i0(i13);
        dVar.v0(this.mMinWidth - i15);
        dVar.u0(this.mMinHeight - i14);
    }

    public void setState(int i10, int i11, int i12) {
        androidx.constraintlayout.widget.a aVar = this.mConstraintLayoutSpec;
        if (aVar != null) {
            aVar.d(i10, i11, i12);
        }
    }

    @Override // android.view.ViewGroup
    public boolean shouldDelayChildPressedState() {
        return false;
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // android.view.ViewGroup
    public LayoutParams generateDefaultLayoutParams() {
        return new LayoutParams(-2, -2);
    }

    @Override // android.view.ViewGroup
    public LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new LayoutParams(getContext(), attributeSet);
    }

    @Override // android.view.ViewGroup
    protected ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return new LayoutParams(layoutParams);
    }

    public ConstraintLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.mChildrenByIds = new SparseArray<>();
        this.mConstraintHelpers = new ArrayList<>(4);
        this.mLayoutWidget = new androidx.constraintlayout.solver.widgets.d();
        this.mMinWidth = 0;
        this.mMinHeight = 0;
        this.mMaxWidth = Integer.MAX_VALUE;
        this.mMaxHeight = Integer.MAX_VALUE;
        this.mDirtyHierarchy = true;
        this.mOptimizationLevel = 263;
        this.mConstraintSet = null;
        this.mConstraintLayoutSpec = null;
        this.mConstraintSetId = -1;
        this.mDesignIds = new HashMap<>();
        this.mLastMeasureWidth = -1;
        this.mLastMeasureHeight = -1;
        this.mLastMeasureWidthSize = -1;
        this.mLastMeasureHeightSize = -1;
        this.mLastMeasureWidthMode = 0;
        this.mLastMeasureHeightMode = 0;
        this.mTempMapIdToWidget = new SparseArray<>();
        this.mMeasurer = new b(this);
        this.mOnMeasureWidthMeasureSpec = 0;
        this.mOnMeasureHeightMeasureSpec = 0;
        init(attributeSet, 0, 0);
    }

    public ConstraintLayout(Context context, AttributeSet attributeSet, int i10) {
        super(context, attributeSet, i10);
        this.mChildrenByIds = new SparseArray<>();
        this.mConstraintHelpers = new ArrayList<>(4);
        this.mLayoutWidget = new androidx.constraintlayout.solver.widgets.d();
        this.mMinWidth = 0;
        this.mMinHeight = 0;
        this.mMaxWidth = Integer.MAX_VALUE;
        this.mMaxHeight = Integer.MAX_VALUE;
        this.mDirtyHierarchy = true;
        this.mOptimizationLevel = 263;
        this.mConstraintSet = null;
        this.mConstraintLayoutSpec = null;
        this.mConstraintSetId = -1;
        this.mDesignIds = new HashMap<>();
        this.mLastMeasureWidth = -1;
        this.mLastMeasureHeight = -1;
        this.mLastMeasureWidthSize = -1;
        this.mLastMeasureHeightSize = -1;
        this.mLastMeasureWidthMode = 0;
        this.mLastMeasureHeightMode = 0;
        this.mTempMapIdToWidget = new SparseArray<>();
        this.mMeasurer = new b(this);
        this.mOnMeasureWidthMeasureSpec = 0;
        this.mOnMeasureHeightMeasureSpec = 0;
        init(attributeSet, i10, 0);
    }

    @TargetApi(21)
    public ConstraintLayout(Context context, AttributeSet attributeSet, int i10, int i11) {
        super(context, attributeSet, i10, i11);
        this.mChildrenByIds = new SparseArray<>();
        this.mConstraintHelpers = new ArrayList<>(4);
        this.mLayoutWidget = new androidx.constraintlayout.solver.widgets.d();
        this.mMinWidth = 0;
        this.mMinHeight = 0;
        this.mMaxWidth = Integer.MAX_VALUE;
        this.mMaxHeight = Integer.MAX_VALUE;
        this.mDirtyHierarchy = true;
        this.mOptimizationLevel = 263;
        this.mConstraintSet = null;
        this.mConstraintLayoutSpec = null;
        this.mConstraintSetId = -1;
        this.mDesignIds = new HashMap<>();
        this.mLastMeasureWidth = -1;
        this.mLastMeasureHeight = -1;
        this.mLastMeasureWidthSize = -1;
        this.mLastMeasureHeightSize = -1;
        this.mLastMeasureWidthMode = 0;
        this.mLastMeasureHeightMode = 0;
        this.mTempMapIdToWidget = new SparseArray<>();
        this.mMeasurer = new b(this);
        this.mOnMeasureWidthMeasureSpec = 0;
        this.mOnMeasureHeightMeasureSpec = 0;
        init(attributeSet, i10, i11);
    }

    public static class LayoutParams extends ViewGroup.MarginLayoutParams {
        public static final int BASELINE = 5;
        public static final int BOTTOM = 4;
        public static final int CHAIN_PACKED = 2;
        public static final int CHAIN_SPREAD = 0;
        public static final int CHAIN_SPREAD_INSIDE = 1;
        public static final int END = 7;
        public static final int HORIZONTAL = 0;
        public static final int LEFT = 1;
        public static final int MATCH_CONSTRAINT = 0;
        public static final int MATCH_CONSTRAINT_PERCENT = 2;
        public static final int MATCH_CONSTRAINT_SPREAD = 0;
        public static final int MATCH_CONSTRAINT_WRAP = 1;
        public static final int PARENT_ID = 0;
        public static final int RIGHT = 2;
        public static final int START = 6;
        public static final int TOP = 3;
        public static final int UNSET = -1;
        public static final int VERTICAL = 1;
        public int baselineToBaseline;
        public int bottomToBottom;
        public int bottomToTop;
        public float circleAngle;
        public int circleConstraint;
        public int circleRadius;
        public boolean constrainedHeight;
        public boolean constrainedWidth;
        public String constraintTag;
        public String dimensionRatio;
        int dimensionRatioSide;
        float dimensionRatioValue;
        public int editorAbsoluteX;
        public int editorAbsoluteY;
        public int endToEnd;
        public int endToStart;
        public int goneBottomMargin;
        public int goneEndMargin;
        public int goneLeftMargin;
        public int goneRightMargin;
        public int goneStartMargin;
        public int goneTopMargin;
        public int guideBegin;
        public int guideEnd;
        public float guidePercent;
        public boolean helped;
        public float horizontalBias;
        public int horizontalChainStyle;
        boolean horizontalDimensionFixed;
        public float horizontalWeight;
        boolean isGuideline;
        boolean isHelper;
        boolean isInPlaceholder;
        boolean isVirtualGroup;
        public int leftToLeft;
        public int leftToRight;
        public int matchConstraintDefaultHeight;
        public int matchConstraintDefaultWidth;
        public int matchConstraintMaxHeight;
        public int matchConstraintMaxWidth;
        public int matchConstraintMinHeight;
        public int matchConstraintMinWidth;
        public float matchConstraintPercentHeight;
        public float matchConstraintPercentWidth;
        boolean needsBaseline;
        public int orientation;
        int resolveGoneLeftMargin;
        int resolveGoneRightMargin;
        int resolvedGuideBegin;
        int resolvedGuideEnd;
        float resolvedGuidePercent;
        float resolvedHorizontalBias;
        int resolvedLeftToLeft;
        int resolvedLeftToRight;
        int resolvedRightToLeft;
        int resolvedRightToRight;
        public int rightToLeft;
        public int rightToRight;
        public int startToEnd;
        public int startToStart;
        public int topToBottom;
        public int topToTop;
        public float verticalBias;
        public int verticalChainStyle;
        boolean verticalDimensionFixed;
        public float verticalWeight;
        ConstraintWidget widget;

        private static class a {

            /* JADX INFO: renamed from: a, reason: collision with root package name */
            public static final SparseIntArray f1958a;

            static {
                SparseIntArray sparseIntArray = new SparseIntArray();
                f1958a = sparseIntArray;
                sparseIntArray.append(R$styleable.ConstraintLayout_Layout_layout_constraintLeft_toLeftOf, 8);
                sparseIntArray.append(R$styleable.ConstraintLayout_Layout_layout_constraintLeft_toRightOf, 9);
                sparseIntArray.append(R$styleable.ConstraintLayout_Layout_layout_constraintRight_toLeftOf, 10);
                sparseIntArray.append(R$styleable.ConstraintLayout_Layout_layout_constraintRight_toRightOf, 11);
                sparseIntArray.append(R$styleable.ConstraintLayout_Layout_layout_constraintTop_toTopOf, 12);
                sparseIntArray.append(R$styleable.ConstraintLayout_Layout_layout_constraintTop_toBottomOf, 13);
                sparseIntArray.append(R$styleable.ConstraintLayout_Layout_layout_constraintBottom_toTopOf, 14);
                sparseIntArray.append(R$styleable.ConstraintLayout_Layout_layout_constraintBottom_toBottomOf, 15);
                sparseIntArray.append(R$styleable.ConstraintLayout_Layout_layout_constraintBaseline_toBaselineOf, 16);
                sparseIntArray.append(R$styleable.ConstraintLayout_Layout_layout_constraintCircle, 2);
                sparseIntArray.append(R$styleable.ConstraintLayout_Layout_layout_constraintCircleRadius, 3);
                sparseIntArray.append(R$styleable.ConstraintLayout_Layout_layout_constraintCircleAngle, 4);
                sparseIntArray.append(R$styleable.ConstraintLayout_Layout_layout_editor_absoluteX, 49);
                sparseIntArray.append(R$styleable.ConstraintLayout_Layout_layout_editor_absoluteY, 50);
                sparseIntArray.append(R$styleable.ConstraintLayout_Layout_layout_constraintGuide_begin, 5);
                sparseIntArray.append(R$styleable.ConstraintLayout_Layout_layout_constraintGuide_end, 6);
                sparseIntArray.append(R$styleable.ConstraintLayout_Layout_layout_constraintGuide_percent, 7);
                sparseIntArray.append(R$styleable.ConstraintLayout_Layout_android_orientation, 1);
                sparseIntArray.append(R$styleable.ConstraintLayout_Layout_layout_constraintStart_toEndOf, 17);
                sparseIntArray.append(R$styleable.ConstraintLayout_Layout_layout_constraintStart_toStartOf, 18);
                sparseIntArray.append(R$styleable.ConstraintLayout_Layout_layout_constraintEnd_toStartOf, 19);
                sparseIntArray.append(R$styleable.ConstraintLayout_Layout_layout_constraintEnd_toEndOf, 20);
                sparseIntArray.append(R$styleable.ConstraintLayout_Layout_layout_goneMarginLeft, 21);
                sparseIntArray.append(R$styleable.ConstraintLayout_Layout_layout_goneMarginTop, 22);
                sparseIntArray.append(R$styleable.ConstraintLayout_Layout_layout_goneMarginRight, 23);
                sparseIntArray.append(R$styleable.ConstraintLayout_Layout_layout_goneMarginBottom, 24);
                sparseIntArray.append(R$styleable.ConstraintLayout_Layout_layout_goneMarginStart, 25);
                sparseIntArray.append(R$styleable.ConstraintLayout_Layout_layout_goneMarginEnd, 26);
                sparseIntArray.append(R$styleable.ConstraintLayout_Layout_layout_constraintHorizontal_bias, 29);
                sparseIntArray.append(R$styleable.ConstraintLayout_Layout_layout_constraintVertical_bias, 30);
                sparseIntArray.append(R$styleable.ConstraintLayout_Layout_layout_constraintDimensionRatio, 44);
                sparseIntArray.append(R$styleable.ConstraintLayout_Layout_layout_constraintHorizontal_weight, 45);
                sparseIntArray.append(R$styleable.ConstraintLayout_Layout_layout_constraintVertical_weight, 46);
                sparseIntArray.append(R$styleable.ConstraintLayout_Layout_layout_constraintHorizontal_chainStyle, 47);
                sparseIntArray.append(R$styleable.ConstraintLayout_Layout_layout_constraintVertical_chainStyle, 48);
                sparseIntArray.append(R$styleable.ConstraintLayout_Layout_layout_constrainedWidth, 27);
                sparseIntArray.append(R$styleable.ConstraintLayout_Layout_layout_constrainedHeight, 28);
                sparseIntArray.append(R$styleable.ConstraintLayout_Layout_layout_constraintWidth_default, 31);
                sparseIntArray.append(R$styleable.ConstraintLayout_Layout_layout_constraintHeight_default, 32);
                sparseIntArray.append(R$styleable.ConstraintLayout_Layout_layout_constraintWidth_min, 33);
                sparseIntArray.append(R$styleable.ConstraintLayout_Layout_layout_constraintWidth_max, 34);
                sparseIntArray.append(R$styleable.ConstraintLayout_Layout_layout_constraintWidth_percent, 35);
                sparseIntArray.append(R$styleable.ConstraintLayout_Layout_layout_constraintHeight_min, 36);
                sparseIntArray.append(R$styleable.ConstraintLayout_Layout_layout_constraintHeight_max, 37);
                sparseIntArray.append(R$styleable.ConstraintLayout_Layout_layout_constraintHeight_percent, 38);
                sparseIntArray.append(R$styleable.ConstraintLayout_Layout_layout_constraintLeft_creator, 39);
                sparseIntArray.append(R$styleable.ConstraintLayout_Layout_layout_constraintTop_creator, 40);
                sparseIntArray.append(R$styleable.ConstraintLayout_Layout_layout_constraintRight_creator, 41);
                sparseIntArray.append(R$styleable.ConstraintLayout_Layout_layout_constraintBottom_creator, 42);
                sparseIntArray.append(R$styleable.ConstraintLayout_Layout_layout_constraintBaseline_creator, 43);
                sparseIntArray.append(R$styleable.ConstraintLayout_Layout_layout_constraintTag, 51);
            }
        }

        public LayoutParams(LayoutParams layoutParams) {
            super((ViewGroup.MarginLayoutParams) layoutParams);
            this.guideBegin = -1;
            this.guideEnd = -1;
            this.guidePercent = -1.0f;
            this.leftToLeft = -1;
            this.leftToRight = -1;
            this.rightToLeft = -1;
            this.rightToRight = -1;
            this.topToTop = -1;
            this.topToBottom = -1;
            this.bottomToTop = -1;
            this.bottomToBottom = -1;
            this.baselineToBaseline = -1;
            this.circleConstraint = -1;
            this.circleRadius = 0;
            this.circleAngle = 0.0f;
            this.startToEnd = -1;
            this.startToStart = -1;
            this.endToStart = -1;
            this.endToEnd = -1;
            this.goneLeftMargin = -1;
            this.goneTopMargin = -1;
            this.goneRightMargin = -1;
            this.goneBottomMargin = -1;
            this.goneStartMargin = -1;
            this.goneEndMargin = -1;
            this.horizontalBias = 0.5f;
            this.verticalBias = 0.5f;
            this.dimensionRatio = null;
            this.dimensionRatioValue = 0.0f;
            this.dimensionRatioSide = 1;
            this.horizontalWeight = -1.0f;
            this.verticalWeight = -1.0f;
            this.horizontalChainStyle = 0;
            this.verticalChainStyle = 0;
            this.matchConstraintDefaultWidth = 0;
            this.matchConstraintDefaultHeight = 0;
            this.matchConstraintMinWidth = 0;
            this.matchConstraintMinHeight = 0;
            this.matchConstraintMaxWidth = 0;
            this.matchConstraintMaxHeight = 0;
            this.matchConstraintPercentWidth = 1.0f;
            this.matchConstraintPercentHeight = 1.0f;
            this.editorAbsoluteX = -1;
            this.editorAbsoluteY = -1;
            this.orientation = -1;
            this.constrainedWidth = false;
            this.constrainedHeight = false;
            this.constraintTag = null;
            this.horizontalDimensionFixed = true;
            this.verticalDimensionFixed = true;
            this.needsBaseline = false;
            this.isGuideline = false;
            this.isHelper = false;
            this.isInPlaceholder = false;
            this.isVirtualGroup = false;
            this.resolvedLeftToLeft = -1;
            this.resolvedLeftToRight = -1;
            this.resolvedRightToLeft = -1;
            this.resolvedRightToRight = -1;
            this.resolveGoneLeftMargin = -1;
            this.resolveGoneRightMargin = -1;
            this.resolvedHorizontalBias = 0.5f;
            this.widget = new ConstraintWidget();
            this.helped = false;
            this.guideBegin = layoutParams.guideBegin;
            this.guideEnd = layoutParams.guideEnd;
            this.guidePercent = layoutParams.guidePercent;
            this.leftToLeft = layoutParams.leftToLeft;
            this.leftToRight = layoutParams.leftToRight;
            this.rightToLeft = layoutParams.rightToLeft;
            this.rightToRight = layoutParams.rightToRight;
            this.topToTop = layoutParams.topToTop;
            this.topToBottom = layoutParams.topToBottom;
            this.bottomToTop = layoutParams.bottomToTop;
            this.bottomToBottom = layoutParams.bottomToBottom;
            this.baselineToBaseline = layoutParams.baselineToBaseline;
            this.circleConstraint = layoutParams.circleConstraint;
            this.circleRadius = layoutParams.circleRadius;
            this.circleAngle = layoutParams.circleAngle;
            this.startToEnd = layoutParams.startToEnd;
            this.startToStart = layoutParams.startToStart;
            this.endToStart = layoutParams.endToStart;
            this.endToEnd = layoutParams.endToEnd;
            this.goneLeftMargin = layoutParams.goneLeftMargin;
            this.goneTopMargin = layoutParams.goneTopMargin;
            this.goneRightMargin = layoutParams.goneRightMargin;
            this.goneBottomMargin = layoutParams.goneBottomMargin;
            this.goneStartMargin = layoutParams.goneStartMargin;
            this.goneEndMargin = layoutParams.goneEndMargin;
            this.horizontalBias = layoutParams.horizontalBias;
            this.verticalBias = layoutParams.verticalBias;
            this.dimensionRatio = layoutParams.dimensionRatio;
            this.dimensionRatioValue = layoutParams.dimensionRatioValue;
            this.dimensionRatioSide = layoutParams.dimensionRatioSide;
            this.horizontalWeight = layoutParams.horizontalWeight;
            this.verticalWeight = layoutParams.verticalWeight;
            this.horizontalChainStyle = layoutParams.horizontalChainStyle;
            this.verticalChainStyle = layoutParams.verticalChainStyle;
            this.constrainedWidth = layoutParams.constrainedWidth;
            this.constrainedHeight = layoutParams.constrainedHeight;
            this.matchConstraintDefaultWidth = layoutParams.matchConstraintDefaultWidth;
            this.matchConstraintDefaultHeight = layoutParams.matchConstraintDefaultHeight;
            this.matchConstraintMinWidth = layoutParams.matchConstraintMinWidth;
            this.matchConstraintMaxWidth = layoutParams.matchConstraintMaxWidth;
            this.matchConstraintMinHeight = layoutParams.matchConstraintMinHeight;
            this.matchConstraintMaxHeight = layoutParams.matchConstraintMaxHeight;
            this.matchConstraintPercentWidth = layoutParams.matchConstraintPercentWidth;
            this.matchConstraintPercentHeight = layoutParams.matchConstraintPercentHeight;
            this.editorAbsoluteX = layoutParams.editorAbsoluteX;
            this.editorAbsoluteY = layoutParams.editorAbsoluteY;
            this.orientation = layoutParams.orientation;
            this.horizontalDimensionFixed = layoutParams.horizontalDimensionFixed;
            this.verticalDimensionFixed = layoutParams.verticalDimensionFixed;
            this.needsBaseline = layoutParams.needsBaseline;
            this.isGuideline = layoutParams.isGuideline;
            this.resolvedLeftToLeft = layoutParams.resolvedLeftToLeft;
            this.resolvedLeftToRight = layoutParams.resolvedLeftToRight;
            this.resolvedRightToLeft = layoutParams.resolvedRightToLeft;
            this.resolvedRightToRight = layoutParams.resolvedRightToRight;
            this.resolveGoneLeftMargin = layoutParams.resolveGoneLeftMargin;
            this.resolveGoneRightMargin = layoutParams.resolveGoneRightMargin;
            this.resolvedHorizontalBias = layoutParams.resolvedHorizontalBias;
            this.constraintTag = layoutParams.constraintTag;
            this.widget = layoutParams.widget;
        }

        public String getConstraintTag() {
            return this.constraintTag;
        }

        public ConstraintWidget getConstraintWidget() {
            return this.widget;
        }

        public void reset() {
            ConstraintWidget constraintWidget = this.widget;
            if (constraintWidget != null) {
                constraintWidget.Z();
            }
        }

        /* JADX WARN: Code duplicated, block: B:17:0x0048  */
        /* JADX WARN: Code duplicated, block: B:20:0x004f  */
        /* JADX WARN: Code duplicated, block: B:23:0x0056  */
        /* JADX WARN: Code duplicated, block: B:26:0x005c  */
        /* JADX WARN: Code duplicated, block: B:29:0x0062  */
        /* JADX WARN: Code duplicated, block: B:36:0x0074  */
        /* JADX WARN: Code duplicated, block: B:37:0x007c A[DONT_INVERT] */
        /* JADX WARN: Code duplicated, block: B:38:0x007e  */
        /* JADX WARN: Code duplicated, block: B:39:0x0085 A[DONT_INVERT] */
        /* JADX WARN: Code duplicated, block: B:40:0x0087  */
        @Override // android.view.ViewGroup.MarginLayoutParams, android.view.ViewGroup.LayoutParams
        @TargetApi(17)
        public void resolveLayoutDirection(int i10) {
            int i11;
            int i12;
            int i13;
            int i14;
            int i15 = ((ViewGroup.MarginLayoutParams) this).leftMargin;
            int i16 = ((ViewGroup.MarginLayoutParams) this).rightMargin;
            super.resolveLayoutDirection(i10);
            boolean z10 = false;
            boolean z11 = 1 == getLayoutDirection();
            this.resolvedRightToLeft = -1;
            this.resolvedRightToRight = -1;
            this.resolvedLeftToLeft = -1;
            this.resolvedLeftToRight = -1;
            this.resolveGoneLeftMargin = this.goneLeftMargin;
            this.resolveGoneRightMargin = this.goneRightMargin;
            float f10 = this.horizontalBias;
            this.resolvedHorizontalBias = f10;
            int i17 = this.guideBegin;
            this.resolvedGuideBegin = i17;
            int i18 = this.guideEnd;
            this.resolvedGuideEnd = i18;
            float f11 = this.guidePercent;
            this.resolvedGuidePercent = f11;
            if (z11) {
                int i19 = this.startToEnd;
                if (i19 != -1) {
                    this.resolvedRightToLeft = i19;
                } else {
                    int i20 = this.startToStart;
                    if (i20 != -1) {
                        this.resolvedRightToRight = i20;
                    } else {
                        i11 = this.endToStart;
                        if (i11 != -1) {
                            this.resolvedLeftToRight = i11;
                            z10 = true;
                        }
                        i12 = this.endToEnd;
                        if (i12 != -1) {
                            this.resolvedLeftToLeft = i12;
                            z10 = true;
                        }
                        i13 = this.goneStartMargin;
                        if (i13 != -1) {
                            this.resolveGoneRightMargin = i13;
                        }
                        i14 = this.goneEndMargin;
                        if (i14 != -1) {
                            this.resolveGoneLeftMargin = i14;
                        }
                        if (z10) {
                            this.resolvedHorizontalBias = 1.0f - f10;
                        }
                        if (this.isGuideline && this.orientation == 1) {
                            if (f11 != -1.0f) {
                                this.resolvedGuidePercent = 1.0f - f11;
                                this.resolvedGuideBegin = -1;
                                this.resolvedGuideEnd = -1;
                            } else if (i17 != -1) {
                                this.resolvedGuideEnd = i17;
                                this.resolvedGuideBegin = -1;
                                this.resolvedGuidePercent = -1.0f;
                            } else if (i18 != -1) {
                                this.resolvedGuideBegin = i18;
                                this.resolvedGuideEnd = -1;
                                this.resolvedGuidePercent = -1.0f;
                            }
                        }
                    }
                }
                z10 = true;
                i11 = this.endToStart;
                if (i11 != -1) {
                    this.resolvedLeftToRight = i11;
                    z10 = true;
                }
                i12 = this.endToEnd;
                if (i12 != -1) {
                    this.resolvedLeftToLeft = i12;
                    z10 = true;
                }
                i13 = this.goneStartMargin;
                if (i13 != -1) {
                    this.resolveGoneRightMargin = i13;
                }
                i14 = this.goneEndMargin;
                if (i14 != -1) {
                    this.resolveGoneLeftMargin = i14;
                }
                if (z10) {
                    this.resolvedHorizontalBias = 1.0f - f10;
                }
                if (this.isGuideline) {
                    if (f11 != -1.0f) {
                        this.resolvedGuidePercent = 1.0f - f11;
                        this.resolvedGuideBegin = -1;
                        this.resolvedGuideEnd = -1;
                    } else if (i17 != -1) {
                        this.resolvedGuideEnd = i17;
                        this.resolvedGuideBegin = -1;
                        this.resolvedGuidePercent = -1.0f;
                    } else if (i18 != -1) {
                        this.resolvedGuideBegin = i18;
                        this.resolvedGuideEnd = -1;
                        this.resolvedGuidePercent = -1.0f;
                    }
                }
            } else {
                int i21 = this.startToEnd;
                if (i21 != -1) {
                    this.resolvedLeftToRight = i21;
                }
                int i22 = this.startToStart;
                if (i22 != -1) {
                    this.resolvedLeftToLeft = i22;
                }
                int i23 = this.endToStart;
                if (i23 != -1) {
                    this.resolvedRightToLeft = i23;
                }
                int i24 = this.endToEnd;
                if (i24 != -1) {
                    this.resolvedRightToRight = i24;
                }
                int i25 = this.goneStartMargin;
                if (i25 != -1) {
                    this.resolveGoneLeftMargin = i25;
                }
                int i26 = this.goneEndMargin;
                if (i26 != -1) {
                    this.resolveGoneRightMargin = i26;
                }
            }
            if (this.endToStart == -1 && this.endToEnd == -1 && this.startToStart == -1 && this.startToEnd == -1) {
                int i27 = this.rightToLeft;
                if (i27 != -1) {
                    this.resolvedRightToLeft = i27;
                    if (((ViewGroup.MarginLayoutParams) this).rightMargin <= 0 && i16 > 0) {
                        ((ViewGroup.MarginLayoutParams) this).rightMargin = i16;
                    }
                } else {
                    int i28 = this.rightToRight;
                    if (i28 != -1) {
                        this.resolvedRightToRight = i28;
                        if (((ViewGroup.MarginLayoutParams) this).rightMargin <= 0 && i16 > 0) {
                            ((ViewGroup.MarginLayoutParams) this).rightMargin = i16;
                        }
                    }
                }
                int i29 = this.leftToLeft;
                if (i29 != -1) {
                    this.resolvedLeftToLeft = i29;
                    if (((ViewGroup.MarginLayoutParams) this).leftMargin > 0 || i15 <= 0) {
                        return;
                    }
                    ((ViewGroup.MarginLayoutParams) this).leftMargin = i15;
                    return;
                }
                int i30 = this.leftToRight;
                if (i30 != -1) {
                    this.resolvedLeftToRight = i30;
                    if (((ViewGroup.MarginLayoutParams) this).leftMargin > 0 || i15 <= 0) {
                        return;
                    }
                    ((ViewGroup.MarginLayoutParams) this).leftMargin = i15;
                }
            }
        }

        public void setWidgetDebugName(String str) {
            this.widget.e0(str);
        }

        public void validate() {
            this.isGuideline = false;
            this.horizontalDimensionFixed = true;
            this.verticalDimensionFixed = true;
            int i10 = ((ViewGroup.MarginLayoutParams) this).width;
            if (i10 == -2 && this.constrainedWidth) {
                this.horizontalDimensionFixed = false;
                if (this.matchConstraintDefaultWidth == 0) {
                    this.matchConstraintDefaultWidth = 1;
                }
            }
            int i11 = ((ViewGroup.MarginLayoutParams) this).height;
            if (i11 == -2 && this.constrainedHeight) {
                this.verticalDimensionFixed = false;
                if (this.matchConstraintDefaultHeight == 0) {
                    this.matchConstraintDefaultHeight = 1;
                }
            }
            if (i10 == 0 || i10 == -1) {
                this.horizontalDimensionFixed = false;
                if (i10 == 0 && this.matchConstraintDefaultWidth == 1) {
                    ((ViewGroup.MarginLayoutParams) this).width = -2;
                    this.constrainedWidth = true;
                }
            }
            if (i11 == 0 || i11 == -1) {
                this.verticalDimensionFixed = false;
                if (i11 == 0 && this.matchConstraintDefaultHeight == 1) {
                    ((ViewGroup.MarginLayoutParams) this).height = -2;
                    this.constrainedHeight = true;
                }
            }
            if (this.guidePercent == -1.0f && this.guideBegin == -1 && this.guideEnd == -1) {
                return;
            }
            this.isGuideline = true;
            this.horizontalDimensionFixed = true;
            this.verticalDimensionFixed = true;
            if (!(this.widget instanceof f)) {
                this.widget = new f();
            }
            ((f) this.widget).S0(this.orientation);
        }

        public LayoutParams(Context context, AttributeSet attributeSet) {
            int i10;
            super(context, attributeSet);
            this.guideBegin = -1;
            this.guideEnd = -1;
            this.guidePercent = -1.0f;
            this.leftToLeft = -1;
            this.leftToRight = -1;
            this.rightToLeft = -1;
            this.rightToRight = -1;
            this.topToTop = -1;
            this.topToBottom = -1;
            this.bottomToTop = -1;
            this.bottomToBottom = -1;
            this.baselineToBaseline = -1;
            this.circleConstraint = -1;
            this.circleRadius = 0;
            this.circleAngle = 0.0f;
            this.startToEnd = -1;
            this.startToStart = -1;
            this.endToStart = -1;
            this.endToEnd = -1;
            this.goneLeftMargin = -1;
            this.goneTopMargin = -1;
            this.goneRightMargin = -1;
            this.goneBottomMargin = -1;
            this.goneStartMargin = -1;
            this.goneEndMargin = -1;
            this.horizontalBias = 0.5f;
            this.verticalBias = 0.5f;
            this.dimensionRatio = null;
            this.dimensionRatioValue = 0.0f;
            this.dimensionRatioSide = 1;
            this.horizontalWeight = -1.0f;
            this.verticalWeight = -1.0f;
            this.horizontalChainStyle = 0;
            this.verticalChainStyle = 0;
            this.matchConstraintDefaultWidth = 0;
            this.matchConstraintDefaultHeight = 0;
            this.matchConstraintMinWidth = 0;
            this.matchConstraintMinHeight = 0;
            this.matchConstraintMaxWidth = 0;
            this.matchConstraintMaxHeight = 0;
            this.matchConstraintPercentWidth = 1.0f;
            this.matchConstraintPercentHeight = 1.0f;
            this.editorAbsoluteX = -1;
            this.editorAbsoluteY = -1;
            this.orientation = -1;
            this.constrainedWidth = false;
            this.constrainedHeight = false;
            this.constraintTag = null;
            this.horizontalDimensionFixed = true;
            this.verticalDimensionFixed = true;
            this.needsBaseline = false;
            this.isGuideline = false;
            this.isHelper = false;
            this.isInPlaceholder = false;
            this.isVirtualGroup = false;
            this.resolvedLeftToLeft = -1;
            this.resolvedLeftToRight = -1;
            this.resolvedRightToLeft = -1;
            this.resolvedRightToRight = -1;
            this.resolveGoneLeftMargin = -1;
            this.resolveGoneRightMargin = -1;
            this.resolvedHorizontalBias = 0.5f;
            this.widget = new ConstraintWidget();
            this.helped = false;
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R$styleable.ConstraintLayout_Layout);
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            for (int i11 = 0; i11 < indexCount; i11++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i11);
                int i12 = a.f1958a.get(index);
                switch (i12) {
                    case 1:
                        this.orientation = typedArrayObtainStyledAttributes.getInt(index, this.orientation);
                        break;
                    case 2:
                        int resourceId = typedArrayObtainStyledAttributes.getResourceId(index, this.circleConstraint);
                        this.circleConstraint = resourceId;
                        if (resourceId == -1) {
                            this.circleConstraint = typedArrayObtainStyledAttributes.getInt(index, -1);
                        }
                        break;
                    case 3:
                        this.circleRadius = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.circleRadius);
                        break;
                    case 4:
                        float f10 = typedArrayObtainStyledAttributes.getFloat(index, this.circleAngle) % 360.0f;
                        this.circleAngle = f10;
                        if (f10 < 0.0f) {
                            this.circleAngle = (360.0f - f10) % 360.0f;
                        }
                        break;
                    case 5:
                        this.guideBegin = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, this.guideBegin);
                        break;
                    case 6:
                        this.guideEnd = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, this.guideEnd);
                        break;
                    case 7:
                        this.guidePercent = typedArrayObtainStyledAttributes.getFloat(index, this.guidePercent);
                        break;
                    case 8:
                        int resourceId2 = typedArrayObtainStyledAttributes.getResourceId(index, this.leftToLeft);
                        this.leftToLeft = resourceId2;
                        if (resourceId2 == -1) {
                            this.leftToLeft = typedArrayObtainStyledAttributes.getInt(index, -1);
                        }
                        break;
                    case 9:
                        int resourceId3 = typedArrayObtainStyledAttributes.getResourceId(index, this.leftToRight);
                        this.leftToRight = resourceId3;
                        if (resourceId3 == -1) {
                            this.leftToRight = typedArrayObtainStyledAttributes.getInt(index, -1);
                        }
                        break;
                    case 10:
                        int resourceId4 = typedArrayObtainStyledAttributes.getResourceId(index, this.rightToLeft);
                        this.rightToLeft = resourceId4;
                        if (resourceId4 == -1) {
                            this.rightToLeft = typedArrayObtainStyledAttributes.getInt(index, -1);
                        }
                        break;
                    case 11:
                        int resourceId5 = typedArrayObtainStyledAttributes.getResourceId(index, this.rightToRight);
                        this.rightToRight = resourceId5;
                        if (resourceId5 == -1) {
                            this.rightToRight = typedArrayObtainStyledAttributes.getInt(index, -1);
                        }
                        break;
                    case 12:
                        int resourceId6 = typedArrayObtainStyledAttributes.getResourceId(index, this.topToTop);
                        this.topToTop = resourceId6;
                        if (resourceId6 == -1) {
                            this.topToTop = typedArrayObtainStyledAttributes.getInt(index, -1);
                        }
                        break;
                    case 13:
                        int resourceId7 = typedArrayObtainStyledAttributes.getResourceId(index, this.topToBottom);
                        this.topToBottom = resourceId7;
                        if (resourceId7 == -1) {
                            this.topToBottom = typedArrayObtainStyledAttributes.getInt(index, -1);
                        }
                        break;
                    case 14:
                        int resourceId8 = typedArrayObtainStyledAttributes.getResourceId(index, this.bottomToTop);
                        this.bottomToTop = resourceId8;
                        if (resourceId8 == -1) {
                            this.bottomToTop = typedArrayObtainStyledAttributes.getInt(index, -1);
                        }
                        break;
                    case 15:
                        int resourceId9 = typedArrayObtainStyledAttributes.getResourceId(index, this.bottomToBottom);
                        this.bottomToBottom = resourceId9;
                        if (resourceId9 == -1) {
                            this.bottomToBottom = typedArrayObtainStyledAttributes.getInt(index, -1);
                        }
                        break;
                    case 16:
                        int resourceId10 = typedArrayObtainStyledAttributes.getResourceId(index, this.baselineToBaseline);
                        this.baselineToBaseline = resourceId10;
                        if (resourceId10 == -1) {
                            this.baselineToBaseline = typedArrayObtainStyledAttributes.getInt(index, -1);
                        }
                        break;
                    case 17:
                        int resourceId11 = typedArrayObtainStyledAttributes.getResourceId(index, this.startToEnd);
                        this.startToEnd = resourceId11;
                        if (resourceId11 == -1) {
                            this.startToEnd = typedArrayObtainStyledAttributes.getInt(index, -1);
                        }
                        break;
                    case 18:
                        int resourceId12 = typedArrayObtainStyledAttributes.getResourceId(index, this.startToStart);
                        this.startToStart = resourceId12;
                        if (resourceId12 == -1) {
                            this.startToStart = typedArrayObtainStyledAttributes.getInt(index, -1);
                        }
                        break;
                    case 19:
                        int resourceId13 = typedArrayObtainStyledAttributes.getResourceId(index, this.endToStart);
                        this.endToStart = resourceId13;
                        if (resourceId13 == -1) {
                            this.endToStart = typedArrayObtainStyledAttributes.getInt(index, -1);
                        }
                        break;
                    case 20:
                        int resourceId14 = typedArrayObtainStyledAttributes.getResourceId(index, this.endToEnd);
                        this.endToEnd = resourceId14;
                        if (resourceId14 == -1) {
                            this.endToEnd = typedArrayObtainStyledAttributes.getInt(index, -1);
                        }
                        break;
                    case 21:
                        this.goneLeftMargin = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.goneLeftMargin);
                        break;
                    case 22:
                        this.goneTopMargin = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.goneTopMargin);
                        break;
                    case 23:
                        this.goneRightMargin = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.goneRightMargin);
                        break;
                    case 24:
                        this.goneBottomMargin = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.goneBottomMargin);
                        break;
                    case 25:
                        this.goneStartMargin = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.goneStartMargin);
                        break;
                    case 26:
                        this.goneEndMargin = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.goneEndMargin);
                        break;
                    case 27:
                        this.constrainedWidth = typedArrayObtainStyledAttributes.getBoolean(index, this.constrainedWidth);
                        break;
                    case 28:
                        this.constrainedHeight = typedArrayObtainStyledAttributes.getBoolean(index, this.constrainedHeight);
                        break;
                    case 29:
                        this.horizontalBias = typedArrayObtainStyledAttributes.getFloat(index, this.horizontalBias);
                        break;
                    case 30:
                        this.verticalBias = typedArrayObtainStyledAttributes.getFloat(index, this.verticalBias);
                        break;
                    case 31:
                        int i13 = typedArrayObtainStyledAttributes.getInt(index, 0);
                        this.matchConstraintDefaultWidth = i13;
                        if (i13 == 1) {
                            Log.e(ConstraintLayout.TAG, "layout_constraintWidth_default=\"wrap\" is deprecated.\nUse layout_width=\"WRAP_CONTENT\" and layout_constrainedWidth=\"true\" instead.");
                        }
                        break;
                    case 32:
                        int i14 = typedArrayObtainStyledAttributes.getInt(index, 0);
                        this.matchConstraintDefaultHeight = i14;
                        if (i14 == 1) {
                            Log.e(ConstraintLayout.TAG, "layout_constraintHeight_default=\"wrap\" is deprecated.\nUse layout_height=\"WRAP_CONTENT\" and layout_constrainedHeight=\"true\" instead.");
                        }
                        break;
                    case 33:
                        try {
                            this.matchConstraintMinWidth = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.matchConstraintMinWidth);
                        } catch (Exception unused) {
                            if (typedArrayObtainStyledAttributes.getInt(index, this.matchConstraintMinWidth) == -2) {
                                this.matchConstraintMinWidth = -2;
                            }
                        }
                        break;
                    case 34:
                        try {
                            this.matchConstraintMaxWidth = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.matchConstraintMaxWidth);
                        } catch (Exception unused2) {
                            if (typedArrayObtainStyledAttributes.getInt(index, this.matchConstraintMaxWidth) == -2) {
                                this.matchConstraintMaxWidth = -2;
                            }
                        }
                        break;
                    case 35:
                        this.matchConstraintPercentWidth = Math.max(0.0f, typedArrayObtainStyledAttributes.getFloat(index, this.matchConstraintPercentWidth));
                        this.matchConstraintDefaultWidth = 2;
                        break;
                    case 36:
                        try {
                            this.matchConstraintMinHeight = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.matchConstraintMinHeight);
                        } catch (Exception unused3) {
                            if (typedArrayObtainStyledAttributes.getInt(index, this.matchConstraintMinHeight) == -2) {
                                this.matchConstraintMinHeight = -2;
                            }
                        }
                        break;
                    case 37:
                        try {
                            this.matchConstraintMaxHeight = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.matchConstraintMaxHeight);
                        } catch (Exception unused4) {
                            if (typedArrayObtainStyledAttributes.getInt(index, this.matchConstraintMaxHeight) == -2) {
                                this.matchConstraintMaxHeight = -2;
                            }
                        }
                        break;
                    case 38:
                        this.matchConstraintPercentHeight = Math.max(0.0f, typedArrayObtainStyledAttributes.getFloat(index, this.matchConstraintPercentHeight));
                        this.matchConstraintDefaultHeight = 2;
                        break;
                    default:
                        switch (i12) {
                            case 44:
                                String string = typedArrayObtainStyledAttributes.getString(index);
                                this.dimensionRatio = string;
                                this.dimensionRatioValue = Float.NaN;
                                this.dimensionRatioSide = -1;
                                if (string != null) {
                                    int length = string.length();
                                    int iIndexOf = this.dimensionRatio.indexOf(44);
                                    if (iIndexOf <= 0 || iIndexOf >= length - 1) {
                                        i10 = 0;
                                    } else {
                                        String strSubstring = this.dimensionRatio.substring(0, iIndexOf);
                                        if (strSubstring.equalsIgnoreCase("W")) {
                                            this.dimensionRatioSide = 0;
                                        } else if (strSubstring.equalsIgnoreCase("H")) {
                                            this.dimensionRatioSide = 1;
                                        }
                                        i10 = iIndexOf + 1;
                                    }
                                    int iIndexOf2 = this.dimensionRatio.indexOf(58);
                                    if (iIndexOf2 >= 0 && iIndexOf2 < length - 1) {
                                        String strSubstring2 = this.dimensionRatio.substring(i10, iIndexOf2);
                                        String strSubstring3 = this.dimensionRatio.substring(iIndexOf2 + 1);
                                        if (strSubstring2.length() > 0 && strSubstring3.length() > 0) {
                                            try {
                                                float f11 = Float.parseFloat(strSubstring2);
                                                float f12 = Float.parseFloat(strSubstring3);
                                                if (f11 > 0.0f && f12 > 0.0f) {
                                                    if (this.dimensionRatioSide == 1) {
                                                        this.dimensionRatioValue = Math.abs(f12 / f11);
                                                    } else {
                                                        this.dimensionRatioValue = Math.abs(f11 / f12);
                                                    }
                                                }
                                            } catch (NumberFormatException unused5) {
                                            }
                                        }
                                    } else {
                                        String strSubstring4 = this.dimensionRatio.substring(i10);
                                        if (strSubstring4.length() > 0) {
                                            this.dimensionRatioValue = Float.parseFloat(strSubstring4);
                                        }
                                    }
                                }
                                break;
                            case 45:
                                this.horizontalWeight = typedArrayObtainStyledAttributes.getFloat(index, this.horizontalWeight);
                                break;
                            case 46:
                                this.verticalWeight = typedArrayObtainStyledAttributes.getFloat(index, this.verticalWeight);
                                break;
                            case 47:
                                this.horizontalChainStyle = typedArrayObtainStyledAttributes.getInt(index, 0);
                                break;
                            case 48:
                                this.verticalChainStyle = typedArrayObtainStyledAttributes.getInt(index, 0);
                                break;
                            case 49:
                                this.editorAbsoluteX = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, this.editorAbsoluteX);
                                break;
                            case 50:
                                this.editorAbsoluteY = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, this.editorAbsoluteY);
                                break;
                            case 51:
                                this.constraintTag = typedArrayObtainStyledAttributes.getString(index);
                                break;
                        }
                        break;
                }
            }
            typedArrayObtainStyledAttributes.recycle();
            validate();
        }

        public LayoutParams(int i10, int i11) {
            super(i10, i11);
            this.guideBegin = -1;
            this.guideEnd = -1;
            this.guidePercent = -1.0f;
            this.leftToLeft = -1;
            this.leftToRight = -1;
            this.rightToLeft = -1;
            this.rightToRight = -1;
            this.topToTop = -1;
            this.topToBottom = -1;
            this.bottomToTop = -1;
            this.bottomToBottom = -1;
            this.baselineToBaseline = -1;
            this.circleConstraint = -1;
            this.circleRadius = 0;
            this.circleAngle = 0.0f;
            this.startToEnd = -1;
            this.startToStart = -1;
            this.endToStart = -1;
            this.endToEnd = -1;
            this.goneLeftMargin = -1;
            this.goneTopMargin = -1;
            this.goneRightMargin = -1;
            this.goneBottomMargin = -1;
            this.goneStartMargin = -1;
            this.goneEndMargin = -1;
            this.horizontalBias = 0.5f;
            this.verticalBias = 0.5f;
            this.dimensionRatio = null;
            this.dimensionRatioValue = 0.0f;
            this.dimensionRatioSide = 1;
            this.horizontalWeight = -1.0f;
            this.verticalWeight = -1.0f;
            this.horizontalChainStyle = 0;
            this.verticalChainStyle = 0;
            this.matchConstraintDefaultWidth = 0;
            this.matchConstraintDefaultHeight = 0;
            this.matchConstraintMinWidth = 0;
            this.matchConstraintMinHeight = 0;
            this.matchConstraintMaxWidth = 0;
            this.matchConstraintMaxHeight = 0;
            this.matchConstraintPercentWidth = 1.0f;
            this.matchConstraintPercentHeight = 1.0f;
            this.editorAbsoluteX = -1;
            this.editorAbsoluteY = -1;
            this.orientation = -1;
            this.constrainedWidth = false;
            this.constrainedHeight = false;
            this.constraintTag = null;
            this.horizontalDimensionFixed = true;
            this.verticalDimensionFixed = true;
            this.needsBaseline = false;
            this.isGuideline = false;
            this.isHelper = false;
            this.isInPlaceholder = false;
            this.isVirtualGroup = false;
            this.resolvedLeftToLeft = -1;
            this.resolvedLeftToRight = -1;
            this.resolvedRightToLeft = -1;
            this.resolvedRightToRight = -1;
            this.resolveGoneLeftMargin = -1;
            this.resolveGoneRightMargin = -1;
            this.resolvedHorizontalBias = 0.5f;
            this.widget = new ConstraintWidget();
            this.helped = false;
        }

        public LayoutParams(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
            this.guideBegin = -1;
            this.guideEnd = -1;
            this.guidePercent = -1.0f;
            this.leftToLeft = -1;
            this.leftToRight = -1;
            this.rightToLeft = -1;
            this.rightToRight = -1;
            this.topToTop = -1;
            this.topToBottom = -1;
            this.bottomToTop = -1;
            this.bottomToBottom = -1;
            this.baselineToBaseline = -1;
            this.circleConstraint = -1;
            this.circleRadius = 0;
            this.circleAngle = 0.0f;
            this.startToEnd = -1;
            this.startToStart = -1;
            this.endToStart = -1;
            this.endToEnd = -1;
            this.goneLeftMargin = -1;
            this.goneTopMargin = -1;
            this.goneRightMargin = -1;
            this.goneBottomMargin = -1;
            this.goneStartMargin = -1;
            this.goneEndMargin = -1;
            this.horizontalBias = 0.5f;
            this.verticalBias = 0.5f;
            this.dimensionRatio = null;
            this.dimensionRatioValue = 0.0f;
            this.dimensionRatioSide = 1;
            this.horizontalWeight = -1.0f;
            this.verticalWeight = -1.0f;
            this.horizontalChainStyle = 0;
            this.verticalChainStyle = 0;
            this.matchConstraintDefaultWidth = 0;
            this.matchConstraintDefaultHeight = 0;
            this.matchConstraintMinWidth = 0;
            this.matchConstraintMinHeight = 0;
            this.matchConstraintMaxWidth = 0;
            this.matchConstraintMaxHeight = 0;
            this.matchConstraintPercentWidth = 1.0f;
            this.matchConstraintPercentHeight = 1.0f;
            this.editorAbsoluteX = -1;
            this.editorAbsoluteY = -1;
            this.orientation = -1;
            this.constrainedWidth = false;
            this.constrainedHeight = false;
            this.constraintTag = null;
            this.horizontalDimensionFixed = true;
            this.verticalDimensionFixed = true;
            this.needsBaseline = false;
            this.isGuideline = false;
            this.isHelper = false;
            this.isInPlaceholder = false;
            this.isVirtualGroup = false;
            this.resolvedLeftToLeft = -1;
            this.resolvedLeftToRight = -1;
            this.resolvedRightToLeft = -1;
            this.resolvedRightToRight = -1;
            this.resolveGoneLeftMargin = -1;
            this.resolveGoneRightMargin = -1;
            this.resolvedHorizontalBias = 0.5f;
            this.widget = new ConstraintWidget();
            this.helped = false;
        }
    }
}
