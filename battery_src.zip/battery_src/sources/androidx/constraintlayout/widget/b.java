package androidx.constraintlayout.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.util.SparseIntArray;
import android.util.Xml;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.constraintlayout.solver.widgets.ConstraintWidget;
import com.oplus.sceneservice.sdk.dataprovider.bean.UserProfileInfo;
import com.oplus.smartenginehelper.entity.TextEntity;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

/* JADX INFO: compiled from: ConstraintSet.java */
/* JADX INFO: loaded from: classes.dex */
public class b {

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private static final int[] f2003e = {0, 4, 8};

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private static SparseIntArray f2004f;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private boolean f2005a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private HashMap<String, ConstraintAttribute> f2006b = new HashMap<>();

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private boolean f2007c = true;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private HashMap<Integer, a> f2008d = new HashMap<>();

    /* JADX INFO: compiled from: ConstraintSet.java */
    public static class a {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        int f2009a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public final d f2010b = new d();

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        public final c f2011c = new c();

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        public final C0009b f2012d = new C0009b();

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        public final e f2013e = new e();

        /* JADX INFO: renamed from: f, reason: collision with root package name */
        public HashMap<String, ConstraintAttribute> f2014f = new HashMap<>();

        /* JADX INFO: Access modifiers changed from: private */
        public void f(int i10, ConstraintLayout.LayoutParams layoutParams) {
            this.f2009a = i10;
            C0009b c0009b = this.f2012d;
            c0009b.f2030h = layoutParams.leftToLeft;
            c0009b.f2032i = layoutParams.leftToRight;
            c0009b.f2034j = layoutParams.rightToLeft;
            c0009b.f2036k = layoutParams.rightToRight;
            c0009b.f2037l = layoutParams.topToTop;
            c0009b.f2038m = layoutParams.topToBottom;
            c0009b.f2039n = layoutParams.bottomToTop;
            c0009b.f2040o = layoutParams.bottomToBottom;
            c0009b.f2041p = layoutParams.baselineToBaseline;
            c0009b.f2042q = layoutParams.startToEnd;
            c0009b.f2043r = layoutParams.startToStart;
            c0009b.f2044s = layoutParams.endToStart;
            c0009b.f2045t = layoutParams.endToEnd;
            c0009b.f2046u = layoutParams.horizontalBias;
            c0009b.f2047v = layoutParams.verticalBias;
            c0009b.f2048w = layoutParams.dimensionRatio;
            c0009b.f2049x = layoutParams.circleConstraint;
            c0009b.f2050y = layoutParams.circleRadius;
            c0009b.f2051z = layoutParams.circleAngle;
            c0009b.A = layoutParams.editorAbsoluteX;
            c0009b.B = layoutParams.editorAbsoluteY;
            c0009b.C = layoutParams.orientation;
            c0009b.f2028g = layoutParams.guidePercent;
            c0009b.f2024e = layoutParams.guideBegin;
            c0009b.f2026f = layoutParams.guideEnd;
            c0009b.f2020c = ((ViewGroup.MarginLayoutParams) layoutParams).width;
            c0009b.f2022d = ((ViewGroup.MarginLayoutParams) layoutParams).height;
            c0009b.D = ((ViewGroup.MarginLayoutParams) layoutParams).leftMargin;
            c0009b.E = ((ViewGroup.MarginLayoutParams) layoutParams).rightMargin;
            c0009b.F = ((ViewGroup.MarginLayoutParams) layoutParams).topMargin;
            c0009b.G = ((ViewGroup.MarginLayoutParams) layoutParams).bottomMargin;
            c0009b.P = layoutParams.verticalWeight;
            c0009b.Q = layoutParams.horizontalWeight;
            c0009b.S = layoutParams.verticalChainStyle;
            c0009b.R = layoutParams.horizontalChainStyle;
            c0009b.f2031h0 = layoutParams.constrainedWidth;
            c0009b.f2033i0 = layoutParams.constrainedHeight;
            c0009b.T = layoutParams.matchConstraintDefaultWidth;
            c0009b.U = layoutParams.matchConstraintDefaultHeight;
            c0009b.V = layoutParams.matchConstraintMaxWidth;
            c0009b.W = layoutParams.matchConstraintMaxHeight;
            c0009b.X = layoutParams.matchConstraintMinWidth;
            c0009b.Y = layoutParams.matchConstraintMinHeight;
            c0009b.Z = layoutParams.matchConstraintPercentWidth;
            c0009b.f2017a0 = layoutParams.matchConstraintPercentHeight;
            c0009b.f2029g0 = layoutParams.constraintTag;
            c0009b.K = layoutParams.goneTopMargin;
            c0009b.M = layoutParams.goneBottomMargin;
            c0009b.J = layoutParams.goneLeftMargin;
            c0009b.L = layoutParams.goneRightMargin;
            c0009b.O = layoutParams.goneStartMargin;
            c0009b.N = layoutParams.goneEndMargin;
            c0009b.H = layoutParams.getMarginEnd();
            this.f2012d.I = layoutParams.getMarginStart();
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void g(int i10, Constraints.LayoutParams layoutParams) {
            f(i10, layoutParams);
            this.f2010b.f2063d = layoutParams.f1969a;
            e eVar = this.f2013e;
            eVar.f2067b = layoutParams.f1972d;
            eVar.f2068c = layoutParams.f1973e;
            eVar.f2069d = layoutParams.f1974f;
            eVar.f2070e = layoutParams.f1975g;
            eVar.f2071f = layoutParams.f1976h;
            eVar.f2072g = layoutParams.f1977i;
            eVar.f2073h = layoutParams.f1978j;
            eVar.f2074i = layoutParams.f1979k;
            eVar.f2075j = layoutParams.f1980l;
            eVar.f2076k = layoutParams.f1981m;
            eVar.f2078m = layoutParams.f1971c;
            eVar.f2077l = layoutParams.f1970b;
        }

        /* JADX INFO: Access modifiers changed from: private */
        public void h(ConstraintHelper constraintHelper, int i10, Constraints.LayoutParams layoutParams) {
            g(i10, layoutParams);
            if (constraintHelper instanceof Barrier) {
                C0009b c0009b = this.f2012d;
                c0009b.f2023d0 = 1;
                Barrier barrier = (Barrier) constraintHelper;
                c0009b.f2019b0 = barrier.getType();
                this.f2012d.f2025e0 = barrier.getReferencedIds();
                this.f2012d.f2021c0 = barrier.getMargin();
            }
        }

        public void d(ConstraintLayout.LayoutParams layoutParams) {
            C0009b c0009b = this.f2012d;
            layoutParams.leftToLeft = c0009b.f2030h;
            layoutParams.leftToRight = c0009b.f2032i;
            layoutParams.rightToLeft = c0009b.f2034j;
            layoutParams.rightToRight = c0009b.f2036k;
            layoutParams.topToTop = c0009b.f2037l;
            layoutParams.topToBottom = c0009b.f2038m;
            layoutParams.bottomToTop = c0009b.f2039n;
            layoutParams.bottomToBottom = c0009b.f2040o;
            layoutParams.baselineToBaseline = c0009b.f2041p;
            layoutParams.startToEnd = c0009b.f2042q;
            layoutParams.startToStart = c0009b.f2043r;
            layoutParams.endToStart = c0009b.f2044s;
            layoutParams.endToEnd = c0009b.f2045t;
            ((ViewGroup.MarginLayoutParams) layoutParams).leftMargin = c0009b.D;
            ((ViewGroup.MarginLayoutParams) layoutParams).rightMargin = c0009b.E;
            ((ViewGroup.MarginLayoutParams) layoutParams).topMargin = c0009b.F;
            ((ViewGroup.MarginLayoutParams) layoutParams).bottomMargin = c0009b.G;
            layoutParams.goneStartMargin = c0009b.O;
            layoutParams.goneEndMargin = c0009b.N;
            layoutParams.goneTopMargin = c0009b.K;
            layoutParams.goneBottomMargin = c0009b.M;
            layoutParams.horizontalBias = c0009b.f2046u;
            layoutParams.verticalBias = c0009b.f2047v;
            layoutParams.circleConstraint = c0009b.f2049x;
            layoutParams.circleRadius = c0009b.f2050y;
            layoutParams.circleAngle = c0009b.f2051z;
            layoutParams.dimensionRatio = c0009b.f2048w;
            layoutParams.editorAbsoluteX = c0009b.A;
            layoutParams.editorAbsoluteY = c0009b.B;
            layoutParams.verticalWeight = c0009b.P;
            layoutParams.horizontalWeight = c0009b.Q;
            layoutParams.verticalChainStyle = c0009b.S;
            layoutParams.horizontalChainStyle = c0009b.R;
            layoutParams.constrainedWidth = c0009b.f2031h0;
            layoutParams.constrainedHeight = c0009b.f2033i0;
            layoutParams.matchConstraintDefaultWidth = c0009b.T;
            layoutParams.matchConstraintDefaultHeight = c0009b.U;
            layoutParams.matchConstraintMaxWidth = c0009b.V;
            layoutParams.matchConstraintMaxHeight = c0009b.W;
            layoutParams.matchConstraintMinWidth = c0009b.X;
            layoutParams.matchConstraintMinHeight = c0009b.Y;
            layoutParams.matchConstraintPercentWidth = c0009b.Z;
            layoutParams.matchConstraintPercentHeight = c0009b.f2017a0;
            layoutParams.orientation = c0009b.C;
            layoutParams.guidePercent = c0009b.f2028g;
            layoutParams.guideBegin = c0009b.f2024e;
            layoutParams.guideEnd = c0009b.f2026f;
            ((ViewGroup.MarginLayoutParams) layoutParams).width = c0009b.f2020c;
            ((ViewGroup.MarginLayoutParams) layoutParams).height = c0009b.f2022d;
            String str = c0009b.f2029g0;
            if (str != null) {
                layoutParams.constraintTag = str;
            }
            layoutParams.setMarginStart(c0009b.I);
            layoutParams.setMarginEnd(this.f2012d.H);
            layoutParams.validate();
        }

        /* JADX INFO: renamed from: e, reason: merged with bridge method [inline-methods] */
        public a clone() {
            a aVar = new a();
            aVar.f2012d.a(this.f2012d);
            aVar.f2011c.a(this.f2011c);
            aVar.f2010b.a(this.f2010b);
            aVar.f2013e.a(this.f2013e);
            aVar.f2009a = this.f2009a;
            return aVar;
        }
    }

    /* JADX INFO: renamed from: androidx.constraintlayout.widget.b$b, reason: collision with other inner class name */
    /* JADX INFO: compiled from: ConstraintSet.java */
    public static class C0009b {

        /* JADX INFO: renamed from: k0, reason: collision with root package name */
        private static SparseIntArray f2015k0;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        public int f2020c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        public int f2022d;

        /* JADX INFO: renamed from: e0, reason: collision with root package name */
        public int[] f2025e0;

        /* JADX INFO: renamed from: f0, reason: collision with root package name */
        public String f2027f0;

        /* JADX INFO: renamed from: g0, reason: collision with root package name */
        public String f2029g0;

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public boolean f2016a = false;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public boolean f2018b = false;

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        public int f2024e = -1;

        /* JADX INFO: renamed from: f, reason: collision with root package name */
        public int f2026f = -1;

        /* JADX INFO: renamed from: g, reason: collision with root package name */
        public float f2028g = -1.0f;

        /* JADX INFO: renamed from: h, reason: collision with root package name */
        public int f2030h = -1;

        /* JADX INFO: renamed from: i, reason: collision with root package name */
        public int f2032i = -1;

        /* JADX INFO: renamed from: j, reason: collision with root package name */
        public int f2034j = -1;

        /* JADX INFO: renamed from: k, reason: collision with root package name */
        public int f2036k = -1;

        /* JADX INFO: renamed from: l, reason: collision with root package name */
        public int f2037l = -1;

        /* JADX INFO: renamed from: m, reason: collision with root package name */
        public int f2038m = -1;

        /* JADX INFO: renamed from: n, reason: collision with root package name */
        public int f2039n = -1;

        /* JADX INFO: renamed from: o, reason: collision with root package name */
        public int f2040o = -1;

        /* JADX INFO: renamed from: p, reason: collision with root package name */
        public int f2041p = -1;

        /* JADX INFO: renamed from: q, reason: collision with root package name */
        public int f2042q = -1;

        /* JADX INFO: renamed from: r, reason: collision with root package name */
        public int f2043r = -1;

        /* JADX INFO: renamed from: s, reason: collision with root package name */
        public int f2044s = -1;

        /* JADX INFO: renamed from: t, reason: collision with root package name */
        public int f2045t = -1;

        /* JADX INFO: renamed from: u, reason: collision with root package name */
        public float f2046u = 0.5f;

        /* JADX INFO: renamed from: v, reason: collision with root package name */
        public float f2047v = 0.5f;

        /* JADX INFO: renamed from: w, reason: collision with root package name */
        public String f2048w = null;

        /* JADX INFO: renamed from: x, reason: collision with root package name */
        public int f2049x = -1;

        /* JADX INFO: renamed from: y, reason: collision with root package name */
        public int f2050y = 0;

        /* JADX INFO: renamed from: z, reason: collision with root package name */
        public float f2051z = 0.0f;
        public int A = -1;
        public int B = -1;
        public int C = -1;
        public int D = -1;
        public int E = -1;
        public int F = -1;
        public int G = -1;
        public int H = -1;
        public int I = -1;
        public int J = -1;
        public int K = -1;
        public int L = -1;
        public int M = -1;
        public int N = -1;
        public int O = -1;
        public float P = -1.0f;
        public float Q = -1.0f;
        public int R = 0;
        public int S = 0;
        public int T = 0;
        public int U = 0;
        public int V = -1;
        public int W = -1;
        public int X = -1;
        public int Y = -1;
        public float Z = 1.0f;

        /* JADX INFO: renamed from: a0, reason: collision with root package name */
        public float f2017a0 = 1.0f;

        /* JADX INFO: renamed from: b0, reason: collision with root package name */
        public int f2019b0 = -1;

        /* JADX INFO: renamed from: c0, reason: collision with root package name */
        public int f2021c0 = 0;

        /* JADX INFO: renamed from: d0, reason: collision with root package name */
        public int f2023d0 = -1;

        /* JADX INFO: renamed from: h0, reason: collision with root package name */
        public boolean f2031h0 = false;

        /* JADX INFO: renamed from: i0, reason: collision with root package name */
        public boolean f2033i0 = false;

        /* JADX INFO: renamed from: j0, reason: collision with root package name */
        public boolean f2035j0 = true;

        static {
            SparseIntArray sparseIntArray = new SparseIntArray();
            f2015k0 = sparseIntArray;
            sparseIntArray.append(R$styleable.Layout_layout_constraintLeft_toLeftOf, 24);
            f2015k0.append(R$styleable.Layout_layout_constraintLeft_toRightOf, 25);
            f2015k0.append(R$styleable.Layout_layout_constraintRight_toLeftOf, 28);
            f2015k0.append(R$styleable.Layout_layout_constraintRight_toRightOf, 29);
            f2015k0.append(R$styleable.Layout_layout_constraintTop_toTopOf, 35);
            f2015k0.append(R$styleable.Layout_layout_constraintTop_toBottomOf, 34);
            f2015k0.append(R$styleable.Layout_layout_constraintBottom_toTopOf, 4);
            f2015k0.append(R$styleable.Layout_layout_constraintBottom_toBottomOf, 3);
            f2015k0.append(R$styleable.Layout_layout_constraintBaseline_toBaselineOf, 1);
            f2015k0.append(R$styleable.Layout_layout_editor_absoluteX, 6);
            f2015k0.append(R$styleable.Layout_layout_editor_absoluteY, 7);
            f2015k0.append(R$styleable.Layout_layout_constraintGuide_begin, 17);
            f2015k0.append(R$styleable.Layout_layout_constraintGuide_end, 18);
            f2015k0.append(R$styleable.Layout_layout_constraintGuide_percent, 19);
            f2015k0.append(R$styleable.Layout_android_orientation, 26);
            f2015k0.append(R$styleable.Layout_layout_constraintStart_toEndOf, 31);
            f2015k0.append(R$styleable.Layout_layout_constraintStart_toStartOf, 32);
            f2015k0.append(R$styleable.Layout_layout_constraintEnd_toStartOf, 10);
            f2015k0.append(R$styleable.Layout_layout_constraintEnd_toEndOf, 9);
            f2015k0.append(R$styleable.Layout_layout_goneMarginLeft, 13);
            f2015k0.append(R$styleable.Layout_layout_goneMarginTop, 16);
            f2015k0.append(R$styleable.Layout_layout_goneMarginRight, 14);
            f2015k0.append(R$styleable.Layout_layout_goneMarginBottom, 11);
            f2015k0.append(R$styleable.Layout_layout_goneMarginStart, 15);
            f2015k0.append(R$styleable.Layout_layout_goneMarginEnd, 12);
            f2015k0.append(R$styleable.Layout_layout_constraintVertical_weight, 38);
            f2015k0.append(R$styleable.Layout_layout_constraintHorizontal_weight, 37);
            f2015k0.append(R$styleable.Layout_layout_constraintHorizontal_chainStyle, 39);
            f2015k0.append(R$styleable.Layout_layout_constraintVertical_chainStyle, 40);
            f2015k0.append(R$styleable.Layout_layout_constraintHorizontal_bias, 20);
            f2015k0.append(R$styleable.Layout_layout_constraintVertical_bias, 36);
            f2015k0.append(R$styleable.Layout_layout_constraintDimensionRatio, 5);
            f2015k0.append(R$styleable.Layout_layout_constraintLeft_creator, 76);
            f2015k0.append(R$styleable.Layout_layout_constraintTop_creator, 76);
            f2015k0.append(R$styleable.Layout_layout_constraintRight_creator, 76);
            f2015k0.append(R$styleable.Layout_layout_constraintBottom_creator, 76);
            f2015k0.append(R$styleable.Layout_layout_constraintBaseline_creator, 76);
            f2015k0.append(R$styleable.Layout_android_layout_marginLeft, 23);
            f2015k0.append(R$styleable.Layout_android_layout_marginRight, 27);
            f2015k0.append(R$styleable.Layout_android_layout_marginStart, 30);
            f2015k0.append(R$styleable.Layout_android_layout_marginEnd, 8);
            f2015k0.append(R$styleable.Layout_android_layout_marginTop, 33);
            f2015k0.append(R$styleable.Layout_android_layout_marginBottom, 2);
            f2015k0.append(R$styleable.Layout_android_layout_width, 22);
            f2015k0.append(R$styleable.Layout_android_layout_height, 21);
            f2015k0.append(R$styleable.Layout_layout_constraintCircle, 61);
            f2015k0.append(R$styleable.Layout_layout_constraintCircleRadius, 62);
            f2015k0.append(R$styleable.Layout_layout_constraintCircleAngle, 63);
            f2015k0.append(R$styleable.Layout_layout_constraintWidth_percent, 69);
            f2015k0.append(R$styleable.Layout_layout_constraintHeight_percent, 70);
            f2015k0.append(R$styleable.Layout_chainUseRtl, 71);
            f2015k0.append(R$styleable.Layout_barrierDirection, 72);
            f2015k0.append(R$styleable.Layout_barrierMargin, 73);
            f2015k0.append(R$styleable.Layout_constraint_referenced_ids, 74);
            f2015k0.append(R$styleable.Layout_barrierAllowsGoneWidgets, 75);
        }

        public void a(C0009b c0009b) {
            this.f2016a = c0009b.f2016a;
            this.f2020c = c0009b.f2020c;
            this.f2018b = c0009b.f2018b;
            this.f2022d = c0009b.f2022d;
            this.f2024e = c0009b.f2024e;
            this.f2026f = c0009b.f2026f;
            this.f2028g = c0009b.f2028g;
            this.f2030h = c0009b.f2030h;
            this.f2032i = c0009b.f2032i;
            this.f2034j = c0009b.f2034j;
            this.f2036k = c0009b.f2036k;
            this.f2037l = c0009b.f2037l;
            this.f2038m = c0009b.f2038m;
            this.f2039n = c0009b.f2039n;
            this.f2040o = c0009b.f2040o;
            this.f2041p = c0009b.f2041p;
            this.f2042q = c0009b.f2042q;
            this.f2043r = c0009b.f2043r;
            this.f2044s = c0009b.f2044s;
            this.f2045t = c0009b.f2045t;
            this.f2046u = c0009b.f2046u;
            this.f2047v = c0009b.f2047v;
            this.f2048w = c0009b.f2048w;
            this.f2049x = c0009b.f2049x;
            this.f2050y = c0009b.f2050y;
            this.f2051z = c0009b.f2051z;
            this.A = c0009b.A;
            this.B = c0009b.B;
            this.C = c0009b.C;
            this.D = c0009b.D;
            this.E = c0009b.E;
            this.F = c0009b.F;
            this.G = c0009b.G;
            this.H = c0009b.H;
            this.I = c0009b.I;
            this.J = c0009b.J;
            this.K = c0009b.K;
            this.L = c0009b.L;
            this.M = c0009b.M;
            this.N = c0009b.N;
            this.O = c0009b.O;
            this.P = c0009b.P;
            this.Q = c0009b.Q;
            this.R = c0009b.R;
            this.S = c0009b.S;
            this.T = c0009b.T;
            this.U = c0009b.U;
            this.V = c0009b.V;
            this.W = c0009b.W;
            this.X = c0009b.X;
            this.Y = c0009b.Y;
            this.Z = c0009b.Z;
            this.f2017a0 = c0009b.f2017a0;
            this.f2019b0 = c0009b.f2019b0;
            this.f2021c0 = c0009b.f2021c0;
            this.f2023d0 = c0009b.f2023d0;
            this.f2029g0 = c0009b.f2029g0;
            int[] iArr = c0009b.f2025e0;
            if (iArr != null) {
                this.f2025e0 = Arrays.copyOf(iArr, iArr.length);
            } else {
                this.f2025e0 = null;
            }
            this.f2027f0 = c0009b.f2027f0;
            this.f2031h0 = c0009b.f2031h0;
            this.f2033i0 = c0009b.f2033i0;
            this.f2035j0 = c0009b.f2035j0;
        }

        void b(Context context, AttributeSet attributeSet) {
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R$styleable.Layout);
            this.f2018b = true;
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            for (int i10 = 0; i10 < indexCount; i10++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i10);
                int i11 = f2015k0.get(index);
                if (i11 == 80) {
                    this.f2031h0 = typedArrayObtainStyledAttributes.getBoolean(index, this.f2031h0);
                } else if (i11 != 81) {
                    switch (i11) {
                        case 1:
                            this.f2041p = b.y(typedArrayObtainStyledAttributes, index, this.f2041p);
                            break;
                        case 2:
                            this.G = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.G);
                            break;
                        case 3:
                            this.f2040o = b.y(typedArrayObtainStyledAttributes, index, this.f2040o);
                            break;
                        case 4:
                            this.f2039n = b.y(typedArrayObtainStyledAttributes, index, this.f2039n);
                            break;
                        case 5:
                            this.f2048w = typedArrayObtainStyledAttributes.getString(index);
                            break;
                        case 6:
                            this.A = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, this.A);
                            break;
                        case 7:
                            this.B = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, this.B);
                            break;
                        case 8:
                            this.H = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.H);
                            break;
                        case 9:
                            this.f2045t = b.y(typedArrayObtainStyledAttributes, index, this.f2045t);
                            break;
                        case 10:
                            this.f2044s = b.y(typedArrayObtainStyledAttributes, index, this.f2044s);
                            break;
                        case 11:
                            this.M = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.M);
                            break;
                        case 12:
                            this.N = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.N);
                            break;
                        case 13:
                            this.J = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.J);
                            break;
                        case 14:
                            this.L = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.L);
                            break;
                        case 15:
                            this.O = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.O);
                            break;
                        case 16:
                            this.K = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.K);
                            break;
                        case 17:
                            this.f2024e = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, this.f2024e);
                            break;
                        case 18:
                            this.f2026f = typedArrayObtainStyledAttributes.getDimensionPixelOffset(index, this.f2026f);
                            break;
                        case 19:
                            this.f2028g = typedArrayObtainStyledAttributes.getFloat(index, this.f2028g);
                            break;
                        case 20:
                            this.f2046u = typedArrayObtainStyledAttributes.getFloat(index, this.f2046u);
                            break;
                        case 21:
                            this.f2022d = typedArrayObtainStyledAttributes.getLayoutDimension(index, this.f2022d);
                            break;
                        case 22:
                            this.f2020c = typedArrayObtainStyledAttributes.getLayoutDimension(index, this.f2020c);
                            break;
                        case 23:
                            this.D = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.D);
                            break;
                        case 24:
                            this.f2030h = b.y(typedArrayObtainStyledAttributes, index, this.f2030h);
                            break;
                        case 25:
                            this.f2032i = b.y(typedArrayObtainStyledAttributes, index, this.f2032i);
                            break;
                        case 26:
                            this.C = typedArrayObtainStyledAttributes.getInt(index, this.C);
                            break;
                        case 27:
                            this.E = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.E);
                            break;
                        case 28:
                            this.f2034j = b.y(typedArrayObtainStyledAttributes, index, this.f2034j);
                            break;
                        case 29:
                            this.f2036k = b.y(typedArrayObtainStyledAttributes, index, this.f2036k);
                            break;
                        case 30:
                            this.I = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.I);
                            break;
                        case 31:
                            this.f2042q = b.y(typedArrayObtainStyledAttributes, index, this.f2042q);
                            break;
                        case 32:
                            this.f2043r = b.y(typedArrayObtainStyledAttributes, index, this.f2043r);
                            break;
                        case 33:
                            this.F = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.F);
                            break;
                        case 34:
                            this.f2038m = b.y(typedArrayObtainStyledAttributes, index, this.f2038m);
                            break;
                        case 35:
                            this.f2037l = b.y(typedArrayObtainStyledAttributes, index, this.f2037l);
                            break;
                        case 36:
                            this.f2047v = typedArrayObtainStyledAttributes.getFloat(index, this.f2047v);
                            break;
                        case 37:
                            this.Q = typedArrayObtainStyledAttributes.getFloat(index, this.Q);
                            break;
                        case 38:
                            this.P = typedArrayObtainStyledAttributes.getFloat(index, this.P);
                            break;
                        case 39:
                            this.R = typedArrayObtainStyledAttributes.getInt(index, this.R);
                            break;
                        case 40:
                            this.S = typedArrayObtainStyledAttributes.getInt(index, this.S);
                            break;
                        default:
                            switch (i11) {
                                case 54:
                                    this.T = typedArrayObtainStyledAttributes.getInt(index, this.T);
                                    break;
                                case 55:
                                    this.U = typedArrayObtainStyledAttributes.getInt(index, this.U);
                                    break;
                                case 56:
                                    this.V = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.V);
                                    break;
                                case 57:
                                    this.W = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.W);
                                    break;
                                case 58:
                                    this.X = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.X);
                                    break;
                                case 59:
                                    this.Y = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.Y);
                                    break;
                                default:
                                    switch (i11) {
                                        case 61:
                                            this.f2049x = b.y(typedArrayObtainStyledAttributes, index, this.f2049x);
                                            break;
                                        case 62:
                                            this.f2050y = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.f2050y);
                                            break;
                                        case 63:
                                            this.f2051z = typedArrayObtainStyledAttributes.getFloat(index, this.f2051z);
                                            break;
                                        default:
                                            switch (i11) {
                                                case 69:
                                                    this.Z = typedArrayObtainStyledAttributes.getFloat(index, 1.0f);
                                                    break;
                                                case 70:
                                                    this.f2017a0 = typedArrayObtainStyledAttributes.getFloat(index, 1.0f);
                                                    break;
                                                case 71:
                                                    Log.e("ConstraintSet", "CURRENTLY UNSUPPORTED");
                                                    break;
                                                case 72:
                                                    this.f2019b0 = typedArrayObtainStyledAttributes.getInt(index, this.f2019b0);
                                                    break;
                                                case 73:
                                                    this.f2021c0 = typedArrayObtainStyledAttributes.getDimensionPixelSize(index, this.f2021c0);
                                                    break;
                                                case 74:
                                                    this.f2027f0 = typedArrayObtainStyledAttributes.getString(index);
                                                    break;
                                                case 75:
                                                    this.f2035j0 = typedArrayObtainStyledAttributes.getBoolean(index, this.f2035j0);
                                                    break;
                                                case 76:
                                                    Log.w("ConstraintSet", "unused attribute 0x" + Integer.toHexString(index) + "   " + f2015k0.get(index));
                                                    break;
                                                case 77:
                                                    this.f2029g0 = typedArrayObtainStyledAttributes.getString(index);
                                                    break;
                                                default:
                                                    Log.w("ConstraintSet", "Unknown attribute 0x" + Integer.toHexString(index) + "   " + f2015k0.get(index));
                                                    break;
                                            }
                                            break;
                                    }
                                    break;
                            }
                            break;
                    }
                } else {
                    this.f2033i0 = typedArrayObtainStyledAttributes.getBoolean(index, this.f2033i0);
                }
            }
            typedArrayObtainStyledAttributes.recycle();
        }
    }

    /* JADX INFO: compiled from: ConstraintSet.java */
    public static class c {

        /* JADX INFO: renamed from: h, reason: collision with root package name */
        private static SparseIntArray f2052h;

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public boolean f2053a = false;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public int f2054b = -1;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        public String f2055c = null;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        public int f2056d = -1;

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        public int f2057e = 0;

        /* JADX INFO: renamed from: f, reason: collision with root package name */
        public float f2058f = Float.NaN;

        /* JADX INFO: renamed from: g, reason: collision with root package name */
        public float f2059g = Float.NaN;

        static {
            SparseIntArray sparseIntArray = new SparseIntArray();
            f2052h = sparseIntArray;
            sparseIntArray.append(R$styleable.Motion_motionPathRotate, 1);
            f2052h.append(R$styleable.Motion_pathMotionArc, 2);
            f2052h.append(R$styleable.Motion_transitionEasing, 3);
            f2052h.append(R$styleable.Motion_drawPath, 4);
            f2052h.append(R$styleable.Motion_animate_relativeTo, 5);
            f2052h.append(R$styleable.Motion_motionStagger, 6);
        }

        public void a(c cVar) {
            this.f2053a = cVar.f2053a;
            this.f2054b = cVar.f2054b;
            this.f2055c = cVar.f2055c;
            this.f2056d = cVar.f2056d;
            this.f2057e = cVar.f2057e;
            this.f2059g = cVar.f2059g;
            this.f2058f = cVar.f2058f;
        }

        void b(Context context, AttributeSet attributeSet) {
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R$styleable.Motion);
            this.f2053a = true;
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            for (int i10 = 0; i10 < indexCount; i10++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i10);
                switch (f2052h.get(index)) {
                    case 1:
                        this.f2059g = typedArrayObtainStyledAttributes.getFloat(index, this.f2059g);
                        break;
                    case 2:
                        this.f2056d = typedArrayObtainStyledAttributes.getInt(index, this.f2056d);
                        break;
                    case 3:
                        if (typedArrayObtainStyledAttributes.peekValue(index).type == 3) {
                            this.f2055c = typedArrayObtainStyledAttributes.getString(index);
                        } else {
                            this.f2055c = s.c.f16717c[typedArrayObtainStyledAttributes.getInteger(index, 0)];
                        }
                        break;
                    case 4:
                        this.f2057e = typedArrayObtainStyledAttributes.getInt(index, 0);
                        break;
                    case 5:
                        this.f2054b = b.y(typedArrayObtainStyledAttributes, index, this.f2054b);
                        break;
                    case 6:
                        this.f2058f = typedArrayObtainStyledAttributes.getFloat(index, this.f2058f);
                        break;
                }
            }
            typedArrayObtainStyledAttributes.recycle();
        }
    }

    /* JADX INFO: compiled from: ConstraintSet.java */
    public static class d {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public boolean f2060a = false;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public int f2061b = 0;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        public int f2062c = 0;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        public float f2063d = 1.0f;

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        public float f2064e = Float.NaN;

        public void a(d dVar) {
            this.f2060a = dVar.f2060a;
            this.f2061b = dVar.f2061b;
            this.f2063d = dVar.f2063d;
            this.f2064e = dVar.f2064e;
            this.f2062c = dVar.f2062c;
        }

        void b(Context context, AttributeSet attributeSet) {
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R$styleable.PropertySet);
            this.f2060a = true;
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            for (int i10 = 0; i10 < indexCount; i10++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i10);
                if (index == R$styleable.PropertySet_android_alpha) {
                    this.f2063d = typedArrayObtainStyledAttributes.getFloat(index, this.f2063d);
                } else if (index == R$styleable.PropertySet_android_visibility) {
                    this.f2061b = typedArrayObtainStyledAttributes.getInt(index, this.f2061b);
                    this.f2061b = b.f2003e[this.f2061b];
                } else if (index == R$styleable.PropertySet_visibilityMode) {
                    this.f2062c = typedArrayObtainStyledAttributes.getInt(index, this.f2062c);
                } else if (index == R$styleable.PropertySet_motionProgress) {
                    this.f2064e = typedArrayObtainStyledAttributes.getFloat(index, this.f2064e);
                }
            }
            typedArrayObtainStyledAttributes.recycle();
        }
    }

    /* JADX INFO: compiled from: ConstraintSet.java */
    public static class e {

        /* JADX INFO: renamed from: n, reason: collision with root package name */
        private static SparseIntArray f2065n;

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        public boolean f2066a = false;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        public float f2067b = 0.0f;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        public float f2068c = 0.0f;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        public float f2069d = 0.0f;

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        public float f2070e = 1.0f;

        /* JADX INFO: renamed from: f, reason: collision with root package name */
        public float f2071f = 1.0f;

        /* JADX INFO: renamed from: g, reason: collision with root package name */
        public float f2072g = Float.NaN;

        /* JADX INFO: renamed from: h, reason: collision with root package name */
        public float f2073h = Float.NaN;

        /* JADX INFO: renamed from: i, reason: collision with root package name */
        public float f2074i = 0.0f;

        /* JADX INFO: renamed from: j, reason: collision with root package name */
        public float f2075j = 0.0f;

        /* JADX INFO: renamed from: k, reason: collision with root package name */
        public float f2076k = 0.0f;

        /* JADX INFO: renamed from: l, reason: collision with root package name */
        public boolean f2077l = false;

        /* JADX INFO: renamed from: m, reason: collision with root package name */
        public float f2078m = 0.0f;

        static {
            SparseIntArray sparseIntArray = new SparseIntArray();
            f2065n = sparseIntArray;
            sparseIntArray.append(R$styleable.Transform_android_rotation, 1);
            f2065n.append(R$styleable.Transform_android_rotationX, 2);
            f2065n.append(R$styleable.Transform_android_rotationY, 3);
            f2065n.append(R$styleable.Transform_android_scaleX, 4);
            f2065n.append(R$styleable.Transform_android_scaleY, 5);
            f2065n.append(R$styleable.Transform_android_transformPivotX, 6);
            f2065n.append(R$styleable.Transform_android_transformPivotY, 7);
            f2065n.append(R$styleable.Transform_android_translationX, 8);
            f2065n.append(R$styleable.Transform_android_translationY, 9);
            f2065n.append(R$styleable.Transform_android_translationZ, 10);
            f2065n.append(R$styleable.Transform_android_elevation, 11);
        }

        public void a(e eVar) {
            this.f2066a = eVar.f2066a;
            this.f2067b = eVar.f2067b;
            this.f2068c = eVar.f2068c;
            this.f2069d = eVar.f2069d;
            this.f2070e = eVar.f2070e;
            this.f2071f = eVar.f2071f;
            this.f2072g = eVar.f2072g;
            this.f2073h = eVar.f2073h;
            this.f2074i = eVar.f2074i;
            this.f2075j = eVar.f2075j;
            this.f2076k = eVar.f2076k;
            this.f2077l = eVar.f2077l;
            this.f2078m = eVar.f2078m;
        }

        void b(Context context, AttributeSet attributeSet) {
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R$styleable.Transform);
            this.f2066a = true;
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            for (int i10 = 0; i10 < indexCount; i10++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i10);
                switch (f2065n.get(index)) {
                    case 1:
                        this.f2067b = typedArrayObtainStyledAttributes.getFloat(index, this.f2067b);
                        break;
                    case 2:
                        this.f2068c = typedArrayObtainStyledAttributes.getFloat(index, this.f2068c);
                        break;
                    case 3:
                        this.f2069d = typedArrayObtainStyledAttributes.getFloat(index, this.f2069d);
                        break;
                    case 4:
                        this.f2070e = typedArrayObtainStyledAttributes.getFloat(index, this.f2070e);
                        break;
                    case 5:
                        this.f2071f = typedArrayObtainStyledAttributes.getFloat(index, this.f2071f);
                        break;
                    case 6:
                        this.f2072g = typedArrayObtainStyledAttributes.getDimension(index, this.f2072g);
                        break;
                    case 7:
                        this.f2073h = typedArrayObtainStyledAttributes.getDimension(index, this.f2073h);
                        break;
                    case 8:
                        this.f2074i = typedArrayObtainStyledAttributes.getDimension(index, this.f2074i);
                        break;
                    case 9:
                        this.f2075j = typedArrayObtainStyledAttributes.getDimension(index, this.f2075j);
                        break;
                    case 10:
                        this.f2076k = typedArrayObtainStyledAttributes.getDimension(index, this.f2076k);
                        break;
                    case 11:
                        this.f2077l = true;
                        this.f2078m = typedArrayObtainStyledAttributes.getDimension(index, this.f2078m);
                        break;
                }
            }
            typedArrayObtainStyledAttributes.recycle();
        }
    }

    static {
        SparseIntArray sparseIntArray = new SparseIntArray();
        f2004f = sparseIntArray;
        sparseIntArray.append(R$styleable.Constraint_layout_constraintLeft_toLeftOf, 25);
        f2004f.append(R$styleable.Constraint_layout_constraintLeft_toRightOf, 26);
        f2004f.append(R$styleable.Constraint_layout_constraintRight_toLeftOf, 29);
        f2004f.append(R$styleable.Constraint_layout_constraintRight_toRightOf, 30);
        f2004f.append(R$styleable.Constraint_layout_constraintTop_toTopOf, 36);
        f2004f.append(R$styleable.Constraint_layout_constraintTop_toBottomOf, 35);
        f2004f.append(R$styleable.Constraint_layout_constraintBottom_toTopOf, 4);
        f2004f.append(R$styleable.Constraint_layout_constraintBottom_toBottomOf, 3);
        f2004f.append(R$styleable.Constraint_layout_constraintBaseline_toBaselineOf, 1);
        f2004f.append(R$styleable.Constraint_layout_editor_absoluteX, 6);
        f2004f.append(R$styleable.Constraint_layout_editor_absoluteY, 7);
        f2004f.append(R$styleable.Constraint_layout_constraintGuide_begin, 17);
        f2004f.append(R$styleable.Constraint_layout_constraintGuide_end, 18);
        f2004f.append(R$styleable.Constraint_layout_constraintGuide_percent, 19);
        f2004f.append(R$styleable.Constraint_android_orientation, 27);
        f2004f.append(R$styleable.Constraint_layout_constraintStart_toEndOf, 32);
        f2004f.append(R$styleable.Constraint_layout_constraintStart_toStartOf, 33);
        f2004f.append(R$styleable.Constraint_layout_constraintEnd_toStartOf, 10);
        f2004f.append(R$styleable.Constraint_layout_constraintEnd_toEndOf, 9);
        f2004f.append(R$styleable.Constraint_layout_goneMarginLeft, 13);
        f2004f.append(R$styleable.Constraint_layout_goneMarginTop, 16);
        f2004f.append(R$styleable.Constraint_layout_goneMarginRight, 14);
        f2004f.append(R$styleable.Constraint_layout_goneMarginBottom, 11);
        f2004f.append(R$styleable.Constraint_layout_goneMarginStart, 15);
        f2004f.append(R$styleable.Constraint_layout_goneMarginEnd, 12);
        f2004f.append(R$styleable.Constraint_layout_constraintVertical_weight, 40);
        f2004f.append(R$styleable.Constraint_layout_constraintHorizontal_weight, 39);
        f2004f.append(R$styleable.Constraint_layout_constraintHorizontal_chainStyle, 41);
        f2004f.append(R$styleable.Constraint_layout_constraintVertical_chainStyle, 42);
        f2004f.append(R$styleable.Constraint_layout_constraintHorizontal_bias, 20);
        f2004f.append(R$styleable.Constraint_layout_constraintVertical_bias, 37);
        f2004f.append(R$styleable.Constraint_layout_constraintDimensionRatio, 5);
        f2004f.append(R$styleable.Constraint_layout_constraintLeft_creator, 82);
        f2004f.append(R$styleable.Constraint_layout_constraintTop_creator, 82);
        f2004f.append(R$styleable.Constraint_layout_constraintRight_creator, 82);
        f2004f.append(R$styleable.Constraint_layout_constraintBottom_creator, 82);
        f2004f.append(R$styleable.Constraint_layout_constraintBaseline_creator, 82);
        f2004f.append(R$styleable.Constraint_android_layout_marginLeft, 24);
        f2004f.append(R$styleable.Constraint_android_layout_marginRight, 28);
        f2004f.append(R$styleable.Constraint_android_layout_marginStart, 31);
        f2004f.append(R$styleable.Constraint_android_layout_marginEnd, 8);
        f2004f.append(R$styleable.Constraint_android_layout_marginTop, 34);
        f2004f.append(R$styleable.Constraint_android_layout_marginBottom, 2);
        f2004f.append(R$styleable.Constraint_android_layout_width, 23);
        f2004f.append(R$styleable.Constraint_android_layout_height, 21);
        f2004f.append(R$styleable.Constraint_android_visibility, 22);
        f2004f.append(R$styleable.Constraint_android_alpha, 43);
        f2004f.append(R$styleable.Constraint_android_elevation, 44);
        f2004f.append(R$styleable.Constraint_android_rotationX, 45);
        f2004f.append(R$styleable.Constraint_android_rotationY, 46);
        f2004f.append(R$styleable.Constraint_android_rotation, 60);
        f2004f.append(R$styleable.Constraint_android_scaleX, 47);
        f2004f.append(R$styleable.Constraint_android_scaleY, 48);
        f2004f.append(R$styleable.Constraint_android_transformPivotX, 49);
        f2004f.append(R$styleable.Constraint_android_transformPivotY, 50);
        f2004f.append(R$styleable.Constraint_android_translationX, 51);
        f2004f.append(R$styleable.Constraint_android_translationY, 52);
        f2004f.append(R$styleable.Constraint_android_translationZ, 53);
        f2004f.append(R$styleable.Constraint_layout_constraintWidth_default, 54);
        f2004f.append(R$styleable.Constraint_layout_constraintHeight_default, 55);
        f2004f.append(R$styleable.Constraint_layout_constraintWidth_max, 56);
        f2004f.append(R$styleable.Constraint_layout_constraintHeight_max, 57);
        f2004f.append(R$styleable.Constraint_layout_constraintWidth_min, 58);
        f2004f.append(R$styleable.Constraint_layout_constraintHeight_min, 59);
        f2004f.append(R$styleable.Constraint_layout_constraintCircle, 61);
        f2004f.append(R$styleable.Constraint_layout_constraintCircleRadius, 62);
        f2004f.append(R$styleable.Constraint_layout_constraintCircleAngle, 63);
        f2004f.append(R$styleable.Constraint_animate_relativeTo, 64);
        f2004f.append(R$styleable.Constraint_transitionEasing, 65);
        f2004f.append(R$styleable.Constraint_drawPath, 66);
        f2004f.append(R$styleable.Constraint_transitionPathRotate, 67);
        f2004f.append(R$styleable.Constraint_motionStagger, 79);
        f2004f.append(R$styleable.Constraint_android_id, 38);
        f2004f.append(R$styleable.Constraint_motionProgress, 68);
        f2004f.append(R$styleable.Constraint_layout_constraintWidth_percent, 69);
        f2004f.append(R$styleable.Constraint_layout_constraintHeight_percent, 70);
        f2004f.append(R$styleable.Constraint_chainUseRtl, 71);
        f2004f.append(R$styleable.Constraint_barrierDirection, 72);
        f2004f.append(R$styleable.Constraint_barrierMargin, 73);
        f2004f.append(R$styleable.Constraint_constraint_referenced_ids, 74);
        f2004f.append(R$styleable.Constraint_barrierAllowsGoneWidgets, 75);
        f2004f.append(R$styleable.Constraint_pathMotionArc, 76);
        f2004f.append(R$styleable.Constraint_layout_constraintTag, 77);
        f2004f.append(R$styleable.Constraint_visibilityMode, 78);
        f2004f.append(R$styleable.Constraint_layout_constrainedWidth, 80);
        f2004f.append(R$styleable.Constraint_layout_constrainedHeight, 81);
    }

    private String G(int i10) {
        switch (i10) {
            case 1:
                return "left";
            case 2:
                return "right";
            case 3:
                return "top";
            case 4:
                return "bottom";
            case 5:
                return "baseline";
            case 6:
                return "start";
            case 7:
                return TextEntity.ELLIPSIZE_END;
            default:
                return "undefined";
        }
    }

    private int[] m(View view, String str) {
        int iIntValue;
        Object designInformation;
        String[] strArrSplit = str.split(",");
        Context context = view.getContext();
        int[] iArr = new int[strArrSplit.length];
        int i10 = 0;
        int i11 = 0;
        while (i10 < strArrSplit.length) {
            String strTrim = strArrSplit[i10].trim();
            try {
                iIntValue = R$id.class.getField(strTrim).getInt(null);
            } catch (Exception unused) {
                iIntValue = 0;
            }
            if (iIntValue == 0) {
                iIntValue = context.getResources().getIdentifier(strTrim, "id", context.getPackageName());
            }
            if (iIntValue == 0 && view.isInEditMode() && (view.getParent() instanceof ConstraintLayout) && (designInformation = ((ConstraintLayout) view.getParent()).getDesignInformation(0, strTrim)) != null && (designInformation instanceof Integer)) {
                iIntValue = ((Integer) designInformation).intValue();
            }
            iArr[i11] = iIntValue;
            i10++;
            i11++;
        }
        return i11 != strArrSplit.length ? Arrays.copyOf(iArr, i11) : iArr;
    }

    private a n(Context context, AttributeSet attributeSet) {
        a aVar = new a();
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R$styleable.Constraint);
        z(context, aVar, typedArrayObtainStyledAttributes);
        typedArrayObtainStyledAttributes.recycle();
        return aVar;
    }

    private a o(int i10) {
        if (!this.f2008d.containsKey(Integer.valueOf(i10))) {
            this.f2008d.put(Integer.valueOf(i10), new a());
        }
        return this.f2008d.get(Integer.valueOf(i10));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static int y(TypedArray typedArray, int i10, int i11) {
        int resourceId = typedArray.getResourceId(i10, i11);
        return resourceId == -1 ? typedArray.getInt(i10, -1) : resourceId;
    }

    private void z(Context context, a aVar, TypedArray typedArray) {
        int indexCount = typedArray.getIndexCount();
        for (int i10 = 0; i10 < indexCount; i10++) {
            int index = typedArray.getIndex(i10);
            if (index != R$styleable.Constraint_android_id && R$styleable.Constraint_android_layout_marginStart != index && R$styleable.Constraint_android_layout_marginEnd != index) {
                aVar.f2011c.f2053a = true;
                aVar.f2012d.f2018b = true;
                aVar.f2010b.f2060a = true;
                aVar.f2013e.f2066a = true;
            }
            switch (f2004f.get(index)) {
                case 1:
                    C0009b c0009b = aVar.f2012d;
                    c0009b.f2041p = y(typedArray, index, c0009b.f2041p);
                    break;
                case 2:
                    C0009b c0009b2 = aVar.f2012d;
                    c0009b2.G = typedArray.getDimensionPixelSize(index, c0009b2.G);
                    break;
                case 3:
                    C0009b c0009b3 = aVar.f2012d;
                    c0009b3.f2040o = y(typedArray, index, c0009b3.f2040o);
                    break;
                case 4:
                    C0009b c0009b4 = aVar.f2012d;
                    c0009b4.f2039n = y(typedArray, index, c0009b4.f2039n);
                    break;
                case 5:
                    aVar.f2012d.f2048w = typedArray.getString(index);
                    break;
                case 6:
                    C0009b c0009b5 = aVar.f2012d;
                    c0009b5.A = typedArray.getDimensionPixelOffset(index, c0009b5.A);
                    break;
                case 7:
                    C0009b c0009b6 = aVar.f2012d;
                    c0009b6.B = typedArray.getDimensionPixelOffset(index, c0009b6.B);
                    break;
                case 8:
                    C0009b c0009b7 = aVar.f2012d;
                    c0009b7.H = typedArray.getDimensionPixelSize(index, c0009b7.H);
                    break;
                case 9:
                    C0009b c0009b8 = aVar.f2012d;
                    c0009b8.f2045t = y(typedArray, index, c0009b8.f2045t);
                    break;
                case 10:
                    C0009b c0009b9 = aVar.f2012d;
                    c0009b9.f2044s = y(typedArray, index, c0009b9.f2044s);
                    break;
                case 11:
                    C0009b c0009b10 = aVar.f2012d;
                    c0009b10.M = typedArray.getDimensionPixelSize(index, c0009b10.M);
                    break;
                case 12:
                    C0009b c0009b11 = aVar.f2012d;
                    c0009b11.N = typedArray.getDimensionPixelSize(index, c0009b11.N);
                    break;
                case 13:
                    C0009b c0009b12 = aVar.f2012d;
                    c0009b12.J = typedArray.getDimensionPixelSize(index, c0009b12.J);
                    break;
                case 14:
                    C0009b c0009b13 = aVar.f2012d;
                    c0009b13.L = typedArray.getDimensionPixelSize(index, c0009b13.L);
                    break;
                case 15:
                    C0009b c0009b14 = aVar.f2012d;
                    c0009b14.O = typedArray.getDimensionPixelSize(index, c0009b14.O);
                    break;
                case 16:
                    C0009b c0009b15 = aVar.f2012d;
                    c0009b15.K = typedArray.getDimensionPixelSize(index, c0009b15.K);
                    break;
                case 17:
                    C0009b c0009b16 = aVar.f2012d;
                    c0009b16.f2024e = typedArray.getDimensionPixelOffset(index, c0009b16.f2024e);
                    break;
                case 18:
                    C0009b c0009b17 = aVar.f2012d;
                    c0009b17.f2026f = typedArray.getDimensionPixelOffset(index, c0009b17.f2026f);
                    break;
                case 19:
                    C0009b c0009b18 = aVar.f2012d;
                    c0009b18.f2028g = typedArray.getFloat(index, c0009b18.f2028g);
                    break;
                case 20:
                    C0009b c0009b19 = aVar.f2012d;
                    c0009b19.f2046u = typedArray.getFloat(index, c0009b19.f2046u);
                    break;
                case 21:
                    C0009b c0009b20 = aVar.f2012d;
                    c0009b20.f2022d = typedArray.getLayoutDimension(index, c0009b20.f2022d);
                    break;
                case 22:
                    d dVar = aVar.f2010b;
                    dVar.f2061b = typedArray.getInt(index, dVar.f2061b);
                    d dVar2 = aVar.f2010b;
                    dVar2.f2061b = f2003e[dVar2.f2061b];
                    break;
                case 23:
                    C0009b c0009b21 = aVar.f2012d;
                    c0009b21.f2020c = typedArray.getLayoutDimension(index, c0009b21.f2020c);
                    break;
                case 24:
                    C0009b c0009b22 = aVar.f2012d;
                    c0009b22.D = typedArray.getDimensionPixelSize(index, c0009b22.D);
                    break;
                case 25:
                    C0009b c0009b23 = aVar.f2012d;
                    c0009b23.f2030h = y(typedArray, index, c0009b23.f2030h);
                    break;
                case 26:
                    C0009b c0009b24 = aVar.f2012d;
                    c0009b24.f2032i = y(typedArray, index, c0009b24.f2032i);
                    break;
                case 27:
                    C0009b c0009b25 = aVar.f2012d;
                    c0009b25.C = typedArray.getInt(index, c0009b25.C);
                    break;
                case 28:
                    C0009b c0009b26 = aVar.f2012d;
                    c0009b26.E = typedArray.getDimensionPixelSize(index, c0009b26.E);
                    break;
                case 29:
                    C0009b c0009b27 = aVar.f2012d;
                    c0009b27.f2034j = y(typedArray, index, c0009b27.f2034j);
                    break;
                case 30:
                    C0009b c0009b28 = aVar.f2012d;
                    c0009b28.f2036k = y(typedArray, index, c0009b28.f2036k);
                    break;
                case 31:
                    C0009b c0009b29 = aVar.f2012d;
                    c0009b29.I = typedArray.getDimensionPixelSize(index, c0009b29.I);
                    break;
                case 32:
                    C0009b c0009b30 = aVar.f2012d;
                    c0009b30.f2042q = y(typedArray, index, c0009b30.f2042q);
                    break;
                case 33:
                    C0009b c0009b31 = aVar.f2012d;
                    c0009b31.f2043r = y(typedArray, index, c0009b31.f2043r);
                    break;
                case 34:
                    C0009b c0009b32 = aVar.f2012d;
                    c0009b32.F = typedArray.getDimensionPixelSize(index, c0009b32.F);
                    break;
                case 35:
                    C0009b c0009b33 = aVar.f2012d;
                    c0009b33.f2038m = y(typedArray, index, c0009b33.f2038m);
                    break;
                case 36:
                    C0009b c0009b34 = aVar.f2012d;
                    c0009b34.f2037l = y(typedArray, index, c0009b34.f2037l);
                    break;
                case 37:
                    C0009b c0009b35 = aVar.f2012d;
                    c0009b35.f2047v = typedArray.getFloat(index, c0009b35.f2047v);
                    break;
                case 38:
                    aVar.f2009a = typedArray.getResourceId(index, aVar.f2009a);
                    break;
                case 39:
                    C0009b c0009b36 = aVar.f2012d;
                    c0009b36.Q = typedArray.getFloat(index, c0009b36.Q);
                    break;
                case 40:
                    C0009b c0009b37 = aVar.f2012d;
                    c0009b37.P = typedArray.getFloat(index, c0009b37.P);
                    break;
                case 41:
                    C0009b c0009b38 = aVar.f2012d;
                    c0009b38.R = typedArray.getInt(index, c0009b38.R);
                    break;
                case 42:
                    C0009b c0009b39 = aVar.f2012d;
                    c0009b39.S = typedArray.getInt(index, c0009b39.S);
                    break;
                case 43:
                    d dVar3 = aVar.f2010b;
                    dVar3.f2063d = typedArray.getFloat(index, dVar3.f2063d);
                    break;
                case 44:
                    e eVar = aVar.f2013e;
                    eVar.f2077l = true;
                    eVar.f2078m = typedArray.getDimension(index, eVar.f2078m);
                    break;
                case 45:
                    e eVar2 = aVar.f2013e;
                    eVar2.f2068c = typedArray.getFloat(index, eVar2.f2068c);
                    break;
                case 46:
                    e eVar3 = aVar.f2013e;
                    eVar3.f2069d = typedArray.getFloat(index, eVar3.f2069d);
                    break;
                case 47:
                    e eVar4 = aVar.f2013e;
                    eVar4.f2070e = typedArray.getFloat(index, eVar4.f2070e);
                    break;
                case 48:
                    e eVar5 = aVar.f2013e;
                    eVar5.f2071f = typedArray.getFloat(index, eVar5.f2071f);
                    break;
                case 49:
                    e eVar6 = aVar.f2013e;
                    eVar6.f2072g = typedArray.getDimension(index, eVar6.f2072g);
                    break;
                case 50:
                    e eVar7 = aVar.f2013e;
                    eVar7.f2073h = typedArray.getDimension(index, eVar7.f2073h);
                    break;
                case 51:
                    e eVar8 = aVar.f2013e;
                    eVar8.f2074i = typedArray.getDimension(index, eVar8.f2074i);
                    break;
                case 52:
                    e eVar9 = aVar.f2013e;
                    eVar9.f2075j = typedArray.getDimension(index, eVar9.f2075j);
                    break;
                case 53:
                    e eVar10 = aVar.f2013e;
                    eVar10.f2076k = typedArray.getDimension(index, eVar10.f2076k);
                    break;
                case 54:
                    C0009b c0009b40 = aVar.f2012d;
                    c0009b40.T = typedArray.getInt(index, c0009b40.T);
                    break;
                case 55:
                    C0009b c0009b41 = aVar.f2012d;
                    c0009b41.U = typedArray.getInt(index, c0009b41.U);
                    break;
                case 56:
                    C0009b c0009b42 = aVar.f2012d;
                    c0009b42.V = typedArray.getDimensionPixelSize(index, c0009b42.V);
                    break;
                case 57:
                    C0009b c0009b43 = aVar.f2012d;
                    c0009b43.W = typedArray.getDimensionPixelSize(index, c0009b43.W);
                    break;
                case 58:
                    C0009b c0009b44 = aVar.f2012d;
                    c0009b44.X = typedArray.getDimensionPixelSize(index, c0009b44.X);
                    break;
                case 59:
                    C0009b c0009b45 = aVar.f2012d;
                    c0009b45.Y = typedArray.getDimensionPixelSize(index, c0009b45.Y);
                    break;
                case 60:
                    e eVar11 = aVar.f2013e;
                    eVar11.f2067b = typedArray.getFloat(index, eVar11.f2067b);
                    break;
                case 61:
                    C0009b c0009b46 = aVar.f2012d;
                    c0009b46.f2049x = y(typedArray, index, c0009b46.f2049x);
                    break;
                case 62:
                    C0009b c0009b47 = aVar.f2012d;
                    c0009b47.f2050y = typedArray.getDimensionPixelSize(index, c0009b47.f2050y);
                    break;
                case 63:
                    C0009b c0009b48 = aVar.f2012d;
                    c0009b48.f2051z = typedArray.getFloat(index, c0009b48.f2051z);
                    break;
                case 64:
                    c cVar = aVar.f2011c;
                    cVar.f2054b = y(typedArray, index, cVar.f2054b);
                    break;
                case 65:
                    if (typedArray.peekValue(index).type == 3) {
                        aVar.f2011c.f2055c = typedArray.getString(index);
                    } else {
                        aVar.f2011c.f2055c = s.c.f16717c[typedArray.getInteger(index, 0)];
                    }
                    break;
                case 66:
                    aVar.f2011c.f2057e = typedArray.getInt(index, 0);
                    break;
                case 67:
                    c cVar2 = aVar.f2011c;
                    cVar2.f2059g = typedArray.getFloat(index, cVar2.f2059g);
                    break;
                case 68:
                    d dVar4 = aVar.f2010b;
                    dVar4.f2064e = typedArray.getFloat(index, dVar4.f2064e);
                    break;
                case 69:
                    aVar.f2012d.Z = typedArray.getFloat(index, 1.0f);
                    break;
                case 70:
                    aVar.f2012d.f2017a0 = typedArray.getFloat(index, 1.0f);
                    break;
                case 71:
                    Log.e("ConstraintSet", "CURRENTLY UNSUPPORTED");
                    break;
                case 72:
                    C0009b c0009b49 = aVar.f2012d;
                    c0009b49.f2019b0 = typedArray.getInt(index, c0009b49.f2019b0);
                    break;
                case 73:
                    C0009b c0009b50 = aVar.f2012d;
                    c0009b50.f2021c0 = typedArray.getDimensionPixelSize(index, c0009b50.f2021c0);
                    break;
                case 74:
                    aVar.f2012d.f2027f0 = typedArray.getString(index);
                    break;
                case 75:
                    C0009b c0009b51 = aVar.f2012d;
                    c0009b51.f2035j0 = typedArray.getBoolean(index, c0009b51.f2035j0);
                    break;
                case 76:
                    c cVar3 = aVar.f2011c;
                    cVar3.f2056d = typedArray.getInt(index, cVar3.f2056d);
                    break;
                case 77:
                    aVar.f2012d.f2029g0 = typedArray.getString(index);
                    break;
                case 78:
                    d dVar5 = aVar.f2010b;
                    dVar5.f2062c = typedArray.getInt(index, dVar5.f2062c);
                    break;
                case 79:
                    c cVar4 = aVar.f2011c;
                    cVar4.f2058f = typedArray.getFloat(index, cVar4.f2058f);
                    break;
                case 80:
                    C0009b c0009b52 = aVar.f2012d;
                    c0009b52.f2031h0 = typedArray.getBoolean(index, c0009b52.f2031h0);
                    break;
                case 81:
                    C0009b c0009b53 = aVar.f2012d;
                    c0009b53.f2033i0 = typedArray.getBoolean(index, c0009b53.f2033i0);
                    break;
                case 82:
                    Log.w("ConstraintSet", "unused attribute 0x" + Integer.toHexString(index) + "   " + f2004f.get(index));
                    break;
                default:
                    Log.w("ConstraintSet", "Unknown attribute 0x" + Integer.toHexString(index) + "   " + f2004f.get(index));
                    break;
            }
        }
    }

    public void A(ConstraintLayout constraintLayout) {
        int childCount = constraintLayout.getChildCount();
        for (int i10 = 0; i10 < childCount; i10++) {
            View childAt = constraintLayout.getChildAt(i10);
            ConstraintLayout.LayoutParams layoutParams = (ConstraintLayout.LayoutParams) childAt.getLayoutParams();
            int id = childAt.getId();
            if (this.f2007c && id == -1) {
                throw new RuntimeException("All children of ConstraintLayout must have ids to use ConstraintSet");
            }
            if (!this.f2008d.containsKey(Integer.valueOf(id))) {
                this.f2008d.put(Integer.valueOf(id), new a());
            }
            a aVar = this.f2008d.get(Integer.valueOf(id));
            if (!aVar.f2012d.f2018b) {
                aVar.f(id, layoutParams);
                if (childAt instanceof ConstraintHelper) {
                    aVar.f2012d.f2025e0 = ((ConstraintHelper) childAt).getReferencedIds();
                    if (childAt instanceof Barrier) {
                        Barrier barrier = (Barrier) childAt;
                        aVar.f2012d.f2035j0 = barrier.v();
                        aVar.f2012d.f2019b0 = barrier.getType();
                        aVar.f2012d.f2021c0 = barrier.getMargin();
                    }
                }
                aVar.f2012d.f2018b = true;
            }
            d dVar = aVar.f2010b;
            if (!dVar.f2060a) {
                dVar.f2061b = childAt.getVisibility();
                aVar.f2010b.f2063d = childAt.getAlpha();
                aVar.f2010b.f2060a = true;
            }
            e eVar = aVar.f2013e;
            if (!eVar.f2066a) {
                eVar.f2066a = true;
                eVar.f2067b = childAt.getRotation();
                aVar.f2013e.f2068c = childAt.getRotationX();
                aVar.f2013e.f2069d = childAt.getRotationY();
                aVar.f2013e.f2070e = childAt.getScaleX();
                aVar.f2013e.f2071f = childAt.getScaleY();
                float pivotX = childAt.getPivotX();
                float pivotY = childAt.getPivotY();
                if (pivotX != UserProfileInfo.Constant.NA_LAT_LON || pivotY != UserProfileInfo.Constant.NA_LAT_LON) {
                    e eVar2 = aVar.f2013e;
                    eVar2.f2072g = pivotX;
                    eVar2.f2073h = pivotY;
                }
                aVar.f2013e.f2074i = childAt.getTranslationX();
                aVar.f2013e.f2075j = childAt.getTranslationY();
                aVar.f2013e.f2076k = childAt.getTranslationZ();
                e eVar3 = aVar.f2013e;
                if (eVar3.f2077l) {
                    eVar3.f2078m = childAt.getElevation();
                }
            }
        }
    }

    public void B(b bVar) {
        for (Integer num : bVar.f2008d.keySet()) {
            num.intValue();
            a aVar = bVar.f2008d.get(num);
            if (!this.f2008d.containsKey(num)) {
                this.f2008d.put(num, new a());
            }
            a aVar2 = this.f2008d.get(num);
            C0009b c0009b = aVar2.f2012d;
            if (!c0009b.f2018b) {
                c0009b.a(aVar.f2012d);
            }
            d dVar = aVar2.f2010b;
            if (!dVar.f2060a) {
                dVar.a(aVar.f2010b);
            }
            e eVar = aVar2.f2013e;
            if (!eVar.f2066a) {
                eVar.a(aVar.f2013e);
            }
            c cVar = aVar2.f2011c;
            if (!cVar.f2053a) {
                cVar.a(aVar.f2011c);
            }
            for (String str : aVar.f2014f.keySet()) {
                if (!aVar2.f2014f.containsKey(str)) {
                    aVar2.f2014f.put(str, aVar.f2014f.get(str));
                }
            }
        }
    }

    public void C(boolean z10) {
        this.f2007c = z10;
    }

    public void D(int i10, int i11, int i12) {
        a aVarO = o(i10);
        switch (i11) {
            case 1:
                aVarO.f2012d.D = i12;
                return;
            case 2:
                aVarO.f2012d.E = i12;
                return;
            case 3:
                aVarO.f2012d.F = i12;
                return;
            case 4:
                aVarO.f2012d.G = i12;
                return;
            case 5:
                throw new IllegalArgumentException("baseline does not support margins");
            case 6:
                aVarO.f2012d.I = i12;
                return;
            case 7:
                aVarO.f2012d.H = i12;
                return;
            default:
                throw new IllegalArgumentException("unknown constraint");
        }
    }

    public void E(boolean z10) {
        this.f2005a = z10;
    }

    public void F(int i10, int i11) {
        o(i10).f2010b.f2061b = i11;
    }

    public void c(ConstraintLayout constraintLayout) {
        int childCount = constraintLayout.getChildCount();
        for (int i10 = 0; i10 < childCount; i10++) {
            View childAt = constraintLayout.getChildAt(i10);
            int id = childAt.getId();
            if (!this.f2008d.containsKey(Integer.valueOf(id))) {
                Log.v("ConstraintSet", "id unknown " + androidx.constraintlayout.motion.widget.a.c(childAt));
            } else {
                if (this.f2007c && id == -1) {
                    throw new RuntimeException("All children of ConstraintLayout must have ids to use ConstraintSet");
                }
                if (this.f2008d.containsKey(Integer.valueOf(id))) {
                    ConstraintAttribute.h(childAt, this.f2008d.get(Integer.valueOf(id)).f2014f);
                }
            }
        }
    }

    public void d(ConstraintLayout constraintLayout) {
        f(constraintLayout, true);
        constraintLayout.setConstraintSet(null);
        constraintLayout.requestLayout();
    }

    public void e(ConstraintHelper constraintHelper, ConstraintWidget constraintWidget, ConstraintLayout.LayoutParams layoutParams, SparseArray<ConstraintWidget> sparseArray) {
        int id = constraintHelper.getId();
        if (this.f2008d.containsKey(Integer.valueOf(id))) {
            a aVar = this.f2008d.get(Integer.valueOf(id));
            if (constraintWidget instanceof u.b) {
                constraintHelper.n(aVar, (u.b) constraintWidget, layoutParams, sparseArray);
            }
        }
    }

    void f(ConstraintLayout constraintLayout, boolean z10) {
        int childCount = constraintLayout.getChildCount();
        HashSet<Integer> hashSet = new HashSet(this.f2008d.keySet());
        for (int i10 = 0; i10 < childCount; i10++) {
            View childAt = constraintLayout.getChildAt(i10);
            int id = childAt.getId();
            if (!this.f2008d.containsKey(Integer.valueOf(id))) {
                Log.w("ConstraintSet", "id unknown " + androidx.constraintlayout.motion.widget.a.c(childAt));
            } else {
                if (this.f2007c && id == -1) {
                    throw new RuntimeException("All children of ConstraintLayout must have ids to use ConstraintSet");
                }
                if (id != -1) {
                    if (this.f2008d.containsKey(Integer.valueOf(id))) {
                        hashSet.remove(Integer.valueOf(id));
                        a aVar = this.f2008d.get(Integer.valueOf(id));
                        if (childAt instanceof Barrier) {
                            aVar.f2012d.f2023d0 = 1;
                        }
                        int i11 = aVar.f2012d.f2023d0;
                        if (i11 != -1 && i11 == 1) {
                            Barrier barrier = (Barrier) childAt;
                            barrier.setId(id);
                            barrier.setType(aVar.f2012d.f2019b0);
                            barrier.setMargin(aVar.f2012d.f2021c0);
                            barrier.setAllowsGoneWidget(aVar.f2012d.f2035j0);
                            C0009b c0009b = aVar.f2012d;
                            int[] iArr = c0009b.f2025e0;
                            if (iArr != null) {
                                barrier.setReferencedIds(iArr);
                            } else {
                                String str = c0009b.f2027f0;
                                if (str != null) {
                                    c0009b.f2025e0 = m(barrier, str);
                                    barrier.setReferencedIds(aVar.f2012d.f2025e0);
                                }
                            }
                        }
                        ConstraintLayout.LayoutParams layoutParams = (ConstraintLayout.LayoutParams) childAt.getLayoutParams();
                        layoutParams.validate();
                        aVar.d(layoutParams);
                        if (z10) {
                            ConstraintAttribute.h(childAt, aVar.f2014f);
                        }
                        childAt.setLayoutParams(layoutParams);
                        d dVar = aVar.f2010b;
                        if (dVar.f2062c == 0) {
                            childAt.setVisibility(dVar.f2061b);
                        }
                        childAt.setAlpha(aVar.f2010b.f2063d);
                        childAt.setRotation(aVar.f2013e.f2067b);
                        childAt.setRotationX(aVar.f2013e.f2068c);
                        childAt.setRotationY(aVar.f2013e.f2069d);
                        childAt.setScaleX(aVar.f2013e.f2070e);
                        childAt.setScaleY(aVar.f2013e.f2071f);
                        if (!Float.isNaN(aVar.f2013e.f2072g)) {
                            childAt.setPivotX(aVar.f2013e.f2072g);
                        }
                        if (!Float.isNaN(aVar.f2013e.f2073h)) {
                            childAt.setPivotY(aVar.f2013e.f2073h);
                        }
                        childAt.setTranslationX(aVar.f2013e.f2074i);
                        childAt.setTranslationY(aVar.f2013e.f2075j);
                        childAt.setTranslationZ(aVar.f2013e.f2076k);
                        e eVar = aVar.f2013e;
                        if (eVar.f2077l) {
                            childAt.setElevation(eVar.f2078m);
                        }
                    } else {
                        Log.v("ConstraintSet", "WARNING NO CONSTRAINTS for view " + id);
                    }
                }
            }
        }
        for (Integer num : hashSet) {
            a aVar2 = this.f2008d.get(num);
            int i12 = aVar2.f2012d.f2023d0;
            if (i12 != -1 && i12 == 1) {
                Barrier barrier2 = new Barrier(constraintLayout.getContext());
                barrier2.setId(num.intValue());
                C0009b c0009b2 = aVar2.f2012d;
                int[] iArr2 = c0009b2.f2025e0;
                if (iArr2 != null) {
                    barrier2.setReferencedIds(iArr2);
                } else {
                    String str2 = c0009b2.f2027f0;
                    if (str2 != null) {
                        c0009b2.f2025e0 = m(barrier2, str2);
                        barrier2.setReferencedIds(aVar2.f2012d.f2025e0);
                    }
                }
                barrier2.setType(aVar2.f2012d.f2019b0);
                barrier2.setMargin(aVar2.f2012d.f2021c0);
                ConstraintLayout.LayoutParams layoutParamsGenerateDefaultLayoutParams = constraintLayout.generateDefaultLayoutParams();
                barrier2.u();
                aVar2.d(layoutParamsGenerateDefaultLayoutParams);
                constraintLayout.addView(barrier2, layoutParamsGenerateDefaultLayoutParams);
            }
            if (aVar2.f2012d.f2016a) {
                View guideline = new Guideline(constraintLayout.getContext());
                guideline.setId(num.intValue());
                ConstraintLayout.LayoutParams layoutParamsGenerateDefaultLayoutParams2 = constraintLayout.generateDefaultLayoutParams();
                aVar2.d(layoutParamsGenerateDefaultLayoutParams2);
                constraintLayout.addView(guideline, layoutParamsGenerateDefaultLayoutParams2);
            }
        }
    }

    public void g(int i10, ConstraintLayout.LayoutParams layoutParams) {
        if (this.f2008d.containsKey(Integer.valueOf(i10))) {
            this.f2008d.get(Integer.valueOf(i10)).d(layoutParams);
        }
    }

    public void h(Context context, int i10) {
        i((ConstraintLayout) LayoutInflater.from(context).inflate(i10, (ViewGroup) null));
    }

    public void i(ConstraintLayout constraintLayout) {
        int childCount = constraintLayout.getChildCount();
        this.f2008d.clear();
        for (int i10 = 0; i10 < childCount; i10++) {
            View childAt = constraintLayout.getChildAt(i10);
            ConstraintLayout.LayoutParams layoutParams = (ConstraintLayout.LayoutParams) childAt.getLayoutParams();
            int id = childAt.getId();
            if (this.f2007c && id == -1) {
                throw new RuntimeException("All children of ConstraintLayout must have ids to use ConstraintSet");
            }
            if (!this.f2008d.containsKey(Integer.valueOf(id))) {
                this.f2008d.put(Integer.valueOf(id), new a());
            }
            a aVar = this.f2008d.get(Integer.valueOf(id));
            aVar.f2014f = ConstraintAttribute.b(this.f2006b, childAt);
            aVar.f(id, layoutParams);
            aVar.f2010b.f2061b = childAt.getVisibility();
            aVar.f2010b.f2063d = childAt.getAlpha();
            aVar.f2013e.f2067b = childAt.getRotation();
            aVar.f2013e.f2068c = childAt.getRotationX();
            aVar.f2013e.f2069d = childAt.getRotationY();
            aVar.f2013e.f2070e = childAt.getScaleX();
            aVar.f2013e.f2071f = childAt.getScaleY();
            float pivotX = childAt.getPivotX();
            float pivotY = childAt.getPivotY();
            if (pivotX != UserProfileInfo.Constant.NA_LAT_LON || pivotY != UserProfileInfo.Constant.NA_LAT_LON) {
                e eVar = aVar.f2013e;
                eVar.f2072g = pivotX;
                eVar.f2073h = pivotY;
            }
            aVar.f2013e.f2074i = childAt.getTranslationX();
            aVar.f2013e.f2075j = childAt.getTranslationY();
            aVar.f2013e.f2076k = childAt.getTranslationZ();
            e eVar2 = aVar.f2013e;
            if (eVar2.f2077l) {
                eVar2.f2078m = childAt.getElevation();
            }
            if (childAt instanceof Barrier) {
                Barrier barrier = (Barrier) childAt;
                aVar.f2012d.f2035j0 = barrier.v();
                aVar.f2012d.f2025e0 = barrier.getReferencedIds();
                aVar.f2012d.f2019b0 = barrier.getType();
                aVar.f2012d.f2021c0 = barrier.getMargin();
            }
        }
    }

    public void j(Constraints constraints) {
        int childCount = constraints.getChildCount();
        this.f2008d.clear();
        for (int i10 = 0; i10 < childCount; i10++) {
            View childAt = constraints.getChildAt(i10);
            Constraints.LayoutParams layoutParams = (Constraints.LayoutParams) childAt.getLayoutParams();
            int id = childAt.getId();
            if (this.f2007c && id == -1) {
                throw new RuntimeException("All children of ConstraintLayout must have ids to use ConstraintSet");
            }
            if (!this.f2008d.containsKey(Integer.valueOf(id))) {
                this.f2008d.put(Integer.valueOf(id), new a());
            }
            a aVar = this.f2008d.get(Integer.valueOf(id));
            if (childAt instanceof ConstraintHelper) {
                aVar.h((ConstraintHelper) childAt, id, layoutParams);
            }
            aVar.g(id, layoutParams);
        }
    }

    public void k(int i10, int i11, int i12, int i13) {
        if (!this.f2008d.containsKey(Integer.valueOf(i10))) {
            this.f2008d.put(Integer.valueOf(i10), new a());
        }
        a aVar = this.f2008d.get(Integer.valueOf(i10));
        switch (i11) {
            case 1:
                if (i13 == 1) {
                    C0009b c0009b = aVar.f2012d;
                    c0009b.f2030h = i12;
                    c0009b.f2032i = -1;
                    return;
                } else if (i13 == 2) {
                    C0009b c0009b2 = aVar.f2012d;
                    c0009b2.f2032i = i12;
                    c0009b2.f2030h = -1;
                    return;
                } else {
                    throw new IllegalArgumentException("left to " + G(i13) + " undefined");
                }
            case 2:
                if (i13 == 1) {
                    C0009b c0009b3 = aVar.f2012d;
                    c0009b3.f2034j = i12;
                    c0009b3.f2036k = -1;
                    return;
                } else if (i13 == 2) {
                    C0009b c0009b4 = aVar.f2012d;
                    c0009b4.f2036k = i12;
                    c0009b4.f2034j = -1;
                    return;
                } else {
                    throw new IllegalArgumentException("right to " + G(i13) + " undefined");
                }
            case 3:
                if (i13 == 3) {
                    C0009b c0009b5 = aVar.f2012d;
                    c0009b5.f2037l = i12;
                    c0009b5.f2038m = -1;
                    c0009b5.f2041p = -1;
                    return;
                }
                if (i13 == 4) {
                    C0009b c0009b6 = aVar.f2012d;
                    c0009b6.f2038m = i12;
                    c0009b6.f2037l = -1;
                    c0009b6.f2041p = -1;
                    return;
                }
                throw new IllegalArgumentException("right to " + G(i13) + " undefined");
            case 4:
                if (i13 == 4) {
                    C0009b c0009b7 = aVar.f2012d;
                    c0009b7.f2040o = i12;
                    c0009b7.f2039n = -1;
                    c0009b7.f2041p = -1;
                    return;
                }
                if (i13 == 3) {
                    C0009b c0009b8 = aVar.f2012d;
                    c0009b8.f2039n = i12;
                    c0009b8.f2040o = -1;
                    c0009b8.f2041p = -1;
                    return;
                }
                throw new IllegalArgumentException("right to " + G(i13) + " undefined");
            case 5:
                if (i13 != 5) {
                    throw new IllegalArgumentException("right to " + G(i13) + " undefined");
                }
                C0009b c0009b9 = aVar.f2012d;
                c0009b9.f2041p = i12;
                c0009b9.f2040o = -1;
                c0009b9.f2039n = -1;
                c0009b9.f2037l = -1;
                c0009b9.f2038m = -1;
                return;
            case 6:
                if (i13 == 6) {
                    C0009b c0009b10 = aVar.f2012d;
                    c0009b10.f2043r = i12;
                    c0009b10.f2042q = -1;
                    return;
                } else if (i13 == 7) {
                    C0009b c0009b11 = aVar.f2012d;
                    c0009b11.f2042q = i12;
                    c0009b11.f2043r = -1;
                    return;
                } else {
                    throw new IllegalArgumentException("right to " + G(i13) + " undefined");
                }
            case 7:
                if (i13 == 7) {
                    C0009b c0009b12 = aVar.f2012d;
                    c0009b12.f2045t = i12;
                    c0009b12.f2044s = -1;
                    return;
                } else if (i13 == 6) {
                    C0009b c0009b13 = aVar.f2012d;
                    c0009b13.f2044s = i12;
                    c0009b13.f2045t = -1;
                    return;
                } else {
                    throw new IllegalArgumentException("right to " + G(i13) + " undefined");
                }
            default:
                throw new IllegalArgumentException(G(i11) + " to " + G(i13) + " unknown");
        }
    }

    public void l(int i10, int i11, int i12, float f10) {
        C0009b c0009b = o(i10).f2012d;
        c0009b.f2049x = i11;
        c0009b.f2050y = i12;
        c0009b.f2051z = f10;
    }

    public a p(int i10) {
        if (this.f2008d.containsKey(Integer.valueOf(i10))) {
            return this.f2008d.get(Integer.valueOf(i10));
        }
        return null;
    }

    public int q(int i10) {
        return o(i10).f2012d.f2022d;
    }

    public int[] r() {
        Integer[] numArr = (Integer[]) this.f2008d.keySet().toArray(new Integer[0]);
        int length = numArr.length;
        int[] iArr = new int[length];
        for (int i10 = 0; i10 < length; i10++) {
            iArr[i10] = numArr[i10].intValue();
        }
        return iArr;
    }

    public a s(int i10) {
        return o(i10);
    }

    public int t(int i10) {
        return o(i10).f2010b.f2061b;
    }

    public int u(int i10) {
        return o(i10).f2010b.f2062c;
    }

    public int v(int i10) {
        return o(i10).f2012d.f2020c;
    }

    public void w(Context context, int i10) {
        XmlResourceParser xml = context.getResources().getXml(i10);
        try {
            for (int eventType = xml.getEventType(); eventType != 1; eventType = xml.next()) {
                if (eventType == 0) {
                    xml.getName();
                } else if (eventType == 2) {
                    String name = xml.getName();
                    a aVarN = n(context, Xml.asAttributeSet(xml));
                    if (name.equalsIgnoreCase("Guideline")) {
                        aVarN.f2012d.f2016a = true;
                    }
                    this.f2008d.put(Integer.valueOf(aVarN.f2009a), aVarN);
                }
            }
        } catch (IOException e10) {
            e10.printStackTrace();
        } catch (XmlPullParserException e11) {
            e11.printStackTrace();
        }
    }

    /* JADX WARN: Code duplicated, block: B:48:0x0095  */
    public void x(Context context, XmlPullParser xmlPullParser) {
        try {
            int eventType = xmlPullParser.getEventType();
            a aVarN = null;
            while (eventType != 1) {
                if (eventType != 0) {
                    if (eventType == 2) {
                        switch (xmlPullParser.getName()) {
                            case "Constraint":
                                aVarN = n(context, Xml.asAttributeSet(xmlPullParser));
                                break;
                            case "Guideline":
                                aVarN = n(context, Xml.asAttributeSet(xmlPullParser));
                                C0009b c0009b = aVarN.f2012d;
                                c0009b.f2016a = true;
                                c0009b.f2018b = true;
                                break;
                            case "Barrier":
                                aVarN = n(context, Xml.asAttributeSet(xmlPullParser));
                                aVarN.f2012d.f2023d0 = 1;
                                break;
                            case "PropertySet":
                                if (aVarN == null) {
                                    throw new RuntimeException("XML parser error must be within a Constraint " + xmlPullParser.getLineNumber());
                                }
                                aVarN.f2010b.b(context, Xml.asAttributeSet(xmlPullParser));
                                break;
                                break;
                            case "Transform":
                                if (aVarN == null) {
                                    throw new RuntimeException("XML parser error must be within a Constraint " + xmlPullParser.getLineNumber());
                                }
                                aVarN.f2013e.b(context, Xml.asAttributeSet(xmlPullParser));
                                break;
                                break;
                            case "Layout":
                                if (aVarN == null) {
                                    throw new RuntimeException("XML parser error must be within a Constraint " + xmlPullParser.getLineNumber());
                                }
                                aVarN.f2012d.b(context, Xml.asAttributeSet(xmlPullParser));
                                break;
                                break;
                            case "Motion":
                                if (aVarN == null) {
                                    throw new RuntimeException("XML parser error must be within a Constraint " + xmlPullParser.getLineNumber());
                                }
                                aVarN.f2011c.b(context, Xml.asAttributeSet(xmlPullParser));
                                break;
                                break;
                            case "CustomAttribute":
                                if (aVarN == null) {
                                    throw new RuntimeException("XML parser error must be within a Constraint " + xmlPullParser.getLineNumber());
                                }
                                ConstraintAttribute.g(context, xmlPullParser, aVarN.f2014f);
                                break;
                                break;
                        }
                    } else if (eventType != 3) {
                        continue;
                    } else {
                        String name = xmlPullParser.getName();
                        if ("ConstraintSet".equals(name)) {
                            return;
                        }
                        if (name.equalsIgnoreCase("Constraint")) {
                            this.f2008d.put(Integer.valueOf(aVarN.f2009a), aVarN);
                            aVarN = null;
                        }
                    }
                } else {
                    xmlPullParser.getName();
                }
                eventType = xmlPullParser.next();
            }
        } catch (IOException e10) {
            e10.printStackTrace();
        } catch (XmlPullParserException e11) {
            e11.printStackTrace();
        }
    }
}
