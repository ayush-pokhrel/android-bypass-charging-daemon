package androidx.constraintlayout.helper.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import androidx.constraintlayout.solver.widgets.ConstraintWidget;
import androidx.constraintlayout.widget.ConstraintHelper;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.R$styleable;

/* JADX INFO: loaded from: classes.dex */
public class Layer extends ConstraintHelper {
    private float A;
    private boolean B;
    private boolean C;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private float f1170l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    private float f1171m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    private float f1172n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    ConstraintLayout f1173o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    private float f1174p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    private float f1175q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    protected float f1176r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    protected float f1177s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    protected float f1178t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    protected float f1179u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    protected float f1180v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    protected float f1181w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    boolean f1182x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    View[] f1183y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    private float f1184z;

    public Layer(Context context) {
        super(context);
        this.f1170l = Float.NaN;
        this.f1171m = Float.NaN;
        this.f1172n = Float.NaN;
        this.f1174p = 1.0f;
        this.f1175q = 1.0f;
        this.f1176r = Float.NaN;
        this.f1177s = Float.NaN;
        this.f1178t = Float.NaN;
        this.f1179u = Float.NaN;
        this.f1180v = Float.NaN;
        this.f1181w = Float.NaN;
        this.f1182x = true;
        this.f1183y = null;
        this.f1184z = 0.0f;
        this.A = 0.0f;
    }

    private void w() {
        int i10;
        if (this.f1173o == null || (i10 = this.f1951b) == 0) {
            return;
        }
        View[] viewArr = this.f1183y;
        if (viewArr == null || viewArr.length != i10) {
            this.f1183y = new View[i10];
        }
        for (int i11 = 0; i11 < this.f1951b; i11++) {
            this.f1183y[i11] = this.f1173o.getViewById(this.f1950a[i11]);
        }
    }

    private void x() {
        if (this.f1173o == null) {
            return;
        }
        if (this.f1183y == null) {
            w();
        }
        v();
        double radians = Math.toRadians(this.f1172n);
        float fSin = (float) Math.sin(radians);
        float fCos = (float) Math.cos(radians);
        float f10 = this.f1174p;
        float f11 = f10 * fCos;
        float f12 = this.f1175q;
        float f13 = (-f12) * fSin;
        float f14 = f10 * fSin;
        float f15 = f12 * fCos;
        for (int i10 = 0; i10 < this.f1951b; i10++) {
            View view = this.f1183y[i10];
            int left = (view.getLeft() + view.getRight()) / 2;
            int top = (view.getTop() + view.getBottom()) / 2;
            float f16 = left - this.f1176r;
            float f17 = top - this.f1177s;
            float f18 = (((f11 * f16) + (f13 * f17)) - f16) + this.f1184z;
            float f19 = (((f16 * f14) + (f15 * f17)) - f17) + this.A;
            view.setTranslationX(f18);
            view.setTranslationY(f19);
            view.setScaleY(this.f1175q);
            view.setScaleX(this.f1174p);
            view.setRotation(this.f1172n);
        }
    }

    @Override // androidx.constraintlayout.widget.ConstraintHelper
    protected void m(AttributeSet attributeSet) {
        super.m(attributeSet);
        this.f1954h = false;
        if (attributeSet != null) {
            TypedArray typedArrayObtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, R$styleable.ConstraintLayout_Layout);
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            for (int i10 = 0; i10 < indexCount; i10++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i10);
                if (index == R$styleable.ConstraintLayout_Layout_android_visibility) {
                    this.B = true;
                } else if (index == R$styleable.ConstraintLayout_Layout_android_elevation) {
                    this.C = true;
                }
            }
        }
    }

    @Override // androidx.constraintlayout.widget.ConstraintHelper, android.view.View
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.f1173o = (ConstraintLayout) getParent();
        if (this.B || this.C) {
            int visibility = getVisibility();
            float elevation = getElevation();
            for (int i10 = 0; i10 < this.f1951b; i10++) {
                View viewById = this.f1173o.getViewById(this.f1950a[i10]);
                if (viewById != null) {
                    if (this.B) {
                        viewById.setVisibility(visibility);
                    }
                    if (this.C && elevation > 0.0f) {
                        viewById.setTranslationZ(viewById.getTranslationZ() + elevation);
                    }
                }
            }
        }
    }

    @Override // androidx.constraintlayout.widget.ConstraintHelper
    public void p(ConstraintLayout constraintLayout) {
        w();
        this.f1176r = Float.NaN;
        this.f1177s = Float.NaN;
        ConstraintWidget constraintWidget = ((ConstraintLayout.LayoutParams) getLayoutParams()).getConstraintWidget();
        constraintWidget.F0(0);
        constraintWidget.i0(0);
        v();
        layout(((int) this.f1180v) - getPaddingLeft(), ((int) this.f1181w) - getPaddingTop(), ((int) this.f1178t) + getPaddingRight(), ((int) this.f1179u) + getPaddingBottom());
        if (Float.isNaN(this.f1172n)) {
            return;
        }
        x();
    }

    @Override // androidx.constraintlayout.widget.ConstraintHelper
    public void r(ConstraintLayout constraintLayout) {
        this.f1173o = constraintLayout;
        float rotation = getRotation();
        if (rotation != 0.0f) {
            this.f1172n = rotation;
        } else {
            if (Float.isNaN(this.f1172n)) {
                return;
            }
            this.f1172n = rotation;
        }
    }

    @Override // android.view.View
    public void setElevation(float f10) {
        super.setElevation(f10);
        g();
    }

    @Override // android.view.View
    public void setPivotX(float f10) {
        this.f1170l = f10;
        x();
    }

    @Override // android.view.View
    public void setPivotY(float f10) {
        this.f1171m = f10;
        x();
    }

    @Override // android.view.View
    public void setRotation(float f10) {
        this.f1172n = f10;
        x();
    }

    @Override // android.view.View
    public void setScaleX(float f10) {
        this.f1174p = f10;
        x();
    }

    @Override // android.view.View
    public void setScaleY(float f10) {
        this.f1175q = f10;
        x();
    }

    @Override // android.view.View
    public void setTranslationX(float f10) {
        this.f1184z = f10;
        x();
    }

    @Override // android.view.View
    public void setTranslationY(float f10) {
        this.A = f10;
        x();
    }

    @Override // android.view.View
    public void setVisibility(int i10) {
        super.setVisibility(i10);
        g();
    }

    protected void v() {
        if (this.f1173o == null) {
            return;
        }
        if (this.f1182x || Float.isNaN(this.f1176r) || Float.isNaN(this.f1177s)) {
            if (!Float.isNaN(this.f1170l) && !Float.isNaN(this.f1171m)) {
                this.f1177s = this.f1171m;
                this.f1176r = this.f1170l;
                return;
            }
            View[] viewArrL = l(this.f1173o);
            int left = viewArrL[0].getLeft();
            int top = viewArrL[0].getTop();
            int right = viewArrL[0].getRight();
            int bottom = viewArrL[0].getBottom();
            for (int i10 = 0; i10 < this.f1951b; i10++) {
                View view = viewArrL[i10];
                left = Math.min(left, view.getLeft());
                top = Math.min(top, view.getTop());
                right = Math.max(right, view.getRight());
                bottom = Math.max(bottom, view.getBottom());
            }
            this.f1178t = right;
            this.f1179u = bottom;
            this.f1180v = left;
            this.f1181w = top;
            if (Float.isNaN(this.f1170l)) {
                this.f1176r = (left + right) / 2;
            } else {
                this.f1176r = this.f1170l;
            }
            if (Float.isNaN(this.f1171m)) {
                this.f1177s = (top + bottom) / 2;
            } else {
                this.f1177s = this.f1171m;
            }
        }
    }

    public Layer(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f1170l = Float.NaN;
        this.f1171m = Float.NaN;
        this.f1172n = Float.NaN;
        this.f1174p = 1.0f;
        this.f1175q = 1.0f;
        this.f1176r = Float.NaN;
        this.f1177s = Float.NaN;
        this.f1178t = Float.NaN;
        this.f1179u = Float.NaN;
        this.f1180v = Float.NaN;
        this.f1181w = Float.NaN;
        this.f1182x = true;
        this.f1183y = null;
        this.f1184z = 0.0f;
        this.A = 0.0f;
    }

    public Layer(Context context, AttributeSet attributeSet, int i10) {
        super(context, attributeSet, i10);
        this.f1170l = Float.NaN;
        this.f1171m = Float.NaN;
        this.f1172n = Float.NaN;
        this.f1174p = 1.0f;
        this.f1175q = 1.0f;
        this.f1176r = Float.NaN;
        this.f1177s = Float.NaN;
        this.f1178t = Float.NaN;
        this.f1179u = Float.NaN;
        this.f1180v = Float.NaN;
        this.f1181w = Float.NaN;
        this.f1182x = true;
        this.f1183y = null;
        this.f1184z = 0.0f;
        this.A = 0.0f;
    }
}
