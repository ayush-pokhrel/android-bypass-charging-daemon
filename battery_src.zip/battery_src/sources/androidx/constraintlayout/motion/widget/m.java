package androidx.constraintlayout.motion.widget;

import android.util.Log;
import android.view.View;
import androidx.constraintlayout.solver.widgets.ConstraintWidget;
import androidx.constraintlayout.widget.ConstraintAttribute;
import com.oplus.smartenginehelper.ParserTag;
import com.oplus.smartenginehelper.entity.ViewEntity;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;

/* JADX INFO: compiled from: MotionConstrainedPoint.java */
/* JADX INFO: loaded from: classes.dex */
class m implements Comparable<m> {
    static String[] F = {"position", "x", "y", "width", "height", "pathRotate"};

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    int f1418c;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    private s.c f1431s;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    private float f1433u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    private float f1434v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    private float f1435w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    private float f1436x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    private float f1437y;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private float f1416a = 1.0f;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    int f1417b = 0;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private boolean f1419g = false;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private float f1420h = 0.0f;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private float f1421i = 0.0f;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private float f1422j = 0.0f;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    public float f1423k = 0.0f;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private float f1424l = 1.0f;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    private float f1425m = 1.0f;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    private float f1426n = Float.NaN;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    private float f1427o = Float.NaN;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    private float f1428p = 0.0f;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    private float f1429q = 0.0f;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    private float f1430r = 0.0f;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    private int f1432t = 0;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    private float f1438z = Float.NaN;
    private float A = Float.NaN;
    LinkedHashMap<String, ConstraintAttribute> B = new LinkedHashMap<>();
    int C = 0;
    double[] D = new double[18];
    double[] E = new double[18];

    private boolean e(float f10, float f11) {
        if (Float.isNaN(f10) || Float.isNaN(f11)) {
            return Float.isNaN(f10) != Float.isNaN(f11);
        }
        return Math.abs(f10 - f11) > 1.0E-6f;
    }

    public void a(HashMap<String, r> map, int i10) {
        for (String str : map.keySet()) {
            r rVar = map.get(str);
            str.hashCode();
            switch (str) {
                case "rotationX":
                    rVar.e(i10, Float.isNaN(this.f1422j) ? 0.0f : this.f1422j);
                    break;
                case "rotationY":
                    rVar.e(i10, Float.isNaN(this.f1423k) ? 0.0f : this.f1423k);
                    break;
                case "translationX":
                    rVar.e(i10, Float.isNaN(this.f1428p) ? 0.0f : this.f1428p);
                    break;
                case "translationY":
                    rVar.e(i10, Float.isNaN(this.f1429q) ? 0.0f : this.f1429q);
                    break;
                case "translationZ":
                    rVar.e(i10, Float.isNaN(this.f1430r) ? 0.0f : this.f1430r);
                    break;
                case "progress":
                    rVar.e(i10, Float.isNaN(this.A) ? 0.0f : this.A);
                    break;
                case "scaleX":
                    rVar.e(i10, Float.isNaN(this.f1424l) ? 1.0f : this.f1424l);
                    break;
                case "scaleY":
                    rVar.e(i10, Float.isNaN(this.f1425m) ? 1.0f : this.f1425m);
                    break;
                case "transformPivotX":
                    rVar.e(i10, Float.isNaN(this.f1426n) ? 0.0f : this.f1426n);
                    break;
                case "transformPivotY":
                    rVar.e(i10, Float.isNaN(this.f1427o) ? 0.0f : this.f1427o);
                    break;
                case "rotation":
                    rVar.e(i10, Float.isNaN(this.f1421i) ? 0.0f : this.f1421i);
                    break;
                case "elevation":
                    rVar.e(i10, Float.isNaN(this.f1420h) ? 0.0f : this.f1420h);
                    break;
                case "transitionPathRotate":
                    rVar.e(i10, Float.isNaN(this.f1438z) ? 0.0f : this.f1438z);
                    break;
                case "alpha":
                    rVar.e(i10, Float.isNaN(this.f1416a) ? 1.0f : this.f1416a);
                    break;
                default:
                    if (!str.startsWith("CUSTOM")) {
                        Log.e("MotionPaths", "UNKNOWN spline " + str);
                        break;
                    } else {
                        String str2 = str.split(",")[1];
                        if (this.B.containsKey(str2)) {
                            ConstraintAttribute constraintAttribute = this.B.get(str2);
                            if (rVar instanceof r.b) {
                                ((r.b) rVar).i(i10, constraintAttribute);
                            } else {
                                Log.e("MotionPaths", str + " splineSet not a CustomSet frame = " + i10 + ", value" + constraintAttribute.d() + rVar);
                            }
                        } else {
                            Log.e("MotionPaths", "UNKNOWN customName " + str2);
                        }
                        break;
                    }
                    break;
            }
        }
    }

    public void b(View view) {
        this.f1418c = view.getVisibility();
        this.f1416a = view.getVisibility() != 0 ? 0.0f : view.getAlpha();
        this.f1419g = false;
        this.f1420h = view.getElevation();
        this.f1421i = view.getRotation();
        this.f1422j = view.getRotationX();
        this.f1423k = view.getRotationY();
        this.f1424l = view.getScaleX();
        this.f1425m = view.getScaleY();
        this.f1426n = view.getPivotX();
        this.f1427o = view.getPivotY();
        this.f1428p = view.getTranslationX();
        this.f1429q = view.getTranslationY();
        this.f1430r = view.getTranslationZ();
    }

    public void c(androidx.constraintlayout.widget.b.a aVar) {
        androidx.constraintlayout.widget.b.d dVar = aVar.f2010b;
        int i10 = dVar.f2062c;
        this.f1417b = i10;
        int i11 = dVar.f2061b;
        this.f1418c = i11;
        this.f1416a = (i11 == 0 || i10 != 0) ? dVar.f2063d : 0.0f;
        androidx.constraintlayout.widget.b.e eVar = aVar.f2013e;
        this.f1419g = eVar.f2077l;
        this.f1420h = eVar.f2078m;
        this.f1421i = eVar.f2067b;
        this.f1422j = eVar.f2068c;
        this.f1423k = eVar.f2069d;
        this.f1424l = eVar.f2070e;
        this.f1425m = eVar.f2071f;
        this.f1426n = eVar.f2072g;
        this.f1427o = eVar.f2073h;
        this.f1428p = eVar.f2074i;
        this.f1429q = eVar.f2075j;
        this.f1430r = eVar.f2076k;
        this.f1431s = s.c.c(aVar.f2011c.f2055c);
        androidx.constraintlayout.widget.b.c cVar = aVar.f2011c;
        this.f1438z = cVar.f2059g;
        this.f1432t = cVar.f2057e;
        this.A = aVar.f2010b.f2064e;
        for (String str : aVar.f2014f.keySet()) {
            ConstraintAttribute constraintAttribute = aVar.f2014f.get(str);
            if (constraintAttribute.c() != ConstraintAttribute.AttributeType.STRING_TYPE) {
                this.B.put(str, constraintAttribute);
            }
        }
    }

    @Override // java.lang.Comparable
    /* JADX INFO: renamed from: d, reason: merged with bridge method [inline-methods] */
    public int compareTo(m mVar) {
        return Float.compare(this.f1433u, mVar.f1433u);
    }

    void f(m mVar, HashSet<String> hashSet) {
        if (e(this.f1416a, mVar.f1416a)) {
            hashSet.add(ViewEntity.ALPHA);
        }
        if (e(this.f1420h, mVar.f1420h)) {
            hashSet.add(ViewEntity.ELEVATION);
        }
        int i10 = this.f1418c;
        int i11 = mVar.f1418c;
        if (i10 != i11 && this.f1417b == 0 && (i10 == 0 || i11 == 0)) {
            hashSet.add(ViewEntity.ALPHA);
        }
        if (e(this.f1421i, mVar.f1421i)) {
            hashSet.add(ViewEntity.ROTATION);
        }
        if (!Float.isNaN(this.f1438z) || !Float.isNaN(mVar.f1438z)) {
            hashSet.add("transitionPathRotate");
        }
        if (!Float.isNaN(this.A) || !Float.isNaN(mVar.A)) {
            hashSet.add(ParserTag.TAG_PROGRESS);
        }
        if (e(this.f1422j, mVar.f1422j)) {
            hashSet.add(ViewEntity.ROTATION_X);
        }
        if (e(this.f1423k, mVar.f1423k)) {
            hashSet.add(ViewEntity.ROTATION_Y);
        }
        if (e(this.f1426n, mVar.f1426n)) {
            hashSet.add(ViewEntity.TRANSFORM_PIVOT_X);
        }
        if (e(this.f1427o, mVar.f1427o)) {
            hashSet.add(ViewEntity.TRANSFORM_PIVOT_Y);
        }
        if (e(this.f1424l, mVar.f1424l)) {
            hashSet.add(ViewEntity.SCALE_X);
        }
        if (e(this.f1425m, mVar.f1425m)) {
            hashSet.add(ViewEntity.SCALE_Y);
        }
        if (e(this.f1428p, mVar.f1428p)) {
            hashSet.add(ViewEntity.TRANSLATION_X);
        }
        if (e(this.f1429q, mVar.f1429q)) {
            hashSet.add(ViewEntity.TRANSLATION_Y);
        }
        if (e(this.f1430r, mVar.f1430r)) {
            hashSet.add(ViewEntity.TRANSLATION_Z);
        }
    }

    void g(float f10, float f11, float f12, float f13) {
        this.f1434v = f10;
        this.f1435w = f11;
        this.f1436x = f12;
        this.f1437y = f13;
    }

    public void h(View view) {
        g(view.getX(), view.getY(), view.getWidth(), view.getHeight());
        b(view);
    }

    public void i(ConstraintWidget constraintWidget, androidx.constraintlayout.widget.b bVar, int i10) {
        g(constraintWidget.R(), constraintWidget.S(), constraintWidget.Q(), constraintWidget.w());
        c(bVar.s(i10));
    }
}
