package androidx.constraintlayout.motion.widget;

import android.content.Context;
import android.util.Log;
import android.util.Xml;
import androidx.constraintlayout.widget.ConstraintAttribute;
import androidx.constraintlayout.widget.ConstraintLayout;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.HashMap;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

/* JADX INFO: compiled from: KeyFrames.java */
/* JADX INFO: loaded from: classes.dex */
public class h {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    static HashMap<String, Constructor<? extends c>> f1361b;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private HashMap<Integer, ArrayList<c>> f1362a = new HashMap<>();

    static {
        HashMap<String, Constructor<? extends c>> map = new HashMap<>();
        f1361b = map;
        try {
            map.put("KeyAttribute", d.class.getConstructor(null));
            f1361b.put("KeyPosition", i.class.getConstructor(null));
            f1361b.put("KeyCycle", f.class.getConstructor(null));
            f1361b.put("KeyTimeCycle", k.class.getConstructor(null));
            f1361b.put("KeyTrigger", l.class.getConstructor(null));
        } catch (NoSuchMethodException e10) {
            Log.e("KeyFrames", "unable to load", e10);
        }
    }

    public h(Context context, XmlPullParser xmlPullParser) {
        Exception e10;
        c cVarNewInstance;
        HashMap<String, ConstraintAttribute> map;
        try {
            int eventType = xmlPullParser.getEventType();
            c cVar = null;
            while (eventType != 1) {
                if (eventType == 2) {
                    String name = xmlPullParser.getName();
                    if (f1361b.containsKey(name)) {
                        try {
                            cVarNewInstance = f1361b.get(name).newInstance(null);
                            try {
                                cVarNewInstance.c(context, Xml.asAttributeSet(xmlPullParser));
                                b(cVarNewInstance);
                            } catch (Exception e11) {
                                e10 = e11;
                                Log.e("KeyFrames", "unable to create ", e10);
                            }
                        } catch (Exception e12) {
                            c cVar2 = cVar;
                            e10 = e12;
                            cVarNewInstance = cVar2;
                        }
                        cVar = cVarNewInstance;
                    } else if (name.equalsIgnoreCase("CustomAttribute") && cVar != null && (map = cVar.f1295e) != null) {
                        ConstraintAttribute.g(context, xmlPullParser, map);
                    }
                } else if (eventType == 3 && "KeyFrameSet".equals(xmlPullParser.getName())) {
                    return;
                }
                eventType = xmlPullParser.next();
            }
        } catch (IOException e13) {
            e13.printStackTrace();
        } catch (XmlPullParserException e14) {
            e14.printStackTrace();
        }
    }

    private void b(c cVar) {
        if (!this.f1362a.containsKey(Integer.valueOf(cVar.f1292b))) {
            this.f1362a.put(Integer.valueOf(cVar.f1292b), new ArrayList<>());
        }
        this.f1362a.get(Integer.valueOf(cVar.f1292b)).add(cVar);
    }

    public void a(n nVar) {
        ArrayList<c> arrayList = this.f1362a.get(Integer.valueOf(nVar.f1440b));
        if (arrayList != null) {
            nVar.b(arrayList);
        }
        ArrayList<c> arrayList2 = this.f1362a.get(-1);
        if (arrayList2 != null) {
            for (c cVar : arrayList2) {
                if (cVar.d(((ConstraintLayout.LayoutParams) nVar.f1439a.getLayoutParams()).constraintTag)) {
                    nVar.a(cVar);
                }
            }
        }
    }
}
