package androidx.constraintlayout.motion.widget;

import android.view.View;
import androidx.constraintlayout.widget.ConstraintAttribute;
import com.oplus.sceneservice.sdk.dataprovider.bean.UserProfileInfo;
import java.util.Arrays;
import java.util.LinkedHashMap;

/* JADX INFO: compiled from: MotionPaths.java */
/* JADX INFO: loaded from: classes.dex */
class p implements Comparable<p> {

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    static String[] f1465s = {"position", "x", "y", "width", "height", "pathRotate"};

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    s.c f1466a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    int f1467b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    float f1468c;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    float f1469g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    float f1470h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    float f1471i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    float f1472j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    float f1473k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    float f1474l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    float f1475m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    int f1476n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    LinkedHashMap<String, ConstraintAttribute> f1477o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    int f1478p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    double[] f1479q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    double[] f1480r;

    public p() {
        this.f1467b = 0;
        this.f1474l = Float.NaN;
        this.f1475m = Float.NaN;
        this.f1476n = c.f1290f;
        this.f1477o = new LinkedHashMap<>();
        this.f1478p = 0;
        this.f1479q = new double[18];
        this.f1480r = new double[18];
    }

    private boolean c(float f10, float f11) {
        if (Float.isNaN(f10) || Float.isNaN(f11)) {
            return Float.isNaN(f10) != Float.isNaN(f11);
        }
        return Math.abs(f10 - f11) > 1.0E-6f;
    }

    public void a(androidx.constraintlayout.widget.b.a aVar) {
        this.f1466a = s.c.c(aVar.f2011c.f2055c);
        androidx.constraintlayout.widget.b.c cVar = aVar.f2011c;
        this.f1476n = cVar.f2056d;
        this.f1474l = cVar.f2059g;
        this.f1467b = cVar.f2057e;
        this.f1475m = aVar.f2010b.f2064e;
        for (String str : aVar.f2014f.keySet()) {
            ConstraintAttribute constraintAttribute = aVar.f2014f.get(str);
            if (constraintAttribute.c() != ConstraintAttribute.AttributeType.STRING_TYPE) {
                this.f1477o.put(str, constraintAttribute);
            }
        }
    }

    @Override // java.lang.Comparable
    /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
    public int compareTo(p pVar) {
        return Float.compare(this.f1469g, pVar.f1469g);
    }

    void d(p pVar, boolean[] zArr, String[] strArr, boolean z10) {
        zArr[0] = zArr[0] | c(this.f1469g, pVar.f1469g);
        zArr[1] = zArr[1] | c(this.f1470h, pVar.f1470h) | z10;
        zArr[2] = z10 | c(this.f1471i, pVar.f1471i) | zArr[2];
        zArr[3] = zArr[3] | c(this.f1472j, pVar.f1472j);
        zArr[4] = c(this.f1473k, pVar.f1473k) | zArr[4];
    }

    void e(double[] dArr, int[] iArr) {
        float[] fArr = {this.f1469g, this.f1470h, this.f1471i, this.f1472j, this.f1473k, this.f1474l};
        int i10 = 0;
        for (int i11 : iArr) {
            if (i11 < 6) {
                dArr[i10] = fArr[i11];
                i10++;
            }
        }
    }

    void f(int[] iArr, double[] dArr, float[] fArr, int i10) {
        float f10 = this.f1470h;
        float f11 = this.f1471i;
        float f12 = this.f1472j;
        float f13 = this.f1473k;
        for (int i11 = 0; i11 < iArr.length; i11++) {
            float f14 = (float) dArr[i11];
            int i12 = iArr[i11];
            if (i12 == 1) {
                f10 = f14;
            } else if (i12 == 2) {
                f11 = f14;
            } else if (i12 == 3) {
                f12 = f14;
            } else if (i12 == 4) {
                f13 = f14;
            }
        }
        fArr[i10] = f10 + (f12 / 2.0f) + 0.0f;
        fArr[i10 + 1] = f11 + (f13 / 2.0f) + 0.0f;
    }

    int g(String str, double[] dArr, int i10) {
        ConstraintAttribute constraintAttribute = this.f1477o.get(str);
        if (constraintAttribute.f() == 1) {
            dArr[i10] = constraintAttribute.d();
            return 1;
        }
        int iF = constraintAttribute.f();
        float[] fArr = new float[iF];
        constraintAttribute.e(fArr);
        int i11 = 0;
        while (i11 < iF) {
            dArr[i10] = fArr[i11];
            i11++;
            i10++;
        }
        return iF;
    }

    int h(String str) {
        return this.f1477o.get(str).f();
    }

    void i(int[] iArr, double[] dArr, float[] fArr, int i10) {
        float f10 = this.f1470h;
        float f11 = this.f1471i;
        float f12 = this.f1472j;
        float f13 = this.f1473k;
        for (int i11 = 0; i11 < iArr.length; i11++) {
            float f14 = (float) dArr[i11];
            int i12 = iArr[i11];
            if (i12 == 1) {
                f10 = f14;
            } else if (i12 == 2) {
                f11 = f14;
            } else if (i12 == 3) {
                f12 = f14;
            } else if (i12 == 4) {
                f13 = f14;
            }
        }
        float f15 = f12 + f10;
        float f16 = f13 + f11;
        Float.isNaN(Float.NaN);
        Float.isNaN(Float.NaN);
        fArr[i10] = f10 + 0.0f;
        fArr[i10 + 1] = f11 + 0.0f;
        fArr[i10 + 2] = f15 + 0.0f;
        fArr[i10 + 3] = f11 + 0.0f;
        fArr[i10 + 4] = f15 + 0.0f;
        int i13 = i10 + 6;
        fArr[i10 + 5] = f16 + 0.0f;
        fArr[i13] = f10 + 0.0f;
        fArr[i10 + 7] = f16 + 0.0f;
    }

    boolean j(String str) {
        return this.f1477o.containsKey(str);
    }

    void k(i iVar, p pVar, p pVar2) {
        float f10 = iVar.f1291a / 100.0f;
        this.f1468c = f10;
        this.f1467b = iVar.f1365j;
        float f11 = Float.isNaN(iVar.f1366k) ? f10 : iVar.f1366k;
        float f12 = Float.isNaN(iVar.f1367l) ? f10 : iVar.f1367l;
        float f13 = pVar2.f1472j;
        float f14 = pVar.f1472j;
        float f15 = pVar2.f1473k;
        float f16 = pVar.f1473k;
        this.f1469g = this.f1468c;
        float f17 = pVar.f1470h;
        float f18 = pVar.f1471i;
        float f19 = (pVar2.f1470h + (f13 / 2.0f)) - ((f14 / 2.0f) + f17);
        float f20 = (pVar2.f1471i + (f15 / 2.0f)) - (f18 + (f16 / 2.0f));
        float f21 = (f13 - f14) * f11;
        float f22 = f21 / 2.0f;
        this.f1470h = (int) ((f17 + (f19 * f10)) - f22);
        float f23 = (f15 - f16) * f12;
        float f24 = f23 / 2.0f;
        this.f1471i = (int) ((f18 + (f20 * f10)) - f24);
        this.f1472j = (int) (f14 + f21);
        this.f1473k = (int) (f16 + f23);
        float f25 = Float.isNaN(iVar.f1368m) ? f10 : iVar.f1368m;
        float f26 = Float.isNaN(iVar.f1371p) ? 0.0f : iVar.f1371p;
        if (!Float.isNaN(iVar.f1369n)) {
            f10 = iVar.f1369n;
        }
        float f27 = Float.isNaN(iVar.f1370o) ? 0.0f : iVar.f1370o;
        this.f1478p = 2;
        this.f1470h = (int) (((pVar.f1470h + (f25 * f19)) + (f27 * f20)) - f22);
        this.f1471i = (int) (((pVar.f1471i + (f19 * f26)) + (f20 * f10)) - f24);
        this.f1466a = s.c.c(iVar.f1363h);
        this.f1476n = iVar.f1364i;
    }

    void l(i iVar, p pVar, p pVar2) {
        float f10 = iVar.f1291a / 100.0f;
        this.f1468c = f10;
        this.f1467b = iVar.f1365j;
        float f11 = Float.isNaN(iVar.f1366k) ? f10 : iVar.f1366k;
        float f12 = Float.isNaN(iVar.f1367l) ? f10 : iVar.f1367l;
        float f13 = pVar2.f1472j - pVar.f1472j;
        float f14 = pVar2.f1473k - pVar.f1473k;
        this.f1469g = this.f1468c;
        if (!Float.isNaN(iVar.f1368m)) {
            f10 = iVar.f1368m;
        }
        float f15 = pVar.f1470h;
        float f16 = pVar.f1472j;
        float f17 = pVar.f1471i;
        float f18 = pVar.f1473k;
        float f19 = (pVar2.f1470h + (pVar2.f1472j / 2.0f)) - ((f16 / 2.0f) + f15);
        float f20 = (pVar2.f1471i + (pVar2.f1473k / 2.0f)) - ((f18 / 2.0f) + f17);
        float f21 = f19 * f10;
        float f22 = f13 * f11;
        float f23 = f22 / 2.0f;
        this.f1470h = (int) ((f15 + f21) - f23);
        float f24 = f10 * f20;
        float f25 = f14 * f12;
        float f26 = f25 / 2.0f;
        this.f1471i = (int) ((f17 + f24) - f26);
        this.f1472j = (int) (f16 + f22);
        this.f1473k = (int) (f18 + f25);
        float f27 = Float.isNaN(iVar.f1369n) ? 0.0f : iVar.f1369n;
        this.f1478p = 1;
        float f28 = (int) ((pVar.f1470h + f21) - f23);
        float f29 = (int) ((pVar.f1471i + f24) - f26);
        this.f1470h = f28 + ((-f20) * f27);
        this.f1471i = f29 + (f19 * f27);
        this.f1466a = s.c.c(iVar.f1363h);
        this.f1476n = iVar.f1364i;
    }

    void m(int i10, int i11, i iVar, p pVar, p pVar2) {
        float f10 = iVar.f1291a / 100.0f;
        this.f1468c = f10;
        this.f1467b = iVar.f1365j;
        float f11 = Float.isNaN(iVar.f1366k) ? f10 : iVar.f1366k;
        float f12 = Float.isNaN(iVar.f1367l) ? f10 : iVar.f1367l;
        float f13 = pVar2.f1472j;
        float f14 = pVar.f1472j;
        float f15 = pVar2.f1473k;
        float f16 = pVar.f1473k;
        this.f1469g = this.f1468c;
        float f17 = pVar.f1470h;
        float f18 = pVar.f1471i;
        float f19 = pVar2.f1470h + (f13 / 2.0f);
        float f20 = pVar2.f1471i + (f15 / 2.0f);
        float f21 = (f13 - f14) * f11;
        this.f1470h = (int) ((f17 + ((f19 - ((f14 / 2.0f) + f17)) * f10)) - (f21 / 2.0f));
        float f22 = (f15 - f16) * f12;
        this.f1471i = (int) ((f18 + ((f20 - (f18 + (f16 / 2.0f))) * f10)) - (f22 / 2.0f));
        this.f1472j = (int) (f14 + f21);
        this.f1473k = (int) (f16 + f22);
        this.f1478p = 3;
        if (!Float.isNaN(iVar.f1368m)) {
            this.f1470h = (int) (iVar.f1368m * ((int) (i10 - this.f1472j)));
        }
        if (!Float.isNaN(iVar.f1369n)) {
            this.f1471i = (int) (iVar.f1369n * ((int) (i11 - this.f1473k)));
        }
        this.f1466a = s.c.c(iVar.f1363h);
        this.f1476n = iVar.f1364i;
    }

    void n(float f10, float f11, float f12, float f13) {
        this.f1470h = f10;
        this.f1471i = f11;
        this.f1472j = f12;
        this.f1473k = f13;
    }

    void o(float f10, float f11, float[] fArr, int[] iArr, double[] dArr, double[] dArr2) {
        float f12 = 0.0f;
        float f13 = 0.0f;
        float f14 = 0.0f;
        float f15 = 0.0f;
        for (int i10 = 0; i10 < iArr.length; i10++) {
            float f16 = (float) dArr[i10];
            double d10 = dArr2[i10];
            int i11 = iArr[i10];
            if (i11 == 1) {
                f12 = f16;
            } else if (i11 == 2) {
                f14 = f16;
            } else if (i11 == 3) {
                f13 = f16;
            } else if (i11 == 4) {
                f15 = f16;
            }
        }
        float f17 = f12 - ((0.0f * f13) / 2.0f);
        float f18 = f14 - ((0.0f * f15) / 2.0f);
        fArr[0] = (f17 * (1.0f - f10)) + (((f13 * 1.0f) + f17) * f10) + 0.0f;
        fArr[1] = (f18 * (1.0f - f11)) + (((f15 * 1.0f) + f18) * f11) + 0.0f;
    }

    void p(View view, int[] iArr, double[] dArr, double[] dArr2, double[] dArr3) {
        float f10;
        float f11 = this.f1470h;
        float f12 = this.f1471i;
        float f13 = this.f1472j;
        float f14 = this.f1473k;
        if (iArr.length != 0 && this.f1479q.length <= iArr[iArr.length - 1]) {
            int i10 = iArr[iArr.length - 1] + 1;
            this.f1479q = new double[i10];
            this.f1480r = new double[i10];
        }
        Arrays.fill(this.f1479q, Double.NaN);
        int i11 = 0;
        for (int i12 = 0; i12 < iArr.length; i12++) {
            double[] dArr4 = this.f1479q;
            int i13 = iArr[i12];
            dArr4[i13] = dArr[i12];
            this.f1480r[i13] = dArr2[i12];
        }
        float f15 = Float.NaN;
        float f16 = 0.0f;
        float f17 = 0.0f;
        float f18 = 0.0f;
        float f19 = 0.0f;
        while (true) {
            double[] dArr5 = this.f1479q;
            if (i11 >= dArr5.length) {
                break;
            }
            boolean zIsNaN = Double.isNaN(dArr5[i11]);
            double d10 = UserProfileInfo.Constant.NA_LAT_LON;
            if (zIsNaN && (dArr3 == null || dArr3[i11] == UserProfileInfo.Constant.NA_LAT_LON)) {
                f10 = f15;
            } else {
                if (dArr3 != null) {
                    d10 = dArr3[i11];
                }
                if (!Double.isNaN(this.f1479q[i11])) {
                    d10 = this.f1479q[i11] + d10;
                }
                f10 = f15;
                float f20 = (float) d10;
                float f21 = (float) this.f1480r[i11];
                if (i11 == 1) {
                    f15 = f10;
                    f11 = f20;
                    f16 = f21;
                } else if (i11 == 2) {
                    f15 = f10;
                    f12 = f20;
                    f18 = f21;
                } else if (i11 == 3) {
                    f15 = f10;
                    f13 = f20;
                    f17 = f21;
                } else if (i11 == 4) {
                    f15 = f10;
                    f14 = f20;
                    f19 = f21;
                } else if (i11 == 5) {
                    f15 = f20;
                }
                i11++;
            }
            f15 = f10;
            i11++;
        }
        float f22 = f15;
        if (!Float.isNaN(f22)) {
            view.setRotation((float) (((double) (Float.isNaN(Float.NaN) ? 0.0f : Float.NaN)) + ((double) f22) + Math.toDegrees(Math.atan2(f18 + (f19 / 2.0f), f16 + (f17 / 2.0f)))));
        } else if (!Float.isNaN(Float.NaN)) {
            view.setRotation(Float.NaN);
        }
        float f23 = f11 + 0.5f;
        int i14 = (int) f23;
        float f24 = f12 + 0.5f;
        int i15 = (int) f24;
        int i16 = (int) (f23 + f13);
        int i17 = (int) (f24 + f14);
        int i18 = i16 - i14;
        int i19 = i17 - i15;
        if (i18 != view.getMeasuredWidth() || i19 != view.getMeasuredHeight()) {
            view.measure(View.MeasureSpec.makeMeasureSpec(i18, 1073741824), View.MeasureSpec.makeMeasureSpec(i19, 1073741824));
        }
        view.layout(i14, i15, i16, i17);
    }

    public p(int i10, int i11, i iVar, p pVar, p pVar2) {
        this.f1467b = 0;
        this.f1474l = Float.NaN;
        this.f1475m = Float.NaN;
        this.f1476n = c.f1290f;
        this.f1477o = new LinkedHashMap<>();
        this.f1478p = 0;
        this.f1479q = new double[18];
        this.f1480r = new double[18];
        int i12 = iVar.f1372q;
        if (i12 == 1) {
            l(iVar, pVar, pVar2);
        } else if (i12 != 2) {
            k(iVar, pVar, pVar2);
        } else {
            m(i10, i11, iVar, pVar, pVar2);
        }
    }
}
