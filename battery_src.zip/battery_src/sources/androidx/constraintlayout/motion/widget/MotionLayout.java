package androidx.constraintlayout.motion.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.os.Bundle;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.util.SparseIntArray;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Interpolator;
import androidx.constraintlayout.solver.widgets.ConstraintWidget;
import androidx.constraintlayout.widget.Barrier;
import androidx.constraintlayout.widget.ConstraintHelper;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.Constraints;
import androidx.constraintlayout.widget.R$styleable;
import androidx.core.view.v;
import com.oplus.sceneservice.sdk.dataprovider.bean.UserProfileInfo;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

/* JADX INFO: loaded from: classes.dex */
public class MotionLayout extends ConstraintLayout implements v {

    /* JADX INFO: renamed from: t0, reason: collision with root package name */
    public static boolean f1189t0;
    d A;
    private boolean B;
    private s.g C;
    private c D;
    private androidx.constraintlayout.motion.widget.b E;
    boolean F;
    int G;
    int H;
    int I;
    int J;
    boolean K;
    float L;
    float M;
    long N;
    float O;
    private boolean P;
    private ArrayList<MotionHelper> Q;
    private ArrayList<MotionHelper> R;
    private ArrayList<i> S;
    private int T;
    private long U;
    private float V;
    private int W;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    q f1190a;

    /* JADX INFO: renamed from: a0, reason: collision with root package name */
    private float f1191a0;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    Interpolator f1192b;

    /* JADX INFO: renamed from: b0, reason: collision with root package name */
    boolean f1193b0;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    float f1194c;

    /* JADX INFO: renamed from: c0, reason: collision with root package name */
    protected boolean f1195c0;

    /* JADX INFO: renamed from: d0, reason: collision with root package name */
    int f1196d0;

    /* JADX INFO: renamed from: e0, reason: collision with root package name */
    int f1197e0;

    /* JADX INFO: renamed from: f0, reason: collision with root package name */
    int f1198f0;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private int f1199g;

    /* JADX INFO: renamed from: g0, reason: collision with root package name */
    int f1200g0;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    int f1201h;

    /* JADX INFO: renamed from: h0, reason: collision with root package name */
    int f1202h0;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private int f1203i;

    /* JADX INFO: renamed from: i0, reason: collision with root package name */
    int f1204i0;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private int f1205j;

    /* JADX INFO: renamed from: j0, reason: collision with root package name */
    float f1206j0;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    private int f1207k;

    /* JADX INFO: renamed from: k0, reason: collision with root package name */
    private androidx.constraintlayout.motion.widget.e f1208k0;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private boolean f1209l;

    /* JADX INFO: renamed from: l0, reason: collision with root package name */
    private boolean f1210l0;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    HashMap<View, n> f1211m;

    /* JADX INFO: renamed from: m0, reason: collision with root package name */
    private h f1212m0;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    private long f1213n;

    /* JADX INFO: renamed from: n0, reason: collision with root package name */
    TransitionState f1214n0;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    private float f1215o;

    /* JADX INFO: renamed from: o0, reason: collision with root package name */
    e f1216o0;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    float f1217p;

    /* JADX INFO: renamed from: p0, reason: collision with root package name */
    private boolean f1218p0;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    float f1219q;

    /* JADX INFO: renamed from: q0, reason: collision with root package name */
    private RectF f1220q0;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    private long f1221r;

    /* JADX INFO: renamed from: r0, reason: collision with root package name */
    private View f1222r0;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    float f1223s;

    /* JADX INFO: renamed from: s0, reason: collision with root package name */
    ArrayList<Integer> f1224s0;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    private boolean f1225t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    boolean f1226u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    boolean f1227v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    private i f1228w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    private float f1229x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    private float f1230y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    int f1231z;

    enum TransitionState {
        UNDEFINED,
        SETUP,
        MOVING,
        FINISHED
    }

    class a implements Runnable {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        final /* synthetic */ View f1237a;

        a(View view) {
            this.f1237a = view;
        }

        @Override // java.lang.Runnable
        public void run() {
            this.f1237a.setNestedScrollingEnabled(true);
        }
    }

    static /* synthetic */ class b {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        static final /* synthetic */ int[] f1239a;

        static {
            int[] iArr = new int[TransitionState.values().length];
            f1239a = iArr;
            try {
                iArr[TransitionState.UNDEFINED.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                f1239a[TransitionState.SETUP.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                f1239a[TransitionState.MOVING.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                f1239a[TransitionState.FINISHED.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
        }
    }

    class c extends o {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        float f1240a = 0.0f;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        float f1241b = 0.0f;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        float f1242c;

        c() {
        }

        @Override // androidx.constraintlayout.motion.widget.o
        public float a() {
            return MotionLayout.this.f1194c;
        }

        public void b(float f10, float f11, float f12) {
            this.f1240a = f10;
            this.f1241b = f11;
            this.f1242c = f12;
        }

        @Override // android.animation.TimeInterpolator
        public float getInterpolation(float f10) {
            float f11;
            float f12;
            float f13 = this.f1240a;
            if (f13 > 0.0f) {
                float f14 = this.f1242c;
                if (f13 / f14 < f10) {
                    f10 = f13 / f14;
                }
                MotionLayout.this.f1194c = f13 - (f14 * f10);
                f11 = (f13 * f10) - (((f14 * f10) * f10) / 2.0f);
                f12 = this.f1241b;
            } else {
                float f15 = this.f1242c;
                if ((-f13) / f15 < f10) {
                    f10 = (-f13) / f15;
                }
                MotionLayout.this.f1194c = (f15 * f10) + f13;
                f11 = (f13 * f10) + (((f15 * f10) * f10) / 2.0f);
                f12 = this.f1241b;
            }
            return f11 + f12;
        }
    }

    private class d {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        float[] f1244a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        int[] f1245b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        float[] f1246c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        Path f1247d;

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        Paint f1248e;

        /* JADX INFO: renamed from: f, reason: collision with root package name */
        Paint f1249f;

        /* JADX INFO: renamed from: g, reason: collision with root package name */
        Paint f1250g;

        /* JADX INFO: renamed from: h, reason: collision with root package name */
        Paint f1251h;

        /* JADX INFO: renamed from: i, reason: collision with root package name */
        Paint f1252i;

        /* JADX INFO: renamed from: j, reason: collision with root package name */
        private float[] f1253j;

        /* JADX INFO: renamed from: p, reason: collision with root package name */
        DashPathEffect f1259p;

        /* JADX INFO: renamed from: q, reason: collision with root package name */
        int f1260q;

        /* JADX INFO: renamed from: t, reason: collision with root package name */
        int f1263t;

        /* JADX INFO: renamed from: k, reason: collision with root package name */
        final int f1254k = -21965;

        /* JADX INFO: renamed from: l, reason: collision with root package name */
        final int f1255l = -2067046;

        /* JADX INFO: renamed from: m, reason: collision with root package name */
        final int f1256m = -13391360;

        /* JADX INFO: renamed from: n, reason: collision with root package name */
        final int f1257n = 1996488704;

        /* JADX INFO: renamed from: o, reason: collision with root package name */
        final int f1258o = 10;

        /* JADX INFO: renamed from: r, reason: collision with root package name */
        Rect f1261r = new Rect();

        /* JADX INFO: renamed from: s, reason: collision with root package name */
        boolean f1262s = false;

        public d() {
            this.f1263t = 1;
            Paint paint = new Paint();
            this.f1248e = paint;
            paint.setAntiAlias(true);
            this.f1248e.setColor(-21965);
            this.f1248e.setStrokeWidth(2.0f);
            Paint paint2 = this.f1248e;
            Paint.Style style = Paint.Style.STROKE;
            paint2.setStyle(style);
            Paint paint3 = new Paint();
            this.f1249f = paint3;
            paint3.setAntiAlias(true);
            this.f1249f.setColor(-2067046);
            this.f1249f.setStrokeWidth(2.0f);
            this.f1249f.setStyle(style);
            Paint paint4 = new Paint();
            this.f1250g = paint4;
            paint4.setAntiAlias(true);
            this.f1250g.setColor(-13391360);
            this.f1250g.setStrokeWidth(2.0f);
            this.f1250g.setStyle(style);
            Paint paint5 = new Paint();
            this.f1251h = paint5;
            paint5.setAntiAlias(true);
            this.f1251h.setColor(-13391360);
            this.f1251h.setTextSize(MotionLayout.this.getContext().getResources().getDisplayMetrics().density * 12.0f);
            this.f1253j = new float[8];
            Paint paint6 = new Paint();
            this.f1252i = paint6;
            paint6.setAntiAlias(true);
            DashPathEffect dashPathEffect = new DashPathEffect(new float[]{4.0f, 8.0f}, 0.0f);
            this.f1259p = dashPathEffect;
            this.f1250g.setPathEffect(dashPathEffect);
            this.f1246c = new float[100];
            this.f1245b = new int[50];
            if (this.f1262s) {
                this.f1248e.setStrokeWidth(8.0f);
                this.f1252i.setStrokeWidth(8.0f);
                this.f1249f.setStrokeWidth(8.0f);
                this.f1263t = 4;
            }
        }

        private void c(Canvas canvas) {
            canvas.drawLines(this.f1244a, this.f1248e);
        }

        private void d(Canvas canvas) {
            boolean z10 = false;
            boolean z11 = false;
            for (int i10 = 0; i10 < this.f1260q; i10++) {
                int i11 = this.f1245b[i10];
                if (i11 == 1) {
                    z10 = true;
                }
                if (i11 == 2) {
                    z11 = true;
                }
            }
            if (z10) {
                g(canvas);
            }
            if (z11) {
                e(canvas);
            }
        }

        private void e(Canvas canvas) {
            float[] fArr = this.f1244a;
            float f10 = fArr[0];
            float f11 = fArr[1];
            float f12 = fArr[fArr.length - 2];
            float f13 = fArr[fArr.length - 1];
            canvas.drawLine(Math.min(f10, f12), Math.max(f11, f13), Math.max(f10, f12), Math.max(f11, f13), this.f1250g);
            canvas.drawLine(Math.min(f10, f12), Math.min(f11, f13), Math.min(f10, f12), Math.max(f11, f13), this.f1250g);
        }

        private void f(Canvas canvas, float f10, float f11) {
            float[] fArr = this.f1244a;
            float f12 = fArr[0];
            float f13 = fArr[1];
            float f14 = fArr[fArr.length - 2];
            float f15 = fArr[fArr.length - 1];
            float fMin = Math.min(f12, f14);
            float fMax = Math.max(f13, f15);
            float fMin2 = f10 - Math.min(f12, f14);
            float fMax2 = Math.max(f13, f15) - f11;
            String str = "" + (((int) (((double) ((fMin2 * 100.0f) / Math.abs(f14 - f12))) + 0.5d)) / 100.0f);
            l(str, this.f1251h);
            canvas.drawText(str, ((fMin2 / 2.0f) - (this.f1261r.width() / 2)) + fMin, f11 - 20.0f, this.f1251h);
            canvas.drawLine(f10, f11, Math.min(f12, f14), f11, this.f1250g);
            String str2 = "" + (((int) (((double) ((fMax2 * 100.0f) / Math.abs(f15 - f13))) + 0.5d)) / 100.0f);
            l(str2, this.f1251h);
            canvas.drawText(str2, f10 + 5.0f, fMax - ((fMax2 / 2.0f) - (this.f1261r.height() / 2)), this.f1251h);
            canvas.drawLine(f10, f11, f10, Math.max(f13, f15), this.f1250g);
        }

        private void g(Canvas canvas) {
            float[] fArr = this.f1244a;
            canvas.drawLine(fArr[0], fArr[1], fArr[fArr.length - 2], fArr[fArr.length - 1], this.f1250g);
        }

        private void h(Canvas canvas, float f10, float f11) {
            float[] fArr = this.f1244a;
            float f12 = fArr[0];
            float f13 = fArr[1];
            float f14 = fArr[fArr.length - 2];
            float f15 = fArr[fArr.length - 1];
            float fHypot = (float) Math.hypot(f12 - f14, f13 - f15);
            float f16 = f14 - f12;
            float f17 = f15 - f13;
            float f18 = (((f10 - f12) * f16) + ((f11 - f13) * f17)) / (fHypot * fHypot);
            float f19 = f12 + (f16 * f18);
            float f20 = f13 + (f18 * f17);
            Path path = new Path();
            path.moveTo(f10, f11);
            path.lineTo(f19, f20);
            float fHypot2 = (float) Math.hypot(f19 - f10, f20 - f11);
            String str = "" + (((int) ((fHypot2 * 100.0f) / fHypot)) / 100.0f);
            l(str, this.f1251h);
            canvas.drawTextOnPath(str, path, (fHypot2 / 2.0f) - (this.f1261r.width() / 2), -20.0f, this.f1251h);
            canvas.drawLine(f10, f11, f19, f20, this.f1250g);
        }

        private void i(Canvas canvas, float f10, float f11, int i10, int i11) {
            String str = "" + (((int) (((double) (((f10 - (i10 / 2)) * 100.0f) / (MotionLayout.this.getWidth() - i10))) + 0.5d)) / 100.0f);
            l(str, this.f1251h);
            canvas.drawText(str, ((f10 / 2.0f) - (this.f1261r.width() / 2)) + 0.0f, f11 - 20.0f, this.f1251h);
            canvas.drawLine(f10, f11, Math.min(0.0f, 1.0f), f11, this.f1250g);
            String str2 = "" + (((int) (((double) (((f11 - (i11 / 2)) * 100.0f) / (MotionLayout.this.getHeight() - i11))) + 0.5d)) / 100.0f);
            l(str2, this.f1251h);
            canvas.drawText(str2, f10 + 5.0f, 0.0f - ((f11 / 2.0f) - (this.f1261r.height() / 2)), this.f1251h);
            canvas.drawLine(f10, f11, f10, Math.max(0.0f, 1.0f), this.f1250g);
        }

        private void j(Canvas canvas, n nVar) {
            this.f1247d.reset();
            for (int i10 = 0; i10 <= 50; i10++) {
                nVar.e(i10 / 50, this.f1253j, 0);
                Path path = this.f1247d;
                float[] fArr = this.f1253j;
                path.moveTo(fArr[0], fArr[1]);
                Path path2 = this.f1247d;
                float[] fArr2 = this.f1253j;
                path2.lineTo(fArr2[2], fArr2[3]);
                Path path3 = this.f1247d;
                float[] fArr3 = this.f1253j;
                path3.lineTo(fArr3[4], fArr3[5]);
                Path path4 = this.f1247d;
                float[] fArr4 = this.f1253j;
                path4.lineTo(fArr4[6], fArr4[7]);
                this.f1247d.close();
            }
            this.f1248e.setColor(1140850688);
            canvas.translate(2.0f, 2.0f);
            canvas.drawPath(this.f1247d, this.f1248e);
            canvas.translate(-2.0f, -2.0f);
            this.f1248e.setColor(-65536);
            canvas.drawPath(this.f1247d, this.f1248e);
        }

        private void k(Canvas canvas, int i10, int i11, n nVar) {
            int width;
            int height;
            View view = nVar.f1439a;
            if (view != null) {
                width = view.getWidth();
                height = nVar.f1439a.getHeight();
            } else {
                width = 0;
                height = 0;
            }
            for (int i12 = 1; i12 < i11 - 1; i12++) {
                if (i10 != 4 || this.f1245b[i12 - 1] != 0) {
                    float[] fArr = this.f1246c;
                    int i13 = i12 * 2;
                    float f10 = fArr[i13];
                    float f11 = fArr[i13 + 1];
                    this.f1247d.reset();
                    this.f1247d.moveTo(f10, f11 + 10.0f);
                    this.f1247d.lineTo(f10 + 10.0f, f11);
                    this.f1247d.lineTo(f10, f11 - 10.0f);
                    this.f1247d.lineTo(f10 - 10.0f, f11);
                    this.f1247d.close();
                    int i14 = i12 - 1;
                    nVar.k(i14);
                    int i15 = 3;
                    if (i10 == 4) {
                        int i16 = this.f1245b[i14];
                        if (i16 == 1) {
                            h(canvas, f10 - 0.0f, f11 - 0.0f);
                        } else if (i16 == 2) {
                            f(canvas, f10 - 0.0f, f11 - 0.0f);
                        } else {
                            if (i16 == 3) {
                                i(canvas, f10 - 0.0f, f11 - 0.0f, width, height);
                            }
                            canvas.drawPath(this.f1247d, this.f1252i);
                        }
                        canvas.drawPath(this.f1247d, this.f1252i);
                    } else {
                        i15 = 3;
                        f11 = f11;
                        f10 = f10;
                    }
                    if (i10 == 2) {
                        h(canvas, f10 - 0.0f, f11 - 0.0f);
                    }
                    if (i10 == i15) {
                        f(canvas, f10 - 0.0f, f11 - 0.0f);
                    }
                    if (i10 == 6) {
                        i(canvas, f10 - 0.0f, f11 - 0.0f, width, height);
                    }
                    canvas.drawPath(this.f1247d, this.f1252i);
                }
            }
            float[] fArr2 = this.f1244a;
            if (fArr2.length > 1) {
                canvas.drawCircle(fArr2[0], fArr2[1], 8.0f, this.f1249f);
                float[] fArr3 = this.f1244a;
                canvas.drawCircle(fArr3[fArr3.length - 2], fArr3[fArr3.length - 1], 8.0f, this.f1249f);
            }
        }

        public void a(Canvas canvas, HashMap<View, n> map, int i10, int i11) {
            if (map == null || map.size() == 0) {
                return;
            }
            canvas.save();
            if (!MotionLayout.this.isInEditMode() && (i11 & 1) == 2) {
                String str = MotionLayout.this.getContext().getResources().getResourceName(MotionLayout.this.f1203i) + ":" + MotionLayout.this.getProgress();
                canvas.drawText(str, 10.0f, MotionLayout.this.getHeight() - 30, this.f1251h);
                canvas.drawText(str, 11.0f, MotionLayout.this.getHeight() - 29, this.f1248e);
            }
            for (n nVar : map.values()) {
                int iH = nVar.h();
                if (i11 > 0 && iH == 0) {
                    iH = 1;
                }
                if (iH != 0) {
                    this.f1260q = nVar.c(this.f1246c, this.f1245b);
                    if (iH >= 1) {
                        int i12 = i10 / 16;
                        float[] fArr = this.f1244a;
                        if (fArr == null || fArr.length != i12 * 2) {
                            this.f1244a = new float[i12 * 2];
                            this.f1247d = new Path();
                        }
                        int i13 = this.f1263t;
                        canvas.translate(i13, i13);
                        this.f1248e.setColor(1996488704);
                        this.f1252i.setColor(1996488704);
                        this.f1249f.setColor(1996488704);
                        this.f1250g.setColor(1996488704);
                        nVar.d(this.f1244a, i12);
                        b(canvas, iH, this.f1260q, nVar);
                        this.f1248e.setColor(-21965);
                        this.f1249f.setColor(-2067046);
                        this.f1252i.setColor(-2067046);
                        this.f1250g.setColor(-13391360);
                        int i14 = this.f1263t;
                        canvas.translate(-i14, -i14);
                        b(canvas, iH, this.f1260q, nVar);
                        if (iH == 5) {
                            j(canvas, nVar);
                        }
                    }
                }
            }
            canvas.restore();
        }

        public void b(Canvas canvas, int i10, int i11, n nVar) {
            if (i10 == 4) {
                d(canvas);
            }
            if (i10 == 2) {
                g(canvas);
            }
            if (i10 == 3) {
                e(canvas);
            }
            c(canvas);
            k(canvas, i10, i11, nVar);
        }

        void l(String str, Paint paint) {
            paint.getTextBounds(str, 0, str.length(), this.f1261r);
        }
    }

    class e {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        androidx.constraintlayout.solver.widgets.d f1265a = new androidx.constraintlayout.solver.widgets.d();

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        androidx.constraintlayout.solver.widgets.d f1266b = new androidx.constraintlayout.solver.widgets.d();

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        androidx.constraintlayout.widget.b f1267c = null;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        androidx.constraintlayout.widget.b f1268d = null;

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        int f1269e;

        /* JADX INFO: renamed from: f, reason: collision with root package name */
        int f1270f;

        e() {
        }

        /* JADX WARN: Multi-variable type inference failed */
        private void i(androidx.constraintlayout.solver.widgets.d dVar, androidx.constraintlayout.widget.b bVar) {
            SparseArray<ConstraintWidget> sparseArray = new SparseArray<>();
            Constraints.LayoutParams layoutParams = new Constraints.LayoutParams(-2, -2);
            sparseArray.clear();
            sparseArray.put(0, dVar);
            sparseArray.put(MotionLayout.this.getId(), dVar);
            for (ConstraintWidget constraintWidget : dVar.L0()) {
                sparseArray.put(((View) constraintWidget.r()).getId(), constraintWidget);
            }
            for (ConstraintWidget constraintWidget2 : dVar.L0()) {
                View view = (View) constraintWidget2.r();
                bVar.g(view.getId(), layoutParams);
                constraintWidget2.F0(bVar.v(view.getId()));
                constraintWidget2.i0(bVar.q(view.getId()));
                if (view instanceof ConstraintHelper) {
                    bVar.e((ConstraintHelper) view, constraintWidget2, layoutParams, sparseArray);
                    if (view instanceof Barrier) {
                        ((Barrier) view).u();
                    }
                }
                layoutParams.resolveLayoutDirection(MotionLayout.this.getLayoutDirection());
                MotionLayout.this.applyConstraintsFromLayoutParams(false, view, constraintWidget2, layoutParams, sparseArray);
                if (bVar.u(view.getId()) == 1) {
                    constraintWidget2.E0(view.getVisibility());
                } else {
                    constraintWidget2.E0(bVar.t(view.getId()));
                }
            }
            for (ConstraintWidget constraintWidget3 : dVar.L0()) {
                if (constraintWidget3 instanceof androidx.constraintlayout.solver.widgets.h) {
                    ConstraintHelper constraintHelper = (ConstraintHelper) constraintWidget3.r();
                    u.a aVar = (u.a) constraintWidget3;
                    constraintHelper.s(dVar, aVar, sparseArray);
                    ((androidx.constraintlayout.solver.widgets.h) aVar).M0();
                }
            }
        }

        public void a() {
            int childCount = MotionLayout.this.getChildCount();
            MotionLayout.this.f1211m.clear();
            for (int i10 = 0; i10 < childCount; i10++) {
                View childAt = MotionLayout.this.getChildAt(i10);
                MotionLayout.this.f1211m.put(childAt, new n(childAt));
            }
            for (int i11 = 0; i11 < childCount; i11++) {
                View childAt2 = MotionLayout.this.getChildAt(i11);
                n nVar = MotionLayout.this.f1211m.get(childAt2);
                if (nVar != null) {
                    if (this.f1267c != null) {
                        ConstraintWidget constraintWidgetC = c(this.f1265a, childAt2);
                        if (constraintWidgetC != null) {
                            nVar.t(constraintWidgetC, this.f1267c);
                        } else if (MotionLayout.this.f1231z != 0) {
                            Log.e("MotionLayout", androidx.constraintlayout.motion.widget.a.a() + "no widget for  " + androidx.constraintlayout.motion.widget.a.c(childAt2) + " (" + childAt2.getClass().getName() + ")");
                        }
                    }
                    if (this.f1268d != null) {
                        ConstraintWidget constraintWidgetC2 = c(this.f1266b, childAt2);
                        if (constraintWidgetC2 != null) {
                            nVar.q(constraintWidgetC2, this.f1268d);
                        } else if (MotionLayout.this.f1231z != 0) {
                            Log.e("MotionLayout", androidx.constraintlayout.motion.widget.a.a() + "no widget for  " + androidx.constraintlayout.motion.widget.a.c(childAt2) + " (" + childAt2.getClass().getName() + ")");
                        }
                    }
                }
            }
        }

        void b(androidx.constraintlayout.solver.widgets.d dVar, androidx.constraintlayout.solver.widgets.d dVar2) {
            ConstraintWidget bVar;
            ArrayList<ConstraintWidget> arrayListL0 = dVar.L0();
            HashMap<ConstraintWidget, ConstraintWidget> map = new HashMap<>();
            map.put(dVar, dVar2);
            dVar2.L0().clear();
            dVar2.l(dVar, map);
            for (ConstraintWidget constraintWidget : arrayListL0) {
                if (constraintWidget instanceof androidx.constraintlayout.solver.widgets.a) {
                    bVar = new androidx.constraintlayout.solver.widgets.a();
                } else if (constraintWidget instanceof androidx.constraintlayout.solver.widgets.f) {
                    bVar = new androidx.constraintlayout.solver.widgets.f();
                } else if (constraintWidget instanceof androidx.constraintlayout.solver.widgets.e) {
                    bVar = new androidx.constraintlayout.solver.widgets.e();
                } else {
                    bVar = constraintWidget instanceof u.a ? new u.b() : new ConstraintWidget();
                }
                dVar2.a(bVar);
                map.put(constraintWidget, bVar);
            }
            for (ConstraintWidget constraintWidget2 : arrayListL0) {
                map.get(constraintWidget2).l(constraintWidget2, map);
            }
        }

        ConstraintWidget c(androidx.constraintlayout.solver.widgets.d dVar, View view) {
            if (dVar.r() == view) {
                return dVar;
            }
            ArrayList<ConstraintWidget> arrayListL0 = dVar.L0();
            int size = arrayListL0.size();
            for (int i10 = 0; i10 < size; i10++) {
                ConstraintWidget constraintWidget = arrayListL0.get(i10);
                if (constraintWidget.r() == view) {
                    return constraintWidget;
                }
            }
            return null;
        }

        void d(androidx.constraintlayout.solver.widgets.d dVar, androidx.constraintlayout.widget.b bVar, androidx.constraintlayout.widget.b bVar2) {
            this.f1267c = bVar;
            this.f1268d = bVar2;
            this.f1265a = new androidx.constraintlayout.solver.widgets.d();
            this.f1266b = new androidx.constraintlayout.solver.widgets.d();
            this.f1265a.i1(((ConstraintLayout) MotionLayout.this).mLayoutWidget.X0());
            this.f1266b.i1(((ConstraintLayout) MotionLayout.this).mLayoutWidget.X0());
            this.f1265a.O0();
            this.f1266b.O0();
            b(((ConstraintLayout) MotionLayout.this).mLayoutWidget, this.f1265a);
            b(((ConstraintLayout) MotionLayout.this).mLayoutWidget, this.f1266b);
            if (MotionLayout.this.f1219q > 0.5d) {
                if (bVar != null) {
                    i(this.f1265a, bVar);
                }
                i(this.f1266b, bVar2);
            } else {
                i(this.f1266b, bVar2);
                if (bVar != null) {
                    i(this.f1265a, bVar);
                }
            }
            this.f1265a.k1(MotionLayout.this.isRtl());
            this.f1265a.m1();
            this.f1266b.k1(MotionLayout.this.isRtl());
            this.f1266b.m1();
            ViewGroup.LayoutParams layoutParams = MotionLayout.this.getLayoutParams();
            if (layoutParams != null) {
                if (layoutParams.width == -2) {
                    androidx.constraintlayout.solver.widgets.d dVar2 = this.f1265a;
                    ConstraintWidget.DimensionBehaviour dimensionBehaviour = ConstraintWidget.DimensionBehaviour.WRAP_CONTENT;
                    dVar2.m0(dimensionBehaviour);
                    this.f1266b.m0(dimensionBehaviour);
                }
                if (layoutParams.height == -2) {
                    androidx.constraintlayout.solver.widgets.d dVar3 = this.f1265a;
                    ConstraintWidget.DimensionBehaviour dimensionBehaviour2 = ConstraintWidget.DimensionBehaviour.WRAP_CONTENT;
                    dVar3.B0(dimensionBehaviour2);
                    this.f1266b.B0(dimensionBehaviour2);
                }
            }
        }

        public boolean e(int i10, int i11) {
            return (i10 == this.f1269e && i11 == this.f1270f) ? false : true;
        }

        public void f(int i10, int i11) {
            int mode = View.MeasureSpec.getMode(i10);
            int mode2 = View.MeasureSpec.getMode(i11);
            MotionLayout motionLayout = MotionLayout.this;
            motionLayout.f1202h0 = mode;
            motionLayout.f1204i0 = mode2;
            int optimizationLevel = motionLayout.getOptimizationLevel();
            MotionLayout motionLayout2 = MotionLayout.this;
            if (motionLayout2.f1201h == motionLayout2.getStartState()) {
                MotionLayout.this.resolveSystem(this.f1266b, optimizationLevel, i10, i11);
                if (this.f1267c != null) {
                    MotionLayout.this.resolveSystem(this.f1265a, optimizationLevel, i10, i11);
                }
            } else {
                if (this.f1267c != null) {
                    MotionLayout.this.resolveSystem(this.f1265a, optimizationLevel, i10, i11);
                }
                MotionLayout.this.resolveSystem(this.f1266b, optimizationLevel, i10, i11);
            }
            boolean z10 = true;
            if (!(MotionLayout.this.getParent() instanceof MotionLayout) || mode != 1073741824 || mode2 != 1073741824) {
                MotionLayout motionLayout3 = MotionLayout.this;
                motionLayout3.f1202h0 = mode;
                motionLayout3.f1204i0 = mode2;
                if (motionLayout3.f1201h == motionLayout3.getStartState()) {
                    MotionLayout.this.resolveSystem(this.f1266b, optimizationLevel, i10, i11);
                    if (this.f1267c != null) {
                        MotionLayout.this.resolveSystem(this.f1265a, optimizationLevel, i10, i11);
                    }
                } else {
                    if (this.f1267c != null) {
                        MotionLayout.this.resolveSystem(this.f1265a, optimizationLevel, i10, i11);
                    }
                    MotionLayout.this.resolveSystem(this.f1266b, optimizationLevel, i10, i11);
                }
                MotionLayout.this.f1196d0 = this.f1265a.Q();
                MotionLayout.this.f1197e0 = this.f1265a.w();
                MotionLayout.this.f1198f0 = this.f1266b.Q();
                MotionLayout.this.f1200g0 = this.f1266b.w();
                MotionLayout motionLayout4 = MotionLayout.this;
                motionLayout4.f1195c0 = (motionLayout4.f1196d0 == motionLayout4.f1198f0 && motionLayout4.f1197e0 == motionLayout4.f1200g0) ? false : true;
            }
            MotionLayout motionLayout5 = MotionLayout.this;
            int i12 = motionLayout5.f1196d0;
            int i13 = motionLayout5.f1197e0;
            int i14 = motionLayout5.f1202h0;
            if (i14 == Integer.MIN_VALUE || i14 == 0) {
                i12 = (int) (i12 + (motionLayout5.f1206j0 * (motionLayout5.f1198f0 - i12)));
            }
            int i15 = motionLayout5.f1204i0;
            if (i15 == Integer.MIN_VALUE || i15 == 0) {
                i13 = (int) (i13 + (motionLayout5.f1206j0 * (motionLayout5.f1200g0 - i13)));
            }
            boolean z11 = this.f1265a.e1() || this.f1266b.e1();
            if (!this.f1265a.c1() && !this.f1266b.c1()) {
                z10 = false;
            }
            MotionLayout.this.resolveMeasuredDimension(i10, i11, i12, i13, z11, z10);
        }

        public void g() {
            f(MotionLayout.this.f1205j, MotionLayout.this.f1207k);
            MotionLayout.this.Y();
        }

        public void h(int i10, int i11) {
            this.f1269e = i10;
            this.f1270f = i11;
        }
    }

    protected interface f {
        void a(MotionEvent motionEvent);

        float b();

        float c();

        void d();

        void e(int i10);
    }

    private static class g implements f {

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private static g f1272b = new g();

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        VelocityTracker f1273a;

        private g() {
        }

        public static g f() {
            f1272b.f1273a = VelocityTracker.obtain();
            return f1272b;
        }

        @Override // androidx.constraintlayout.motion.widget.MotionLayout.f
        public void a(MotionEvent motionEvent) {
            VelocityTracker velocityTracker = this.f1273a;
            if (velocityTracker != null) {
                velocityTracker.addMovement(motionEvent);
            }
        }

        @Override // androidx.constraintlayout.motion.widget.MotionLayout.f
        public float b() {
            return this.f1273a.getYVelocity();
        }

        @Override // androidx.constraintlayout.motion.widget.MotionLayout.f
        public float c() {
            return this.f1273a.getXVelocity();
        }

        @Override // androidx.constraintlayout.motion.widget.MotionLayout.f
        public void d() {
            this.f1273a.recycle();
            this.f1273a = null;
        }

        @Override // androidx.constraintlayout.motion.widget.MotionLayout.f
        public void e(int i10) {
            this.f1273a.computeCurrentVelocity(i10);
        }
    }

    class h {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        float f1274a = Float.NaN;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        float f1275b = Float.NaN;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        int f1276c = -1;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        int f1277d = -1;

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        final String f1278e = "motion.progress";

        /* JADX INFO: renamed from: f, reason: collision with root package name */
        final String f1279f = "motion.velocity";

        /* JADX INFO: renamed from: g, reason: collision with root package name */
        final String f1280g = "motion.StartState";

        /* JADX INFO: renamed from: h, reason: collision with root package name */
        final String f1281h = "motion.EndState";

        h() {
        }

        void a() {
            int i10 = this.f1276c;
            if (i10 != -1 || this.f1277d != -1) {
                if (i10 == -1) {
                    MotionLayout.this.c0(this.f1277d);
                } else {
                    int i11 = this.f1277d;
                    if (i11 == -1) {
                        MotionLayout.this.setState(i10, -1, -1);
                    } else {
                        MotionLayout.this.X(i10, i11);
                    }
                }
                MotionLayout.this.setState(TransitionState.SETUP);
            }
            if (Float.isNaN(this.f1275b)) {
                if (Float.isNaN(this.f1274a)) {
                    return;
                }
                MotionLayout.this.setProgress(this.f1274a);
            } else {
                MotionLayout.this.W(this.f1274a, this.f1275b);
                this.f1274a = Float.NaN;
                this.f1275b = Float.NaN;
                this.f1276c = -1;
                this.f1277d = -1;
            }
        }

        public Bundle b() {
            Bundle bundle = new Bundle();
            bundle.putFloat("motion.progress", this.f1274a);
            bundle.putFloat("motion.velocity", this.f1275b);
            bundle.putInt("motion.StartState", this.f1276c);
            bundle.putInt("motion.EndState", this.f1277d);
            return bundle;
        }

        public void c() {
            this.f1277d = MotionLayout.this.f1203i;
            this.f1276c = MotionLayout.this.f1199g;
            this.f1275b = MotionLayout.this.getVelocity();
            this.f1274a = MotionLayout.this.getProgress();
        }

        public void d(int i10) {
            this.f1277d = i10;
        }

        public void e(float f10) {
            this.f1274a = f10;
        }

        public void f(int i10) {
            this.f1276c = i10;
        }

        public void g(Bundle bundle) {
            this.f1274a = bundle.getFloat("motion.progress");
            this.f1275b = bundle.getFloat("motion.velocity");
            this.f1276c = bundle.getInt("motion.StartState");
            this.f1277d = bundle.getInt("motion.EndState");
        }

        public void h(float f10) {
            this.f1275b = f10;
        }
    }

    public interface i {
        void a(MotionLayout motionLayout, int i10, int i11, float f10);

        void b(MotionLayout motionLayout, int i10, int i11);

        void c(MotionLayout motionLayout, int i10, boolean z10, float f10);

        void d(MotionLayout motionLayout, int i10);
    }

    public MotionLayout(Context context) {
        super(context);
        this.f1194c = 0.0f;
        this.f1199g = -1;
        this.f1201h = -1;
        this.f1203i = -1;
        this.f1205j = 0;
        this.f1207k = 0;
        this.f1209l = true;
        this.f1211m = new HashMap<>();
        this.f1213n = 0L;
        this.f1215o = 1.0f;
        this.f1217p = 0.0f;
        this.f1219q = 0.0f;
        this.f1223s = 0.0f;
        this.f1226u = false;
        this.f1227v = false;
        this.f1231z = 0;
        this.B = false;
        this.C = new s.g();
        this.D = new c();
        this.F = true;
        this.K = false;
        this.P = false;
        this.Q = null;
        this.R = null;
        this.S = null;
        this.T = 0;
        this.U = -1L;
        this.V = 0.0f;
        this.W = 0;
        this.f1191a0 = 0.0f;
        this.f1193b0 = false;
        this.f1195c0 = false;
        this.f1208k0 = new androidx.constraintlayout.motion.widget.e();
        this.f1210l0 = false;
        this.f1214n0 = TransitionState.UNDEFINED;
        this.f1216o0 = new e();
        this.f1218p0 = false;
        this.f1220q0 = new RectF();
        this.f1222r0 = null;
        this.f1224s0 = new ArrayList<>();
        Q(null);
    }

    private void D() {
        q qVar = this.f1190a;
        if (qVar == null) {
            Log.e("MotionLayout", "CHECK: motion scene not set! set \"app:layoutDescription=\"@xml/file\"");
            return;
        }
        int iX = qVar.x();
        q qVar2 = this.f1190a;
        E(iX, qVar2.i(qVar2.x()));
        SparseIntArray sparseIntArray = new SparseIntArray();
        SparseIntArray sparseIntArray2 = new SparseIntArray();
        for (q.b bVar : this.f1190a.l()) {
            if (bVar == this.f1190a.f1483c) {
                Log.v("MotionLayout", "CHECK: CURRENT");
            }
            F(bVar);
            int iA = bVar.A();
            int iY = bVar.y();
            String strB = androidx.constraintlayout.motion.widget.a.b(getContext(), iA);
            String strB2 = androidx.constraintlayout.motion.widget.a.b(getContext(), iY);
            if (sparseIntArray.get(iA) == iY) {
                Log.e("MotionLayout", "CHECK: two transitions with the same start and end " + strB + "->" + strB2);
            }
            if (sparseIntArray2.get(iY) == iA) {
                Log.e("MotionLayout", "CHECK: you can't have reverse transitions" + strB + "->" + strB2);
            }
            sparseIntArray.put(iA, iY);
            sparseIntArray2.put(iY, iA);
            if (this.f1190a.i(iA) == null) {
                Log.e("MotionLayout", " no such constraintSetStart " + strB);
            }
            if (this.f1190a.i(iY) == null) {
                Log.e("MotionLayout", " no such constraintSetEnd " + strB);
            }
        }
    }

    private void E(int i10, androidx.constraintlayout.widget.b bVar) {
        String strB = androidx.constraintlayout.motion.widget.a.b(getContext(), i10);
        int childCount = getChildCount();
        for (int i11 = 0; i11 < childCount; i11++) {
            View childAt = getChildAt(i11);
            int id = childAt.getId();
            if (id == -1) {
                Log.w("MotionLayout", "CHECK: " + strB + " ALL VIEWS SHOULD HAVE ID's " + childAt.getClass().getName() + " does not!");
            }
            if (bVar.p(id) == null) {
                Log.w("MotionLayout", "CHECK: " + strB + " NO CONSTRAINTS for " + androidx.constraintlayout.motion.widget.a.c(childAt));
            }
        }
        int[] iArrR = bVar.r();
        for (int i12 = 0; i12 < iArrR.length; i12++) {
            int i13 = iArrR[i12];
            String strB2 = androidx.constraintlayout.motion.widget.a.b(getContext(), i13);
            if (findViewById(iArrR[i12]) == null) {
                Log.w("MotionLayout", "CHECK: " + strB + " NO View matches id " + strB2);
            }
            if (bVar.q(i13) == -1) {
                Log.w("MotionLayout", "CHECK: " + strB + "(" + strB2 + ") no LAYOUT_HEIGHT");
            }
            if (bVar.v(i13) == -1) {
                Log.w("MotionLayout", "CHECK: " + strB + "(" + strB2 + ") no LAYOUT_HEIGHT");
            }
        }
    }

    private void F(q.b bVar) {
        Log.v("MotionLayout", "CHECK: transition = " + bVar.u(getContext()));
        Log.v("MotionLayout", "CHECK: transition.setDuration = " + bVar.x());
        if (bVar.A() == bVar.y()) {
            Log.e("MotionLayout", "CHECK: start and end constraint set should not be the same!");
        }
    }

    private void G() {
        int childCount = getChildCount();
        for (int i10 = 0; i10 < childCount; i10++) {
            View childAt = getChildAt(i10);
            n nVar = this.f1211m.get(childAt);
            if (nVar != null) {
                nVar.s(childAt);
            }
        }
    }

    private void I() {
        boolean z10;
        float fSignum = Math.signum(this.f1223s - this.f1219q);
        long nanoTime = getNanoTime();
        Interpolator interpolator = this.f1192b;
        float interpolation = this.f1219q + (!(interpolator instanceof s.g) ? (((nanoTime - this.f1221r) * fSignum) * 1.0E-9f) / this.f1215o : 0.0f);
        if (this.f1225t) {
            interpolation = this.f1223s;
        }
        if ((fSignum <= 0.0f || interpolation < this.f1223s) && (fSignum > 0.0f || interpolation > this.f1223s)) {
            z10 = false;
        } else {
            interpolation = this.f1223s;
            z10 = true;
        }
        if (interpolator != null && !z10) {
            interpolation = this.B ? interpolator.getInterpolation((nanoTime - this.f1213n) * 1.0E-9f) : interpolator.getInterpolation(interpolation);
        }
        if ((fSignum > 0.0f && interpolation >= this.f1223s) || (fSignum <= 0.0f && interpolation <= this.f1223s)) {
            interpolation = this.f1223s;
        }
        this.f1206j0 = interpolation;
        int childCount = getChildCount();
        long nanoTime2 = getNanoTime();
        for (int i10 = 0; i10 < childCount; i10++) {
            View childAt = getChildAt(i10);
            n nVar = this.f1211m.get(childAt);
            if (nVar != null) {
                nVar.o(childAt, interpolation, nanoTime2, this.f1208k0);
            }
        }
        if (this.f1195c0) {
            requestLayout();
        }
    }

    private void J() {
        ArrayList<i> arrayList;
        if ((this.f1228w == null && ((arrayList = this.S) == null || arrayList.isEmpty())) || this.f1191a0 == this.f1217p) {
            return;
        }
        if (this.W != -1) {
            i iVar = this.f1228w;
            if (iVar != null) {
                iVar.b(this, this.f1199g, this.f1203i);
            }
            ArrayList<i> arrayList2 = this.S;
            if (arrayList2 != null) {
                Iterator<i> it = arrayList2.iterator();
                while (it.hasNext()) {
                    it.next().b(this, this.f1199g, this.f1203i);
                }
            }
            this.f1193b0 = true;
        }
        this.W = -1;
        float f10 = this.f1217p;
        this.f1191a0 = f10;
        i iVar2 = this.f1228w;
        if (iVar2 != null) {
            iVar2.a(this, this.f1199g, this.f1203i, f10);
        }
        ArrayList<i> arrayList3 = this.S;
        if (arrayList3 != null) {
            Iterator<i> it2 = arrayList3.iterator();
            while (it2.hasNext()) {
                it2.next().a(this, this.f1199g, this.f1203i, this.f1217p);
            }
        }
        this.f1193b0 = true;
    }

    private boolean P(float f10, float f11, View view, MotionEvent motionEvent) {
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            int childCount = viewGroup.getChildCount();
            for (int i10 = 0; i10 < childCount; i10++) {
                if (P(view.getLeft() + f10, view.getTop() + f11, viewGroup.getChildAt(i10), motionEvent)) {
                    return true;
                }
            }
        }
        this.f1220q0.set(view.getLeft() + f10, view.getTop() + f11, f10 + view.getRight(), f11 + view.getBottom());
        if (motionEvent.getAction() == 0) {
            if (this.f1220q0.contains(motionEvent.getX(), motionEvent.getY()) && view.onTouchEvent(motionEvent)) {
                return true;
            }
        } else if (view.onTouchEvent(motionEvent)) {
            return true;
        }
        return false;
    }

    private void Q(AttributeSet attributeSet) {
        q qVar;
        f1189t0 = isInEditMode();
        if (attributeSet != null) {
            TypedArray typedArrayObtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, R$styleable.MotionLayout);
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            boolean z10 = true;
            for (int i10 = 0; i10 < indexCount; i10++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i10);
                if (index == R$styleable.MotionLayout_layoutDescription) {
                    this.f1190a = new q(getContext(), this, typedArrayObtainStyledAttributes.getResourceId(index, -1));
                } else if (index == R$styleable.MotionLayout_currentState) {
                    this.f1201h = typedArrayObtainStyledAttributes.getResourceId(index, -1);
                } else if (index == R$styleable.MotionLayout_motionProgress) {
                    this.f1223s = typedArrayObtainStyledAttributes.getFloat(index, 0.0f);
                    this.f1226u = true;
                } else if (index == R$styleable.MotionLayout_applyMotionScene) {
                    z10 = typedArrayObtainStyledAttributes.getBoolean(index, z10);
                } else if (index == R$styleable.MotionLayout_showPaths) {
                    if (this.f1231z == 0) {
                        this.f1231z = typedArrayObtainStyledAttributes.getBoolean(index, false) ? 2 : 0;
                    }
                } else if (index == R$styleable.MotionLayout_motionDebug) {
                    this.f1231z = typedArrayObtainStyledAttributes.getInt(index, 0);
                }
            }
            typedArrayObtainStyledAttributes.recycle();
            if (this.f1190a == null) {
                Log.e("MotionLayout", "WARNING NO app:layoutDescription tag");
            }
            if (!z10) {
                this.f1190a = null;
            }
        }
        if (this.f1231z != 0) {
            D();
        }
        if (this.f1201h != -1 || (qVar = this.f1190a) == null) {
            return;
        }
        this.f1201h = qVar.x();
        this.f1199g = this.f1190a.x();
        this.f1203i = this.f1190a.n();
    }

    private void T() {
        q qVar = this.f1190a;
        if (qVar == null) {
            return;
        }
        if (qVar.f(this, this.f1201h)) {
            requestLayout();
            return;
        }
        int i10 = this.f1201h;
        if (i10 != -1) {
            this.f1190a.e(this, i10);
        }
        if (this.f1190a.Q()) {
            this.f1190a.O();
        }
    }

    private void U() {
        ArrayList<i> arrayList;
        if (this.f1228w == null && ((arrayList = this.S) == null || arrayList.isEmpty())) {
            return;
        }
        this.f1193b0 = false;
        for (Integer num : this.f1224s0) {
            i iVar = this.f1228w;
            if (iVar != null) {
                iVar.d(this, num.intValue());
            }
            ArrayList<i> arrayList2 = this.S;
            if (arrayList2 != null) {
                Iterator<i> it = arrayList2.iterator();
                while (it.hasNext()) {
                    it.next().d(this, num.intValue());
                }
            }
        }
        this.f1224s0.clear();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void Y() {
        int childCount = getChildCount();
        this.f1216o0.a();
        this.f1226u = true;
        int width = getWidth();
        int height = getHeight();
        int iH = this.f1190a.h();
        int i10 = 0;
        if (iH != -1) {
            for (int i11 = 0; i11 < childCount; i11++) {
                n nVar = this.f1211m.get(getChildAt(i11));
                if (nVar != null) {
                    nVar.r(iH);
                }
            }
        }
        for (int i12 = 0; i12 < childCount; i12++) {
            n nVar2 = this.f1211m.get(getChildAt(i12));
            if (nVar2 != null) {
                this.f1190a.q(nVar2);
                nVar2.v(width, height, this.f1215o, getNanoTime());
            }
        }
        float fW = this.f1190a.w();
        if (fW != 0.0f) {
            boolean z10 = ((double) fW) < UserProfileInfo.Constant.NA_LAT_LON;
            float fAbs = Math.abs(fW);
            float fMax = -3.4028235E38f;
            float fMin = Float.MAX_VALUE;
            float fMax2 = -3.4028235E38f;
            float fMin2 = Float.MAX_VALUE;
            for (int i13 = 0; i13 < childCount; i13++) {
                n nVar3 = this.f1211m.get(getChildAt(i13));
                if (!Float.isNaN(nVar3.f1449k)) {
                    for (int i14 = 0; i14 < childCount; i14++) {
                        n nVar4 = this.f1211m.get(getChildAt(i14));
                        if (!Float.isNaN(nVar4.f1449k)) {
                            fMin = Math.min(fMin, nVar4.f1449k);
                            fMax = Math.max(fMax, nVar4.f1449k);
                        }
                    }
                    while (i10 < childCount) {
                        n nVar5 = this.f1211m.get(getChildAt(i10));
                        if (!Float.isNaN(nVar5.f1449k)) {
                            nVar5.f1451m = 1.0f / (1.0f - fAbs);
                            if (z10) {
                                nVar5.f1450l = fAbs - (((fMax - nVar5.f1449k) / (fMax - fMin)) * fAbs);
                            } else {
                                nVar5.f1450l = fAbs - (((nVar5.f1449k - fMin) * fAbs) / (fMax - fMin));
                            }
                        }
                        i10++;
                    }
                    return;
                }
                float fI = nVar3.i();
                float fJ = nVar3.j();
                float f10 = z10 ? fJ - fI : fJ + fI;
                fMin2 = Math.min(fMin2, f10);
                fMax2 = Math.max(fMax2, f10);
            }
            while (i10 < childCount) {
                n nVar6 = this.f1211m.get(getChildAt(i10));
                float fI2 = nVar6.i();
                float fJ2 = nVar6.j();
                float f11 = z10 ? fJ2 - fI2 : fJ2 + fI2;
                nVar6.f1451m = 1.0f / (1.0f - fAbs);
                nVar6.f1450l = fAbs - (((f11 - fMin2) * fAbs) / (fMax2 - fMin2));
                i10++;
            }
        }
    }

    private static boolean e0(float f10, float f11, float f12) {
        if (f10 > 0.0f) {
            float f13 = f10 / f12;
            return f11 + ((f10 * f13) - (((f12 * f13) * f13) / 2.0f)) > 1.0f;
        }
        float f14 = (-f10) / f12;
        return f11 + ((f10 * f14) + (((f12 * f14) * f14) / 2.0f)) < 0.0f;
    }

    void C(float f10) {
        q qVar = this.f1190a;
        if (qVar == null) {
            return;
        }
        float f11 = this.f1219q;
        float f12 = this.f1217p;
        if (f11 != f12 && this.f1225t) {
            this.f1219q = f12;
        }
        float f13 = this.f1219q;
        if (f13 == f10) {
            return;
        }
        this.B = false;
        this.f1223s = f10;
        this.f1215o = qVar.m() / 1000.0f;
        setProgress(this.f1223s);
        this.f1192b = this.f1190a.p();
        this.f1225t = false;
        this.f1213n = getNanoTime();
        this.f1226u = true;
        this.f1217p = f13;
        this.f1219q = f13;
        invalidate();
    }

    void H(boolean z10) {
        float f10;
        boolean z11;
        int i10;
        float interpolation;
        boolean z12;
        if (this.f1221r == -1) {
            this.f1221r = getNanoTime();
        }
        float f11 = this.f1219q;
        if (f11 > 0.0f && f11 < 1.0f) {
            this.f1201h = -1;
        }
        boolean z13 = false;
        if (this.P || (this.f1226u && (z10 || this.f1223s != f11))) {
            float fSignum = Math.signum(this.f1223s - f11);
            long nanoTime = getNanoTime();
            Interpolator interpolator = this.f1192b;
            if (interpolator instanceof o) {
                f10 = 0.0f;
            } else {
                f10 = (((nanoTime - this.f1221r) * fSignum) * 1.0E-9f) / this.f1215o;
                this.f1194c = f10;
            }
            float f12 = this.f1219q + f10;
            if (this.f1225t) {
                f12 = this.f1223s;
            }
            if ((fSignum <= 0.0f || f12 < this.f1223s) && (fSignum > 0.0f || f12 > this.f1223s)) {
                z11 = false;
            } else {
                f12 = this.f1223s;
                this.f1226u = false;
                z11 = true;
            }
            this.f1219q = f12;
            this.f1217p = f12;
            this.f1221r = nanoTime;
            if (interpolator != null && !z11) {
                if (this.B) {
                    interpolation = interpolator.getInterpolation((nanoTime - this.f1213n) * 1.0E-9f);
                    this.f1219q = interpolation;
                    this.f1221r = nanoTime;
                    Interpolator interpolator2 = this.f1192b;
                    if (interpolator2 instanceof o) {
                        float fA = ((o) interpolator2).a();
                        this.f1194c = fA;
                        if (Math.abs(fA) * this.f1215o <= 1.0E-5f) {
                            this.f1226u = false;
                        }
                        if (fA > 0.0f && interpolation >= 1.0f) {
                            this.f1219q = 1.0f;
                            this.f1226u = false;
                            interpolation = 1.0f;
                        }
                        if (fA < 0.0f && interpolation <= 0.0f) {
                            this.f1219q = 0.0f;
                            this.f1226u = false;
                            f12 = 0.0f;
                        }
                    }
                } else {
                    interpolation = interpolator.getInterpolation(f12);
                    Interpolator interpolator3 = this.f1192b;
                    if (interpolator3 instanceof o) {
                        this.f1194c = ((o) interpolator3).a();
                    } else {
                        this.f1194c = ((interpolator3.getInterpolation(f12 + f10) - interpolation) * fSignum) / f10;
                    }
                }
                f12 = interpolation;
            }
            if (Math.abs(this.f1194c) > 1.0E-5f) {
                setState(TransitionState.MOVING);
            }
            if ((fSignum > 0.0f && f12 >= this.f1223s) || (fSignum <= 0.0f && f12 <= this.f1223s)) {
                f12 = this.f1223s;
                this.f1226u = false;
            }
            if (f12 >= 1.0f || f12 <= 0.0f) {
                this.f1226u = false;
                setState(TransitionState.FINISHED);
            }
            int childCount = getChildCount();
            this.P = false;
            long nanoTime2 = getNanoTime();
            this.f1206j0 = f12;
            for (int i11 = 0; i11 < childCount; i11++) {
                View childAt = getChildAt(i11);
                n nVar = this.f1211m.get(childAt);
                if (nVar != null) {
                    this.P = nVar.o(childAt, f12, nanoTime2, this.f1208k0) | this.P;
                }
            }
            boolean z14 = (fSignum > 0.0f && f12 >= this.f1223s) || (fSignum <= 0.0f && f12 <= this.f1223s);
            if (!this.P && !this.f1226u && z14) {
                setState(TransitionState.FINISHED);
            }
            if (this.f1195c0) {
                requestLayout();
            }
            this.P = (!z14) | this.P;
            if (f12 <= 0.0f && (i10 = this.f1199g) != -1 && this.f1201h != i10) {
                this.f1201h = i10;
                this.f1190a.i(i10).c(this);
                setState(TransitionState.FINISHED);
                z13 = true;
            }
            if (f12 >= 1.0d) {
                int i12 = this.f1201h;
                int i13 = this.f1203i;
                if (i12 != i13) {
                    this.f1201h = i13;
                    this.f1190a.i(i13).c(this);
                    setState(TransitionState.FINISHED);
                    z13 = true;
                }
            }
            if (this.P || this.f1226u) {
                invalidate();
            } else if ((fSignum > 0.0f && f12 == 1.0f) || (fSignum < 0.0f && f12 == 0.0f)) {
                setState(TransitionState.FINISHED);
            }
            if ((!this.P && this.f1226u && fSignum > 0.0f && f12 == 1.0f) || (fSignum < 0.0f && f12 == 0.0f)) {
                T();
            }
        }
        float f13 = this.f1219q;
        if (f13 < 1.0f) {
            if (f13 <= 0.0f) {
                int i14 = this.f1201h;
                int i15 = this.f1199g;
                z12 = i14 == i15 ? z13 : true;
                this.f1201h = i15;
            }
            this.f1218p0 |= z13;
            if (z13 && !this.f1210l0) {
                requestLayout();
            }
            this.f1217p = this.f1219q;
        }
        int i16 = this.f1201h;
        int i17 = this.f1203i;
        z12 = i16 == i17 ? z13 : true;
        this.f1201h = i17;
        z13 = z12;
        this.f1218p0 |= z13;
        if (z13) {
            requestLayout();
        }
        this.f1217p = this.f1219q;
    }

    protected void K() {
        int iIntValue;
        ArrayList<i> arrayList;
        if ((this.f1228w != null || ((arrayList = this.S) != null && !arrayList.isEmpty())) && this.W == -1) {
            this.W = this.f1201h;
            if (this.f1224s0.isEmpty()) {
                iIntValue = -1;
            } else {
                ArrayList<Integer> arrayList2 = this.f1224s0;
                iIntValue = arrayList2.get(arrayList2.size() - 1).intValue();
            }
            int i10 = this.f1201h;
            if (iIntValue != i10 && i10 != -1) {
                this.f1224s0.add(Integer.valueOf(i10));
            }
        }
        U();
    }

    public void L(int i10, boolean z10, float f10) {
        i iVar = this.f1228w;
        if (iVar != null) {
            iVar.c(this, i10, z10, f10);
        }
        ArrayList<i> arrayList = this.S;
        if (arrayList != null) {
            Iterator<i> it = arrayList.iterator();
            while (it.hasNext()) {
                it.next().c(this, i10, z10, f10);
            }
        }
    }

    void M(int i10, float f10, float f11, float f12, float[] fArr) {
        String resourceName;
        HashMap<View, n> map = this.f1211m;
        View viewById = getViewById(i10);
        n nVar = map.get(viewById);
        if (nVar != null) {
            nVar.g(f10, f11, f12, fArr);
            float y10 = viewById.getY();
            this.f1229x = f10;
            this.f1230y = y10;
            return;
        }
        if (viewById == null) {
            resourceName = "" + i10;
        } else {
            resourceName = viewById.getContext().getResources().getResourceName(i10);
        }
        Log.w("MotionLayout", "WARNING could not find view id " + resourceName);
    }

    public q.b N(int i10) {
        return this.f1190a.y(i10);
    }

    public void O(View view, float f10, float f11, float[] fArr, int i10) {
        float interpolation;
        float fA = this.f1194c;
        float f12 = this.f1219q;
        if (this.f1192b != null) {
            float fSignum = Math.signum(this.f1223s - f12);
            float interpolation2 = this.f1192b.getInterpolation(this.f1219q + 1.0E-5f);
            interpolation = this.f1192b.getInterpolation(this.f1219q);
            fA = (fSignum * ((interpolation2 - interpolation) / 1.0E-5f)) / this.f1215o;
        } else {
            interpolation = f12;
        }
        Interpolator interpolator = this.f1192b;
        if (interpolator instanceof o) {
            fA = ((o) interpolator).a();
        }
        n nVar = this.f1211m.get(view);
        if ((i10 & 1) == 0) {
            nVar.l(interpolation, view.getWidth(), view.getHeight(), f10, f11, fArr);
        } else {
            nVar.g(interpolation, f10, f11, fArr);
        }
        if (i10 < 2) {
            fArr[0] = fArr[0] * fA;
            fArr[1] = fArr[1] * fA;
        }
    }

    public boolean R() {
        return this.f1209l;
    }

    protected f S() {
        return g.f();
    }

    public void V() {
        this.f1216o0.g();
        invalidate();
    }

    public void W(float f10, float f11) {
        if (isAttachedToWindow()) {
            setProgress(f10);
            setState(TransitionState.MOVING);
            this.f1194c = f11;
            C(1.0f);
            return;
        }
        if (this.f1212m0 == null) {
            this.f1212m0 = new h();
        }
        this.f1212m0.e(f10);
        this.f1212m0.h(f11);
    }

    public void X(int i10, int i11) {
        if (!isAttachedToWindow()) {
            if (this.f1212m0 == null) {
                this.f1212m0 = new h();
            }
            this.f1212m0.f(i10);
            this.f1212m0.d(i11);
            return;
        }
        q qVar = this.f1190a;
        if (qVar != null) {
            this.f1199g = i10;
            this.f1203i = i11;
            qVar.M(i10, i11);
            this.f1216o0.d(this.mLayoutWidget, this.f1190a.i(i10), this.f1190a.i(i11));
            V();
            this.f1219q = 0.0f;
            b0();
        }
    }

    public void Z(int i10, float f10, float f11) {
        if (this.f1190a == null || this.f1219q == f10) {
            return;
        }
        this.B = true;
        this.f1213n = getNanoTime();
        float fM = this.f1190a.m() / 1000.0f;
        this.f1215o = fM;
        this.f1223s = f10;
        this.f1226u = true;
        if (i10 == 0 || i10 == 1 || i10 == 2) {
            if (i10 == 1) {
                f10 = 0.0f;
            } else if (i10 == 2) {
                f10 = 1.0f;
            }
            this.C.c(this.f1219q, f10, f11, fM, this.f1190a.r(), this.f1190a.s());
            int i11 = this.f1201h;
            this.f1223s = f10;
            this.f1201h = i11;
            this.f1192b = this.C;
        } else if (i10 == 4) {
            this.D.b(f11, this.f1219q, this.f1190a.r());
            this.f1192b = this.D;
        } else if (i10 == 5) {
            if (e0(f11, this.f1219q, this.f1190a.r())) {
                this.D.b(f11, this.f1219q, this.f1190a.r());
                this.f1192b = this.D;
            } else {
                this.C.c(this.f1219q, f10, f11, this.f1215o, this.f1190a.r(), this.f1190a.s());
                this.f1194c = 0.0f;
                int i12 = this.f1201h;
                this.f1223s = f10;
                this.f1201h = i12;
                this.f1192b = this.C;
            }
        }
        this.f1225t = false;
        this.f1213n = getNanoTime();
        invalidate();
    }

    public void a0() {
        C(1.0f);
    }

    public void b0() {
        C(0.0f);
    }

    public void c0(int i10) {
        if (isAttachedToWindow()) {
            d0(i10, -1, -1);
            return;
        }
        if (this.f1212m0 == null) {
            this.f1212m0 = new h();
        }
        this.f1212m0.d(i10);
    }

    public void d0(int i10, int i11, int i12) {
        androidx.constraintlayout.widget.d dVar;
        int iA;
        q qVar = this.f1190a;
        if (qVar != null && (dVar = qVar.f1482b) != null && (iA = dVar.a(this.f1201h, i10, i11, i12)) != -1) {
            i10 = iA;
        }
        int i13 = this.f1201h;
        if (i13 == i10) {
            return;
        }
        if (this.f1199g == i10) {
            C(0.0f);
            return;
        }
        if (this.f1203i == i10) {
            C(1.0f);
            return;
        }
        this.f1203i = i10;
        if (i13 != -1) {
            X(i13, i10);
            C(1.0f);
            this.f1219q = 0.0f;
            a0();
            return;
        }
        this.B = false;
        this.f1223s = 1.0f;
        this.f1217p = 0.0f;
        this.f1219q = 0.0f;
        this.f1221r = getNanoTime();
        this.f1213n = getNanoTime();
        this.f1225t = false;
        this.f1192b = null;
        this.f1215o = this.f1190a.m() / 1000.0f;
        this.f1199g = -1;
        this.f1190a.M(-1, this.f1203i);
        this.f1190a.x();
        int childCount = getChildCount();
        this.f1211m.clear();
        for (int i14 = 0; i14 < childCount; i14++) {
            View childAt = getChildAt(i14);
            this.f1211m.put(childAt, new n(childAt));
        }
        this.f1226u = true;
        this.f1216o0.d(this.mLayoutWidget, null, this.f1190a.i(i10));
        V();
        this.f1216o0.a();
        G();
        int width = getWidth();
        int height = getHeight();
        for (int i15 = 0; i15 < childCount; i15++) {
            n nVar = this.f1211m.get(getChildAt(i15));
            this.f1190a.q(nVar);
            nVar.v(width, height, this.f1215o, getNanoTime());
        }
        float fW = this.f1190a.w();
        if (fW != 0.0f) {
            float fMin = Float.MAX_VALUE;
            float fMax = -3.4028235E38f;
            for (int i16 = 0; i16 < childCount; i16++) {
                n nVar2 = this.f1211m.get(getChildAt(i16));
                float fJ = nVar2.j() + nVar2.i();
                fMin = Math.min(fMin, fJ);
                fMax = Math.max(fMax, fJ);
            }
            for (int i17 = 0; i17 < childCount; i17++) {
                n nVar3 = this.f1211m.get(getChildAt(i17));
                float fI = nVar3.i();
                float fJ2 = nVar3.j();
                nVar3.f1451m = 1.0f / (1.0f - fW);
                nVar3.f1450l = fW - ((((fI + fJ2) - fMin) * fW) / (fMax - fMin));
            }
        }
        this.f1217p = 0.0f;
        this.f1219q = 0.0f;
        this.f1226u = true;
        invalidate();
    }

    @Override // androidx.constraintlayout.widget.ConstraintLayout, android.view.ViewGroup, android.view.View
    protected void dispatchDraw(Canvas canvas) {
        H(false);
        super.dispatchDraw(canvas);
        if (this.f1190a == null) {
            return;
        }
        if ((this.f1231z & 1) == 1 && !isInEditMode()) {
            this.T++;
            long nanoTime = getNanoTime();
            long j10 = this.U;
            if (j10 != -1) {
                long j11 = nanoTime - j10;
                if (j11 > 200000000) {
                    this.V = ((int) ((this.T / (j11 * 1.0E-9f)) * 100.0f)) / 100.0f;
                    this.T = 0;
                    this.U = nanoTime;
                }
            } else {
                this.U = nanoTime;
            }
            Paint paint = new Paint();
            paint.setTextSize(42.0f);
            float progress = ((int) (getProgress() * 1000.0f)) / 10.0f;
            String str = this.V + " fps " + androidx.constraintlayout.motion.widget.a.d(this, this.f1199g) + " -> ";
            StringBuilder sb2 = new StringBuilder();
            sb2.append(str);
            sb2.append(androidx.constraintlayout.motion.widget.a.d(this, this.f1203i));
            sb2.append(" (progress: ");
            sb2.append(progress);
            sb2.append(" ) state=");
            int i10 = this.f1201h;
            sb2.append(i10 == -1 ? "undefined" : androidx.constraintlayout.motion.widget.a.d(this, i10));
            String string = sb2.toString();
            paint.setColor(-16777216);
            canvas.drawText(string, 11.0f, getHeight() - 29, paint);
            paint.setColor(-7864184);
            canvas.drawText(string, 10.0f, getHeight() - 30, paint);
        }
        if (this.f1231z > 1) {
            if (this.A == null) {
                this.A = new d();
            }
            this.A.a(canvas, this.f1211m, this.f1190a.m(), this.f1231z);
        }
    }

    public int[] getConstraintSetIds() {
        q qVar = this.f1190a;
        if (qVar == null) {
            return null;
        }
        return qVar.k();
    }

    public int getCurrentState() {
        return this.f1201h;
    }

    public ArrayList<q.b> getDefinedTransitions() {
        q qVar = this.f1190a;
        if (qVar == null) {
            return null;
        }
        return qVar.l();
    }

    public androidx.constraintlayout.motion.widget.b getDesignTool() {
        if (this.E == null) {
            this.E = new androidx.constraintlayout.motion.widget.b(this);
        }
        return this.E;
    }

    public int getEndState() {
        return this.f1203i;
    }

    protected long getNanoTime() {
        return System.nanoTime();
    }

    public float getProgress() {
        return this.f1219q;
    }

    public int getStartState() {
        return this.f1199g;
    }

    public float getTargetPosition() {
        return this.f1223s;
    }

    public Bundle getTransitionState() {
        if (this.f1212m0 == null) {
            this.f1212m0 = new h();
        }
        this.f1212m0.c();
        return this.f1212m0.b();
    }

    public long getTransitionTimeMs() {
        q qVar = this.f1190a;
        if (qVar != null) {
            this.f1215o = qVar.m() / 1000.0f;
        }
        return (long) (this.f1215o * 1000.0f);
    }

    public float getVelocity() {
        return this.f1194c;
    }

    @Override // androidx.core.view.u
    public void i(View view, int i10) {
        q qVar = this.f1190a;
        if (qVar == null) {
            return;
        }
        float f10 = this.L;
        float f11 = this.O;
        qVar.G(f10 / f11, this.M / f11);
    }

    @Override // android.view.View
    public boolean isAttachedToWindow() {
        return super.isAttachedToWindow();
    }

    @Override // androidx.core.view.u
    public void j(View view, int i10, int i11, int[] iArr, int i12) {
        q.b bVar;
        t tVarB;
        int iK;
        q qVar = this.f1190a;
        if (qVar == null || (bVar = qVar.f1483c) == null || !bVar.C()) {
            return;
        }
        q.b bVar2 = this.f1190a.f1483c;
        if (bVar2 == null || !bVar2.C() || (tVarB = bVar2.B()) == null || (iK = tVarB.k()) == -1 || view.getId() == iK) {
            q qVar2 = this.f1190a;
            if (qVar2 != null && qVar2.t()) {
                float f10 = this.f1217p;
                if ((f10 == 1.0f || f10 == 0.0f) && view.canScrollVertically(-1)) {
                    return;
                }
            }
            if (bVar2.B() != null && (this.f1190a.f1483c.B().d() & 1) != 0) {
                float fU = this.f1190a.u(i10, i11);
                float f11 = this.f1219q;
                if ((f11 <= 0.0f && fU < 0.0f) || (f11 >= 1.0f && fU > 0.0f)) {
                    view.setNestedScrollingEnabled(false);
                    view.post(new a(view));
                    return;
                }
            }
            float f12 = this.f1217p;
            long nanoTime = getNanoTime();
            float f13 = i10;
            this.L = f13;
            float f14 = i11;
            this.M = f14;
            this.O = (float) ((nanoTime - this.N) * 1.0E-9d);
            this.N = nanoTime;
            this.f1190a.F(f13, f14);
            if (f12 != this.f1217p) {
                iArr[0] = i10;
                iArr[1] = i11;
            }
            H(false);
            if (iArr[0] == 0 && iArr[1] == 0) {
                return;
            }
            this.K = true;
        }
    }

    @Override // androidx.constraintlayout.widget.ConstraintLayout
    public void loadLayoutDescription(int i10) {
        if (i10 == 0) {
            this.f1190a = null;
            return;
        }
        try {
            this.f1190a = new q(getContext(), this, i10);
            if (isAttachedToWindow()) {
                this.f1190a.J(this);
                this.f1216o0.d(this.mLayoutWidget, this.f1190a.i(this.f1199g), this.f1190a.i(this.f1203i));
                V();
                this.f1190a.L(isRtl());
            }
        } catch (Exception e10) {
            throw new IllegalArgumentException("unable to parse MotionScene file", e10);
        }
    }

    @Override // androidx.core.view.v
    public void m(View view, int i10, int i11, int i12, int i13, int i14, int[] iArr) {
        if (this.K || i10 != 0 || i11 != 0) {
            iArr[0] = iArr[0] + i12;
            iArr[1] = iArr[1] + i13;
        }
        this.K = false;
    }

    @Override // androidx.core.view.u
    public boolean o(View view, View view2, int i10, int i11) {
        q.b bVar;
        q qVar = this.f1190a;
        return (qVar == null || (bVar = qVar.f1483c) == null || bVar.B() == null || (this.f1190a.f1483c.B().d() & 2) != 0) ? false : true;
    }

    @Override // android.view.ViewGroup, android.view.View
    protected void onAttachedToWindow() {
        int i10;
        super.onAttachedToWindow();
        q qVar = this.f1190a;
        if (qVar != null && (i10 = this.f1201h) != -1) {
            androidx.constraintlayout.widget.b bVarI = qVar.i(i10);
            this.f1190a.J(this);
            if (bVarI != null) {
                bVarI.d(this);
            }
            this.f1199g = this.f1201h;
        }
        T();
        h hVar = this.f1212m0;
        if (hVar != null) {
            hVar.a();
        }
    }

    @Override // android.view.ViewGroup
    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        q.b bVar;
        t tVarB;
        int iK;
        RectF rectFJ;
        q qVar = this.f1190a;
        if (qVar != null && this.f1209l && (bVar = qVar.f1483c) != null && bVar.C() && (tVarB = bVar.B()) != null && ((motionEvent.getAction() != 0 || (rectFJ = tVarB.j(this, new RectF())) == null || rectFJ.contains(motionEvent.getX(), motionEvent.getY())) && (iK = tVarB.k()) != -1)) {
            View view = this.f1222r0;
            if (view == null || view.getId() != iK) {
                this.f1222r0 = findViewById(iK);
            }
            View view2 = this.f1222r0;
            if (view2 != null) {
                this.f1220q0.set(view2.getLeft(), this.f1222r0.getTop(), this.f1222r0.getRight(), this.f1222r0.getBottom());
                if (this.f1220q0.contains(motionEvent.getX(), motionEvent.getY()) && !P(0.0f, 0.0f, this.f1222r0, motionEvent)) {
                    return onTouchEvent(motionEvent);
                }
            }
        }
        return false;
    }

    @Override // androidx.constraintlayout.widget.ConstraintLayout, android.view.ViewGroup, android.view.View
    protected void onLayout(boolean z10, int i10, int i11, int i12, int i13) {
        this.f1210l0 = true;
        try {
            if (this.f1190a == null) {
                super.onLayout(z10, i10, i11, i12, i13);
                return;
            }
            int i14 = i12 - i10;
            int i15 = i13 - i11;
            if (this.I != i14 || this.J != i15) {
                V();
                H(true);
            }
            this.I = i14;
            this.J = i15;
            this.G = i14;
            this.H = i15;
        } finally {
            this.f1210l0 = false;
        }
    }

    @Override // androidx.constraintlayout.widget.ConstraintLayout, android.view.View
    protected void onMeasure(int i10, int i11) {
        if (this.f1190a == null) {
            super.onMeasure(i10, i11);
            return;
        }
        boolean z10 = false;
        boolean z11 = (this.f1205j == i10 && this.f1207k == i11) ? false : true;
        if (this.f1218p0) {
            this.f1218p0 = false;
            T();
            U();
            z11 = true;
        }
        if (this.mDirtyHierarchy) {
            z11 = true;
        }
        this.f1205j = i10;
        this.f1207k = i11;
        int iX = this.f1190a.x();
        int iN = this.f1190a.n();
        if ((z11 || this.f1216o0.e(iX, iN)) && this.f1199g != -1) {
            super.onMeasure(i10, i11);
            this.f1216o0.d(this.mLayoutWidget, this.f1190a.i(iX), this.f1190a.i(iN));
            this.f1216o0.g();
            this.f1216o0.h(iX, iN);
        } else {
            z10 = true;
        }
        if (this.f1195c0 || z10) {
            int paddingTop = getPaddingTop() + getPaddingBottom();
            int iQ = this.mLayoutWidget.Q() + getPaddingLeft() + getPaddingRight();
            int iW = this.mLayoutWidget.w() + paddingTop;
            int i12 = this.f1202h0;
            if (i12 == Integer.MIN_VALUE || i12 == 0) {
                int i13 = this.f1196d0;
                iQ = (int) (i13 + (this.f1206j0 * (this.f1198f0 - i13)));
                requestLayout();
            }
            int i14 = this.f1204i0;
            if (i14 == Integer.MIN_VALUE || i14 == 0) {
                int i15 = this.f1197e0;
                iW = (int) (i15 + (this.f1206j0 * (this.f1200g0 - i15)));
                requestLayout();
            }
            setMeasuredDimension(iQ, iW);
        }
        I();
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public boolean onNestedFling(View view, float f10, float f11, boolean z10) {
        return false;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public boolean onNestedPreFling(View view, float f10, float f11) {
        return false;
    }

    @Override // android.view.View
    public void onRtlPropertiesChanged(int i10) {
        q qVar = this.f1190a;
        if (qVar != null) {
            qVar.L(isRtl());
        }
    }

    @Override // android.view.View
    public boolean onTouchEvent(MotionEvent motionEvent) {
        q qVar = this.f1190a;
        if (qVar == null || !this.f1209l || !qVar.Q()) {
            return super.onTouchEvent(motionEvent);
        }
        q.b bVar = this.f1190a.f1483c;
        if (bVar != null && !bVar.C()) {
            return super.onTouchEvent(motionEvent);
        }
        this.f1190a.H(motionEvent, getCurrentState(), this);
        return true;
    }

    @Override // androidx.constraintlayout.widget.ConstraintLayout, android.view.ViewGroup
    public void onViewAdded(View view) {
        super.onViewAdded(view);
        if (view instanceof MotionHelper) {
            MotionHelper motionHelper = (MotionHelper) view;
            if (this.S == null) {
                this.S = new ArrayList<>();
            }
            this.S.add(motionHelper);
            if (motionHelper.w()) {
                if (this.Q == null) {
                    this.Q = new ArrayList<>();
                }
                this.Q.add(motionHelper);
            }
            if (motionHelper.v()) {
                if (this.R == null) {
                    this.R = new ArrayList<>();
                }
                this.R.add(motionHelper);
            }
        }
    }

    @Override // androidx.constraintlayout.widget.ConstraintLayout, android.view.ViewGroup
    public void onViewRemoved(View view) {
        super.onViewRemoved(view);
        ArrayList<MotionHelper> arrayList = this.Q;
        if (arrayList != null) {
            arrayList.remove(view);
        }
        ArrayList<MotionHelper> arrayList2 = this.R;
        if (arrayList2 != null) {
            arrayList2.remove(view);
        }
    }

    @Override // androidx.constraintlayout.widget.ConstraintLayout
    protected void parseLayoutDescription(int i10) {
        this.mConstraintLayoutSpec = null;
    }

    @Override // androidx.constraintlayout.widget.ConstraintLayout, android.view.View, android.view.ViewParent
    public void requestLayout() {
        q qVar;
        q.b bVar;
        if (this.f1195c0 || this.f1201h != -1 || (qVar = this.f1190a) == null || (bVar = qVar.f1483c) == null || bVar.z() != 0) {
            super.requestLayout();
        }
    }

    public void setDebugMode(int i10) {
        this.f1231z = i10;
        invalidate();
    }

    public void setInteractionEnabled(boolean z10) {
        this.f1209l = z10;
    }

    public void setInterpolatedProgress(float f10) {
        if (this.f1190a != null) {
            setState(TransitionState.MOVING);
            Interpolator interpolatorP = this.f1190a.p();
            if (interpolatorP != null) {
                setProgress(interpolatorP.getInterpolation(f10));
                return;
            }
        }
        setProgress(f10);
    }

    public void setOnHide(float f10) {
        ArrayList<MotionHelper> arrayList = this.R;
        if (arrayList != null) {
            int size = arrayList.size();
            for (int i10 = 0; i10 < size; i10++) {
                this.R.get(i10).setProgress(f10);
            }
        }
    }

    public void setOnShow(float f10) {
        ArrayList<MotionHelper> arrayList = this.Q;
        if (arrayList != null) {
            int size = arrayList.size();
            for (int i10 = 0; i10 < size; i10++) {
                this.Q.get(i10).setProgress(f10);
            }
        }
    }

    public void setProgress(float f10) {
        if (!isAttachedToWindow()) {
            if (this.f1212m0 == null) {
                this.f1212m0 = new h();
            }
            this.f1212m0.e(f10);
            return;
        }
        if (f10 <= 0.0f) {
            this.f1201h = this.f1199g;
            if (this.f1219q == 0.0f) {
                setState(TransitionState.FINISHED);
            }
        } else if (f10 >= 1.0f) {
            this.f1201h = this.f1203i;
            if (this.f1219q == 1.0f) {
                setState(TransitionState.FINISHED);
            }
        } else {
            this.f1201h = -1;
            setState(TransitionState.MOVING);
        }
        if (this.f1190a == null) {
            return;
        }
        this.f1225t = true;
        this.f1223s = f10;
        this.f1217p = f10;
        this.f1221r = -1L;
        this.f1213n = -1L;
        this.f1192b = null;
        this.f1226u = true;
        invalidate();
    }

    public void setScene(q qVar) {
        this.f1190a = qVar;
        qVar.L(isRtl());
        V();
    }

    void setState(TransitionState transitionState) {
        TransitionState transitionState2 = TransitionState.FINISHED;
        if (transitionState == transitionState2 && this.f1201h == -1) {
            return;
        }
        TransitionState transitionState3 = this.f1214n0;
        this.f1214n0 = transitionState;
        TransitionState transitionState4 = TransitionState.MOVING;
        if (transitionState3 == transitionState4 && transitionState == transitionState4) {
            J();
        }
        int i10 = b.f1239a[transitionState3.ordinal()];
        if (i10 != 1 && i10 != 2) {
            if (i10 == 3 && transitionState == transitionState2) {
                K();
                return;
            }
            return;
        }
        if (transitionState == transitionState4) {
            J();
        }
        if (transitionState == transitionState2) {
            K();
        }
    }

    public void setTransition(int i10) {
        float f10;
        if (this.f1190a != null) {
            q.b bVarN = N(i10);
            this.f1199g = bVarN.A();
            this.f1203i = bVarN.y();
            if (!isAttachedToWindow()) {
                if (this.f1212m0 == null) {
                    this.f1212m0 = new h();
                }
                this.f1212m0.f(this.f1199g);
                this.f1212m0.d(this.f1203i);
                return;
            }
            int i11 = this.f1201h;
            if (i11 == this.f1199g) {
                f10 = 0.0f;
            } else {
                f10 = i11 == this.f1203i ? 1.0f : Float.NaN;
            }
            this.f1190a.N(bVarN);
            this.f1216o0.d(this.mLayoutWidget, this.f1190a.i(this.f1199g), this.f1190a.i(this.f1203i));
            V();
            this.f1219q = Float.isNaN(f10) ? 0.0f : f10;
            if (!Float.isNaN(f10)) {
                setProgress(f10);
                return;
            }
            Log.v("MotionLayout", androidx.constraintlayout.motion.widget.a.a() + " transitionToStart ");
            b0();
        }
    }

    public void setTransitionDuration(int i10) {
        q qVar = this.f1190a;
        if (qVar == null) {
            Log.e("MotionLayout", "MotionScene not defined");
        } else {
            qVar.K(i10);
        }
    }

    public void setTransitionListener(i iVar) {
        this.f1228w = iVar;
    }

    public void setTransitionState(Bundle bundle) {
        if (this.f1212m0 == null) {
            this.f1212m0 = new h();
        }
        this.f1212m0.g(bundle);
        if (isAttachedToWindow()) {
            this.f1212m0.a();
        }
    }

    @Override // android.view.View
    public String toString() {
        Context context = getContext();
        return androidx.constraintlayout.motion.widget.a.b(context, this.f1199g) + "->" + androidx.constraintlayout.motion.widget.a.b(context, this.f1203i) + " (pos:" + this.f1219q + " Dpos/Dt:" + this.f1194c;
    }

    @Override // androidx.constraintlayout.widget.ConstraintLayout
    public void setState(int i10, int i11, int i12) {
        setState(TransitionState.SETUP);
        this.f1201h = i10;
        this.f1199g = -1;
        this.f1203i = -1;
        androidx.constraintlayout.widget.a aVar = this.mConstraintLayoutSpec;
        if (aVar != null) {
            aVar.d(i10, i11, i12);
            return;
        }
        q qVar = this.f1190a;
        if (qVar != null) {
            qVar.i(i10).d(this);
        }
    }

    protected void setTransition(q.b bVar) {
        this.f1190a.N(bVar);
        setState(TransitionState.SETUP);
        if (this.f1201h == this.f1190a.n()) {
            this.f1219q = 1.0f;
            this.f1217p = 1.0f;
            this.f1223s = 1.0f;
        } else {
            this.f1219q = 0.0f;
            this.f1217p = 0.0f;
            this.f1223s = 0.0f;
        }
        this.f1221r = bVar.D(1) ? -1L : getNanoTime();
        int iX = this.f1190a.x();
        int iN = this.f1190a.n();
        if (iX == this.f1199g && iN == this.f1203i) {
            return;
        }
        this.f1199g = iX;
        this.f1203i = iN;
        this.f1190a.M(iX, iN);
        this.f1216o0.d(this.mLayoutWidget, this.f1190a.i(this.f1199g), this.f1190a.i(this.f1203i));
        this.f1216o0.h(this.f1199g, this.f1203i);
        this.f1216o0.g();
        V();
    }

    public MotionLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f1194c = 0.0f;
        this.f1199g = -1;
        this.f1201h = -1;
        this.f1203i = -1;
        this.f1205j = 0;
        this.f1207k = 0;
        this.f1209l = true;
        this.f1211m = new HashMap<>();
        this.f1213n = 0L;
        this.f1215o = 1.0f;
        this.f1217p = 0.0f;
        this.f1219q = 0.0f;
        this.f1223s = 0.0f;
        this.f1226u = false;
        this.f1227v = false;
        this.f1231z = 0;
        this.B = false;
        this.C = new s.g();
        this.D = new c();
        this.F = true;
        this.K = false;
        this.P = false;
        this.Q = null;
        this.R = null;
        this.S = null;
        this.T = 0;
        this.U = -1L;
        this.V = 0.0f;
        this.W = 0;
        this.f1191a0 = 0.0f;
        this.f1193b0 = false;
        this.f1195c0 = false;
        this.f1208k0 = new androidx.constraintlayout.motion.widget.e();
        this.f1210l0 = false;
        this.f1214n0 = TransitionState.UNDEFINED;
        this.f1216o0 = new e();
        this.f1218p0 = false;
        this.f1220q0 = new RectF();
        this.f1222r0 = null;
        this.f1224s0 = new ArrayList<>();
        Q(attributeSet);
    }

    public MotionLayout(Context context, AttributeSet attributeSet, int i10) {
        super(context, attributeSet, i10);
        this.f1194c = 0.0f;
        this.f1199g = -1;
        this.f1201h = -1;
        this.f1203i = -1;
        this.f1205j = 0;
        this.f1207k = 0;
        this.f1209l = true;
        this.f1211m = new HashMap<>();
        this.f1213n = 0L;
        this.f1215o = 1.0f;
        this.f1217p = 0.0f;
        this.f1219q = 0.0f;
        this.f1223s = 0.0f;
        this.f1226u = false;
        this.f1227v = false;
        this.f1231z = 0;
        this.B = false;
        this.C = new s.g();
        this.D = new c();
        this.F = true;
        this.K = false;
        this.P = false;
        this.Q = null;
        this.R = null;
        this.S = null;
        this.T = 0;
        this.U = -1L;
        this.V = 0.0f;
        this.W = 0;
        this.f1191a0 = 0.0f;
        this.f1193b0 = false;
        this.f1195c0 = false;
        this.f1208k0 = new androidx.constraintlayout.motion.widget.e();
        this.f1210l0 = false;
        this.f1214n0 = TransitionState.UNDEFINED;
        this.f1216o0 = new e();
        this.f1218p0 = false;
        this.f1220q0 = new RectF();
        this.f1222r0 = null;
        this.f1224s0 = new ArrayList<>();
        Q(attributeSet);
    }

    @Override // androidx.core.view.u
    public void h(View view, View view2, int i10, int i11) {
    }

    @Override // androidx.core.view.u
    public void n(View view, int i10, int i11, int i12, int i13, int i14) {
    }
}
