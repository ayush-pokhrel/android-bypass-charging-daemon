package androidx.constraintlayout.motion.widget;

import android.util.Log;
import android.util.SparseArray;
import android.view.View;
import androidx.constraintlayout.widget.ConstraintAttribute;
import com.oplus.sceneservice.sdk.dataprovider.bean.UserProfileInfo;
import com.oplus.smartenginehelper.entity.ClickApiEntity;
import java.lang.reflect.Array;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.text.DecimalFormat;

/* JADX INFO: compiled from: TimeCycleSplineSet.java */
/* JADX INFO: loaded from: classes.dex */
public abstract class s {

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    private static float f1532k = 6.2831855f;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    protected s.b f1533a;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private int f1537e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private String f1538f;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    long f1541i;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    protected int f1534b = 0;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    protected int[] f1535c = new int[10];

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    protected float[][] f1536d = (float[][]) Array.newInstance((Class<?>) Float.TYPE, 10, 3);

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private float[] f1539g = new float[3];

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    protected boolean f1540h = false;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    float f1542j = Float.NaN;

    /* JADX INFO: compiled from: TimeCycleSplineSet.java */
    static class a extends s {
        a() {
        }

        @Override // androidx.constraintlayout.motion.widget.s
        public boolean f(View view, float f10, long j10, androidx.constraintlayout.motion.widget.e eVar) {
            view.setAlpha(b(f10, j10, view, eVar));
            return this.f1540h;
        }
    }

    /* JADX INFO: compiled from: TimeCycleSplineSet.java */
    static class b extends s {

        /* JADX INFO: renamed from: l, reason: collision with root package name */
        String f1543l;

        /* JADX INFO: renamed from: m, reason: collision with root package name */
        SparseArray<ConstraintAttribute> f1544m;

        /* JADX INFO: renamed from: n, reason: collision with root package name */
        SparseArray<float[]> f1545n = new SparseArray<>();

        /* JADX INFO: renamed from: o, reason: collision with root package name */
        float[] f1546o;

        /* JADX INFO: renamed from: p, reason: collision with root package name */
        float[] f1547p;

        public b(String str, SparseArray<ConstraintAttribute> sparseArray) {
            this.f1543l = str.split(",")[1];
            this.f1544m = sparseArray;
        }

        @Override // androidx.constraintlayout.motion.widget.s
        public void e(int i10, float f10, float f11, int i11, float f12) {
            throw new RuntimeException("don't call for custom attribute call setPoint(pos, ConstraintAttribute,...)");
        }

        @Override // androidx.constraintlayout.motion.widget.s
        public boolean f(View view, float f10, long j10, androidx.constraintlayout.motion.widget.e eVar) {
            this.f1533a.e(f10, this.f1546o);
            float[] fArr = this.f1546o;
            float f11 = fArr[fArr.length - 2];
            float f12 = fArr[fArr.length - 1];
            float f13 = (float) ((((double) this.f1542j) + (((j10 - this.f1541i) * 1.0E-9d) * ((double) f11))) % 1.0d);
            this.f1542j = f13;
            this.f1541i = j10;
            float fA = a(f13);
            this.f1540h = false;
            int i10 = 0;
            while (true) {
                float[] fArr2 = this.f1547p;
                if (i10 >= fArr2.length) {
                    break;
                }
                boolean z10 = this.f1540h;
                float f14 = this.f1546o[i10];
                this.f1540h = z10 | (((double) f14) != UserProfileInfo.Constant.NA_LAT_LON);
                fArr2[i10] = (f14 * fA) + f12;
                i10++;
            }
            this.f1544m.valueAt(0).i(view, this.f1547p);
            if (f11 != 0.0f) {
                this.f1540h = true;
            }
            return this.f1540h;
        }

        @Override // androidx.constraintlayout.motion.widget.s
        public void i(int i10) {
            int size = this.f1544m.size();
            int iF = this.f1544m.valueAt(0).f();
            double[] dArr = new double[size];
            int i11 = iF + 2;
            this.f1546o = new float[i11];
            this.f1547p = new float[iF];
            double[][] dArr2 = (double[][]) Array.newInstance((Class<?>) Double.TYPE, size, i11);
            for (int i12 = 0; i12 < size; i12++) {
                int iKeyAt = this.f1544m.keyAt(i12);
                ConstraintAttribute constraintAttributeValueAt = this.f1544m.valueAt(i12);
                float[] fArrValueAt = this.f1545n.valueAt(i12);
                dArr[i12] = ((double) iKeyAt) * 0.01d;
                constraintAttributeValueAt.e(this.f1546o);
                int i13 = 0;
                while (true) {
                    float[] fArr = this.f1546o;
                    if (i13 < fArr.length) {
                        dArr2[i12][i13] = fArr[i13];
                        i13++;
                    }
                }
                double[] dArr3 = dArr2[i12];
                dArr3[iF] = fArrValueAt[0];
                dArr3[iF + 1] = fArrValueAt[1];
            }
            this.f1533a = s.b.a(i10, dArr, dArr2);
        }

        public void j(int i10, ConstraintAttribute constraintAttribute, float f10, int i11, float f11) {
            this.f1544m.append(i10, constraintAttribute);
            this.f1545n.append(i10, new float[]{f10, f11});
            this.f1534b = Math.max(this.f1534b, i11);
        }
    }

    /* JADX INFO: compiled from: TimeCycleSplineSet.java */
    static class c extends s {
        c() {
        }

        @Override // androidx.constraintlayout.motion.widget.s
        public boolean f(View view, float f10, long j10, androidx.constraintlayout.motion.widget.e eVar) {
            view.setElevation(b(f10, j10, view, eVar));
            return this.f1540h;
        }
    }

    /* JADX INFO: compiled from: TimeCycleSplineSet.java */
    static class d extends s {
        d() {
        }

        @Override // androidx.constraintlayout.motion.widget.s
        public boolean f(View view, float f10, long j10, androidx.constraintlayout.motion.widget.e eVar) {
            return this.f1540h;
        }

        public boolean j(View view, androidx.constraintlayout.motion.widget.e eVar, float f10, long j10, double d10, double d11) {
            view.setRotation(b(f10, j10, view, eVar) + ((float) Math.toDegrees(Math.atan2(d11, d10))));
            return this.f1540h;
        }
    }

    /* JADX INFO: compiled from: TimeCycleSplineSet.java */
    static class e extends s {

        /* JADX INFO: renamed from: l, reason: collision with root package name */
        boolean f1548l = false;

        e() {
        }

        @Override // androidx.constraintlayout.motion.widget.s
        public boolean f(View view, float f10, long j10, androidx.constraintlayout.motion.widget.e eVar) {
            Method method;
            if (view instanceof MotionLayout) {
                ((MotionLayout) view).setProgress(b(f10, j10, view, eVar));
            } else {
                if (this.f1548l) {
                    return false;
                }
                try {
                    method = view.getClass().getMethod(ClickApiEntity.SET_PROGRESS, Float.TYPE);
                } catch (NoSuchMethodException unused) {
                    this.f1548l = true;
                    method = null;
                }
                if (method != null) {
                    try {
                        method.invoke(view, Float.valueOf(b(f10, j10, view, eVar)));
                    } catch (IllegalAccessException e10) {
                        Log.e("SplineSet", "unable to setProgress", e10);
                    } catch (InvocationTargetException e11) {
                        Log.e("SplineSet", "unable to setProgress", e11);
                    }
                }
            }
            return this.f1540h;
        }
    }

    /* JADX INFO: compiled from: TimeCycleSplineSet.java */
    static class f extends s {
        f() {
        }

        @Override // androidx.constraintlayout.motion.widget.s
        public boolean f(View view, float f10, long j10, androidx.constraintlayout.motion.widget.e eVar) {
            view.setRotation(b(f10, j10, view, eVar));
            return this.f1540h;
        }
    }

    /* JADX INFO: compiled from: TimeCycleSplineSet.java */
    static class g extends s {
        g() {
        }

        @Override // androidx.constraintlayout.motion.widget.s
        public boolean f(View view, float f10, long j10, androidx.constraintlayout.motion.widget.e eVar) {
            view.setRotationX(b(f10, j10, view, eVar));
            return this.f1540h;
        }
    }

    /* JADX INFO: compiled from: TimeCycleSplineSet.java */
    static class h extends s {
        h() {
        }

        @Override // androidx.constraintlayout.motion.widget.s
        public boolean f(View view, float f10, long j10, androidx.constraintlayout.motion.widget.e eVar) {
            view.setRotationY(b(f10, j10, view, eVar));
            return this.f1540h;
        }
    }

    /* JADX INFO: compiled from: TimeCycleSplineSet.java */
    static class i extends s {
        i() {
        }

        @Override // androidx.constraintlayout.motion.widget.s
        public boolean f(View view, float f10, long j10, androidx.constraintlayout.motion.widget.e eVar) {
            view.setScaleX(b(f10, j10, view, eVar));
            return this.f1540h;
        }
    }

    /* JADX INFO: compiled from: TimeCycleSplineSet.java */
    static class j extends s {
        j() {
        }

        @Override // androidx.constraintlayout.motion.widget.s
        public boolean f(View view, float f10, long j10, androidx.constraintlayout.motion.widget.e eVar) {
            view.setScaleY(b(f10, j10, view, eVar));
            return this.f1540h;
        }
    }

    /* JADX INFO: compiled from: TimeCycleSplineSet.java */
    private static class k {
        static void a(int[] iArr, float[][] fArr, int i10, int i11) {
            int[] iArr2 = new int[iArr.length + 10];
            iArr2[0] = i11;
            iArr2[1] = i10;
            int i12 = 2;
            while (i12 > 0) {
                int i13 = iArr2[i12 - 1];
                int i14 = i12 - 2;
                int i15 = iArr2[i14];
                if (i13 < i15) {
                    int iB = b(iArr, fArr, i13, i15);
                    iArr2[i14] = iB - 1;
                    iArr2[i12 - 1] = i13;
                    int i16 = i12 + 1;
                    iArr2[i12] = i15;
                    i12 += 2;
                    iArr2[i16] = iB + 1;
                } else {
                    i12 = i14;
                }
            }
        }

        private static int b(int[] iArr, float[][] fArr, int i10, int i11) {
            int i12 = iArr[i11];
            int i13 = i10;
            while (i10 < i11) {
                if (iArr[i10] <= i12) {
                    c(iArr, fArr, i13, i10);
                    i13++;
                }
                i10++;
            }
            c(iArr, fArr, i13, i11);
            return i13;
        }

        private static void c(int[] iArr, float[][] fArr, int i10, int i11) {
            int i12 = iArr[i10];
            iArr[i10] = iArr[i11];
            iArr[i11] = i12;
            float[] fArr2 = fArr[i10];
            fArr[i10] = fArr[i11];
            fArr[i11] = fArr2;
        }
    }

    /* JADX INFO: compiled from: TimeCycleSplineSet.java */
    static class l extends s {
        l() {
        }

        @Override // androidx.constraintlayout.motion.widget.s
        public boolean f(View view, float f10, long j10, androidx.constraintlayout.motion.widget.e eVar) {
            view.setTranslationX(b(f10, j10, view, eVar));
            return this.f1540h;
        }
    }

    /* JADX INFO: compiled from: TimeCycleSplineSet.java */
    static class m extends s {
        m() {
        }

        @Override // androidx.constraintlayout.motion.widget.s
        public boolean f(View view, float f10, long j10, androidx.constraintlayout.motion.widget.e eVar) {
            view.setTranslationY(b(f10, j10, view, eVar));
            return this.f1540h;
        }
    }

    /* JADX INFO: compiled from: TimeCycleSplineSet.java */
    static class n extends s {
        n() {
        }

        @Override // androidx.constraintlayout.motion.widget.s
        public boolean f(View view, float f10, long j10, androidx.constraintlayout.motion.widget.e eVar) {
            view.setTranslationZ(b(f10, j10, view, eVar));
            return this.f1540h;
        }
    }

    static s c(String str, SparseArray<ConstraintAttribute> sparseArray) {
        return new b(str, sparseArray);
    }

    static s d(String str, long j10) {
        s gVar;
        str.hashCode();
        switch (str) {
            case "rotationX":
                gVar = new g();
                break;
            case "rotationY":
                gVar = new h();
                break;
            case "translationX":
                gVar = new l();
                break;
            case "translationY":
                gVar = new m();
                break;
            case "translationZ":
                gVar = new n();
                break;
            case "progress":
                gVar = new e();
                break;
            case "scaleX":
                gVar = new i();
                break;
            case "scaleY":
                gVar = new j();
                break;
            case "rotation":
                gVar = new f();
                break;
            case "elevation":
                gVar = new c();
                break;
            case "transitionPathRotate":
                gVar = new d();
                break;
            case "alpha":
                gVar = new a();
                break;
            default:
                return null;
        }
        gVar.g(j10);
        return gVar;
    }

    protected float a(float f10) {
        switch (this.f1534b) {
            case 1:
                return Math.signum(f10 * f1532k);
            case 2:
                return 1.0f - Math.abs(f10);
            case 3:
                return (((f10 * 2.0f) + 1.0f) % 2.0f) - 1.0f;
            case 4:
                return 1.0f - (((f10 * 2.0f) + 1.0f) % 2.0f);
            case 5:
                return (float) Math.cos(f10 * f1532k);
            case 6:
                float fAbs = 1.0f - Math.abs(((f10 * 4.0f) % 4.0f) - 2.0f);
                return 1.0f - (fAbs * fAbs);
            default:
                return (float) Math.sin(f10 * f1532k);
        }
    }

    public float b(float f10, long j10, View view, androidx.constraintlayout.motion.widget.e eVar) {
        this.f1533a.e(f10, this.f1539g);
        float[] fArr = this.f1539g;
        float f11 = fArr[1];
        if (f11 == 0.0f) {
            this.f1540h = false;
            return fArr[2];
        }
        if (Float.isNaN(this.f1542j)) {
            float fA = eVar.a(view, this.f1538f, 0);
            this.f1542j = fA;
            if (Float.isNaN(fA)) {
                this.f1542j = 0.0f;
            }
        }
        float f12 = (float) ((((double) this.f1542j) + (((j10 - this.f1541i) * 1.0E-9d) * ((double) f11))) % 1.0d);
        this.f1542j = f12;
        eVar.b(view, this.f1538f, 0, f12);
        this.f1541i = j10;
        float f13 = this.f1539g[0];
        float fA2 = (a(this.f1542j) * f13) + this.f1539g[2];
        this.f1540h = (f13 == 0.0f && f11 == 0.0f) ? false : true;
        return fA2;
    }

    public void e(int i10, float f10, float f11, int i11, float f12) {
        int[] iArr = this.f1535c;
        int i12 = this.f1537e;
        iArr[i12] = i10;
        float[] fArr = this.f1536d[i12];
        fArr[0] = f10;
        fArr[1] = f11;
        fArr[2] = f12;
        this.f1534b = Math.max(this.f1534b, i11);
        this.f1537e++;
    }

    public abstract boolean f(View view, float f10, long j10, androidx.constraintlayout.motion.widget.e eVar);

    protected void g(long j10) {
        this.f1541i = j10;
    }

    public void h(String str) {
        this.f1538f = str;
    }

    /* JADX WARN: Code duplicated, block: B:22:0x0063  */
    public void i(int i10) {
        int i11 = this.f1537e;
        if (i11 == 0) {
            Log.e("SplineSet", "Error no points added to " + this.f1538f);
            return;
        }
        k.a(this.f1535c, this.f1536d, 0, i11 - 1);
        int i12 = 1;
        int i13 = 0;
        while (true) {
            int[] iArr = this.f1535c;
            if (i12 >= iArr.length) {
                break;
            }
            if (iArr[i12] != iArr[i12 - 1]) {
                i13++;
            }
            i12++;
        }
        if (i13 == 0) {
            i13 = 1;
        }
        double[] dArr = new double[i13];
        double[][] dArr2 = (double[][]) Array.newInstance((Class<?>) Double.TYPE, i13, 3);
        int i14 = 0;
        for (int i15 = 0; i15 < this.f1537e; i15++) {
            if (i15 > 0) {
                int[] iArr2 = this.f1535c;
                if (iArr2[i15] != iArr2[i15 - 1]) {
                    dArr[i14] = ((double) this.f1535c[i15]) * 0.01d;
                    double[] dArr3 = dArr2[i14];
                    float[] fArr = this.f1536d[i15];
                    dArr3[0] = fArr[0];
                    dArr3[1] = fArr[1];
                    dArr3[2] = fArr[2];
                    i14++;
                }
            } else {
                dArr[i14] = ((double) this.f1535c[i15]) * 0.01d;
                double[] dArr4 = dArr2[i14];
                float[] fArr2 = this.f1536d[i15];
                dArr4[0] = fArr2[0];
                dArr4[1] = fArr2[1];
                dArr4[2] = fArr2[2];
                i14++;
            }
        }
        this.f1533a = s.b.a(i10, dArr, dArr2);
    }

    public String toString() {
        String str = this.f1538f;
        DecimalFormat decimalFormat = new DecimalFormat("##.##");
        for (int i10 = 0; i10 < this.f1537e; i10++) {
            str = str + "[" + this.f1535c[i10] + " , " + decimalFormat.format(this.f1536d[i10]) + "] ";
        }
        return str;
    }
}
