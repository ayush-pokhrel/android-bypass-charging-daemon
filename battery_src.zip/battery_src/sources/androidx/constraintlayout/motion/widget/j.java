package androidx.constraintlayout.motion.widget;

import java.util.HashSet;

/* JADX INFO: compiled from: KeyPositionBase.java */
/* JADX INFO: loaded from: classes.dex */
abstract class j extends c {

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    int f1376g = c.f1290f;

    j() {
    }

    @Override // androidx.constraintlayout.motion.widget.c
    void b(HashSet<String> hashSet) {
    }
}
