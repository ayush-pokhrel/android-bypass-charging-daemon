package androidx.constraintlayout.motion.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseIntArray;
import androidx.constraintlayout.widget.ConstraintAttribute;
import androidx.constraintlayout.widget.R$styleable;
import com.oplus.smartenginehelper.ParserTag;
import com.oplus.smartenginehelper.entity.ViewEntity;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;

/* JADX INFO: compiled from: KeyTimeCycle.java */
/* JADX INFO: loaded from: classes.dex */
public class k extends c {

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private String f1377g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private int f1378h = -1;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private float f1379i = Float.NaN;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private float f1380j = Float.NaN;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    private float f1381k = Float.NaN;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private float f1382l = Float.NaN;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    private float f1383m = Float.NaN;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    private float f1384n = Float.NaN;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    private float f1385o = Float.NaN;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    private float f1386p = Float.NaN;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    private float f1387q = Float.NaN;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    private float f1388r = Float.NaN;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    private float f1389s = Float.NaN;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    private float f1390t = Float.NaN;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    private int f1391u = 0;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    private float f1392v = Float.NaN;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    private float f1393w = 0.0f;

    /* JADX INFO: compiled from: KeyTimeCycle.java */
    private static class a {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private static SparseIntArray f1394a;

        static {
            SparseIntArray sparseIntArray = new SparseIntArray();
            f1394a = sparseIntArray;
            sparseIntArray.append(R$styleable.KeyTimeCycle_android_alpha, 1);
            f1394a.append(R$styleable.KeyTimeCycle_android_elevation, 2);
            f1394a.append(R$styleable.KeyTimeCycle_android_rotation, 4);
            f1394a.append(R$styleable.KeyTimeCycle_android_rotationX, 5);
            f1394a.append(R$styleable.KeyTimeCycle_android_rotationY, 6);
            f1394a.append(R$styleable.KeyTimeCycle_android_scaleX, 7);
            f1394a.append(R$styleable.KeyTimeCycle_transitionPathRotate, 8);
            f1394a.append(R$styleable.KeyTimeCycle_transitionEasing, 9);
            f1394a.append(R$styleable.KeyTimeCycle_motionTarget, 10);
            f1394a.append(R$styleable.KeyTimeCycle_framePosition, 12);
            f1394a.append(R$styleable.KeyTimeCycle_curveFit, 13);
            f1394a.append(R$styleable.KeyTimeCycle_android_scaleY, 14);
            f1394a.append(R$styleable.KeyTimeCycle_android_translationX, 15);
            f1394a.append(R$styleable.KeyTimeCycle_android_translationY, 16);
            f1394a.append(R$styleable.KeyTimeCycle_android_translationZ, 17);
            f1394a.append(R$styleable.KeyTimeCycle_motionProgress, 18);
            f1394a.append(R$styleable.KeyTimeCycle_wavePeriod, 20);
            f1394a.append(R$styleable.KeyTimeCycle_waveOffset, 21);
            f1394a.append(R$styleable.KeyTimeCycle_waveShape, 19);
        }

        public static void a(k kVar, TypedArray typedArray) {
            int indexCount = typedArray.getIndexCount();
            for (int i10 = 0; i10 < indexCount; i10++) {
                int index = typedArray.getIndex(i10);
                switch (f1394a.get(index)) {
                    case 1:
                        kVar.f1379i = typedArray.getFloat(index, kVar.f1379i);
                        break;
                    case 2:
                        kVar.f1380j = typedArray.getDimension(index, kVar.f1380j);
                        break;
                    case 3:
                    case 11:
                    default:
                        Log.e("KeyTimeCycle", "unused attribute 0x" + Integer.toHexString(index) + "   " + f1394a.get(index));
                        break;
                    case 4:
                        kVar.f1381k = typedArray.getFloat(index, kVar.f1381k);
                        break;
                    case 5:
                        kVar.f1382l = typedArray.getFloat(index, kVar.f1382l);
                        break;
                    case 6:
                        kVar.f1383m = typedArray.getFloat(index, kVar.f1383m);
                        break;
                    case 7:
                        kVar.f1385o = typedArray.getFloat(index, kVar.f1385o);
                        break;
                    case 8:
                        kVar.f1384n = typedArray.getFloat(index, kVar.f1384n);
                        break;
                    case 9:
                        kVar.f1377g = typedArray.getString(index);
                        break;
                    case 10:
                        if (MotionLayout.f1189t0) {
                            int resourceId = typedArray.getResourceId(index, kVar.f1292b);
                            kVar.f1292b = resourceId;
                            if (resourceId == -1) {
                                kVar.f1293c = typedArray.getString(index);
                            }
                        } else if (typedArray.peekValue(index).type == 3) {
                            kVar.f1293c = typedArray.getString(index);
                        } else {
                            kVar.f1292b = typedArray.getResourceId(index, kVar.f1292b);
                        }
                        break;
                    case 12:
                        kVar.f1291a = typedArray.getInt(index, kVar.f1291a);
                        break;
                    case 13:
                        kVar.f1378h = typedArray.getInteger(index, kVar.f1378h);
                        break;
                    case 14:
                        kVar.f1386p = typedArray.getFloat(index, kVar.f1386p);
                        break;
                    case 15:
                        kVar.f1387q = typedArray.getDimension(index, kVar.f1387q);
                        break;
                    case 16:
                        kVar.f1388r = typedArray.getDimension(index, kVar.f1388r);
                        break;
                    case 17:
                        kVar.f1389s = typedArray.getDimension(index, kVar.f1389s);
                        break;
                    case 18:
                        kVar.f1390t = typedArray.getFloat(index, kVar.f1390t);
                        break;
                    case 19:
                        kVar.f1391u = typedArray.getInt(index, kVar.f1391u);
                        break;
                    case 20:
                        kVar.f1392v = typedArray.getFloat(index, kVar.f1392v);
                        break;
                    case 21:
                        if (typedArray.peekValue(index).type == 5) {
                            kVar.f1393w = typedArray.getDimension(index, kVar.f1393w);
                        } else {
                            kVar.f1393w = typedArray.getFloat(index, kVar.f1393w);
                        }
                        break;
                }
            }
        }
    }

    public k() {
        this.f1294d = 3;
        this.f1295e = new HashMap<>();
    }

    public void M(HashMap<String, s> map) {
        for (String str : map.keySet()) {
            s sVar = map.get(str);
            if (!str.startsWith("CUSTOM")) {
                switch (str) {
                    case "rotationX":
                        if (Float.isNaN(this.f1382l)) {
                            break;
                        } else {
                            sVar.e(this.f1291a, this.f1382l, this.f1392v, this.f1391u, this.f1393w);
                            break;
                        }
                        break;
                    case "rotationY":
                        if (Float.isNaN(this.f1383m)) {
                            break;
                        } else {
                            sVar.e(this.f1291a, this.f1383m, this.f1392v, this.f1391u, this.f1393w);
                            break;
                        }
                        break;
                    case "translationX":
                        if (Float.isNaN(this.f1387q)) {
                            break;
                        } else {
                            sVar.e(this.f1291a, this.f1387q, this.f1392v, this.f1391u, this.f1393w);
                            break;
                        }
                        break;
                    case "translationY":
                        if (Float.isNaN(this.f1388r)) {
                            break;
                        } else {
                            sVar.e(this.f1291a, this.f1388r, this.f1392v, this.f1391u, this.f1393w);
                            break;
                        }
                        break;
                    case "translationZ":
                        if (Float.isNaN(this.f1389s)) {
                            break;
                        } else {
                            sVar.e(this.f1291a, this.f1389s, this.f1392v, this.f1391u, this.f1393w);
                            break;
                        }
                        break;
                    case "progress":
                        if (Float.isNaN(this.f1390t)) {
                            break;
                        } else {
                            sVar.e(this.f1291a, this.f1390t, this.f1392v, this.f1391u, this.f1393w);
                            break;
                        }
                        break;
                    case "scaleX":
                        if (Float.isNaN(this.f1385o)) {
                            break;
                        } else {
                            sVar.e(this.f1291a, this.f1385o, this.f1392v, this.f1391u, this.f1393w);
                            break;
                        }
                        break;
                    case "scaleY":
                        if (Float.isNaN(this.f1386p)) {
                            break;
                        } else {
                            sVar.e(this.f1291a, this.f1386p, this.f1392v, this.f1391u, this.f1393w);
                            break;
                        }
                        break;
                    case "rotation":
                        if (Float.isNaN(this.f1381k)) {
                            break;
                        } else {
                            sVar.e(this.f1291a, this.f1381k, this.f1392v, this.f1391u, this.f1393w);
                            break;
                        }
                        break;
                    case "elevation":
                        if (Float.isNaN(this.f1380j)) {
                            break;
                        } else {
                            sVar.e(this.f1291a, this.f1380j, this.f1392v, this.f1391u, this.f1393w);
                            break;
                        }
                        break;
                    case "transitionPathRotate":
                        if (Float.isNaN(this.f1384n)) {
                            break;
                        } else {
                            sVar.e(this.f1291a, this.f1384n, this.f1392v, this.f1391u, this.f1393w);
                            break;
                        }
                        break;
                    case "alpha":
                        if (Float.isNaN(this.f1379i)) {
                            break;
                        } else {
                            sVar.e(this.f1291a, this.f1379i, this.f1392v, this.f1391u, this.f1393w);
                            break;
                        }
                        break;
                    default:
                        Log.e("KeyTimeCycles", "UNKNOWN addValues \"" + str + "\"");
                        break;
                }
            } else {
                ConstraintAttribute constraintAttribute = this.f1295e.get(str.substring(7));
                if (constraintAttribute != null) {
                    ((s.b) sVar).j(this.f1291a, constraintAttribute, this.f1392v, this.f1391u, this.f1393w);
                }
            }
        }
    }

    @Override // androidx.constraintlayout.motion.widget.c
    public void a(HashMap<String, r> map) {
        throw new IllegalArgumentException(" KeyTimeCycles do not support SplineSet");
    }

    @Override // androidx.constraintlayout.motion.widget.c
    public void b(HashSet<String> hashSet) {
        if (!Float.isNaN(this.f1379i)) {
            hashSet.add(ViewEntity.ALPHA);
        }
        if (!Float.isNaN(this.f1380j)) {
            hashSet.add(ViewEntity.ELEVATION);
        }
        if (!Float.isNaN(this.f1381k)) {
            hashSet.add(ViewEntity.ROTATION);
        }
        if (!Float.isNaN(this.f1382l)) {
            hashSet.add(ViewEntity.ROTATION_X);
        }
        if (!Float.isNaN(this.f1383m)) {
            hashSet.add(ViewEntity.ROTATION_Y);
        }
        if (!Float.isNaN(this.f1387q)) {
            hashSet.add(ViewEntity.TRANSLATION_X);
        }
        if (!Float.isNaN(this.f1388r)) {
            hashSet.add(ViewEntity.TRANSLATION_Y);
        }
        if (!Float.isNaN(this.f1389s)) {
            hashSet.add(ViewEntity.TRANSLATION_Z);
        }
        if (!Float.isNaN(this.f1384n)) {
            hashSet.add("transitionPathRotate");
        }
        if (!Float.isNaN(this.f1385o)) {
            hashSet.add(ViewEntity.SCALE_X);
        }
        if (!Float.isNaN(this.f1386p)) {
            hashSet.add(ViewEntity.SCALE_Y);
        }
        if (!Float.isNaN(this.f1390t)) {
            hashSet.add(ParserTag.TAG_PROGRESS);
        }
        if (this.f1295e.size() > 0) {
            Iterator<String> it = this.f1295e.keySet().iterator();
            while (it.hasNext()) {
                hashSet.add("CUSTOM," + it.next());
            }
        }
    }

    @Override // androidx.constraintlayout.motion.widget.c
    public void c(Context context, AttributeSet attributeSet) {
        a.a(this, context.obtainStyledAttributes(attributeSet, R$styleable.KeyTimeCycle));
    }

    @Override // androidx.constraintlayout.motion.widget.c
    public void e(HashMap<String, Integer> map) {
        if (this.f1378h == -1) {
            return;
        }
        if (!Float.isNaN(this.f1379i)) {
            map.put(ViewEntity.ALPHA, Integer.valueOf(this.f1378h));
        }
        if (!Float.isNaN(this.f1380j)) {
            map.put(ViewEntity.ELEVATION, Integer.valueOf(this.f1378h));
        }
        if (!Float.isNaN(this.f1381k)) {
            map.put(ViewEntity.ROTATION, Integer.valueOf(this.f1378h));
        }
        if (!Float.isNaN(this.f1382l)) {
            map.put(ViewEntity.ROTATION_X, Integer.valueOf(this.f1378h));
        }
        if (!Float.isNaN(this.f1383m)) {
            map.put(ViewEntity.ROTATION_Y, Integer.valueOf(this.f1378h));
        }
        if (!Float.isNaN(this.f1387q)) {
            map.put(ViewEntity.TRANSLATION_X, Integer.valueOf(this.f1378h));
        }
        if (!Float.isNaN(this.f1388r)) {
            map.put(ViewEntity.TRANSLATION_Y, Integer.valueOf(this.f1378h));
        }
        if (!Float.isNaN(this.f1389s)) {
            map.put(ViewEntity.TRANSLATION_Z, Integer.valueOf(this.f1378h));
        }
        if (!Float.isNaN(this.f1384n)) {
            map.put("transitionPathRotate", Integer.valueOf(this.f1378h));
        }
        if (!Float.isNaN(this.f1385o)) {
            map.put(ViewEntity.SCALE_X, Integer.valueOf(this.f1378h));
        }
        if (!Float.isNaN(this.f1385o)) {
            map.put(ViewEntity.SCALE_Y, Integer.valueOf(this.f1378h));
        }
        if (!Float.isNaN(this.f1390t)) {
            map.put(ParserTag.TAG_PROGRESS, Integer.valueOf(this.f1378h));
        }
        if (this.f1295e.size() > 0) {
            Iterator<String> it = this.f1295e.keySet().iterator();
            while (it.hasNext()) {
                map.put("CUSTOM," + it.next(), Integer.valueOf(this.f1378h));
            }
        }
    }
}
