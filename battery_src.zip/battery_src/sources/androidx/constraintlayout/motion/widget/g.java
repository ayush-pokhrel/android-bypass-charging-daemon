package androidx.constraintlayout.motion.widget;

import android.annotation.TargetApi;
import android.util.Log;
import android.view.View;
import androidx.constraintlayout.widget.ConstraintAttribute;
import com.oplus.sceneservice.sdk.dataprovider.bean.UserProfileInfo;
import com.oplus.smartenginehelper.entity.ClickApiEntity;
import java.lang.reflect.Array;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;

/* JADX INFO: compiled from: KeyCycleOscillator.java */
/* JADX INFO: loaded from: classes.dex */
public abstract class g {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private s.b f1334a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private d f1335b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    protected ConstraintAttribute f1336c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private String f1337d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private int f1338e = 0;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    public int f1339f = 0;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    ArrayList<p> f1340g = new ArrayList<>();

    /* JADX INFO: compiled from: KeyCycleOscillator.java */
    class a implements Comparator<p> {
        a() {
        }

        @Override // java.util.Comparator
        /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
        public int compare(p pVar, p pVar2) {
            return Integer.compare(pVar.f1357a, pVar2.f1357a);
        }
    }

    /* JADX INFO: compiled from: KeyCycleOscillator.java */
    static class b extends g {
        b() {
        }

        @Override // androidx.constraintlayout.motion.widget.g
        public void f(View view, float f10) {
            view.setAlpha(a(f10));
        }
    }

    /* JADX INFO: compiled from: KeyCycleOscillator.java */
    static class c extends g {

        /* JADX INFO: renamed from: h, reason: collision with root package name */
        float[] f1342h = new float[1];

        c() {
        }

        @Override // androidx.constraintlayout.motion.widget.g
        public void f(View view, float f10) {
            this.f1342h[0] = a(f10);
            this.f1336c.i(view, this.f1342h);
        }
    }

    /* JADX INFO: compiled from: KeyCycleOscillator.java */
    static class d {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private final int f1343a;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        float[] f1345c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        double[] f1346d;

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        float[] f1347e;

        /* JADX INFO: renamed from: f, reason: collision with root package name */
        float[] f1348f;

        /* JADX INFO: renamed from: g, reason: collision with root package name */
        float[] f1349g;

        /* JADX INFO: renamed from: h, reason: collision with root package name */
        int f1350h;

        /* JADX INFO: renamed from: i, reason: collision with root package name */
        s.b f1351i;

        /* JADX INFO: renamed from: j, reason: collision with root package name */
        double[] f1352j;

        /* JADX INFO: renamed from: k, reason: collision with root package name */
        double[] f1353k;

        /* JADX INFO: renamed from: l, reason: collision with root package name */
        float f1354l;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        s.f f1344b = new s.f();

        /* JADX INFO: renamed from: m, reason: collision with root package name */
        public HashMap<String, ConstraintAttribute> f1355m = new HashMap<>();

        d(int i10, int i11, int i12) {
            this.f1350h = i10;
            this.f1343a = i11;
            this.f1344b.g(i10);
            this.f1345c = new float[i12];
            this.f1346d = new double[i12];
            this.f1347e = new float[i12];
            this.f1348f = new float[i12];
            this.f1349g = new float[i12];
        }

        public double a(float f10) {
            s.b bVar = this.f1351i;
            if (bVar != null) {
                double d10 = f10;
                bVar.g(d10, this.f1353k);
                this.f1351i.d(d10, this.f1352j);
            } else {
                double[] dArr = this.f1353k;
                dArr[0] = 0.0d;
                dArr[1] = 0.0d;
            }
            double d11 = f10;
            double dE = this.f1344b.e(d11);
            double d12 = this.f1344b.d(d11);
            double[] dArr2 = this.f1353k;
            return dArr2[0] + (dE * dArr2[1]) + (d12 * this.f1352j[1]);
        }

        public double b(float f10) {
            s.b bVar = this.f1351i;
            if (bVar != null) {
                bVar.d(f10, this.f1352j);
            } else {
                double[] dArr = this.f1352j;
                dArr[0] = this.f1348f[0];
                dArr[1] = this.f1345c[0];
            }
            return this.f1352j[0] + (this.f1344b.e(f10) * this.f1352j[1]);
        }

        public void c(int i10, int i11, float f10, float f11, float f12) {
            this.f1346d[i10] = ((double) i11) / 100.0d;
            this.f1347e[i10] = f10;
            this.f1348f[i10] = f11;
            this.f1345c[i10] = f12;
        }

        public void d(float f10) {
            this.f1354l = f10;
            double[][] dArr = (double[][]) Array.newInstance((Class<?>) Double.TYPE, this.f1346d.length, 2);
            float[] fArr = this.f1345c;
            this.f1352j = new double[fArr.length + 1];
            this.f1353k = new double[fArr.length + 1];
            if (this.f1346d[0] > UserProfileInfo.Constant.NA_LAT_LON) {
                this.f1344b.a(UserProfileInfo.Constant.NA_LAT_LON, this.f1347e[0]);
            }
            double[] dArr2 = this.f1346d;
            int length = dArr2.length - 1;
            if (dArr2[length] < 1.0d) {
                this.f1344b.a(1.0d, this.f1347e[length]);
            }
            for (int i10 = 0; i10 < dArr.length; i10++) {
                dArr[i10][0] = this.f1348f[i10];
                int i11 = 0;
                while (true) {
                    float[] fArr2 = this.f1345c;
                    if (i11 < fArr2.length) {
                        dArr[i11][1] = fArr2[i11];
                        i11++;
                    }
                }
                this.f1344b.a(this.f1346d[i10], this.f1347e[i10]);
            }
            this.f1344b.f();
            double[] dArr3 = this.f1346d;
            if (dArr3.length > 1) {
                this.f1351i = s.b.a(0, dArr3, dArr);
            } else {
                this.f1351i = null;
            }
        }
    }

    /* JADX INFO: compiled from: KeyCycleOscillator.java */
    static class e extends g {
        e() {
        }

        @Override // androidx.constraintlayout.motion.widget.g
        public void f(View view, float f10) {
            view.setElevation(a(f10));
        }
    }

    /* JADX INFO: renamed from: androidx.constraintlayout.motion.widget.g$g, reason: collision with other inner class name */
    /* JADX INFO: compiled from: KeyCycleOscillator.java */
    static class C0006g extends g {

        /* JADX INFO: renamed from: h, reason: collision with root package name */
        boolean f1356h = false;

        C0006g() {
        }

        @Override // androidx.constraintlayout.motion.widget.g
        public void f(View view, float f10) {
            Method method;
            if (view instanceof MotionLayout) {
                ((MotionLayout) view).setProgress(a(f10));
                return;
            }
            if (this.f1356h) {
                return;
            }
            try {
                method = view.getClass().getMethod(ClickApiEntity.SET_PROGRESS, Float.TYPE);
            } catch (NoSuchMethodException unused) {
                this.f1356h = true;
                method = null;
            }
            if (method != null) {
                try {
                    method.invoke(view, Float.valueOf(a(f10)));
                } catch (IllegalAccessException e10) {
                    Log.e("KeyCycleOscillator", "unable to setProgress", e10);
                } catch (InvocationTargetException e11) {
                    Log.e("KeyCycleOscillator", "unable to setProgress", e11);
                }
            }
        }
    }

    /* JADX INFO: compiled from: KeyCycleOscillator.java */
    static class h extends g {
        h() {
        }

        @Override // androidx.constraintlayout.motion.widget.g
        public void f(View view, float f10) {
            view.setRotation(a(f10));
        }
    }

    /* JADX INFO: compiled from: KeyCycleOscillator.java */
    static class i extends g {
        i() {
        }

        @Override // androidx.constraintlayout.motion.widget.g
        public void f(View view, float f10) {
            view.setRotationX(a(f10));
        }
    }

    /* JADX INFO: compiled from: KeyCycleOscillator.java */
    static class j extends g {
        j() {
        }

        @Override // androidx.constraintlayout.motion.widget.g
        public void f(View view, float f10) {
            view.setRotationY(a(f10));
        }
    }

    /* JADX INFO: compiled from: KeyCycleOscillator.java */
    static class k extends g {
        k() {
        }

        @Override // androidx.constraintlayout.motion.widget.g
        public void f(View view, float f10) {
            view.setScaleX(a(f10));
        }
    }

    /* JADX INFO: compiled from: KeyCycleOscillator.java */
    static class l extends g {
        l() {
        }

        @Override // androidx.constraintlayout.motion.widget.g
        public void f(View view, float f10) {
            view.setScaleY(a(f10));
        }
    }

    /* JADX INFO: compiled from: KeyCycleOscillator.java */
    static class m extends g {
        m() {
        }

        @Override // androidx.constraintlayout.motion.widget.g
        public void f(View view, float f10) {
            view.setTranslationX(a(f10));
        }
    }

    /* JADX INFO: compiled from: KeyCycleOscillator.java */
    static class n extends g {
        n() {
        }

        @Override // androidx.constraintlayout.motion.widget.g
        public void f(View view, float f10) {
            view.setTranslationY(a(f10));
        }
    }

    /* JADX INFO: compiled from: KeyCycleOscillator.java */
    static class o extends g {
        o() {
        }

        @Override // androidx.constraintlayout.motion.widget.g
        public void f(View view, float f10) {
            view.setTranslationZ(a(f10));
        }
    }

    /* JADX INFO: compiled from: KeyCycleOscillator.java */
    static class p {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        int f1357a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        float f1358b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        float f1359c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        float f1360d;

        public p(int i10, float f10, float f11, float f12) {
            this.f1357a = i10;
            this.f1358b = f12;
            this.f1359c = f11;
            this.f1360d = f10;
        }
    }

    static g c(String str) {
        if (str.startsWith("CUSTOM")) {
            return new c();
        }
        switch (str) {
            case "rotationX":
                return new i();
            case "rotationY":
                return new j();
            case "translationX":
                return new m();
            case "translationY":
                return new n();
            case "translationZ":
                return new o();
            case "progress":
                return new C0006g();
            case "scaleX":
                return new k();
            case "scaleY":
                return new l();
            case "waveVariesBy":
                return new b();
            case "rotation":
                return new h();
            case "elevation":
                return new e();
            case "transitionPathRotate":
                return new f();
            case "alpha":
                return new b();
            case "waveOffset":
                return new b();
            default:
                return null;
        }
    }

    public float a(float f10) {
        return (float) this.f1335b.b(f10);
    }

    public float b(float f10) {
        return (float) this.f1335b.a(f10);
    }

    public void d(int i10, int i11, int i12, float f10, float f11, float f12) {
        this.f1340g.add(new p(i10, f10, f11, f12));
        if (i12 != -1) {
            this.f1339f = i12;
        }
        this.f1338e = i11;
    }

    public void e(int i10, int i11, int i12, float f10, float f11, float f12, ConstraintAttribute constraintAttribute) {
        this.f1340g.add(new p(i10, f10, f11, f12));
        if (i12 != -1) {
            this.f1339f = i12;
        }
        this.f1338e = i11;
        this.f1336c = constraintAttribute;
    }

    public abstract void f(View view, float f10);

    public void g(String str) {
        this.f1337d = str;
    }

    @TargetApi(19)
    public void h(float f10) {
        int size = this.f1340g.size();
        if (size == 0) {
            return;
        }
        Collections.sort(this.f1340g, new a());
        double[] dArr = new double[size];
        double[][] dArr2 = (double[][]) Array.newInstance((Class<?>) Double.TYPE, size, 2);
        this.f1335b = new d(this.f1338e, this.f1339f, size);
        int i10 = 0;
        for (p pVar : this.f1340g) {
            float f11 = pVar.f1360d;
            dArr[i10] = ((double) f11) * 0.01d;
            double[] dArr3 = dArr2[i10];
            float f12 = pVar.f1358b;
            dArr3[0] = f12;
            float f13 = pVar.f1359c;
            dArr3[1] = f13;
            this.f1335b.c(i10, pVar.f1357a, f11, f13, f12);
            i10++;
        }
        this.f1335b.d(f10);
        this.f1334a = s.b.a(0, dArr, dArr2);
    }

    public boolean i() {
        return this.f1339f == 1;
    }

    public String toString() {
        String str = this.f1337d;
        DecimalFormat decimalFormat = new DecimalFormat("##.##");
        for (p pVar : this.f1340g) {
            str = str + "[" + pVar.f1357a + " , " + decimalFormat.format(pVar.f1358b) + "] ";
        }
        return str;
    }

    /* JADX INFO: compiled from: KeyCycleOscillator.java */
    static class f extends g {
        f() {
        }

        public void j(View view, float f10, double d10, double d11) {
            view.setRotation(a(f10) + ((float) Math.toDegrees(Math.atan2(d11, d10))));
        }

        @Override // androidx.constraintlayout.motion.widget.g
        public void f(View view, float f10) {
        }
    }
}
