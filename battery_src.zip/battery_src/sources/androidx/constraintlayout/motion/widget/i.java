package androidx.constraintlayout.motion.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseIntArray;
import androidx.constraintlayout.widget.R$styleable;
import java.util.HashMap;

/* JADX INFO: compiled from: KeyPosition.java */
/* JADX INFO: loaded from: classes.dex */
public class i extends j {

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    String f1363h = null;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    int f1364i = c.f1290f;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    int f1365j = 0;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    float f1366k = Float.NaN;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    float f1367l = Float.NaN;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    float f1368m = Float.NaN;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    float f1369n = Float.NaN;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    float f1370o = Float.NaN;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    float f1371p = Float.NaN;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    int f1372q = 0;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    private float f1373r = Float.NaN;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    private float f1374s = Float.NaN;

    /* JADX INFO: compiled from: KeyPosition.java */
    private static class a {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private static SparseIntArray f1375a;

        static {
            SparseIntArray sparseIntArray = new SparseIntArray();
            f1375a = sparseIntArray;
            sparseIntArray.append(R$styleable.KeyPosition_motionTarget, 1);
            f1375a.append(R$styleable.KeyPosition_framePosition, 2);
            f1375a.append(R$styleable.KeyPosition_transitionEasing, 3);
            f1375a.append(R$styleable.KeyPosition_curveFit, 4);
            f1375a.append(R$styleable.KeyPosition_drawPath, 5);
            f1375a.append(R$styleable.KeyPosition_percentX, 6);
            f1375a.append(R$styleable.KeyPosition_percentY, 7);
            f1375a.append(R$styleable.KeyPosition_keyPositionType, 9);
            f1375a.append(R$styleable.KeyPosition_sizePercent, 8);
            f1375a.append(R$styleable.KeyPosition_percentWidth, 11);
            f1375a.append(R$styleable.KeyPosition_percentHeight, 12);
            f1375a.append(R$styleable.KeyPosition_pathMotionArc, 10);
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static void b(i iVar, TypedArray typedArray) {
            int indexCount = typedArray.getIndexCount();
            for (int i10 = 0; i10 < indexCount; i10++) {
                int index = typedArray.getIndex(i10);
                switch (f1375a.get(index)) {
                    case 1:
                        if (MotionLayout.f1189t0) {
                            int resourceId = typedArray.getResourceId(index, iVar.f1292b);
                            iVar.f1292b = resourceId;
                            if (resourceId == -1) {
                                iVar.f1293c = typedArray.getString(index);
                            }
                        } else if (typedArray.peekValue(index).type == 3) {
                            iVar.f1293c = typedArray.getString(index);
                        } else {
                            iVar.f1292b = typedArray.getResourceId(index, iVar.f1292b);
                        }
                        break;
                    case 2:
                        iVar.f1291a = typedArray.getInt(index, iVar.f1291a);
                        break;
                    case 3:
                        if (typedArray.peekValue(index).type == 3) {
                            iVar.f1363h = typedArray.getString(index);
                        } else {
                            iVar.f1363h = s.c.f16717c[typedArray.getInteger(index, 0)];
                        }
                        break;
                    case 4:
                        iVar.f1376g = typedArray.getInteger(index, iVar.f1376g);
                        break;
                    case 5:
                        iVar.f1365j = typedArray.getInt(index, iVar.f1365j);
                        break;
                    case 6:
                        iVar.f1368m = typedArray.getFloat(index, iVar.f1368m);
                        break;
                    case 7:
                        iVar.f1369n = typedArray.getFloat(index, iVar.f1369n);
                        break;
                    case 8:
                        float f10 = typedArray.getFloat(index, iVar.f1367l);
                        iVar.f1366k = f10;
                        iVar.f1367l = f10;
                        break;
                    case 9:
                        iVar.f1372q = typedArray.getInt(index, iVar.f1372q);
                        break;
                    case 10:
                        iVar.f1364i = typedArray.getInt(index, iVar.f1364i);
                        break;
                    case 11:
                        iVar.f1366k = typedArray.getFloat(index, iVar.f1366k);
                        break;
                    case 12:
                        iVar.f1367l = typedArray.getFloat(index, iVar.f1367l);
                        break;
                    default:
                        Log.e("KeyPosition", "unused attribute 0x" + Integer.toHexString(index) + "   " + f1375a.get(index));
                        break;
                }
            }
            if (iVar.f1291a == -1) {
                Log.e("KeyPosition", "no frame position");
            }
        }
    }

    public i() {
        this.f1294d = 2;
    }

    @Override // androidx.constraintlayout.motion.widget.c
    public void c(Context context, AttributeSet attributeSet) {
        a.b(this, context.obtainStyledAttributes(attributeSet, R$styleable.KeyPosition));
    }

    @Override // androidx.constraintlayout.motion.widget.c
    public void a(HashMap<String, r> map) {
    }
}
