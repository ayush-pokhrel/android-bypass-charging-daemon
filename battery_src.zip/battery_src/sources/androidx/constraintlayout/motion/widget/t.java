package androidx.constraintlayout.motion.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.util.Log;
import android.util.Xml;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import androidx.constraintlayout.widget.R$styleable;
import androidx.core.widget.NestedScrollView;
import org.xmlpull.v1.XmlPullParser;

/* JADX INFO: compiled from: TouchResponse.java */
/* JADX INFO: loaded from: classes.dex */
class t {

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    private static final float[][] f1549v = {new float[]{0.5f, 0.0f}, new float[]{0.0f, 0.5f}, new float[]{1.0f, 0.5f}, new float[]{0.5f, 1.0f}, new float[]{0.5f, 0.5f}, new float[]{0.0f, 0.5f}, new float[]{1.0f, 0.5f}};

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    private static final float[][] f1550w = {new float[]{0.0f, -1.0f}, new float[]{0.0f, 1.0f}, new float[]{-1.0f, 0.0f}, new float[]{1.0f, 0.0f}, new float[]{-1.0f, 0.0f}, new float[]{1.0f, 0.0f}};

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    private float f1563m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    private float f1564n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    private final MotionLayout f1565o;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private int f1551a = 0;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private int f1552b = 0;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private int f1553c = 0;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private int f1554d = -1;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private int f1555e = -1;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private int f1556f = -1;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private float f1557g = 0.5f;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private float f1558h = 0.5f;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private float f1559i = 0.0f;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private float f1560j = 1.0f;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    private boolean f1561k = false;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private float[] f1562l = new float[2];

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    private float f1566p = 4.0f;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    private float f1567q = 1.2f;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    private boolean f1568r = true;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    private float f1569s = 1.0f;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    private int f1570t = 0;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    private float f1571u = 10.0f;

    /* JADX INFO: compiled from: TouchResponse.java */
    class a implements View.OnTouchListener {
        a() {
        }

        @Override // android.view.View.OnTouchListener
        public boolean onTouch(View view, MotionEvent motionEvent) {
            return false;
        }
    }

    t(Context context, MotionLayout motionLayout, XmlPullParser xmlPullParser) {
        this.f1565o = motionLayout;
        c(context, Xml.asAttributeSet(xmlPullParser));
    }

    private void b(TypedArray typedArray) {
        int indexCount = typedArray.getIndexCount();
        for (int i10 = 0; i10 < indexCount; i10++) {
            int index = typedArray.getIndex(i10);
            if (index == R$styleable.OnSwipe_touchAnchorId) {
                this.f1554d = typedArray.getResourceId(index, this.f1554d);
            } else if (index == R$styleable.OnSwipe_touchAnchorSide) {
                int i11 = typedArray.getInt(index, this.f1551a);
                this.f1551a = i11;
                float[] fArr = f1549v[i11];
                this.f1558h = fArr[0];
                this.f1557g = fArr[1];
            } else if (index == R$styleable.OnSwipe_dragDirection) {
                int i12 = typedArray.getInt(index, this.f1552b);
                this.f1552b = i12;
                float[] fArr2 = f1550w[i12];
                this.f1559i = fArr2[0];
                this.f1560j = fArr2[1];
            } else if (index == R$styleable.OnSwipe_maxVelocity) {
                this.f1566p = typedArray.getFloat(index, this.f1566p);
            } else if (index == R$styleable.OnSwipe_maxAcceleration) {
                this.f1567q = typedArray.getFloat(index, this.f1567q);
            } else if (index == R$styleable.OnSwipe_moveWhenScrollAtTop) {
                this.f1568r = typedArray.getBoolean(index, this.f1568r);
            } else if (index == R$styleable.OnSwipe_dragScale) {
                this.f1569s = typedArray.getFloat(index, this.f1569s);
            } else if (index == R$styleable.OnSwipe_dragThreshold) {
                this.f1571u = typedArray.getFloat(index, this.f1571u);
            } else if (index == R$styleable.OnSwipe_touchRegionId) {
                this.f1555e = typedArray.getResourceId(index, this.f1555e);
            } else if (index == R$styleable.OnSwipe_onTouchUp) {
                this.f1553c = typedArray.getInt(index, this.f1553c);
            } else if (index == R$styleable.OnSwipe_nestedScrollFlags) {
                this.f1570t = typedArray.getInteger(index, 0);
            } else if (index == R$styleable.OnSwipe_limitBoundsTo) {
                this.f1556f = typedArray.getResourceId(index, 0);
            }
        }
    }

    private void c(Context context, AttributeSet attributeSet) {
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R$styleable.OnSwipe);
        b(typedArrayObtainStyledAttributes);
        typedArrayObtainStyledAttributes.recycle();
    }

    float a(float f10, float f11) {
        return (f10 * this.f1559i) + (f11 * this.f1560j);
    }

    public int d() {
        return this.f1570t;
    }

    RectF e(ViewGroup viewGroup, RectF rectF) {
        View viewFindViewById;
        int i10 = this.f1556f;
        if (i10 == -1 || (viewFindViewById = viewGroup.findViewById(i10)) == null) {
            return null;
        }
        rectF.set(viewFindViewById.getLeft(), viewFindViewById.getTop(), viewFindViewById.getRight(), viewFindViewById.getBottom());
        return rectF;
    }

    float f() {
        return this.f1567q;
    }

    public float g() {
        return this.f1566p;
    }

    boolean h() {
        return this.f1568r;
    }

    float i(float f10, float f11) {
        this.f1565o.M(this.f1554d, this.f1565o.getProgress(), this.f1558h, this.f1557g, this.f1562l);
        float f12 = this.f1559i;
        if (f12 != 0.0f) {
            float[] fArr = this.f1562l;
            if (fArr[0] == 0.0f) {
                fArr[0] = 1.0E-7f;
            }
            return (f10 * f12) / fArr[0];
        }
        float[] fArr2 = this.f1562l;
        if (fArr2[1] == 0.0f) {
            fArr2[1] = 1.0E-7f;
        }
        return (f11 * this.f1560j) / fArr2[1];
    }

    RectF j(ViewGroup viewGroup, RectF rectF) {
        View viewFindViewById;
        int i10 = this.f1555e;
        if (i10 == -1 || (viewFindViewById = viewGroup.findViewById(i10)) == null) {
            return null;
        }
        rectF.set(viewFindViewById.getLeft(), viewFindViewById.getTop(), viewFindViewById.getRight(), viewFindViewById.getBottom());
        return rectF;
    }

    int k() {
        return this.f1555e;
    }

    void l(MotionEvent motionEvent, MotionLayout.f fVar, int i10, q qVar) {
        int i11;
        fVar.a(motionEvent);
        int action = motionEvent.getAction();
        if (action == 0) {
            this.f1563m = motionEvent.getRawX();
            this.f1564n = motionEvent.getRawY();
            this.f1561k = false;
            return;
        }
        if (action == 1) {
            this.f1561k = false;
            fVar.e(1000);
            float fC = fVar.c();
            float fB = fVar.b();
            float progress = this.f1565o.getProgress();
            int i12 = this.f1554d;
            if (i12 != -1) {
                this.f1565o.M(i12, progress, this.f1558h, this.f1557g, this.f1562l);
            } else {
                float fMin = Math.min(this.f1565o.getWidth(), this.f1565o.getHeight());
                float[] fArr = this.f1562l;
                fArr[1] = this.f1560j * fMin;
                fArr[0] = fMin * this.f1559i;
            }
            float f10 = this.f1559i;
            float[] fArr2 = this.f1562l;
            float f11 = f10 != 0.0f ? fC / fArr2[0] : fB / fArr2[1];
            float f12 = !Float.isNaN(f11) ? (f11 / 3.0f) + progress : progress;
            if (f12 == 0.0f || f12 == 1.0f || (i11 = this.f1553c) == 3) {
                if (0.0f >= f12 || 1.0f <= f12) {
                    this.f1565o.setState(MotionLayout.TransitionState.FINISHED);
                    return;
                }
                return;
            }
            this.f1565o.Z(i11, ((double) f12) < 0.5d ? 0.0f : 1.0f, f11);
            if (0.0f >= progress || 1.0f <= progress) {
                this.f1565o.setState(MotionLayout.TransitionState.FINISHED);
                return;
            }
            return;
        }
        if (action != 2) {
            return;
        }
        float rawY = motionEvent.getRawY() - this.f1564n;
        float rawX = motionEvent.getRawX() - this.f1563m;
        if (Math.abs((this.f1559i * rawX) + (this.f1560j * rawY)) > this.f1571u || this.f1561k) {
            float progress2 = this.f1565o.getProgress();
            if (!this.f1561k) {
                this.f1561k = true;
                this.f1565o.setProgress(progress2);
            }
            int i13 = this.f1554d;
            if (i13 != -1) {
                this.f1565o.M(i13, progress2, this.f1558h, this.f1557g, this.f1562l);
            } else {
                float fMin2 = Math.min(this.f1565o.getWidth(), this.f1565o.getHeight());
                float[] fArr3 = this.f1562l;
                fArr3[1] = this.f1560j * fMin2;
                fArr3[0] = fMin2 * this.f1559i;
            }
            float f13 = this.f1559i;
            float[] fArr4 = this.f1562l;
            if (Math.abs(((f13 * fArr4[0]) + (this.f1560j * fArr4[1])) * this.f1569s) < 0.01d) {
                float[] fArr5 = this.f1562l;
                fArr5[0] = 0.01f;
                fArr5[1] = 0.01f;
            }
            float fMax = Math.max(Math.min(progress2 + (this.f1559i != 0.0f ? rawX / this.f1562l[0] : rawY / this.f1562l[1]), 1.0f), 0.0f);
            if (fMax != this.f1565o.getProgress()) {
                this.f1565o.setProgress(fMax);
                fVar.e(1000);
                this.f1565o.f1194c = this.f1559i != 0.0f ? fVar.c() / this.f1562l[0] : fVar.b() / this.f1562l[1];
            } else {
                this.f1565o.f1194c = 0.0f;
            }
            this.f1563m = motionEvent.getRawX();
            this.f1564n = motionEvent.getRawY();
        }
    }

    void m(float f10, float f11) {
        float progress = this.f1565o.getProgress();
        if (!this.f1561k) {
            this.f1561k = true;
            this.f1565o.setProgress(progress);
        }
        this.f1565o.M(this.f1554d, progress, this.f1558h, this.f1557g, this.f1562l);
        float f12 = this.f1559i;
        float[] fArr = this.f1562l;
        if (Math.abs((f12 * fArr[0]) + (this.f1560j * fArr[1])) < 0.01d) {
            float[] fArr2 = this.f1562l;
            fArr2[0] = 0.01f;
            fArr2[1] = 0.01f;
        }
        float f13 = this.f1559i;
        float fMax = Math.max(Math.min(progress + (f13 != 0.0f ? (f10 * f13) / this.f1562l[0] : (f11 * this.f1560j) / this.f1562l[1]), 1.0f), 0.0f);
        if (fMax != this.f1565o.getProgress()) {
            this.f1565o.setProgress(fMax);
        }
    }

    void n(float f10, float f11) {
        this.f1561k = false;
        float progress = this.f1565o.getProgress();
        this.f1565o.M(this.f1554d, progress, this.f1558h, this.f1557g, this.f1562l);
        float f12 = this.f1559i;
        float[] fArr = this.f1562l;
        float f13 = f12 != 0.0f ? (f10 * f12) / fArr[0] : (f11 * this.f1560j) / fArr[1];
        if (!Float.isNaN(f13)) {
            progress += f13 / 3.0f;
        }
        if (progress != 0.0f) {
            boolean z10 = progress != 1.0f;
            int i10 = this.f1553c;
            if ((i10 != 3) && z10) {
                this.f1565o.Z(i10, ((double) progress) >= 0.5d ? 1.0f : 0.0f, f13);
            }
        }
    }

    void o(float f10, float f11) {
        this.f1563m = f10;
        this.f1564n = f11;
    }

    public void p(boolean z10) {
        if (z10) {
            float[][] fArr = f1550w;
            fArr[4] = fArr[3];
            fArr[5] = fArr[2];
            float[][] fArr2 = f1549v;
            fArr2[5] = fArr2[2];
            fArr2[6] = fArr2[1];
        } else {
            float[][] fArr3 = f1550w;
            fArr3[4] = fArr3[2];
            fArr3[5] = fArr3[3];
            float[][] fArr4 = f1549v;
            fArr4[5] = fArr4[1];
            fArr4[6] = fArr4[2];
        }
        float[] fArr5 = f1549v[this.f1551a];
        this.f1558h = fArr5[0];
        this.f1557g = fArr5[1];
        float[] fArr6 = f1550w[this.f1552b];
        this.f1559i = fArr6[0];
        this.f1560j = fArr6[1];
    }

    void q(float f10, float f11) {
        this.f1563m = f10;
        this.f1564n = f11;
        this.f1561k = false;
    }

    void r() {
        View viewFindViewById;
        int i10 = this.f1554d;
        if (i10 != -1) {
            viewFindViewById = this.f1565o.findViewById(i10);
            if (viewFindViewById == null) {
                Log.e("TouchResponse", "cannot find TouchAnchorId @id/" + androidx.constraintlayout.motion.widget.a.b(this.f1565o.getContext(), this.f1554d));
            }
        } else {
            viewFindViewById = null;
        }
        if (viewFindViewById instanceof NestedScrollView) {
            NestedScrollView nestedScrollView = (NestedScrollView) viewFindViewById;
            nestedScrollView.setOnTouchListener(new a());
            nestedScrollView.setOnScrollChangeListener(new b());
        }
    }

    public String toString() {
        return this.f1559i + " , " + this.f1560j;
    }

    /* JADX INFO: compiled from: TouchResponse.java */
    class b implements NestedScrollView.d {
        b() {
        }

        @Override // androidx.core.widget.NestedScrollView.d
        public void a(NestedScrollView nestedScrollView, int i10, int i11, int i12, int i13) {
        }
    }
}
