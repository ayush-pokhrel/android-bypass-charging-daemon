package androidx.constraintlayout.motion.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import androidx.constraintlayout.widget.ConstraintHelper;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.R$styleable;

/* JADX INFO: loaded from: classes.dex */
public class MotionHelper extends ConstraintHelper implements MotionLayout.i {

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private boolean f1185l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    private boolean f1186m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    private float f1187n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    protected View[] f1188o;

    public MotionHelper(Context context) {
        super(context);
        this.f1185l = false;
        this.f1186m = false;
    }

    public float getProgress() {
        return this.f1187n;
    }

    @Override // androidx.constraintlayout.widget.ConstraintHelper
    protected void m(AttributeSet attributeSet) {
        super.m(attributeSet);
        if (attributeSet != null) {
            TypedArray typedArrayObtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, R$styleable.MotionHelper);
            int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
            for (int i10 = 0; i10 < indexCount; i10++) {
                int index = typedArrayObtainStyledAttributes.getIndex(i10);
                if (index == R$styleable.MotionHelper_onShow) {
                    this.f1185l = typedArrayObtainStyledAttributes.getBoolean(index, this.f1185l);
                } else if (index == R$styleable.MotionHelper_onHide) {
                    this.f1186m = typedArrayObtainStyledAttributes.getBoolean(index, this.f1186m);
                }
            }
        }
    }

    public void setProgress(float f10) {
        this.f1187n = f10;
        int i10 = 0;
        if (this.f1951b > 0) {
            this.f1188o = l((ConstraintLayout) getParent());
            while (i10 < this.f1951b) {
                x(this.f1188o[i10], f10);
                i10++;
            }
            return;
        }
        ViewGroup viewGroup = (ViewGroup) getParent();
        int childCount = viewGroup.getChildCount();
        while (i10 < childCount) {
            View childAt = viewGroup.getChildAt(i10);
            if (!(childAt instanceof MotionHelper)) {
                x(childAt, f10);
            }
            i10++;
        }
    }

    public boolean v() {
        return this.f1186m;
    }

    public boolean w() {
        return this.f1185l;
    }

    public MotionHelper(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f1185l = false;
        this.f1186m = false;
        m(attributeSet);
    }

    public MotionHelper(Context context, AttributeSet attributeSet, int i10) {
        super(context, attributeSet, i10);
        this.f1185l = false;
        this.f1186m = false;
        m(attributeSet);
    }

    @Override // androidx.constraintlayout.motion.widget.MotionLayout.i
    public void d(MotionLayout motionLayout, int i10) {
    }

    public void x(View view, float f10) {
    }

    @Override // androidx.constraintlayout.motion.widget.MotionLayout.i
    public void b(MotionLayout motionLayout, int i10, int i11) {
    }

    @Override // androidx.constraintlayout.motion.widget.MotionLayout.i
    public void a(MotionLayout motionLayout, int i10, int i11, float f10) {
    }

    @Override // androidx.constraintlayout.motion.widget.MotionLayout.i
    public void c(MotionLayout motionLayout, int i10, boolean z10, float f10) {
    }
}
