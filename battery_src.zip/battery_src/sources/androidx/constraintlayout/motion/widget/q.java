package androidx.constraintlayout.motion.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.util.SparseIntArray;
import android.util.Xml;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.AnimationUtils;
import android.view.animation.AnticipateInterpolator;
import android.view.animation.BounceInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import androidx.constraintlayout.widget.R$id;
import androidx.constraintlayout.widget.R$styleable;
import com.oplus.sceneservice.sdk.dataprovider.bean.UserProfileInfo;
import com.oplus.sceneservice.sdk.dataprovider.bean.scene.SceneFlightData;
import com.oplus.smartenginehelper.ParserTag;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

/* JADX INFO: compiled from: MotionScene.java */
/* JADX INFO: loaded from: classes.dex */
public class q {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final MotionLayout f1481a;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    private MotionEvent f1494n;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    private MotionLayout.f f1496p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    private boolean f1497q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    float f1498r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    float f1499s;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    androidx.constraintlayout.widget.d f1482b = null;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    b f1483c = null;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private boolean f1484d = false;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private ArrayList<b> f1485e = new ArrayList<>();

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private b f1486f = null;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private ArrayList<b> f1487g = new ArrayList<>();

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private SparseArray<androidx.constraintlayout.widget.b> f1488h = new SparseArray<>();

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private HashMap<String, Integer> f1489i = new HashMap<>();

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private SparseIntArray f1490j = new SparseIntArray();

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    private boolean f1491k = false;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private int f1492l = SceneFlightData.INVALID_LATITUDE_LONGITUDE;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    private int f1493m = 0;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    private boolean f1495o = false;

    /* JADX INFO: compiled from: MotionScene.java */
    class a implements Interpolator {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        final /* synthetic */ s.c f1500a;

        a(s.c cVar) {
            this.f1500a = cVar;
        }

        @Override // android.animation.TimeInterpolator
        public float getInterpolation(float f10) {
            return (float) this.f1500a.a(f10);
        }
    }

    q(Context context, MotionLayout motionLayout, int i10) {
        this.f1481a = motionLayout;
        C(context, i10);
        SparseArray<androidx.constraintlayout.widget.b> sparseArray = this.f1488h;
        int i11 = R$id.motion_base;
        sparseArray.put(i11, new androidx.constraintlayout.widget.b());
        this.f1489i.put("motion_base", Integer.valueOf(i11));
    }

    private boolean A(int i10) {
        int i11 = this.f1490j.get(i10);
        int size = this.f1490j.size();
        while (i11 > 0) {
            if (i11 == i10) {
                return true;
            }
            int i12 = size - 1;
            if (size < 0) {
                return true;
            }
            i11 = this.f1490j.get(i11);
            size = i12;
        }
        return false;
    }

    private boolean B() {
        return this.f1496p != null;
    }

    private void C(Context context, int i10) {
        XmlResourceParser xml = context.getResources().getXml(i10);
        try {
            int eventType = xml.getEventType();
            b bVar = null;
            while (true) {
                if (eventType == 1) {
                    return;
                }
                if (eventType == 0) {
                    xml.getName();
                } else if (eventType == 2) {
                    String name = xml.getName();
                    if (this.f1491k) {
                        System.out.println("parsing = " + name);
                    }
                    switch (name) {
                        case "MotionScene":
                            E(context, xml);
                            break;
                        case "Transition":
                            ArrayList<b> arrayList = this.f1485e;
                            bVar = new b(this, context, xml);
                            arrayList.add(bVar);
                            if (this.f1483c == null && !bVar.f1503b) {
                                this.f1483c = bVar;
                                if (bVar.f1513l != null) {
                                    this.f1483c.f1513l.p(this.f1497q);
                                }
                            }
                            if (!bVar.f1503b) {
                                break;
                            } else {
                                if (bVar.f1504c == -1) {
                                    this.f1486f = bVar;
                                } else {
                                    this.f1487g.add(bVar);
                                }
                                this.f1485e.remove(bVar);
                                break;
                            }
                            break;
                        case "OnSwipe":
                            if (bVar == null) {
                                Log.v("MotionScene", " OnSwipe (" + context.getResources().getResourceEntryName(i10) + ".xml:" + xml.getLineNumber() + ")");
                            }
                            bVar.f1513l = new t(context, this.f1481a, xml);
                            break;
                        case "OnClick":
                            bVar.t(context, xml);
                            break;
                        case "StateSet":
                            this.f1482b = new androidx.constraintlayout.widget.d(context, xml);
                            break;
                        case "ConstraintSet":
                            D(context, xml);
                            break;
                        case "KeyFrameSet":
                            bVar.f1512k.add(new h(context, xml));
                            break;
                        default:
                            Log.v("MotionScene", "WARNING UNKNOWN ATTRIBUTE " + name);
                            break;
                    }
                }
                eventType = xml.next();
            }
        } catch (IOException e10) {
            e10.printStackTrace();
        } catch (XmlPullParserException e11) {
            e11.printStackTrace();
        }
    }

    private void D(Context context, XmlPullParser xmlPullParser) {
        androidx.constraintlayout.widget.b bVar = new androidx.constraintlayout.widget.b();
        bVar.C(false);
        int attributeCount = xmlPullParser.getAttributeCount();
        int iO = -1;
        int iO2 = -1;
        for (int i10 = 0; i10 < attributeCount; i10++) {
            String attributeName = xmlPullParser.getAttributeName(i10);
            String attributeValue = xmlPullParser.getAttributeValue(i10);
            if (this.f1491k) {
                System.out.println("id string = " + attributeValue);
            }
            attributeName.hashCode();
            if (attributeName.equals("deriveConstraintsFrom")) {
                iO2 = o(context, attributeValue);
            } else if (attributeName.equals("id")) {
                iO = o(context, attributeValue);
                this.f1489i.put(P(attributeValue), Integer.valueOf(iO));
            }
        }
        if (iO != -1) {
            if (this.f1481a.f1231z != 0) {
                bVar.E(true);
            }
            bVar.x(context, xmlPullParser);
            if (iO2 != -1) {
                this.f1490j.put(iO, iO2);
            }
            this.f1488h.put(iO, bVar);
        }
    }

    private void E(Context context, XmlPullParser xmlPullParser) {
        TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(Xml.asAttributeSet(xmlPullParser), R$styleable.MotionScene);
        int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
        for (int i10 = 0; i10 < indexCount; i10++) {
            int index = typedArrayObtainStyledAttributes.getIndex(i10);
            if (index == R$styleable.MotionScene_defaultDuration) {
                this.f1492l = typedArrayObtainStyledAttributes.getInt(index, this.f1492l);
            } else if (index == R$styleable.MotionScene_layoutDuringTransition) {
                this.f1493m = typedArrayObtainStyledAttributes.getInteger(index, 0);
            }
        }
        typedArrayObtainStyledAttributes.recycle();
    }

    private void I(int i10) {
        int i11 = this.f1490j.get(i10);
        if (i11 > 0) {
            I(this.f1490j.get(i10));
            androidx.constraintlayout.widget.b bVar = this.f1488h.get(i10);
            androidx.constraintlayout.widget.b bVar2 = this.f1488h.get(i11);
            if (bVar2 != null) {
                bVar.B(bVar2);
                this.f1490j.put(i10, -1);
            } else {
                Log.e("MotionScene", "ERROR! invalid deriveConstraintsFrom: @id/" + androidx.constraintlayout.motion.widget.a.b(this.f1481a.getContext(), i11));
            }
        }
    }

    public static String P(String str) {
        if (str == null) {
            return "";
        }
        int iIndexOf = str.indexOf(47);
        return iIndexOf < 0 ? str : str.substring(iIndexOf + 1);
    }

    private int o(Context context, String str) {
        int identifier;
        if (str.contains("/")) {
            identifier = context.getResources().getIdentifier(str.substring(str.indexOf(47) + 1), "id", context.getPackageName());
            if (this.f1491k) {
                System.out.println("id getMap res = " + identifier);
            }
        } else {
            identifier = -1;
        }
        if (identifier != -1) {
            return identifier;
        }
        if (str.length() > 1) {
            return Integer.parseInt(str.substring(1));
        }
        Log.e("MotionScene", "error in parsing id");
        return identifier;
    }

    private int v(int i10) {
        int iC;
        androidx.constraintlayout.widget.d dVar = this.f1482b;
        return (dVar == null || (iC = dVar.c(i10, -1, -1)) == -1) ? i10 : iC;
    }

    void F(float f10, float f11) {
        b bVar = this.f1483c;
        if (bVar == null || bVar.f1513l == null) {
            return;
        }
        this.f1483c.f1513l.m(f10, f11);
    }

    void G(float f10, float f11) {
        b bVar = this.f1483c;
        if (bVar == null || bVar.f1513l == null) {
            return;
        }
        this.f1483c.f1513l.n(f10, f11);
    }

    void H(MotionEvent motionEvent, int i10, MotionLayout motionLayout) {
        MotionLayout.f fVar;
        MotionEvent motionEvent2;
        RectF rectF = new RectF();
        if (this.f1496p == null) {
            this.f1496p = this.f1481a.S();
        }
        this.f1496p.a(motionEvent);
        if (i10 != -1) {
            int action = motionEvent.getAction();
            boolean z10 = false;
            if (action == 0) {
                this.f1498r = motionEvent.getRawX();
                this.f1499s = motionEvent.getRawY();
                this.f1494n = motionEvent;
                if (this.f1483c.f1513l != null) {
                    RectF rectFE = this.f1483c.f1513l.e(this.f1481a, rectF);
                    if (rectFE != null && !rectFE.contains(this.f1494n.getX(), this.f1494n.getY())) {
                        this.f1494n = null;
                        return;
                    }
                    RectF rectFJ = this.f1483c.f1513l.j(this.f1481a, rectF);
                    if (rectFJ == null || rectFJ.contains(this.f1494n.getX(), this.f1494n.getY())) {
                        this.f1495o = false;
                    } else {
                        this.f1495o = true;
                    }
                    this.f1483c.f1513l.o(this.f1498r, this.f1499s);
                    return;
                }
                return;
            }
            if (action == 2) {
                float rawY = motionEvent.getRawY() - this.f1499s;
                float rawX = motionEvent.getRawX() - this.f1498r;
                if ((rawX == UserProfileInfo.Constant.NA_LAT_LON && rawY == UserProfileInfo.Constant.NA_LAT_LON) || (motionEvent2 = this.f1494n) == null) {
                    return;
                }
                b bVarG = g(i10, rawX, rawY, motionEvent2);
                if (bVarG != null) {
                    motionLayout.setTransition(bVarG);
                    RectF rectFJ2 = this.f1483c.f1513l.j(this.f1481a, rectF);
                    if (rectFJ2 != null && !rectFJ2.contains(this.f1494n.getX(), this.f1494n.getY())) {
                        z10 = true;
                    }
                    this.f1495o = z10;
                    this.f1483c.f1513l.q(this.f1498r, this.f1499s);
                }
            }
        }
        b bVar = this.f1483c;
        if (bVar != null && bVar.f1513l != null && !this.f1495o) {
            this.f1483c.f1513l.l(motionEvent, this.f1496p, i10, this);
        }
        this.f1498r = motionEvent.getRawX();
        this.f1499s = motionEvent.getRawY();
        if (motionEvent.getAction() != 1 || (fVar = this.f1496p) == null) {
            return;
        }
        fVar.d();
        this.f1496p = null;
        int i11 = motionLayout.f1201h;
        if (i11 != -1) {
            f(motionLayout, i11);
        }
    }

    void J(MotionLayout motionLayout) {
        for (int i10 = 0; i10 < this.f1488h.size(); i10++) {
            int iKeyAt = this.f1488h.keyAt(i10);
            if (A(iKeyAt)) {
                Log.e("MotionScene", "Cannot be derived from yourself");
                return;
            }
            I(iKeyAt);
        }
        for (int i11 = 0; i11 < this.f1488h.size(); i11++) {
            this.f1488h.valueAt(i11).A(motionLayout);
        }
    }

    public void K(int i10) {
        b bVar = this.f1483c;
        if (bVar != null) {
            bVar.E(i10);
        } else {
            this.f1492l = i10;
        }
    }

    public void L(boolean z10) {
        this.f1497q = z10;
        b bVar = this.f1483c;
        if (bVar == null || bVar.f1513l == null) {
            return;
        }
        this.f1483c.f1513l.p(this.f1497q);
    }

    /* JADX WARN: Code duplicated, block: B:16:0x0026  */
    /* JADX WARN: Code duplicated, block: B:33:0x0068  */
    /* JADX WARN: Code duplicated, block: B:38:0x0083  */
    /* JADX WARN: Code duplicated, block: B:43:0x005a A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:49:0x0074 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:51:0x0062 A[SYNTHETIC] */
    void M(int i10, int i11) {
        int iC;
        int iC2;
        Iterator<b> it;
        b bVar;
        b bVar2;
        b next;
        androidx.constraintlayout.widget.d dVar = this.f1482b;
        if (dVar != null) {
            iC = dVar.c(i10, -1, -1);
            if (iC == -1) {
                iC = i10;
            }
            iC2 = this.f1482b.c(i11, -1, -1);
            if (iC2 == -1) {
            }
            it = this.f1485e.iterator();
            while (true) {
                if (it.hasNext()) {
                    bVar = this.f1486f;
                    for (b bVar3 : this.f1487g) {
                        if (bVar3.f1504c == i11) {
                            bVar = bVar3;
                        }
                    }
                    bVar2 = new b(this, bVar);
                    bVar2.f1505d = iC;
                    bVar2.f1504c = iC2;
                    if (iC != -1) {
                        this.f1485e.add(bVar2);
                    }
                    this.f1483c = bVar2;
                    return;
                }
                next = it.next();
                if ((next.f1504c != iC2 && next.f1505d == iC) || (next.f1504c == i11 && next.f1505d == i10)) {
                    break;
                }
            }
            this.f1483c = next;
            if (next != null || next.f1513l == null) {
            }
            this.f1483c.f1513l.p(this.f1497q);
            return;
        }
        iC = i10;
        iC2 = i11;
        it = this.f1485e.iterator();
        while (true) {
            if (it.hasNext()) {
                bVar = this.f1486f;
                while (r3.hasNext()) {
                    if (bVar3.f1504c == i11) {
                        bVar = bVar3;
                    }
                }
                bVar2 = new b(this, bVar);
                bVar2.f1505d = iC;
                bVar2.f1504c = iC2;
                if (iC != -1) {
                    this.f1485e.add(bVar2);
                }
                this.f1483c = bVar2;
                return;
            }
            next = it.next();
            if (next.f1504c != iC2) {
            }
        }
        this.f1483c = next;
        if (next != null) {
        }
    }

    public void N(b bVar) {
        this.f1483c = bVar;
        if (bVar == null || bVar.f1513l == null) {
            return;
        }
        this.f1483c.f1513l.p(this.f1497q);
    }

    void O() {
        b bVar = this.f1483c;
        if (bVar == null || bVar.f1513l == null) {
            return;
        }
        this.f1483c.f1513l.r();
    }

    boolean Q() {
        Iterator<b> it = this.f1485e.iterator();
        while (it.hasNext()) {
            if (it.next().f1513l != null) {
                return true;
            }
        }
        b bVar = this.f1483c;
        return (bVar == null || bVar.f1513l == null) ? false : true;
    }

    public void e(MotionLayout motionLayout, int i10) {
        for (b bVar : this.f1485e) {
            if (bVar.f1514m.size() > 0) {
                Iterator it = bVar.f1514m.iterator();
                while (it.hasNext()) {
                    ((b.a) it.next()).c(motionLayout);
                }
            }
        }
        for (b bVar2 : this.f1487g) {
            if (bVar2.f1514m.size() > 0) {
                Iterator it2 = bVar2.f1514m.iterator();
                while (it2.hasNext()) {
                    ((b.a) it2.next()).c(motionLayout);
                }
            }
        }
        for (b bVar3 : this.f1485e) {
            if (bVar3.f1514m.size() > 0) {
                Iterator it3 = bVar3.f1514m.iterator();
                while (it3.hasNext()) {
                    ((b.a) it3.next()).a(motionLayout, i10, bVar3);
                }
            }
        }
        for (b bVar4 : this.f1487g) {
            if (bVar4.f1514m.size() > 0) {
                Iterator it4 = bVar4.f1514m.iterator();
                while (it4.hasNext()) {
                    ((b.a) it4.next()).a(motionLayout, i10, bVar4);
                }
            }
        }
    }

    boolean f(MotionLayout motionLayout, int i10) {
        if (B() || this.f1484d) {
            return false;
        }
        for (b bVar : this.f1485e) {
            if (bVar.f1515n != 0) {
                if (i10 == bVar.f1505d && (bVar.f1515n == 4 || bVar.f1515n == 2)) {
                    MotionLayout.TransitionState transitionState = MotionLayout.TransitionState.FINISHED;
                    motionLayout.setState(transitionState);
                    motionLayout.setTransition(bVar);
                    if (bVar.f1515n == 4) {
                        motionLayout.a0();
                        motionLayout.setState(MotionLayout.TransitionState.SETUP);
                        motionLayout.setState(MotionLayout.TransitionState.MOVING);
                    } else {
                        motionLayout.setProgress(1.0f);
                        motionLayout.H(true);
                        motionLayout.setState(MotionLayout.TransitionState.SETUP);
                        motionLayout.setState(MotionLayout.TransitionState.MOVING);
                        motionLayout.setState(transitionState);
                    }
                    return true;
                }
                if (i10 == bVar.f1504c && (bVar.f1515n == 3 || bVar.f1515n == 1)) {
                    MotionLayout.TransitionState transitionState2 = MotionLayout.TransitionState.FINISHED;
                    motionLayout.setState(transitionState2);
                    motionLayout.setTransition(bVar);
                    if (bVar.f1515n == 3) {
                        motionLayout.b0();
                        motionLayout.setState(MotionLayout.TransitionState.SETUP);
                        motionLayout.setState(MotionLayout.TransitionState.MOVING);
                    } else {
                        motionLayout.setProgress(0.0f);
                        motionLayout.H(true);
                        motionLayout.setState(MotionLayout.TransitionState.SETUP);
                        motionLayout.setState(MotionLayout.TransitionState.MOVING);
                        motionLayout.setState(transitionState2);
                    }
                    return true;
                }
            }
        }
        return false;
    }

    public b g(int i10, float f10, float f11, MotionEvent motionEvent) {
        if (i10 == -1) {
            return this.f1483c;
        }
        List<b> listZ = z(i10);
        RectF rectF = new RectF();
        float f12 = 0.0f;
        b bVar = null;
        for (b bVar2 : listZ) {
            if (!bVar2.f1516o && bVar2.f1513l != null) {
                bVar2.f1513l.p(this.f1497q);
                RectF rectFJ = bVar2.f1513l.j(this.f1481a, rectF);
                if (rectFJ == null || motionEvent == null || rectFJ.contains(motionEvent.getX(), motionEvent.getY())) {
                    RectF rectFJ2 = bVar2.f1513l.j(this.f1481a, rectF);
                    if (rectFJ2 == null || motionEvent == null || rectFJ2.contains(motionEvent.getX(), motionEvent.getY())) {
                        float fA = bVar2.f1513l.a(f10, f11) * (bVar2.f1504c == i10 ? -1.0f : 1.1f);
                        if (fA > f12) {
                            bVar = bVar2;
                            f12 = fA;
                        }
                    }
                }
            }
        }
        return bVar;
    }

    public int h() {
        b bVar = this.f1483c;
        if (bVar != null) {
            return bVar.f1517p;
        }
        return -1;
    }

    androidx.constraintlayout.widget.b i(int i10) {
        return j(i10, -1, -1);
    }

    androidx.constraintlayout.widget.b j(int i10, int i11, int i12) {
        int iC;
        if (this.f1491k) {
            PrintStream printStream = System.out;
            printStream.println("id " + i10);
            printStream.println("size " + this.f1488h.size());
        }
        androidx.constraintlayout.widget.d dVar = this.f1482b;
        if (dVar != null && (iC = dVar.c(i10, i11, i12)) != -1) {
            i10 = iC;
        }
        if (this.f1488h.get(i10) != null) {
            return this.f1488h.get(i10);
        }
        Log.e("MotionScene", "Warning could not find ConstraintSet id/" + androidx.constraintlayout.motion.widget.a.b(this.f1481a.getContext(), i10) + " In MotionScene");
        SparseArray<androidx.constraintlayout.widget.b> sparseArray = this.f1488h;
        return sparseArray.get(sparseArray.keyAt(0));
    }

    public int[] k() {
        int size = this.f1488h.size();
        int[] iArr = new int[size];
        for (int i10 = 0; i10 < size; i10++) {
            iArr[i10] = this.f1488h.keyAt(i10);
        }
        return iArr;
    }

    public ArrayList<b> l() {
        return this.f1485e;
    }

    public int m() {
        b bVar = this.f1483c;
        return bVar != null ? bVar.f1509h : this.f1492l;
    }

    int n() {
        b bVar = this.f1483c;
        if (bVar == null) {
            return -1;
        }
        return bVar.f1504c;
    }

    public Interpolator p() {
        int i10 = this.f1483c.f1506e;
        if (i10 == -2) {
            return AnimationUtils.loadInterpolator(this.f1481a.getContext(), this.f1483c.f1508g);
        }
        if (i10 == -1) {
            return new a(s.c.c(this.f1483c.f1507f));
        }
        if (i10 == 0) {
            return new AccelerateDecelerateInterpolator();
        }
        if (i10 == 1) {
            return new AccelerateInterpolator();
        }
        if (i10 == 2) {
            return new DecelerateInterpolator();
        }
        if (i10 == 4) {
            return new AnticipateInterpolator();
        }
        if (i10 != 5) {
            return null;
        }
        return new BounceInterpolator();
    }

    public void q(n nVar) {
        b bVar = this.f1483c;
        if (bVar != null) {
            Iterator it = bVar.f1512k.iterator();
            while (it.hasNext()) {
                ((h) it.next()).a(nVar);
            }
        } else {
            b bVar2 = this.f1486f;
            if (bVar2 != null) {
                Iterator it2 = bVar2.f1512k.iterator();
                while (it2.hasNext()) {
                    ((h) it2.next()).a(nVar);
                }
            }
        }
    }

    float r() {
        b bVar = this.f1483c;
        if (bVar == null || bVar.f1513l == null) {
            return 0.0f;
        }
        return this.f1483c.f1513l.f();
    }

    float s() {
        b bVar = this.f1483c;
        if (bVar == null || bVar.f1513l == null) {
            return 0.0f;
        }
        return this.f1483c.f1513l.g();
    }

    boolean t() {
        b bVar = this.f1483c;
        if (bVar == null || bVar.f1513l == null) {
            return false;
        }
        return this.f1483c.f1513l.h();
    }

    float u(float f10, float f11) {
        b bVar = this.f1483c;
        if (bVar == null || bVar.f1513l == null) {
            return 0.0f;
        }
        return this.f1483c.f1513l.i(f10, f11);
    }

    public float w() {
        b bVar = this.f1483c;
        if (bVar != null) {
            return bVar.f1510i;
        }
        return 0.0f;
    }

    int x() {
        b bVar = this.f1483c;
        if (bVar == null) {
            return -1;
        }
        return bVar.f1505d;
    }

    public b y(int i10) {
        for (b bVar : this.f1485e) {
            if (bVar.f1502a == i10) {
                return bVar;
            }
        }
        return null;
    }

    public List<b> z(int i10) {
        int iV = v(i10);
        ArrayList arrayList = new ArrayList();
        for (b bVar : this.f1485e) {
            if (bVar.f1505d == iV || bVar.f1504c == iV) {
                arrayList.add(bVar);
            }
        }
        return arrayList;
    }

    /* JADX INFO: compiled from: MotionScene.java */
    public static class b {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private int f1502a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private boolean f1503b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        private int f1504c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        private int f1505d;

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        private int f1506e;

        /* JADX INFO: renamed from: f, reason: collision with root package name */
        private String f1507f;

        /* JADX INFO: renamed from: g, reason: collision with root package name */
        private int f1508g;

        /* JADX INFO: renamed from: h, reason: collision with root package name */
        private int f1509h;

        /* JADX INFO: renamed from: i, reason: collision with root package name */
        private float f1510i;

        /* JADX INFO: renamed from: j, reason: collision with root package name */
        private final q f1511j;

        /* JADX INFO: renamed from: k, reason: collision with root package name */
        private ArrayList<h> f1512k;

        /* JADX INFO: renamed from: l, reason: collision with root package name */
        private t f1513l;

        /* JADX INFO: renamed from: m, reason: collision with root package name */
        private ArrayList<a> f1514m;

        /* JADX INFO: renamed from: n, reason: collision with root package name */
        private int f1515n;

        /* JADX INFO: renamed from: o, reason: collision with root package name */
        private boolean f1516o;

        /* JADX INFO: renamed from: p, reason: collision with root package name */
        private int f1517p;

        /* JADX INFO: renamed from: q, reason: collision with root package name */
        private int f1518q;

        /* JADX INFO: renamed from: r, reason: collision with root package name */
        private int f1519r;

        /* JADX INFO: compiled from: MotionScene.java */
        static class a implements View.OnClickListener {

            /* JADX INFO: renamed from: a, reason: collision with root package name */
            private final b f1520a;

            /* JADX INFO: renamed from: b, reason: collision with root package name */
            int f1521b;

            /* JADX INFO: renamed from: c, reason: collision with root package name */
            int f1522c;

            public a(Context context, b bVar, XmlPullParser xmlPullParser) {
                this.f1521b = -1;
                this.f1522c = 17;
                this.f1520a = bVar;
                TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(Xml.asAttributeSet(xmlPullParser), R$styleable.OnClick);
                int indexCount = typedArrayObtainStyledAttributes.getIndexCount();
                for (int i10 = 0; i10 < indexCount; i10++) {
                    int index = typedArrayObtainStyledAttributes.getIndex(i10);
                    if (index == R$styleable.OnClick_targetId) {
                        this.f1521b = typedArrayObtainStyledAttributes.getResourceId(index, this.f1521b);
                    } else if (index == R$styleable.OnClick_clickAction) {
                        this.f1522c = typedArrayObtainStyledAttributes.getInt(index, this.f1522c);
                    }
                }
                typedArrayObtainStyledAttributes.recycle();
            }

            public void a(MotionLayout motionLayout, int i10, b bVar) {
                boolean z10;
                View viewFindViewById;
                int i11 = this.f1521b;
                View view = motionLayout;
                if (i11 != -1) {
                    viewFindViewById = motionLayout.findViewById(i11);
                }
                if (view == null) {
                    view = viewFindViewById;
                    Log.e("MotionScene", "OnClick could not find id " + this.f1521b);
                    return;
                }
                int i12 = bVar.f1505d;
                int i13 = bVar.f1504c;
                if (i12 == -1) {
                    view = viewFindViewById;
                    view.setOnClickListener(this);
                    return;
                }
                int i14 = this.f1522c;
                boolean z11 = false;
                if ((i14 & 1) == 0 || i10 != i12) {
                    view = viewFindViewById;
                    z10 = false;
                } else {
                    z10 = true;
                }
                boolean z12 = ((i14 & 1) != 0 && i10 == i12) | z10 | ((i14 & 256) != 0 && i10 == i12) | ((i14 & 16) != 0 && i10 == i13);
                if ((i14 & 4096) != 0 && i10 == i13) {
                    z11 = true;
                }
                if (z12 || z11) {
                    view.setOnClickListener(this);
                }
            }

            boolean b(b bVar, MotionLayout motionLayout) {
                b bVar2 = this.f1520a;
                if (bVar2 == bVar) {
                    return true;
                }
                int i10 = bVar2.f1504c;
                int i11 = this.f1520a.f1505d;
                if (i11 == -1) {
                    return motionLayout.f1201h != i10;
                }
                int i12 = motionLayout.f1201h;
                return i12 == i11 || i12 == i10;
            }

            public void c(MotionLayout motionLayout) {
                int i10 = this.f1521b;
                if (i10 == -1) {
                    return;
                }
                View viewFindViewById = motionLayout.findViewById(i10);
                if (viewFindViewById != null) {
                    viewFindViewById.setOnClickListener(null);
                    return;
                }
                Log.e("MotionScene", " (*)  could not find id " + this.f1521b);
            }

            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                MotionLayout motionLayout = this.f1520a.f1511j.f1481a;
                if (motionLayout.R()) {
                    if (this.f1520a.f1505d == -1) {
                        int currentState = motionLayout.getCurrentState();
                        if (currentState == -1) {
                            motionLayout.c0(this.f1520a.f1504c);
                            return;
                        }
                        b bVar = new b(this.f1520a.f1511j, this.f1520a);
                        bVar.f1505d = currentState;
                        bVar.f1504c = this.f1520a.f1504c;
                        motionLayout.setTransition(bVar);
                        motionLayout.a0();
                        return;
                    }
                    b bVar2 = this.f1520a.f1511j.f1483c;
                    int i10 = this.f1522c;
                    boolean z10 = false;
                    boolean z11 = ((i10 & 1) == 0 && (i10 & 256) == 0) ? false : true;
                    boolean z12 = ((i10 & 16) == 0 && (i10 & 4096) == 0) ? false : true;
                    if (z11 && z12) {
                        b bVar3 = this.f1520a.f1511j.f1483c;
                        b bVar4 = this.f1520a;
                        if (bVar3 != bVar4) {
                            motionLayout.setTransition(bVar4);
                        }
                        if (motionLayout.getCurrentState() != motionLayout.getEndState() && motionLayout.getProgress() <= 0.5f) {
                            z12 = false;
                            z10 = z11;
                        }
                    } else {
                        z10 = z11;
                    }
                    if (b(bVar2, motionLayout)) {
                        if (z10 && (this.f1522c & 1) != 0) {
                            motionLayout.setTransition(this.f1520a);
                            motionLayout.a0();
                            return;
                        }
                        if (z12 && (this.f1522c & 16) != 0) {
                            motionLayout.setTransition(this.f1520a);
                            motionLayout.b0();
                        } else if (z10 && (this.f1522c & 256) != 0) {
                            motionLayout.setTransition(this.f1520a);
                            motionLayout.setProgress(1.0f);
                        } else {
                            if (!z12 || (this.f1522c & 4096) == 0) {
                                return;
                            }
                            motionLayout.setTransition(this.f1520a);
                            motionLayout.setProgress(0.0f);
                        }
                    }
                }
            }
        }

        b(q qVar, b bVar) {
            this.f1502a = -1;
            this.f1503b = false;
            this.f1504c = -1;
            this.f1505d = -1;
            this.f1506e = 0;
            this.f1507f = null;
            this.f1508g = -1;
            this.f1509h = SceneFlightData.INVALID_LATITUDE_LONGITUDE;
            this.f1510i = 0.0f;
            this.f1512k = new ArrayList<>();
            this.f1513l = null;
            this.f1514m = new ArrayList<>();
            this.f1515n = 0;
            this.f1516o = false;
            this.f1517p = -1;
            this.f1518q = 0;
            this.f1519r = 0;
            this.f1511j = qVar;
            if (bVar != null) {
                this.f1517p = bVar.f1517p;
                this.f1506e = bVar.f1506e;
                this.f1507f = bVar.f1507f;
                this.f1508g = bVar.f1508g;
                this.f1509h = bVar.f1509h;
                this.f1512k = bVar.f1512k;
                this.f1510i = bVar.f1510i;
                this.f1518q = bVar.f1518q;
            }
        }

        private void v(q qVar, Context context, TypedArray typedArray) {
            int indexCount = typedArray.getIndexCount();
            for (int i10 = 0; i10 < indexCount; i10++) {
                int index = typedArray.getIndex(i10);
                if (index == R$styleable.Transition_constraintSetEnd) {
                    this.f1504c = typedArray.getResourceId(index, this.f1504c);
                    if (ParserTag.CHILD_LAYOUT.equals(context.getResources().getResourceTypeName(this.f1504c))) {
                        androidx.constraintlayout.widget.b bVar = new androidx.constraintlayout.widget.b();
                        bVar.w(context, this.f1504c);
                        qVar.f1488h.append(this.f1504c, bVar);
                    }
                } else if (index == R$styleable.Transition_constraintSetStart) {
                    this.f1505d = typedArray.getResourceId(index, this.f1505d);
                    if (ParserTag.CHILD_LAYOUT.equals(context.getResources().getResourceTypeName(this.f1505d))) {
                        androidx.constraintlayout.widget.b bVar2 = new androidx.constraintlayout.widget.b();
                        bVar2.w(context, this.f1505d);
                        qVar.f1488h.append(this.f1505d, bVar2);
                    }
                } else if (index == R$styleable.Transition_motionInterpolator) {
                    int i11 = typedArray.peekValue(index).type;
                    if (i11 == 1) {
                        int resourceId = typedArray.getResourceId(index, -1);
                        this.f1508g = resourceId;
                        if (resourceId != -1) {
                            this.f1506e = -2;
                        }
                    } else if (i11 == 3) {
                        String string = typedArray.getString(index);
                        this.f1507f = string;
                        if (string.indexOf("/") > 0) {
                            this.f1508g = typedArray.getResourceId(index, -1);
                            this.f1506e = -2;
                        } else {
                            this.f1506e = -1;
                        }
                    } else {
                        this.f1506e = typedArray.getInteger(index, this.f1506e);
                    }
                } else if (index == R$styleable.Transition_duration) {
                    this.f1509h = typedArray.getInt(index, this.f1509h);
                } else if (index == R$styleable.Transition_staggered) {
                    this.f1510i = typedArray.getFloat(index, this.f1510i);
                } else if (index == R$styleable.Transition_autoTransition) {
                    this.f1515n = typedArray.getInteger(index, this.f1515n);
                } else if (index == R$styleable.Transition_android_id) {
                    this.f1502a = typedArray.getResourceId(index, this.f1502a);
                } else if (index == R$styleable.Transition_transitionDisable) {
                    this.f1516o = typedArray.getBoolean(index, this.f1516o);
                } else if (index == R$styleable.Transition_pathMotionArc) {
                    this.f1517p = typedArray.getInteger(index, -1);
                } else if (index == R$styleable.Transition_layoutDuringTransition) {
                    this.f1518q = typedArray.getInteger(index, 0);
                } else if (index == R$styleable.Transition_transitionFlags) {
                    this.f1519r = typedArray.getInteger(index, 0);
                }
            }
            if (this.f1505d == -1) {
                this.f1503b = true;
            }
        }

        private void w(q qVar, Context context, AttributeSet attributeSet) {
            TypedArray typedArrayObtainStyledAttributes = context.obtainStyledAttributes(attributeSet, R$styleable.Transition);
            v(qVar, context, typedArrayObtainStyledAttributes);
            typedArrayObtainStyledAttributes.recycle();
        }

        public int A() {
            return this.f1505d;
        }

        public t B() {
            return this.f1513l;
        }

        public boolean C() {
            return !this.f1516o;
        }

        public boolean D(int i10) {
            return (this.f1519r & i10) != 0;
        }

        public void E(int i10) {
            this.f1509h = i10;
        }

        public void t(Context context, XmlPullParser xmlPullParser) {
            this.f1514m.add(new a(context, this, xmlPullParser));
        }

        public String u(Context context) {
            String resourceEntryName = this.f1505d == -1 ? "null" : context.getResources().getResourceEntryName(this.f1505d);
            if (this.f1504c == -1) {
                return resourceEntryName + " -> null";
            }
            return resourceEntryName + " -> " + context.getResources().getResourceEntryName(this.f1504c);
        }

        public int x() {
            return this.f1509h;
        }

        public int y() {
            return this.f1504c;
        }

        public int z() {
            return this.f1518q;
        }

        b(q qVar, Context context, XmlPullParser xmlPullParser) {
            this.f1502a = -1;
            this.f1503b = false;
            this.f1504c = -1;
            this.f1505d = -1;
            this.f1506e = 0;
            this.f1507f = null;
            this.f1508g = -1;
            this.f1509h = SceneFlightData.INVALID_LATITUDE_LONGITUDE;
            this.f1510i = 0.0f;
            this.f1512k = new ArrayList<>();
            this.f1513l = null;
            this.f1514m = new ArrayList<>();
            this.f1515n = 0;
            this.f1516o = false;
            this.f1517p = -1;
            this.f1518q = 0;
            this.f1519r = 0;
            this.f1509h = qVar.f1492l;
            this.f1518q = qVar.f1493m;
            this.f1511j = qVar;
            w(qVar, context, Xml.asAttributeSet(xmlPullParser));
        }
    }
}
