package androidx.constraintlayout.motion.widget;

import android.util.Log;
import android.util.SparseArray;
import android.view.View;
import androidx.constraintlayout.widget.ConstraintAttribute;
import com.oplus.smartenginehelper.entity.ClickApiEntity;
import java.lang.reflect.Array;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.text.DecimalFormat;
import java.util.Arrays;

/* JADX INFO: compiled from: SplineSet.java */
/* JADX INFO: loaded from: classes.dex */
public abstract class r {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    protected s.b f1523a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    protected int[] f1524b = new int[10];

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    protected float[] f1525c = new float[10];

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private int f1526d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private String f1527e;

    /* JADX INFO: compiled from: SplineSet.java */
    static class a extends r {
        a() {
        }

        @Override // androidx.constraintlayout.motion.widget.r
        public void f(View view, float f10) {
            view.setAlpha(a(f10));
        }
    }

    /* JADX INFO: compiled from: SplineSet.java */
    static class b extends r {

        /* JADX INFO: renamed from: f, reason: collision with root package name */
        String f1528f;

        /* JADX INFO: renamed from: g, reason: collision with root package name */
        SparseArray<ConstraintAttribute> f1529g;

        /* JADX INFO: renamed from: h, reason: collision with root package name */
        float[] f1530h;

        public b(String str, SparseArray<ConstraintAttribute> sparseArray) {
            this.f1528f = str.split(",")[1];
            this.f1529g = sparseArray;
        }

        @Override // androidx.constraintlayout.motion.widget.r
        public void e(int i10, float f10) {
            throw new RuntimeException("don't call for custom attribute call setPoint(pos, ConstraintAttribute)");
        }

        @Override // androidx.constraintlayout.motion.widget.r
        public void f(View view, float f10) {
            this.f1523a.e(f10, this.f1530h);
            this.f1529g.valueAt(0).i(view, this.f1530h);
        }

        @Override // androidx.constraintlayout.motion.widget.r
        public void h(int i10) {
            int size = this.f1529g.size();
            int iF = this.f1529g.valueAt(0).f();
            double[] dArr = new double[size];
            this.f1530h = new float[iF];
            double[][] dArr2 = (double[][]) Array.newInstance((Class<?>) Double.TYPE, size, iF);
            for (int i11 = 0; i11 < size; i11++) {
                int iKeyAt = this.f1529g.keyAt(i11);
                ConstraintAttribute constraintAttributeValueAt = this.f1529g.valueAt(i11);
                dArr[i11] = ((double) iKeyAt) * 0.01d;
                constraintAttributeValueAt.e(this.f1530h);
                int i12 = 0;
                while (true) {
                    float[] fArr = this.f1530h;
                    if (i12 < fArr.length) {
                        dArr2[i11][i12] = fArr[i12];
                        i12++;
                    }
                }
            }
            this.f1523a = s.b.a(i10, dArr, dArr2);
        }

        public void i(int i10, ConstraintAttribute constraintAttribute) {
            this.f1529g.append(i10, constraintAttribute);
        }
    }

    /* JADX INFO: compiled from: SplineSet.java */
    static class c extends r {
        c() {
        }

        @Override // androidx.constraintlayout.motion.widget.r
        public void f(View view, float f10) {
            view.setElevation(a(f10));
        }
    }

    /* JADX INFO: compiled from: SplineSet.java */
    static class e extends r {
        e() {
        }

        @Override // androidx.constraintlayout.motion.widget.r
        public void f(View view, float f10) {
            view.setPivotX(a(f10));
        }
    }

    /* JADX INFO: compiled from: SplineSet.java */
    static class f extends r {
        f() {
        }

        @Override // androidx.constraintlayout.motion.widget.r
        public void f(View view, float f10) {
            view.setPivotY(a(f10));
        }
    }

    /* JADX INFO: compiled from: SplineSet.java */
    static class g extends r {

        /* JADX INFO: renamed from: f, reason: collision with root package name */
        boolean f1531f = false;

        g() {
        }

        @Override // androidx.constraintlayout.motion.widget.r
        public void f(View view, float f10) {
            Method method;
            if (view instanceof MotionLayout) {
                ((MotionLayout) view).setProgress(a(f10));
                return;
            }
            if (this.f1531f) {
                return;
            }
            try {
                method = view.getClass().getMethod(ClickApiEntity.SET_PROGRESS, Float.TYPE);
            } catch (NoSuchMethodException unused) {
                this.f1531f = true;
                method = null;
            }
            if (method != null) {
                try {
                    method.invoke(view, Float.valueOf(a(f10)));
                } catch (IllegalAccessException e10) {
                    Log.e("SplineSet", "unable to setProgress", e10);
                } catch (InvocationTargetException e11) {
                    Log.e("SplineSet", "unable to setProgress", e11);
                }
            }
        }
    }

    /* JADX INFO: compiled from: SplineSet.java */
    static class h extends r {
        h() {
        }

        @Override // androidx.constraintlayout.motion.widget.r
        public void f(View view, float f10) {
            view.setRotation(a(f10));
        }
    }

    /* JADX INFO: compiled from: SplineSet.java */
    static class i extends r {
        i() {
        }

        @Override // androidx.constraintlayout.motion.widget.r
        public void f(View view, float f10) {
            view.setRotationX(a(f10));
        }
    }

    /* JADX INFO: compiled from: SplineSet.java */
    static class j extends r {
        j() {
        }

        @Override // androidx.constraintlayout.motion.widget.r
        public void f(View view, float f10) {
            view.setRotationY(a(f10));
        }
    }

    /* JADX INFO: compiled from: SplineSet.java */
    static class k extends r {
        k() {
        }

        @Override // androidx.constraintlayout.motion.widget.r
        public void f(View view, float f10) {
            view.setScaleX(a(f10));
        }
    }

    /* JADX INFO: compiled from: SplineSet.java */
    static class l extends r {
        l() {
        }

        @Override // androidx.constraintlayout.motion.widget.r
        public void f(View view, float f10) {
            view.setScaleY(a(f10));
        }
    }

    /* JADX INFO: compiled from: SplineSet.java */
    private static class m {
        static void a(int[] iArr, float[] fArr, int i10, int i11) {
            int[] iArr2 = new int[iArr.length + 10];
            iArr2[0] = i11;
            iArr2[1] = i10;
            int i12 = 2;
            while (i12 > 0) {
                int i13 = iArr2[i12 - 1];
                int i14 = i12 - 2;
                int i15 = iArr2[i14];
                if (i13 < i15) {
                    int iB = b(iArr, fArr, i13, i15);
                    iArr2[i14] = iB - 1;
                    iArr2[i12 - 1] = i13;
                    int i16 = i12 + 1;
                    iArr2[i12] = i15;
                    i12 += 2;
                    iArr2[i16] = iB + 1;
                } else {
                    i12 = i14;
                }
            }
        }

        private static int b(int[] iArr, float[] fArr, int i10, int i11) {
            int i12 = iArr[i11];
            int i13 = i10;
            while (i10 < i11) {
                if (iArr[i10] <= i12) {
                    c(iArr, fArr, i13, i10);
                    i13++;
                }
                i10++;
            }
            c(iArr, fArr, i13, i11);
            return i13;
        }

        private static void c(int[] iArr, float[] fArr, int i10, int i11) {
            int i12 = iArr[i10];
            iArr[i10] = iArr[i11];
            iArr[i11] = i12;
            float f10 = fArr[i10];
            fArr[i10] = fArr[i11];
            fArr[i11] = f10;
        }
    }

    /* JADX INFO: compiled from: SplineSet.java */
    static class n extends r {
        n() {
        }

        @Override // androidx.constraintlayout.motion.widget.r
        public void f(View view, float f10) {
            view.setTranslationX(a(f10));
        }
    }

    /* JADX INFO: compiled from: SplineSet.java */
    static class o extends r {
        o() {
        }

        @Override // androidx.constraintlayout.motion.widget.r
        public void f(View view, float f10) {
            view.setTranslationY(a(f10));
        }
    }

    /* JADX INFO: compiled from: SplineSet.java */
    static class p extends r {
        p() {
        }

        @Override // androidx.constraintlayout.motion.widget.r
        public void f(View view, float f10) {
            view.setTranslationZ(a(f10));
        }
    }

    static r c(String str, SparseArray<ConstraintAttribute> sparseArray) {
        return new b(str, sparseArray);
    }

    static r d(String str) {
        str.hashCode();
        switch (str) {
            case "rotationX":
                return new i();
            case "rotationY":
                return new j();
            case "translationX":
                return new n();
            case "translationY":
                return new o();
            case "translationZ":
                return new p();
            case "progress":
                return new g();
            case "scaleX":
                return new k();
            case "scaleY":
                return new l();
            case "waveVariesBy":
                return new a();
            case "transformPivotX":
                return new e();
            case "transformPivotY":
                return new f();
            case "rotation":
                return new h();
            case "elevation":
                return new c();
            case "transitionPathRotate":
                return new d();
            case "alpha":
                return new a();
            case "waveOffset":
                return new a();
            default:
                return null;
        }
    }

    public float a(float f10) {
        return (float) this.f1523a.c(f10, 0);
    }

    public float b(float f10) {
        return (float) this.f1523a.f(f10, 0);
    }

    public void e(int i10, float f10) {
        int[] iArr = this.f1524b;
        if (iArr.length < this.f1526d + 1) {
            this.f1524b = Arrays.copyOf(iArr, iArr.length * 2);
            float[] fArr = this.f1525c;
            this.f1525c = Arrays.copyOf(fArr, fArr.length * 2);
        }
        int[] iArr2 = this.f1524b;
        int i11 = this.f1526d;
        iArr2[i11] = i10;
        this.f1525c[i11] = f10;
        this.f1526d = i11 + 1;
    }

    public abstract void f(View view, float f10);

    public void g(String str) {
        this.f1527e = str;
    }

    /* JADX WARN: Code duplicated, block: B:19:0x0048  */
    public void h(int i10) {
        int i11 = this.f1526d;
        if (i11 == 0) {
            return;
        }
        m.a(this.f1524b, this.f1525c, 0, i11 - 1);
        int i12 = 1;
        for (int i13 = 1; i13 < this.f1526d; i13++) {
            int[] iArr = this.f1524b;
            if (iArr[i13 - 1] != iArr[i13]) {
                i12++;
            }
        }
        double[] dArr = new double[i12];
        double[][] dArr2 = (double[][]) Array.newInstance((Class<?>) Double.TYPE, i12, 1);
        int i14 = 0;
        for (int i15 = 0; i15 < this.f1526d; i15++) {
            if (i15 > 0) {
                int[] iArr2 = this.f1524b;
                if (iArr2[i15] != iArr2[i15 - 1]) {
                    dArr[i14] = ((double) this.f1524b[i15]) * 0.01d;
                    dArr2[i14][0] = this.f1525c[i15];
                    i14++;
                }
            } else {
                dArr[i14] = ((double) this.f1524b[i15]) * 0.01d;
                dArr2[i14][0] = this.f1525c[i15];
                i14++;
            }
        }
        this.f1523a = s.b.a(i10, dArr, dArr2);
    }

    public String toString() {
        String str = this.f1527e;
        DecimalFormat decimalFormat = new DecimalFormat("##.##");
        for (int i10 = 0; i10 < this.f1526d; i10++) {
            str = str + "[" + this.f1524b[i10] + " , " + decimalFormat.format(this.f1525c[i10]) + "] ";
        }
        return str;
    }

    /* JADX INFO: compiled from: SplineSet.java */
    static class d extends r {
        d() {
        }

        public void i(View view, float f10, double d10, double d11) {
            view.setRotation(a(f10) + ((float) Math.toDegrees(Math.atan2(d11, d10))));
        }

        @Override // androidx.constraintlayout.motion.widget.r
        public void f(View view, float f10) {
        }
    }
}
