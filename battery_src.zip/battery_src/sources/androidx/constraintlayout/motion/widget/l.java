package androidx.constraintlayout.motion.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseIntArray;
import android.view.View;
import android.view.ViewGroup;
import androidx.constraintlayout.widget.R$styleable;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.HashSet;

/* JADX INFO: compiled from: KeyTrigger.java */
/* JADX INFO: loaded from: classes.dex */
public class l extends c {

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private int f1395g = -1;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private String f1396h = null;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private int f1397i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private String f1398j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    private String f1399k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private int f1400l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    private int f1401m;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    private View f1402n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    float f1403o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    private boolean f1404p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    private boolean f1405q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    private boolean f1406r;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    private float f1407s;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    private Method f1408t;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    private Method f1409u;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    private Method f1410v;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    private float f1411w;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    private boolean f1412x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    RectF f1413y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    RectF f1414z;

    /* JADX INFO: compiled from: KeyTrigger.java */
    private static class a {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private static SparseIntArray f1415a;

        static {
            SparseIntArray sparseIntArray = new SparseIntArray();
            f1415a = sparseIntArray;
            sparseIntArray.append(R$styleable.KeyTrigger_framePosition, 8);
            f1415a.append(R$styleable.KeyTrigger_onCross, 4);
            f1415a.append(R$styleable.KeyTrigger_onNegativeCross, 1);
            f1415a.append(R$styleable.KeyTrigger_onPositiveCross, 2);
            f1415a.append(R$styleable.KeyTrigger_motionTarget, 7);
            f1415a.append(R$styleable.KeyTrigger_triggerId, 6);
            f1415a.append(R$styleable.KeyTrigger_triggerSlack, 5);
            f1415a.append(R$styleable.KeyTrigger_motion_triggerOnCollision, 9);
            f1415a.append(R$styleable.KeyTrigger_motion_postLayoutCollision, 10);
            f1415a.append(R$styleable.KeyTrigger_triggerReceiver, 11);
        }

        public static void a(l lVar, TypedArray typedArray, Context context) {
            int indexCount = typedArray.getIndexCount();
            for (int i10 = 0; i10 < indexCount; i10++) {
                int index = typedArray.getIndex(i10);
                switch (f1415a.get(index)) {
                    case 1:
                        lVar.f1398j = typedArray.getString(index);
                        continue;
                        break;
                    case 2:
                        lVar.f1399k = typedArray.getString(index);
                        continue;
                        break;
                    case 4:
                        lVar.f1396h = typedArray.getString(index);
                        continue;
                        break;
                    case 5:
                        lVar.f1403o = typedArray.getFloat(index, lVar.f1403o);
                        continue;
                        break;
                    case 6:
                        lVar.f1400l = typedArray.getResourceId(index, lVar.f1400l);
                        continue;
                        break;
                    case 7:
                        if (MotionLayout.f1189t0) {
                            int resourceId = typedArray.getResourceId(index, lVar.f1292b);
                            lVar.f1292b = resourceId;
                            if (resourceId == -1) {
                                lVar.f1293c = typedArray.getString(index);
                            } else {
                                continue;
                            }
                        } else if (typedArray.peekValue(index).type == 3) {
                            lVar.f1293c = typedArray.getString(index);
                        } else {
                            lVar.f1292b = typedArray.getResourceId(index, lVar.f1292b);
                        }
                        break;
                    case 8:
                        int integer = typedArray.getInteger(index, lVar.f1291a);
                        lVar.f1291a = integer;
                        lVar.f1407s = (integer + 0.5f) / 100.0f;
                        continue;
                        break;
                    case 9:
                        lVar.f1401m = typedArray.getResourceId(index, lVar.f1401m);
                        continue;
                        break;
                    case 10:
                        lVar.f1412x = typedArray.getBoolean(index, lVar.f1412x);
                        continue;
                        break;
                    case 11:
                        lVar.f1397i = typedArray.getResourceId(index, lVar.f1397i);
                        break;
                }
                Log.e("KeyTrigger", "unused attribute 0x" + Integer.toHexString(index) + "   " + f1415a.get(index));
            }
        }
    }

    public l() {
        int i10 = c.f1290f;
        this.f1397i = i10;
        this.f1398j = null;
        this.f1399k = null;
        this.f1400l = i10;
        this.f1401m = i10;
        this.f1402n = null;
        this.f1403o = 0.1f;
        this.f1404p = true;
        this.f1405q = true;
        this.f1406r = true;
        this.f1407s = Float.NaN;
        this.f1412x = false;
        this.f1413y = new RectF();
        this.f1414z = new RectF();
        this.f1294d = 5;
        this.f1295e = new HashMap<>();
    }

    private void s(RectF rectF, View view, boolean z10) {
        rectF.top = view.getTop();
        rectF.bottom = view.getBottom();
        rectF.left = view.getLeft();
        rectF.right = view.getRight();
        if (z10) {
            view.getMatrix().mapRect(rectF);
        }
    }

    @Override // androidx.constraintlayout.motion.widget.c
    public void c(Context context, AttributeSet attributeSet) {
        a.a(this, context.obtainStyledAttributes(attributeSet, R$styleable.KeyTrigger), context);
    }

    /* JADX WARN: Code duplicated, block: B:38:0x008d  */
    /* JADX WARN: Code duplicated, block: B:43:0x00a1  */
    /* JADX WARN: Code duplicated, block: B:45:0x00af  */
    /* JADX WARN: Code duplicated, block: B:49:0x00b6  */
    /* JADX WARN: Code duplicated, block: B:51:0x00c2  */
    /* JADX WARN: Code duplicated, block: B:54:0x00c9  */
    /* JADX WARN: Code duplicated, block: B:57:0x00cd  */
    /* JADX WARN: Code duplicated, block: B:59:0x00db  */
    public void r(float f10, View view) {
        boolean z10;
        boolean z11;
        boolean z12;
        float f11;
        float f12;
        float f13;
        float f14;
        boolean z13;
        boolean z14 = true;
        boolean z15 = false;
        if (this.f1401m != c.f1290f) {
            if (this.f1402n == null) {
                this.f1402n = ((ViewGroup) view.getParent()).findViewById(this.f1401m);
            }
            s(this.f1413y, this.f1402n, this.f1412x);
            s(this.f1414z, view, this.f1412x);
            if (this.f1413y.intersect(this.f1414z)) {
                if (this.f1404p) {
                    this.f1404p = false;
                    z10 = true;
                } else {
                    z10 = false;
                }
                if (this.f1406r) {
                    this.f1406r = false;
                    z12 = true;
                } else {
                    z12 = false;
                }
                this.f1405q = true;
            } else {
                if (this.f1404p) {
                    z10 = false;
                } else {
                    this.f1404p = true;
                    z10 = true;
                }
                if (this.f1405q) {
                    this.f1405q = false;
                    z13 = true;
                } else {
                    z13 = false;
                }
                this.f1406r = true;
                z15 = z13;
                z12 = false;
            }
        } else {
            if (this.f1404p) {
                float f15 = this.f1407s;
                if ((f10 - f15) * (this.f1411w - f15) < 0.0f) {
                    this.f1404p = false;
                    z10 = true;
                }
                if (this.f1405q) {
                    f13 = this.f1407s;
                    f14 = f10 - f13;
                    if ((this.f1411w - f13) * f14 >= 0.0f && f14 < 0.0f) {
                        this.f1405q = false;
                        z11 = true;
                    }
                    if (this.f1406r) {
                        f11 = this.f1407s;
                        f12 = f10 - f11;
                        if ((this.f1411w - f11) * f12 < 0.0f || f12 <= 0.0f) {
                            z14 = false;
                        } else {
                            this.f1406r = false;
                        }
                        z12 = z14;
                    } else {
                        if (Math.abs(f10 - this.f1407s) > this.f1403o) {
                            this.f1406r = true;
                        }
                        z12 = false;
                    }
                    z15 = z11;
                } else if (Math.abs(f10 - this.f1407s) > this.f1403o) {
                    this.f1405q = true;
                }
                z11 = false;
                if (this.f1406r) {
                    f11 = this.f1407s;
                    f12 = f10 - f11;
                    if ((this.f1411w - f11) * f12 < 0.0f) {
                        z14 = false;
                    } else {
                        z14 = false;
                    }
                    z12 = z14;
                } else {
                    if (Math.abs(f10 - this.f1407s) > this.f1403o) {
                        this.f1406r = true;
                    }
                    z12 = false;
                }
                z15 = z11;
            } else if (Math.abs(f10 - this.f1407s) > this.f1403o) {
                this.f1404p = true;
            }
            z10 = false;
            if (this.f1405q) {
                f13 = this.f1407s;
                f14 = f10 - f13;
                if ((this.f1411w - f13) * f14 >= 0.0f) {
                }
                if (this.f1406r) {
                    f11 = this.f1407s;
                    f12 = f10 - f11;
                    if ((this.f1411w - f11) * f12 < 0.0f) {
                        z14 = false;
                    } else {
                        z14 = false;
                    }
                    z12 = z14;
                } else {
                    if (Math.abs(f10 - this.f1407s) > this.f1403o) {
                        this.f1406r = true;
                    }
                    z12 = false;
                }
                z15 = z11;
            } else if (Math.abs(f10 - this.f1407s) > this.f1403o) {
                this.f1405q = true;
            }
            z11 = false;
            if (this.f1406r) {
                f11 = this.f1407s;
                f12 = f10 - f11;
                if ((this.f1411w - f11) * f12 < 0.0f) {
                    z14 = false;
                } else {
                    z14 = false;
                }
                z12 = z14;
            } else {
                if (Math.abs(f10 - this.f1407s) > this.f1403o) {
                    this.f1406r = true;
                }
                z12 = false;
            }
            z15 = z11;
        }
        this.f1411w = f10;
        if (z15 || z10 || z12) {
            ((MotionLayout) view.getParent()).L(this.f1400l, z12, f10);
        }
        if (this.f1397i != c.f1290f) {
            view = ((MotionLayout) view.getParent()).findViewById(this.f1397i);
        }
        if (z15 && this.f1398j != null) {
            if (this.f1409u == null) {
                try {
                    this.f1409u = view.getClass().getMethod(this.f1398j, null);
                } catch (NoSuchMethodException unused) {
                    Log.e("KeyTrigger", "Could not find method \"" + this.f1398j + "\"on class " + view.getClass().getSimpleName() + " " + androidx.constraintlayout.motion.widget.a.c(view));
                }
            }
            try {
                this.f1409u.invoke(view, null);
            } catch (Exception unused2) {
                Log.e("KeyTrigger", "Exception in call \"" + this.f1398j + "\"on class " + view.getClass().getSimpleName() + " " + androidx.constraintlayout.motion.widget.a.c(view));
            }
        }
        if (z12 && this.f1399k != null) {
            if (this.f1410v == null) {
                try {
                    this.f1410v = view.getClass().getMethod(this.f1399k, null);
                } catch (NoSuchMethodException unused3) {
                    Log.e("KeyTrigger", "Could not find method \"" + this.f1399k + "\"on class " + view.getClass().getSimpleName() + " " + androidx.constraintlayout.motion.widget.a.c(view));
                }
            }
            try {
                this.f1410v.invoke(view, null);
            } catch (Exception unused4) {
                Log.e("KeyTrigger", "Exception in call \"" + this.f1399k + "\"on class " + view.getClass().getSimpleName() + " " + androidx.constraintlayout.motion.widget.a.c(view));
            }
        }
        if (!z10 || this.f1396h == null) {
            return;
        }
        if (this.f1408t == null) {
            try {
                this.f1408t = view.getClass().getMethod(this.f1396h, null);
            } catch (NoSuchMethodException unused5) {
                Log.e("KeyTrigger", "Could not find method \"" + this.f1396h + "\"on class " + view.getClass().getSimpleName() + " " + androidx.constraintlayout.motion.widget.a.c(view));
            }
        }
        try {
            this.f1408t.invoke(view, null);
        } catch (Exception unused6) {
            Log.e("KeyTrigger", "Exception in call \"" + this.f1396h + "\"on class " + view.getClass().getSimpleName() + " " + androidx.constraintlayout.motion.widget.a.c(view));
        }
    }

    @Override // androidx.constraintlayout.motion.widget.c
    public void a(HashMap<String, r> map) {
    }

    @Override // androidx.constraintlayout.motion.widget.c
    public void b(HashSet<String> hashSet) {
    }
}
