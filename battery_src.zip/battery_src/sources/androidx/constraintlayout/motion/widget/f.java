package androidx.constraintlayout.motion.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseIntArray;
import androidx.constraintlayout.widget.ConstraintAttribute;
import androidx.constraintlayout.widget.R$styleable;
import com.oplus.smartenginehelper.entity.ViewEntity;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;

/* JADX INFO: compiled from: KeyCycle.java */
/* JADX INFO: loaded from: classes.dex */
public class f extends c {

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private String f1315g = null;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private int f1316h = 0;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private int f1317i = -1;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private float f1318j = Float.NaN;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    private float f1319k = 0.0f;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private float f1320l = Float.NaN;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    private int f1321m = -1;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    private float f1322n = Float.NaN;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    private float f1323o = Float.NaN;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    private float f1324p = Float.NaN;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    private float f1325q = Float.NaN;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    private float f1326r = Float.NaN;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    private float f1327s = Float.NaN;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    private float f1328t = Float.NaN;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    private float f1329u = Float.NaN;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    private float f1330v = Float.NaN;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    private float f1331w = Float.NaN;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    private float f1332x = Float.NaN;

    /* JADX INFO: compiled from: KeyCycle.java */
    private static class a {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private static SparseIntArray f1333a;

        static {
            SparseIntArray sparseIntArray = new SparseIntArray();
            f1333a = sparseIntArray;
            sparseIntArray.append(R$styleable.KeyCycle_motionTarget, 1);
            f1333a.append(R$styleable.KeyCycle_framePosition, 2);
            f1333a.append(R$styleable.KeyCycle_transitionEasing, 3);
            f1333a.append(R$styleable.KeyCycle_curveFit, 4);
            f1333a.append(R$styleable.KeyCycle_waveShape, 5);
            f1333a.append(R$styleable.KeyCycle_wavePeriod, 6);
            f1333a.append(R$styleable.KeyCycle_waveOffset, 7);
            f1333a.append(R$styleable.KeyCycle_waveVariesBy, 8);
            f1333a.append(R$styleable.KeyCycle_android_alpha, 9);
            f1333a.append(R$styleable.KeyCycle_android_elevation, 10);
            f1333a.append(R$styleable.KeyCycle_android_rotation, 11);
            f1333a.append(R$styleable.KeyCycle_android_rotationX, 12);
            f1333a.append(R$styleable.KeyCycle_android_rotationY, 13);
            f1333a.append(R$styleable.KeyCycle_transitionPathRotate, 14);
            f1333a.append(R$styleable.KeyCycle_android_scaleX, 15);
            f1333a.append(R$styleable.KeyCycle_android_scaleY, 16);
            f1333a.append(R$styleable.KeyCycle_android_translationX, 17);
            f1333a.append(R$styleable.KeyCycle_android_translationY, 18);
            f1333a.append(R$styleable.KeyCycle_android_translationZ, 19);
            f1333a.append(R$styleable.KeyCycle_motionProgress, 20);
        }

        /* JADX INFO: Access modifiers changed from: private */
        public static void b(f fVar, TypedArray typedArray) {
            int indexCount = typedArray.getIndexCount();
            for (int i10 = 0; i10 < indexCount; i10++) {
                int index = typedArray.getIndex(i10);
                switch (f1333a.get(index)) {
                    case 1:
                        if (MotionLayout.f1189t0) {
                            int resourceId = typedArray.getResourceId(index, fVar.f1292b);
                            fVar.f1292b = resourceId;
                            if (resourceId == -1) {
                                fVar.f1293c = typedArray.getString(index);
                            }
                        } else if (typedArray.peekValue(index).type == 3) {
                            fVar.f1293c = typedArray.getString(index);
                        } else {
                            fVar.f1292b = typedArray.getResourceId(index, fVar.f1292b);
                        }
                        break;
                    case 2:
                        fVar.f1291a = typedArray.getInt(index, fVar.f1291a);
                        break;
                    case 3:
                        fVar.f1315g = typedArray.getString(index);
                        break;
                    case 4:
                        fVar.f1316h = typedArray.getInteger(index, fVar.f1316h);
                        break;
                    case 5:
                        fVar.f1317i = typedArray.getInt(index, fVar.f1317i);
                        break;
                    case 6:
                        fVar.f1318j = typedArray.getFloat(index, fVar.f1318j);
                        break;
                    case 7:
                        if (typedArray.peekValue(index).type == 5) {
                            fVar.f1319k = typedArray.getDimension(index, fVar.f1319k);
                        } else {
                            fVar.f1319k = typedArray.getFloat(index, fVar.f1319k);
                        }
                        break;
                    case 8:
                        fVar.f1321m = typedArray.getInt(index, fVar.f1321m);
                        break;
                    case 9:
                        fVar.f1322n = typedArray.getFloat(index, fVar.f1322n);
                        break;
                    case 10:
                        fVar.f1323o = typedArray.getDimension(index, fVar.f1323o);
                        break;
                    case 11:
                        fVar.f1324p = typedArray.getFloat(index, fVar.f1324p);
                        break;
                    case 12:
                        fVar.f1326r = typedArray.getFloat(index, fVar.f1326r);
                        break;
                    case 13:
                        fVar.f1327s = typedArray.getFloat(index, fVar.f1327s);
                        break;
                    case 14:
                        fVar.f1325q = typedArray.getFloat(index, fVar.f1325q);
                        break;
                    case 15:
                        fVar.f1328t = typedArray.getFloat(index, fVar.f1328t);
                        break;
                    case 16:
                        fVar.f1329u = typedArray.getFloat(index, fVar.f1329u);
                        break;
                    case 17:
                        fVar.f1330v = typedArray.getDimension(index, fVar.f1330v);
                        break;
                    case 18:
                        fVar.f1331w = typedArray.getDimension(index, fVar.f1331w);
                        break;
                    case 19:
                        fVar.f1332x = typedArray.getDimension(index, fVar.f1332x);
                        break;
                    case 20:
                        fVar.f1320l = typedArray.getFloat(index, fVar.f1320l);
                        break;
                    default:
                        Log.e("KeyCycle", "unused attribute 0x" + Integer.toHexString(index) + "   " + f1333a.get(index));
                        break;
                }
            }
        }
    }

    public f() {
        this.f1294d = 4;
        this.f1295e = new HashMap<>();
    }

    public void O(HashMap<String, g> map) {
        for (String str : map.keySet()) {
            if (str.startsWith("CUSTOM")) {
                ConstraintAttribute constraintAttribute = this.f1295e.get(str.substring(7));
                if (constraintAttribute != null && constraintAttribute.c() == ConstraintAttribute.AttributeType.FLOAT_TYPE) {
                    map.get(str).e(this.f1291a, this.f1317i, this.f1321m, this.f1318j, this.f1319k, constraintAttribute.d(), constraintAttribute);
                }
            }
            float fP = P(str);
            if (!Float.isNaN(fP)) {
                map.get(str).d(this.f1291a, this.f1317i, this.f1321m, this.f1318j, this.f1319k, fP);
            }
        }
    }

    public float P(String str) {
        str.hashCode();
        switch (str) {
            case "rotationX":
                return this.f1326r;
            case "rotationY":
                return this.f1327s;
            case "translationX":
                return this.f1330v;
            case "translationY":
                return this.f1331w;
            case "translationZ":
                return this.f1332x;
            case "progress":
                return this.f1320l;
            case "scaleX":
                return this.f1328t;
            case "scaleY":
                return this.f1329u;
            case "rotation":
                return this.f1324p;
            case "elevation":
                return this.f1323o;
            case "transitionPathRotate":
                return this.f1325q;
            case "alpha":
                return this.f1322n;
            case "waveOffset":
                return this.f1319k;
            default:
                Log.v("WARNING! KeyCycle", "  UNKNOWN  " + str);
                return Float.NaN;
        }
    }

    @Override // androidx.constraintlayout.motion.widget.c
    public void a(HashMap<String, r> map) {
        androidx.constraintlayout.motion.widget.a.e("KeyCycle", "add " + map.size() + " values", 2);
        for (String str : map.keySet()) {
            r rVar = map.get(str);
            str.hashCode();
            switch (str) {
                case "rotationX":
                    rVar.e(this.f1291a, this.f1326r);
                    break;
                case "rotationY":
                    rVar.e(this.f1291a, this.f1327s);
                    break;
                case "translationX":
                    rVar.e(this.f1291a, this.f1330v);
                    break;
                case "translationY":
                    rVar.e(this.f1291a, this.f1331w);
                    break;
                case "translationZ":
                    rVar.e(this.f1291a, this.f1332x);
                    break;
                case "progress":
                    rVar.e(this.f1291a, this.f1320l);
                    break;
                case "scaleX":
                    rVar.e(this.f1291a, this.f1328t);
                    break;
                case "scaleY":
                    rVar.e(this.f1291a, this.f1329u);
                    break;
                case "rotation":
                    rVar.e(this.f1291a, this.f1324p);
                    break;
                case "elevation":
                    rVar.e(this.f1291a, this.f1323o);
                    break;
                case "transitionPathRotate":
                    rVar.e(this.f1291a, this.f1325q);
                    break;
                case "alpha":
                    rVar.e(this.f1291a, this.f1322n);
                    break;
                case "waveOffset":
                    rVar.e(this.f1291a, this.f1319k);
                    break;
                default:
                    Log.v("WARNING KeyCycle", "  UNKNOWN  " + str);
                    break;
            }
        }
    }

    @Override // androidx.constraintlayout.motion.widget.c
    public void b(HashSet<String> hashSet) {
        if (!Float.isNaN(this.f1322n)) {
            hashSet.add(ViewEntity.ALPHA);
        }
        if (!Float.isNaN(this.f1323o)) {
            hashSet.add(ViewEntity.ELEVATION);
        }
        if (!Float.isNaN(this.f1324p)) {
            hashSet.add(ViewEntity.ROTATION);
        }
        if (!Float.isNaN(this.f1326r)) {
            hashSet.add(ViewEntity.ROTATION_X);
        }
        if (!Float.isNaN(this.f1327s)) {
            hashSet.add(ViewEntity.ROTATION_Y);
        }
        if (!Float.isNaN(this.f1328t)) {
            hashSet.add(ViewEntity.SCALE_X);
        }
        if (!Float.isNaN(this.f1329u)) {
            hashSet.add(ViewEntity.SCALE_Y);
        }
        if (!Float.isNaN(this.f1325q)) {
            hashSet.add("transitionPathRotate");
        }
        if (!Float.isNaN(this.f1330v)) {
            hashSet.add(ViewEntity.TRANSLATION_X);
        }
        if (!Float.isNaN(this.f1331w)) {
            hashSet.add(ViewEntity.TRANSLATION_Y);
        }
        if (!Float.isNaN(this.f1332x)) {
            hashSet.add(ViewEntity.TRANSLATION_Z);
        }
        if (this.f1295e.size() > 0) {
            Iterator<String> it = this.f1295e.keySet().iterator();
            while (it.hasNext()) {
                hashSet.add("CUSTOM," + it.next());
            }
        }
    }

    @Override // androidx.constraintlayout.motion.widget.c
    public void c(Context context, AttributeSet attributeSet) {
        a.b(this, context.obtainStyledAttributes(attributeSet, R$styleable.KeyCycle));
    }
}
