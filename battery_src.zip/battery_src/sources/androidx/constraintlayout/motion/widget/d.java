package androidx.constraintlayout.motion.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseIntArray;
import androidx.constraintlayout.widget.ConstraintAttribute;
import androidx.constraintlayout.widget.R$styleable;
import com.oplus.smartenginehelper.ParserTag;
import com.oplus.smartenginehelper.entity.ViewEntity;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;

/* JADX INFO: compiled from: KeyAttributes.java */
/* JADX INFO: loaded from: classes.dex */
public class d extends c {

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private String f1296g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private int f1297h = -1;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private boolean f1298i = false;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private float f1299j = Float.NaN;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    private float f1300k = Float.NaN;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private float f1301l = Float.NaN;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    private float f1302m = Float.NaN;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    private float f1303n = Float.NaN;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    private float f1304o = Float.NaN;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    private float f1305p = Float.NaN;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    private float f1306q = Float.NaN;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    private float f1307r = Float.NaN;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    private float f1308s = Float.NaN;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    private float f1309t = Float.NaN;

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    private float f1310u = Float.NaN;

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    private float f1311v = Float.NaN;

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    private float f1312w = Float.NaN;

    /* JADX INFO: compiled from: KeyAttributes.java */
    private static class a {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private static SparseIntArray f1313a;

        static {
            SparseIntArray sparseIntArray = new SparseIntArray();
            f1313a = sparseIntArray;
            sparseIntArray.append(R$styleable.KeyAttribute_android_alpha, 1);
            f1313a.append(R$styleable.KeyAttribute_android_elevation, 2);
            f1313a.append(R$styleable.KeyAttribute_android_rotation, 4);
            f1313a.append(R$styleable.KeyAttribute_android_rotationX, 5);
            f1313a.append(R$styleable.KeyAttribute_android_rotationY, 6);
            f1313a.append(R$styleable.KeyAttribute_android_transformPivotX, 19);
            f1313a.append(R$styleable.KeyAttribute_android_transformPivotY, 20);
            f1313a.append(R$styleable.KeyAttribute_android_scaleX, 7);
            f1313a.append(R$styleable.KeyAttribute_transitionPathRotate, 8);
            f1313a.append(R$styleable.KeyAttribute_transitionEasing, 9);
            f1313a.append(R$styleable.KeyAttribute_motionTarget, 10);
            f1313a.append(R$styleable.KeyAttribute_framePosition, 12);
            f1313a.append(R$styleable.KeyAttribute_curveFit, 13);
            f1313a.append(R$styleable.KeyAttribute_android_scaleY, 14);
            f1313a.append(R$styleable.KeyAttribute_android_translationX, 15);
            f1313a.append(R$styleable.KeyAttribute_android_translationY, 16);
            f1313a.append(R$styleable.KeyAttribute_android_translationZ, 17);
            f1313a.append(R$styleable.KeyAttribute_motionProgress, 18);
        }

        public static void a(d dVar, TypedArray typedArray) {
            int indexCount = typedArray.getIndexCount();
            for (int i10 = 0; i10 < indexCount; i10++) {
                int index = typedArray.getIndex(i10);
                switch (f1313a.get(index)) {
                    case 1:
                        dVar.f1299j = typedArray.getFloat(index, dVar.f1299j);
                        break;
                    case 2:
                        dVar.f1300k = typedArray.getDimension(index, dVar.f1300k);
                        break;
                    case 3:
                    case 11:
                    default:
                        Log.e("KeyAttribute", "unused attribute 0x" + Integer.toHexString(index) + "   " + f1313a.get(index));
                        break;
                    case 4:
                        dVar.f1301l = typedArray.getFloat(index, dVar.f1301l);
                        break;
                    case 5:
                        dVar.f1302m = typedArray.getFloat(index, dVar.f1302m);
                        break;
                    case 6:
                        dVar.f1303n = typedArray.getFloat(index, dVar.f1303n);
                        break;
                    case 7:
                        dVar.f1307r = typedArray.getFloat(index, dVar.f1307r);
                        break;
                    case 8:
                        dVar.f1306q = typedArray.getFloat(index, dVar.f1306q);
                        break;
                    case 9:
                        dVar.f1296g = typedArray.getString(index);
                        break;
                    case 10:
                        if (MotionLayout.f1189t0) {
                            int resourceId = typedArray.getResourceId(index, dVar.f1292b);
                            dVar.f1292b = resourceId;
                            if (resourceId == -1) {
                                dVar.f1293c = typedArray.getString(index);
                            }
                        } else if (typedArray.peekValue(index).type == 3) {
                            dVar.f1293c = typedArray.getString(index);
                        } else {
                            dVar.f1292b = typedArray.getResourceId(index, dVar.f1292b);
                        }
                        break;
                    case 12:
                        dVar.f1291a = typedArray.getInt(index, dVar.f1291a);
                        break;
                    case 13:
                        dVar.f1297h = typedArray.getInteger(index, dVar.f1297h);
                        break;
                    case 14:
                        dVar.f1308s = typedArray.getFloat(index, dVar.f1308s);
                        break;
                    case 15:
                        dVar.f1309t = typedArray.getDimension(index, dVar.f1309t);
                        break;
                    case 16:
                        dVar.f1310u = typedArray.getDimension(index, dVar.f1310u);
                        break;
                    case 17:
                        dVar.f1311v = typedArray.getDimension(index, dVar.f1311v);
                        break;
                    case 18:
                        dVar.f1312w = typedArray.getFloat(index, dVar.f1312w);
                        break;
                    case 19:
                        dVar.f1304o = typedArray.getDimension(index, dVar.f1304o);
                        break;
                    case 20:
                        dVar.f1305p = typedArray.getDimension(index, dVar.f1305p);
                        break;
                }
            }
        }
    }

    public d() {
        this.f1294d = 1;
        this.f1295e = new HashMap<>();
    }

    @Override // androidx.constraintlayout.motion.widget.c
    public void a(HashMap<String, r> map) {
        for (String str : map.keySet()) {
            r rVar = map.get(str);
            if (!str.startsWith("CUSTOM")) {
                switch (str) {
                    case "rotationX":
                        if (Float.isNaN(this.f1302m)) {
                            break;
                        } else {
                            rVar.e(this.f1291a, this.f1302m);
                            break;
                        }
                        break;
                    case "rotationY":
                        if (Float.isNaN(this.f1303n)) {
                            break;
                        } else {
                            rVar.e(this.f1291a, this.f1303n);
                            break;
                        }
                        break;
                    case "translationX":
                        if (Float.isNaN(this.f1309t)) {
                            break;
                        } else {
                            rVar.e(this.f1291a, this.f1309t);
                            break;
                        }
                        break;
                    case "translationY":
                        if (Float.isNaN(this.f1310u)) {
                            break;
                        } else {
                            rVar.e(this.f1291a, this.f1310u);
                            break;
                        }
                        break;
                    case "translationZ":
                        if (Float.isNaN(this.f1311v)) {
                            break;
                        } else {
                            rVar.e(this.f1291a, this.f1311v);
                            break;
                        }
                        break;
                    case "progress":
                        if (Float.isNaN(this.f1312w)) {
                            break;
                        } else {
                            rVar.e(this.f1291a, this.f1312w);
                            break;
                        }
                        break;
                    case "scaleX":
                        if (Float.isNaN(this.f1307r)) {
                            break;
                        } else {
                            rVar.e(this.f1291a, this.f1307r);
                            break;
                        }
                        break;
                    case "scaleY":
                        if (Float.isNaN(this.f1308s)) {
                            break;
                        } else {
                            rVar.e(this.f1291a, this.f1308s);
                            break;
                        }
                        break;
                    case "transformPivotX":
                        if (Float.isNaN(this.f1302m)) {
                            break;
                        } else {
                            rVar.e(this.f1291a, this.f1304o);
                            break;
                        }
                        break;
                    case "transformPivotY":
                        if (Float.isNaN(this.f1303n)) {
                            break;
                        } else {
                            rVar.e(this.f1291a, this.f1305p);
                            break;
                        }
                        break;
                    case "rotation":
                        if (Float.isNaN(this.f1301l)) {
                            break;
                        } else {
                            rVar.e(this.f1291a, this.f1301l);
                            break;
                        }
                        break;
                    case "elevation":
                        if (Float.isNaN(this.f1300k)) {
                            break;
                        } else {
                            rVar.e(this.f1291a, this.f1300k);
                            break;
                        }
                        break;
                    case "transitionPathRotate":
                        if (Float.isNaN(this.f1306q)) {
                            break;
                        } else {
                            rVar.e(this.f1291a, this.f1306q);
                            break;
                        }
                        break;
                    case "alpha":
                        if (Float.isNaN(this.f1299j)) {
                            break;
                        } else {
                            rVar.e(this.f1291a, this.f1299j);
                            break;
                        }
                        break;
                    default:
                        Log.v("KeyAttributes", "UNKNOWN addValues \"" + str + "\"");
                        break;
                }
            } else {
                ConstraintAttribute constraintAttribute = this.f1295e.get(str.substring(7));
                if (constraintAttribute != null) {
                    ((r.b) rVar).i(this.f1291a, constraintAttribute);
                }
            }
        }
    }

    @Override // androidx.constraintlayout.motion.widget.c
    public void b(HashSet<String> hashSet) {
        if (!Float.isNaN(this.f1299j)) {
            hashSet.add(ViewEntity.ALPHA);
        }
        if (!Float.isNaN(this.f1300k)) {
            hashSet.add(ViewEntity.ELEVATION);
        }
        if (!Float.isNaN(this.f1301l)) {
            hashSet.add(ViewEntity.ROTATION);
        }
        if (!Float.isNaN(this.f1302m)) {
            hashSet.add(ViewEntity.ROTATION_X);
        }
        if (!Float.isNaN(this.f1303n)) {
            hashSet.add(ViewEntity.ROTATION_Y);
        }
        if (!Float.isNaN(this.f1304o)) {
            hashSet.add(ViewEntity.TRANSFORM_PIVOT_X);
        }
        if (!Float.isNaN(this.f1305p)) {
            hashSet.add(ViewEntity.TRANSFORM_PIVOT_Y);
        }
        if (!Float.isNaN(this.f1309t)) {
            hashSet.add(ViewEntity.TRANSLATION_X);
        }
        if (!Float.isNaN(this.f1310u)) {
            hashSet.add(ViewEntity.TRANSLATION_Y);
        }
        if (!Float.isNaN(this.f1311v)) {
            hashSet.add(ViewEntity.TRANSLATION_Z);
        }
        if (!Float.isNaN(this.f1306q)) {
            hashSet.add("transitionPathRotate");
        }
        if (!Float.isNaN(this.f1307r)) {
            hashSet.add(ViewEntity.SCALE_X);
        }
        if (!Float.isNaN(this.f1307r)) {
            hashSet.add(ViewEntity.SCALE_Y);
        }
        if (!Float.isNaN(this.f1312w)) {
            hashSet.add(ParserTag.TAG_PROGRESS);
        }
        if (this.f1295e.size() > 0) {
            Iterator<String> it = this.f1295e.keySet().iterator();
            while (it.hasNext()) {
                hashSet.add("CUSTOM," + it.next());
            }
        }
    }

    @Override // androidx.constraintlayout.motion.widget.c
    public void c(Context context, AttributeSet attributeSet) {
        a.a(this, context.obtainStyledAttributes(attributeSet, R$styleable.KeyAttribute));
    }

    @Override // androidx.constraintlayout.motion.widget.c
    public void e(HashMap<String, Integer> map) {
        if (this.f1297h == -1) {
            return;
        }
        if (!Float.isNaN(this.f1299j)) {
            map.put(ViewEntity.ALPHA, Integer.valueOf(this.f1297h));
        }
        if (!Float.isNaN(this.f1300k)) {
            map.put(ViewEntity.ELEVATION, Integer.valueOf(this.f1297h));
        }
        if (!Float.isNaN(this.f1301l)) {
            map.put(ViewEntity.ROTATION, Integer.valueOf(this.f1297h));
        }
        if (!Float.isNaN(this.f1302m)) {
            map.put(ViewEntity.ROTATION_X, Integer.valueOf(this.f1297h));
        }
        if (!Float.isNaN(this.f1303n)) {
            map.put(ViewEntity.ROTATION_Y, Integer.valueOf(this.f1297h));
        }
        if (!Float.isNaN(this.f1304o)) {
            map.put(ViewEntity.TRANSFORM_PIVOT_X, Integer.valueOf(this.f1297h));
        }
        if (!Float.isNaN(this.f1305p)) {
            map.put(ViewEntity.TRANSFORM_PIVOT_Y, Integer.valueOf(this.f1297h));
        }
        if (!Float.isNaN(this.f1309t)) {
            map.put(ViewEntity.TRANSLATION_X, Integer.valueOf(this.f1297h));
        }
        if (!Float.isNaN(this.f1310u)) {
            map.put(ViewEntity.TRANSLATION_Y, Integer.valueOf(this.f1297h));
        }
        if (!Float.isNaN(this.f1311v)) {
            map.put(ViewEntity.TRANSLATION_Z, Integer.valueOf(this.f1297h));
        }
        if (!Float.isNaN(this.f1306q)) {
            map.put("transitionPathRotate", Integer.valueOf(this.f1297h));
        }
        if (!Float.isNaN(this.f1307r)) {
            map.put(ViewEntity.SCALE_X, Integer.valueOf(this.f1297h));
        }
        if (!Float.isNaN(this.f1308s)) {
            map.put(ViewEntity.SCALE_Y, Integer.valueOf(this.f1297h));
        }
        if (!Float.isNaN(this.f1312w)) {
            map.put(ParserTag.TAG_PROGRESS, Integer.valueOf(this.f1297h));
        }
        if (this.f1295e.size() > 0) {
            Iterator<String> it = this.f1295e.keySet().iterator();
            while (it.hasNext()) {
                map.put("CUSTOM," + it.next(), Integer.valueOf(this.f1297h));
            }
        }
    }
}
