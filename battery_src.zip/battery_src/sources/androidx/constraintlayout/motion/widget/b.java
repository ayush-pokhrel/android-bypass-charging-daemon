package androidx.constraintlayout.motion.widget;

import android.util.Pair;
import com.oplus.smartenginehelper.entity.ConstraintEntity;
import java.util.HashMap;

/* JADX INFO: compiled from: DesignTool.java */
/* JADX INFO: loaded from: classes.dex */
public class b {

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    static final HashMap<Pair<Integer, Integer>, String> f1283f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    static final HashMap<String, String> f1284g;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final MotionLayout f1285a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private String f1286b = null;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private String f1287c = null;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private int f1288d = -1;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private int f1289e = -1;

    static {
        HashMap<Pair<Integer, Integer>, String> map = new HashMap<>();
        f1283f = map;
        HashMap<String, String> map2 = new HashMap<>();
        f1284g = map2;
        map.put(Pair.create(4, 4), ConstraintEntity.BOTTOM_TO_BOTTOM);
        map.put(Pair.create(4, 3), ConstraintEntity.BOTTOM_TO_TOP);
        map.put(Pair.create(3, 4), ConstraintEntity.TOP_TO_BOTTOM);
        map.put(Pair.create(3, 3), ConstraintEntity.TOP_TO_TOP);
        map.put(Pair.create(6, 6), ConstraintEntity.START_TO_START);
        map.put(Pair.create(6, 7), ConstraintEntity.START_TO_END);
        map.put(Pair.create(7, 6), ConstraintEntity.END_TO_START);
        map.put(Pair.create(7, 7), ConstraintEntity.END_TO_END);
        map.put(Pair.create(1, 1), "layout_constraintLeft_toLeftOf");
        map.put(Pair.create(1, 2), "layout_constraintLeft_toRightOf");
        map.put(Pair.create(2, 2), "layout_constraintRight_toRightOf");
        map.put(Pair.create(2, 1), "layout_constraintRight_toLeftOf");
        map.put(Pair.create(5, 5), ConstraintEntity.BASELINE_TO_BASELINE);
        map2.put(ConstraintEntity.BOTTOM_TO_BOTTOM, "layout_marginBottom");
        map2.put(ConstraintEntity.BOTTOM_TO_TOP, "layout_marginBottom");
        map2.put(ConstraintEntity.TOP_TO_BOTTOM, "layout_marginTop");
        map2.put(ConstraintEntity.TOP_TO_TOP, "layout_marginTop");
        map2.put(ConstraintEntity.START_TO_START, "layout_marginStart");
        map2.put(ConstraintEntity.START_TO_END, "layout_marginStart");
        map2.put(ConstraintEntity.END_TO_START, "layout_marginEnd");
        map2.put(ConstraintEntity.END_TO_END, "layout_marginEnd");
        map2.put("layout_constraintLeft_toLeftOf", "layout_marginLeft");
        map2.put("layout_constraintLeft_toRightOf", "layout_marginLeft");
        map2.put("layout_constraintRight_toRightOf", "layout_marginRight");
        map2.put("layout_constraintRight_toLeftOf", "layout_marginRight");
    }

    public b(MotionLayout motionLayout) {
        this.f1285a = motionLayout;
    }
}
