package androidx.constraintlayout.motion.widget;

import android.util.Log;
import android.util.SparseArray;
import android.view.View;
import android.view.ViewGroup;
import androidx.constraintlayout.solver.widgets.ConstraintWidget;
import androidx.constraintlayout.widget.ConstraintAttribute;
import androidx.constraintlayout.widget.ConstraintLayout;
import com.oplus.sceneservice.sdk.dataprovider.bean.UserProfileInfo;
import com.oplus.smartenginehelper.entity.ViewEntity;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;

/* JADX INFO: compiled from: MotionController.java */
/* JADX INFO: loaded from: classes.dex */
public class n {
    private l[] A;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    View f1439a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    int f1440b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    String f1441c;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    private s.b[] f1447i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private s.b f1448j;

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    private int[] f1452n;

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    private double[] f1453o;

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    private double[] f1454p;

    /* JADX INFO: renamed from: q, reason: collision with root package name */
    private String[] f1455q;

    /* JADX INFO: renamed from: r, reason: collision with root package name */
    private int[] f1456r;

    /* JADX INFO: renamed from: x, reason: collision with root package name */
    private HashMap<String, s> f1462x;

    /* JADX INFO: renamed from: y, reason: collision with root package name */
    private HashMap<String, r> f1463y;

    /* JADX INFO: renamed from: z, reason: collision with root package name */
    private HashMap<String, g> f1464z;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private int f1442d = -1;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private p f1443e = new p();

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    private p f1444f = new p();

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    private m f1445g = new m();

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    private m f1446h = new m();

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    float f1449k = Float.NaN;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    float f1450l = 0.0f;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    float f1451m = 1.0f;

    /* JADX INFO: renamed from: s, reason: collision with root package name */
    private int f1457s = 4;

    /* JADX INFO: renamed from: t, reason: collision with root package name */
    private float[] f1458t = new float[4];

    /* JADX INFO: renamed from: u, reason: collision with root package name */
    private ArrayList<p> f1459u = new ArrayList<>();

    /* JADX INFO: renamed from: v, reason: collision with root package name */
    private float[] f1460v = new float[1];

    /* JADX INFO: renamed from: w, reason: collision with root package name */
    private ArrayList<c> f1461w = new ArrayList<>();
    private int B = c.f1290f;

    n(View view) {
        u(view);
    }

    private float f(float f10, float[] fArr) {
        float f11 = 0.0f;
        if (fArr != null) {
            fArr[0] = 1.0f;
        } else {
            float f12 = this.f1451m;
            if (f12 != 1.0d) {
                float f13 = this.f1450l;
                if (f10 < f13) {
                    f10 = 0.0f;
                }
                if (f10 > f13 && f10 < 1.0d) {
                    f10 = (f10 - f13) * f12;
                }
            }
        }
        s.c cVar = this.f1443e.f1466a;
        float f14 = Float.NaN;
        for (p pVar : this.f1459u) {
            s.c cVar2 = pVar.f1466a;
            if (cVar2 != null) {
                float f15 = pVar.f1468c;
                if (f15 < f10) {
                    cVar = cVar2;
                    f11 = f15;
                } else if (Float.isNaN(f14)) {
                    f14 = pVar.f1468c;
                }
            }
        }
        if (cVar == null) {
            return f10;
        }
        float f16 = (Float.isNaN(f14) ? 1.0f : f14) - f11;
        double d10 = (f10 - f11) / f16;
        float fA = f11 + (((float) cVar.a(d10)) * f16);
        if (fArr != null) {
            fArr[0] = (float) cVar.b(d10);
        }
        return fA;
    }

    private float m() {
        float[] fArr = new float[2];
        float f10 = 1.0f / 99;
        double d10 = UserProfileInfo.Constant.NA_LAT_LON;
        double d11 = 0.0d;
        int i10 = 0;
        float fHypot = 0.0f;
        while (i10 < 100) {
            float f11 = i10 * f10;
            double dA = f11;
            s.c cVar = this.f1443e.f1466a;
            float f12 = Float.NaN;
            float f13 = 0.0f;
            for (p pVar : this.f1459u) {
                s.c cVar2 = pVar.f1466a;
                float f14 = f10;
                if (cVar2 != null) {
                    float f15 = pVar.f1468c;
                    if (f15 < f11) {
                        f13 = f15;
                        cVar = cVar2;
                    } else if (Float.isNaN(f12)) {
                        f12 = pVar.f1468c;
                    }
                }
                f10 = f14;
            }
            float f16 = f10;
            if (cVar != null) {
                if (Float.isNaN(f12)) {
                    f12 = 1.0f;
                }
                float f17 = f12 - f13;
                dA = (((float) cVar.a((f11 - f13) / f17)) * f17) + f13;
            }
            this.f1447i[0].d(dA, this.f1453o);
            this.f1443e.f(this.f1452n, this.f1453o, fArr, 0);
            if (i10 > 0) {
                fHypot = (float) (((double) fHypot) + Math.hypot(d11 - ((double) fArr[1]), d10 - ((double) fArr[0])));
            }
            d10 = fArr[0];
            d11 = fArr[1];
            i10++;
            f10 = f16;
        }
        return fHypot;
    }

    private void n(p pVar) {
        int iBinarySearch = Collections.binarySearch(this.f1459u, pVar);
        if (iBinarySearch == 0) {
            Log.e("MotionController", " KeyPath positon \"" + pVar.f1469g + "\" outside of range");
        }
        this.f1459u.add((-iBinarySearch) - 1, pVar);
    }

    private void p(p pVar) {
        pVar.n((int) this.f1439a.getX(), (int) this.f1439a.getY(), this.f1439a.getWidth(), this.f1439a.getHeight());
    }

    void a(c cVar) {
        this.f1461w.add(cVar);
    }

    void b(ArrayList<c> arrayList) {
        this.f1461w.addAll(arrayList);
    }

    int c(float[] fArr, int[] iArr) {
        if (fArr == null) {
            return 0;
        }
        double[] dArrH = this.f1447i[0].h();
        if (iArr != null) {
            Iterator<p> it = this.f1459u.iterator();
            int i10 = 0;
            while (it.hasNext()) {
                iArr[i10] = it.next().f1478p;
                i10++;
            }
        }
        int i11 = 0;
        for (double d10 : dArrH) {
            this.f1447i[0].d(d10, this.f1453o);
            this.f1443e.f(this.f1452n, this.f1453o, fArr, i11);
            i11 += 2;
        }
        return i11 / 2;
    }

    void d(float[] fArr, int i10) {
        int i11 = i10;
        float f10 = 1.0f;
        float f11 = 1.0f / (i11 - 1);
        HashMap<String, r> map = this.f1463y;
        r rVar = map == null ? null : map.get(ViewEntity.TRANSLATION_X);
        HashMap<String, r> map2 = this.f1463y;
        r rVar2 = map2 == null ? null : map2.get(ViewEntity.TRANSLATION_Y);
        HashMap<String, g> map3 = this.f1464z;
        g gVar = map3 == null ? null : map3.get(ViewEntity.TRANSLATION_X);
        HashMap<String, g> map4 = this.f1464z;
        g gVar2 = map4 != null ? map4.get(ViewEntity.TRANSLATION_Y) : null;
        int i12 = 0;
        while (i12 < i11) {
            float f12 = i12 * f11;
            float f13 = this.f1451m;
            if (f13 != f10) {
                float f14 = this.f1450l;
                if (f12 < f14) {
                    f12 = 0.0f;
                }
                if (f12 > f14 && f12 < 1.0d) {
                    f12 = (f12 - f14) * f13;
                }
            }
            double dA = f12;
            s.c cVar = this.f1443e.f1466a;
            float f15 = Float.NaN;
            float f16 = 0.0f;
            for (p pVar : this.f1459u) {
                s.c cVar2 = pVar.f1466a;
                if (cVar2 != null) {
                    float f17 = pVar.f1468c;
                    if (f17 < f12) {
                        f16 = f17;
                        cVar = cVar2;
                    } else if (Float.isNaN(f15)) {
                        f15 = pVar.f1468c;
                    }
                }
            }
            if (cVar != null) {
                if (Float.isNaN(f15)) {
                    f15 = 1.0f;
                }
                float f18 = f15 - f16;
                dA = (((float) cVar.a((f12 - f16) / f18)) * f18) + f16;
            }
            this.f1447i[0].d(dA, this.f1453o);
            s.b bVar = this.f1448j;
            if (bVar != null) {
                double[] dArr = this.f1453o;
                if (dArr.length > 0) {
                    bVar.d(dA, dArr);
                }
            }
            int i13 = i12 * 2;
            this.f1443e.f(this.f1452n, this.f1453o, fArr, i13);
            if (gVar != null) {
                fArr[i13] = fArr[i13] + gVar.a(f12);
            } else if (rVar != null) {
                fArr[i13] = fArr[i13] + rVar.a(f12);
            }
            if (gVar2 != null) {
                int i14 = i13 + 1;
                fArr[i14] = fArr[i14] + gVar2.a(f12);
            } else if (rVar2 != null) {
                int i15 = i13 + 1;
                fArr[i15] = fArr[i15] + rVar2.a(f12);
            }
            i12++;
            i11 = i10;
            f10 = 1.0f;
        }
    }

    void e(float f10, float[] fArr, int i10) {
        this.f1447i[0].d(f(f10, null), this.f1453o);
        this.f1443e.i(this.f1452n, this.f1453o, fArr, i10);
    }

    void g(float f10, float f11, float f12, float[] fArr) {
        double[] dArr;
        float f13 = f(f10, this.f1460v);
        s.b[] bVarArr = this.f1447i;
        int i10 = 0;
        if (bVarArr == null) {
            p pVar = this.f1444f;
            float f14 = pVar.f1470h;
            p pVar2 = this.f1443e;
            float f15 = f14 - pVar2.f1470h;
            float f16 = pVar.f1471i - pVar2.f1471i;
            float f17 = (pVar.f1472j - pVar2.f1472j) + f15;
            float f18 = (pVar.f1473k - pVar2.f1473k) + f16;
            fArr[0] = (f15 * (1.0f - f11)) + (f17 * f11);
            fArr[1] = (f16 * (1.0f - f12)) + (f18 * f12);
            return;
        }
        double d10 = f13;
        bVarArr[0].g(d10, this.f1454p);
        this.f1447i[0].d(d10, this.f1453o);
        float f19 = this.f1460v[0];
        while (true) {
            dArr = this.f1454p;
            if (i10 >= dArr.length) {
                break;
            }
            dArr[i10] = dArr[i10] * ((double) f19);
            i10++;
        }
        s.b bVar = this.f1448j;
        if (bVar == null) {
            this.f1443e.o(f11, f12, fArr, this.f1452n, dArr, this.f1453o);
            return;
        }
        double[] dArr2 = this.f1453o;
        if (dArr2.length > 0) {
            bVar.d(d10, dArr2);
            this.f1448j.g(d10, this.f1454p);
            this.f1443e.o(f11, f12, fArr, this.f1452n, this.f1454p, this.f1453o);
        }
    }

    public int h() {
        int iMax = this.f1443e.f1467b;
        Iterator<p> it = this.f1459u.iterator();
        while (it.hasNext()) {
            iMax = Math.max(iMax, it.next().f1467b);
        }
        return Math.max(iMax, this.f1444f.f1467b);
    }

    float i() {
        return this.f1444f.f1470h;
    }

    float j() {
        return this.f1444f.f1471i;
    }

    p k(int i10) {
        return this.f1459u.get(i10);
    }

    void l(float f10, int i10, int i11, float f11, float f12, float[] fArr) {
        float f13 = f(f10, this.f1460v);
        HashMap<String, r> map = this.f1463y;
        r rVar = map == null ? null : map.get(ViewEntity.TRANSLATION_X);
        HashMap<String, r> map2 = this.f1463y;
        r rVar2 = map2 == null ? null : map2.get(ViewEntity.TRANSLATION_Y);
        HashMap<String, r> map3 = this.f1463y;
        r rVar3 = map3 == null ? null : map3.get(ViewEntity.ROTATION);
        HashMap<String, r> map4 = this.f1463y;
        r rVar4 = map4 == null ? null : map4.get(ViewEntity.SCALE_X);
        HashMap<String, r> map5 = this.f1463y;
        r rVar5 = map5 == null ? null : map5.get(ViewEntity.SCALE_Y);
        HashMap<String, g> map6 = this.f1464z;
        g gVar = map6 == null ? null : map6.get(ViewEntity.TRANSLATION_X);
        HashMap<String, g> map7 = this.f1464z;
        g gVar2 = map7 == null ? null : map7.get(ViewEntity.TRANSLATION_Y);
        HashMap<String, g> map8 = this.f1464z;
        g gVar3 = map8 == null ? null : map8.get(ViewEntity.ROTATION);
        HashMap<String, g> map9 = this.f1464z;
        g gVar4 = map9 == null ? null : map9.get(ViewEntity.SCALE_X);
        HashMap<String, g> map10 = this.f1464z;
        g gVar5 = map10 != null ? map10.get(ViewEntity.SCALE_Y) : null;
        s.h hVar = new s.h();
        hVar.b();
        hVar.d(rVar3, f13);
        hVar.h(rVar, rVar2, f13);
        hVar.f(rVar4, rVar5, f13);
        hVar.c(gVar3, f13);
        hVar.g(gVar, gVar2, f13);
        hVar.e(gVar4, gVar5, f13);
        s.b bVar = this.f1448j;
        if (bVar != null) {
            double[] dArr = this.f1453o;
            if (dArr.length > 0) {
                double d10 = f13;
                bVar.d(d10, dArr);
                this.f1448j.g(d10, this.f1454p);
                this.f1443e.o(f11, f12, fArr, this.f1452n, this.f1454p, this.f1453o);
            }
            hVar.a(f11, f12, i10, i11, fArr);
            return;
        }
        int i12 = 0;
        if (this.f1447i == null) {
            p pVar = this.f1444f;
            float f14 = pVar.f1470h;
            p pVar2 = this.f1443e;
            float f15 = f14 - pVar2.f1470h;
            g gVar6 = gVar5;
            float f16 = pVar.f1471i - pVar2.f1471i;
            g gVar7 = gVar4;
            float f17 = (pVar.f1472j - pVar2.f1472j) + f15;
            float f18 = (pVar.f1473k - pVar2.f1473k) + f16;
            fArr[0] = (f15 * (1.0f - f11)) + (f17 * f11);
            fArr[1] = (f16 * (1.0f - f12)) + (f18 * f12);
            hVar.b();
            hVar.d(rVar3, f13);
            hVar.h(rVar, rVar2, f13);
            hVar.f(rVar4, rVar5, f13);
            hVar.c(gVar3, f13);
            hVar.g(gVar, gVar2, f13);
            hVar.e(gVar7, gVar6, f13);
            hVar.a(f11, f12, i10, i11, fArr);
            return;
        }
        double dF = f(f13, this.f1460v);
        this.f1447i[0].g(dF, this.f1454p);
        this.f1447i[0].d(dF, this.f1453o);
        float f19 = this.f1460v[0];
        while (true) {
            double[] dArr2 = this.f1454p;
            if (i12 >= dArr2.length) {
                this.f1443e.o(f11, f12, fArr, this.f1452n, dArr2, this.f1453o);
                hVar.a(f11, f12, i10, i11, fArr);
                return;
            } else {
                dArr2[i12] = dArr2[i12] * ((double) f19);
                i12++;
            }
        }
    }

    boolean o(View view, float f10, long j10, e eVar) {
        s.d dVar;
        boolean zJ;
        float f11 = f(f10, null);
        HashMap<String, r> map = this.f1463y;
        if (map != null) {
            Iterator<r> it = map.values().iterator();
            while (it.hasNext()) {
                it.next().f(view, f11);
            }
        }
        HashMap<String, s> map2 = this.f1462x;
        if (map2 != null) {
            dVar = null;
            boolean zF = false;
            for (s sVar : map2.values()) {
                if (sVar instanceof s.d) {
                    dVar = (s.d) sVar;
                } else {
                    zF |= sVar.f(view, f11, j10, eVar);
                }
            }
            zJ = zF;
        } else {
            dVar = null;
            zJ = false;
        }
        s.b[] bVarArr = this.f1447i;
        if (bVarArr != null) {
            double d10 = f11;
            bVarArr[0].d(d10, this.f1453o);
            this.f1447i[0].g(d10, this.f1454p);
            s.b bVar = this.f1448j;
            if (bVar != null) {
                double[] dArr = this.f1453o;
                if (dArr.length > 0) {
                    bVar.d(d10, dArr);
                    this.f1448j.g(d10, this.f1454p);
                }
            }
            this.f1443e.p(view, this.f1452n, this.f1453o, this.f1454p, null);
            HashMap<String, r> map3 = this.f1463y;
            if (map3 != null) {
                for (r rVar : map3.values()) {
                    if (rVar instanceof r.d) {
                        double[] dArr2 = this.f1454p;
                        ((r.d) rVar).i(view, f11, dArr2[0], dArr2[1]);
                    }
                }
            }
            if (dVar != null) {
                double[] dArr3 = this.f1454p;
                zJ |= dVar.j(view, eVar, f11, j10, dArr3[0], dArr3[1]);
            }
            int i10 = 1;
            while (true) {
                s.b[] bVarArr2 = this.f1447i;
                if (i10 >= bVarArr2.length) {
                    break;
                }
                bVarArr2[i10].e(d10, this.f1458t);
                this.f1443e.f1477o.get(this.f1455q[i10 - 1]).i(view, this.f1458t);
                i10++;
            }
            m mVar = this.f1445g;
            if (mVar.f1417b == 0) {
                if (f11 <= 0.0f) {
                    view.setVisibility(mVar.f1418c);
                } else if (f11 >= 1.0f) {
                    view.setVisibility(this.f1446h.f1418c);
                } else if (this.f1446h.f1418c != mVar.f1418c) {
                    view.setVisibility(0);
                }
            }
            if (this.A != null) {
                int i11 = 0;
                while (true) {
                    l[] lVarArr = this.A;
                    if (i11 >= lVarArr.length) {
                        break;
                    }
                    lVarArr[i11].r(f11, view);
                    i11++;
                }
            }
        } else {
            p pVar = this.f1443e;
            float f12 = pVar.f1470h;
            p pVar2 = this.f1444f;
            float f13 = f12 + ((pVar2.f1470h - f12) * f11);
            float f14 = pVar.f1471i;
            float f15 = f14 + ((pVar2.f1471i - f14) * f11);
            float f16 = pVar.f1472j;
            float f17 = pVar2.f1472j;
            float f18 = pVar.f1473k;
            float f19 = pVar2.f1473k;
            float f20 = f13 + 0.5f;
            int i12 = (int) f20;
            float f21 = f15 + 0.5f;
            int i13 = (int) f21;
            int i14 = (int) (f20 + ((f17 - f16) * f11) + f16);
            int i15 = (int) (f21 + ((f19 - f18) * f11) + f18);
            int i16 = i14 - i12;
            int i17 = i15 - i13;
            if (f17 != f16 || f19 != f18) {
                view.measure(View.MeasureSpec.makeMeasureSpec(i16, 1073741824), View.MeasureSpec.makeMeasureSpec(i17, 1073741824));
            }
            view.layout(i12, i13, i14, i15);
        }
        HashMap<String, g> map4 = this.f1464z;
        if (map4 != null) {
            for (g gVar : map4.values()) {
                if (gVar instanceof g.f) {
                    double[] dArr4 = this.f1454p;
                    ((g.f) gVar).j(view, f11, dArr4[0], dArr4[1]);
                } else {
                    gVar.f(view, f11);
                }
            }
        }
        return zJ;
    }

    void q(ConstraintWidget constraintWidget, androidx.constraintlayout.widget.b bVar) {
        p pVar = this.f1444f;
        pVar.f1468c = 1.0f;
        pVar.f1469g = 1.0f;
        p(pVar);
        this.f1444f.n(constraintWidget.R(), constraintWidget.S(), constraintWidget.Q(), constraintWidget.w());
        this.f1444f.a(bVar.s(this.f1440b));
        this.f1446h.i(constraintWidget, bVar, this.f1440b);
    }

    public void r(int i10) {
        this.B = i10;
    }

    void s(View view) {
        p pVar = this.f1443e;
        pVar.f1468c = 0.0f;
        pVar.f1469g = 0.0f;
        pVar.n(view.getX(), view.getY(), view.getWidth(), view.getHeight());
        this.f1445g.h(view);
    }

    void t(ConstraintWidget constraintWidget, androidx.constraintlayout.widget.b bVar) {
        p pVar = this.f1443e;
        pVar.f1468c = 0.0f;
        pVar.f1469g = 0.0f;
        p(pVar);
        this.f1443e.n(constraintWidget.R(), constraintWidget.S(), constraintWidget.Q(), constraintWidget.w());
        androidx.constraintlayout.widget.b.a aVarS = bVar.s(this.f1440b);
        this.f1443e.a(aVarS);
        this.f1449k = aVarS.f2011c.f2058f;
        this.f1445g.i(constraintWidget, bVar, this.f1440b);
    }

    public String toString() {
        return " start: x: " + this.f1443e.f1470h + " y: " + this.f1443e.f1471i + " end: x: " + this.f1444f.f1470h + " y: " + this.f1444f.f1471i;
    }

    public void u(View view) {
        this.f1439a = view;
        this.f1440b = view.getId();
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        if (layoutParams instanceof ConstraintLayout.LayoutParams) {
            this.f1441c = ((ConstraintLayout.LayoutParams) layoutParams).getConstraintTag();
        }
    }

    public void v(int i10, int i11, float f10, long j10) {
        ArrayList arrayList;
        String[] strArr;
        s sVarD;
        ConstraintAttribute constraintAttribute;
        r rVarD;
        ConstraintAttribute constraintAttribute2;
        new HashSet();
        HashSet<String> hashSet = new HashSet<>();
        HashSet<String> hashSet2 = new HashSet<>();
        HashSet<String> hashSet3 = new HashSet<>();
        HashMap<String, Integer> map = new HashMap<>();
        int i12 = this.B;
        if (i12 != c.f1290f) {
            this.f1443e.f1476n = i12;
        }
        this.f1445g.f(this.f1446h, hashSet2);
        ArrayList<c> arrayList2 = this.f1461w;
        if (arrayList2 != null) {
            arrayList = null;
            for (c cVar : arrayList2) {
                if (cVar instanceof i) {
                    i iVar = (i) cVar;
                    n(new p(i10, i11, iVar, this.f1443e, this.f1444f));
                    int i13 = iVar.f1376g;
                    if (i13 != c.f1290f) {
                        this.f1442d = i13;
                    }
                } else if (cVar instanceof f) {
                    cVar.b(hashSet3);
                } else if (cVar instanceof k) {
                    cVar.b(hashSet);
                } else if (cVar instanceof l) {
                    if (arrayList == null) {
                        arrayList = new ArrayList();
                    }
                    arrayList.add((l) cVar);
                } else {
                    cVar.e(map);
                    cVar.b(hashSet2);
                }
            }
        } else {
            arrayList = null;
        }
        if (arrayList != null) {
            this.A = (l[]) arrayList.toArray(new l[0]);
        }
        char c10 = 1;
        if (!hashSet2.isEmpty()) {
            this.f1463y = new HashMap<>();
            for (String str : hashSet2) {
                if (str.startsWith("CUSTOM,")) {
                    SparseArray sparseArray = new SparseArray();
                    String str2 = str.split(",")[1];
                    for (c cVar2 : this.f1461w) {
                        HashMap<String, ConstraintAttribute> map2 = cVar2.f1295e;
                        if (map2 != null && (constraintAttribute2 = map2.get(str2)) != null) {
                            sparseArray.append(cVar2.f1291a, constraintAttribute2);
                        }
                    }
                    rVarD = r.c(str, sparseArray);
                } else {
                    rVarD = r.d(str);
                }
                if (rVarD != null) {
                    rVarD.g(str);
                    this.f1463y.put(str, rVarD);
                }
            }
            ArrayList<c> arrayList3 = this.f1461w;
            if (arrayList3 != null) {
                for (c cVar3 : arrayList3) {
                    if (cVar3 instanceof d) {
                        cVar3.a(this.f1463y);
                    }
                }
            }
            this.f1445g.a(this.f1463y, 0);
            this.f1446h.a(this.f1463y, 100);
            for (String str3 : this.f1463y.keySet()) {
                this.f1463y.get(str3).h(map.containsKey(str3) ? map.get(str3).intValue() : 0);
            }
        }
        if (!hashSet.isEmpty()) {
            if (this.f1462x == null) {
                this.f1462x = new HashMap<>();
            }
            for (String str4 : hashSet) {
                if (!this.f1462x.containsKey(str4)) {
                    if (str4.startsWith("CUSTOM,")) {
                        SparseArray sparseArray2 = new SparseArray();
                        String str5 = str4.split(",")[1];
                        for (c cVar4 : this.f1461w) {
                            HashMap<String, ConstraintAttribute> map3 = cVar4.f1295e;
                            if (map3 != null && (constraintAttribute = map3.get(str5)) != null) {
                                sparseArray2.append(cVar4.f1291a, constraintAttribute);
                            }
                        }
                        sVarD = s.c(str4, sparseArray2);
                    } else {
                        sVarD = s.d(str4, j10);
                    }
                    if (sVarD != null) {
                        sVarD.h(str4);
                        this.f1462x.put(str4, sVarD);
                    }
                }
            }
            ArrayList<c> arrayList4 = this.f1461w;
            if (arrayList4 != null) {
                for (c cVar5 : arrayList4) {
                    if (cVar5 instanceof k) {
                        ((k) cVar5).M(this.f1462x);
                    }
                }
            }
            for (String str6 : this.f1462x.keySet()) {
                this.f1462x.get(str6).i(map.containsKey(str6) ? map.get(str6).intValue() : 0);
            }
        }
        int size = this.f1459u.size();
        int i14 = size + 2;
        p[] pVarArr = new p[i14];
        pVarArr[0] = this.f1443e;
        pVarArr[size + 1] = this.f1444f;
        if (this.f1459u.size() > 0 && this.f1442d == -1) {
            this.f1442d = 0;
        }
        Iterator<p> it = this.f1459u.iterator();
        int i15 = 1;
        while (it.hasNext()) {
            pVarArr[i15] = it.next();
            i15++;
        }
        HashSet hashSet4 = new HashSet();
        for (String str7 : this.f1444f.f1477o.keySet()) {
            if (this.f1443e.f1477o.containsKey(str7)) {
                if (!hashSet2.contains("CUSTOM," + str7)) {
                    hashSet4.add(str7);
                }
            }
        }
        String[] strArr2 = (String[]) hashSet4.toArray(new String[0]);
        this.f1455q = strArr2;
        this.f1456r = new int[strArr2.length];
        int i16 = 0;
        while (true) {
            strArr = this.f1455q;
            if (i16 >= strArr.length) {
                break;
            }
            String str8 = strArr[i16];
            this.f1456r[i16] = 0;
            for (int i17 = 0; i17 < i14; i17++) {
                if (pVarArr[i17].f1477o.containsKey(str8)) {
                    int[] iArr = this.f1456r;
                    iArr[i16] = iArr[i16] + pVarArr[i17].f1477o.get(str8).f();
                    break;
                }
            }
            i16++;
        }
        boolean z10 = pVarArr[0].f1476n != c.f1290f;
        int length = 18 + strArr.length;
        boolean[] zArr = new boolean[length];
        for (int i18 = 1; i18 < i14; i18++) {
            pVarArr[i18].d(pVarArr[i18 - 1], zArr, this.f1455q, z10);
        }
        int i19 = 0;
        for (int i20 = 1; i20 < length; i20++) {
            if (zArr[i20]) {
                i19++;
            }
        }
        int[] iArr2 = new int[i19];
        this.f1452n = iArr2;
        this.f1453o = new double[iArr2.length];
        this.f1454p = new double[iArr2.length];
        int i21 = 0;
        for (int i22 = 1; i22 < length; i22++) {
            if (zArr[i22]) {
                this.f1452n[i21] = i22;
                i21++;
            }
        }
        int i23 = 2;
        double[][] dArr = (double[][]) Array.newInstance((Class<?>) Double.TYPE, i14, this.f1452n.length);
        double[] dArr2 = new double[i14];
        for (int i24 = 0; i24 < i14; i24++) {
            pVarArr[i24].e(dArr[i24], this.f1452n);
            dArr2[i24] = pVarArr[i24].f1468c;
        }
        int i25 = 0;
        while (true) {
            int[] iArr3 = this.f1452n;
            if (i25 >= iArr3.length) {
                break;
            }
            if (iArr3[i25] < p.f1465s.length) {
                String str9 = p.f1465s[this.f1452n[i25]] + " [";
                for (int i26 = 0; i26 < i14; i26++) {
                    str9 = str9 + dArr[i26][i25];
                }
            }
            i25++;
        }
        this.f1447i = new s.b[this.f1455q.length + 1];
        int i27 = 0;
        while (true) {
            String[] strArr3 = this.f1455q;
            if (i27 >= strArr3.length) {
                break;
            }
            String str10 = strArr3[i27];
            int i28 = 0;
            int i29 = 0;
            double[] dArr3 = null;
            double[][] dArr4 = null;
            while (i28 < i14) {
                if (pVarArr[i28].j(str10)) {
                    if (dArr4 == null) {
                        dArr3 = new double[i14];
                        int[] iArr4 = new int[i23];
                        iArr4[c10] = pVarArr[i28].h(str10);
                        iArr4[0] = i14;
                        dArr4 = (double[][]) Array.newInstance((Class<?>) Double.TYPE, iArr4);
                    }
                    p pVar = pVarArr[i28];
                    dArr3[i29] = pVar.f1468c;
                    pVar.g(str10, dArr4[i29], 0);
                    i29++;
                }
                i28++;
                hashSet3 = hashSet3;
                i23 = 2;
                c10 = 1;
            }
            i27++;
            this.f1447i[i27] = s.b.a(this.f1442d, Arrays.copyOf(dArr3, i29), (double[][]) Arrays.copyOf(dArr4, i29));
            hashSet3 = hashSet3;
            i23 = 2;
            c10 = 1;
        }
        HashSet<String> hashSet5 = hashSet3;
        this.f1447i[0] = s.b.a(this.f1442d, dArr2, dArr);
        if (pVarArr[0].f1476n != c.f1290f) {
            int[] iArr5 = new int[i14];
            double[] dArr5 = new double[i14];
            double[][] dArr6 = (double[][]) Array.newInstance((Class<?>) Double.TYPE, i14, 2);
            for (int i30 = 0; i30 < i14; i30++) {
                p pVar2 = pVarArr[i30];
                iArr5[i30] = pVar2.f1476n;
                dArr5[i30] = pVar2.f1468c;
                double[] dArr7 = dArr6[i30];
                dArr7[0] = pVar2.f1470h;
                dArr7[1] = pVar2.f1471i;
            }
            this.f1448j = s.b.b(iArr5, dArr5, dArr6);
        }
        this.f1464z = new HashMap<>();
        if (this.f1461w != null) {
            float fM = Float.NaN;
            for (String str11 : hashSet5) {
                g gVarC = g.c(str11);
                if (gVarC != null) {
                    if (gVarC.i() && Float.isNaN(fM)) {
                        fM = m();
                    }
                    gVarC.g(str11);
                    this.f1464z.put(str11, gVarC);
                }
            }
            for (c cVar6 : this.f1461w) {
                if (cVar6 instanceof f) {
                    ((f) cVar6).O(this.f1464z);
                }
            }
            Iterator<g> it2 = this.f1464z.values().iterator();
            while (it2.hasNext()) {
                it2.next().h(fM);
            }
        }
    }
}
