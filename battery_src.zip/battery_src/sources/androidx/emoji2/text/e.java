package androidx.emoji2.text;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.view.KeyEvent;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Set;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/* JADX INFO: compiled from: EmojiCompat.java */
/* JADX INFO: loaded from: classes.dex */
public class e {

    /* JADX INFO: renamed from: n, reason: collision with root package name */
    private static final Object f2561n = new Object();

    /* JADX INFO: renamed from: o, reason: collision with root package name */
    private static final Object f2562o = new Object();

    /* JADX INFO: renamed from: p, reason: collision with root package name */
    private static volatile e f2563p;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private final Set<AbstractC0023e> f2565b;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private final b f2568e;

    /* JADX INFO: renamed from: f, reason: collision with root package name */
    final g f2569f;

    /* JADX INFO: renamed from: g, reason: collision with root package name */
    final boolean f2570g;

    /* JADX INFO: renamed from: h, reason: collision with root package name */
    final boolean f2571h;

    /* JADX INFO: renamed from: i, reason: collision with root package name */
    final int[] f2572i;

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private final boolean f2573j;

    /* JADX INFO: renamed from: k, reason: collision with root package name */
    private final int f2574k;

    /* JADX INFO: renamed from: l, reason: collision with root package name */
    private final int f2575l;

    /* JADX INFO: renamed from: m, reason: collision with root package name */
    private final d f2576m;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final ReadWriteLock f2564a = new ReentrantReadWriteLock();

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private volatile int f2566c = 3;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private final Handler f2567d = new Handler(Looper.getMainLooper());

    /* JADX INFO: compiled from: EmojiCompat.java */
    private static final class a extends b {

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private volatile androidx.emoji2.text.h f2577b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        private volatile m f2578c;

        /* JADX INFO: renamed from: androidx.emoji2.text.e$a$a, reason: collision with other inner class name */
        /* JADX INFO: compiled from: EmojiCompat.java */
        class C0022a extends h {
            C0022a() {
            }

            @Override // androidx.emoji2.text.e.h
            public void a(Throwable th) {
                a.this.f2580a.m(th);
            }

            @Override // androidx.emoji2.text.e.h
            public void b(m mVar) {
                a.this.d(mVar);
            }
        }

        a(e eVar) {
            super(eVar);
        }

        @Override // androidx.emoji2.text.e.b
        void a() {
            try {
                this.f2580a.f2569f.a(new C0022a());
            } catch (Throwable th) {
                this.f2580a.m(th);
            }
        }

        @Override // androidx.emoji2.text.e.b
        CharSequence b(CharSequence charSequence, int i10, int i11, int i12, boolean z10) {
            return this.f2577b.h(charSequence, i10, i11, i12, z10);
        }

        @Override // androidx.emoji2.text.e.b
        void c(EditorInfo editorInfo) {
            editorInfo.extras.putInt("android.support.text.emoji.emojiCompat_metadataVersion", this.f2578c.e());
            editorInfo.extras.putBoolean("android.support.text.emoji.emojiCompat_replaceAll", this.f2580a.f2570g);
        }

        void d(m mVar) {
            if (mVar == null) {
                this.f2580a.m(new IllegalArgumentException("metadataRepo cannot be null"));
                return;
            }
            this.f2578c = mVar;
            m mVar2 = this.f2578c;
            i iVar = new i();
            d dVar = this.f2580a.f2576m;
            e eVar = this.f2580a;
            this.f2577b = new androidx.emoji2.text.h(mVar2, iVar, dVar, eVar.f2571h, eVar.f2572i);
            this.f2580a.n();
        }
    }

    /* JADX INFO: compiled from: EmojiCompat.java */
    private static class b {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        final e f2580a;

        b(e eVar) {
            this.f2580a = eVar;
        }

        void a() {
            throw null;
        }

        CharSequence b(CharSequence charSequence, int i10, int i11, int i12, boolean z10) {
            throw null;
        }

        void c(EditorInfo editorInfo) {
            throw null;
        }
    }

    /* JADX INFO: compiled from: EmojiCompat.java */
    public static abstract class c {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        final g f2581a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        boolean f2582b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        boolean f2583c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        int[] f2584d;

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        Set<AbstractC0023e> f2585e;

        /* JADX INFO: renamed from: f, reason: collision with root package name */
        boolean f2586f;

        /* JADX INFO: renamed from: g, reason: collision with root package name */
        int f2587g = -16711936;

        /* JADX INFO: renamed from: h, reason: collision with root package name */
        int f2588h = 0;

        /* JADX INFO: renamed from: i, reason: collision with root package name */
        d f2589i = new androidx.emoji2.text.d();

        protected c(g gVar) {
            a0.h.f(gVar, "metadataLoader cannot be null.");
            this.f2581a = gVar;
        }

        protected final g a() {
            return this.f2581a;
        }

        public c b(int i10) {
            this.f2588h = i10;
            return this;
        }
    }

    /* JADX INFO: compiled from: EmojiCompat.java */
    public interface d {
        boolean a(CharSequence charSequence, int i10, int i11, int i12);
    }

    /* JADX INFO: compiled from: EmojiCompat.java */
    private static class f implements Runnable {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private final List<AbstractC0023e> f2590a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private final Throwable f2591b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        private final int f2592c;

        f(AbstractC0023e abstractC0023e, int i10) {
            this(Arrays.asList((AbstractC0023e) a0.h.f(abstractC0023e, "initCallback cannot be null")), i10, null);
        }

        @Override // java.lang.Runnable
        public void run() {
            int size = this.f2590a.size();
            int i10 = 0;
            if (this.f2592c != 1) {
                while (i10 < size) {
                    this.f2590a.get(i10).a(this.f2591b);
                    i10++;
                }
            } else {
                while (i10 < size) {
                    this.f2590a.get(i10).b();
                    i10++;
                }
            }
        }

        f(Collection<AbstractC0023e> collection, int i10) {
            this(collection, i10, null);
        }

        f(Collection<AbstractC0023e> collection, int i10, Throwable th) {
            a0.h.f(collection, "initCallbacks cannot be null");
            this.f2590a = new ArrayList(collection);
            this.f2592c = i10;
            this.f2591b = th;
        }
    }

    /* JADX INFO: compiled from: EmojiCompat.java */
    public interface g {
        void a(h hVar);
    }

    /* JADX INFO: compiled from: EmojiCompat.java */
    public static abstract class h {
        public abstract void a(Throwable th);

        public abstract void b(m mVar);
    }

    /* JADX INFO: compiled from: EmojiCompat.java */
    static class i {
        i() {
        }

        androidx.emoji2.text.i a(androidx.emoji2.text.g gVar) {
            return new o(gVar);
        }
    }

    private e(c cVar) {
        this.f2570g = cVar.f2582b;
        this.f2571h = cVar.f2583c;
        this.f2572i = cVar.f2584d;
        this.f2573j = cVar.f2586f;
        this.f2574k = cVar.f2587g;
        this.f2569f = cVar.f2581a;
        this.f2575l = cVar.f2588h;
        this.f2576m = cVar.f2589i;
        r.b bVar = new r.b();
        this.f2565b = bVar;
        Set<AbstractC0023e> set = cVar.f2585e;
        if (set != null && !set.isEmpty()) {
            bVar.addAll(cVar.f2585e);
        }
        this.f2568e = new a(this);
        l();
    }

    public static e b() {
        e eVar;
        synchronized (f2561n) {
            eVar = f2563p;
            a0.h.g(eVar != null, "EmojiCompat is not initialized.\n\nYou must initialize EmojiCompat prior to referencing the EmojiCompat instance.\n\nThe most likely cause of this error is disabling the EmojiCompatInitializer\neither explicitly in AndroidManifest.xml, or by including\nandroidx.emoji2:emoji2-bundled.\n\nAutomatic initialization is typically performed by EmojiCompatInitializer. If\nyou are not expecting to initialize EmojiCompat manually in your application,\nplease check to ensure it has not been removed from your APK's manifest. You can\ndo this in Android Studio using Build > Analyze APK.\n\nIn the APK Analyzer, ensure that the startup entry for\nEmojiCompatInitializer and InitializationProvider is present in\n AndroidManifest.xml. If it is missing or contains tools:node=\"remove\", and you\nintend to use automatic configuration, verify:\n\n  1. Your application does not include emoji2-bundled\n  2. All modules do not contain an exclusion manifest rule for\n     EmojiCompatInitializer or InitializationProvider. For more information\n     about manifest exclusions see the documentation for the androidx startup\n     library.\n\nIf you intend to use emoji2-bundled, please call EmojiCompat.init. You can\nlearn more in the documentation for BundledEmojiCompatConfig.\n\nIf you intended to perform manual configuration, it is recommended that you call\nEmojiCompat.init immediately on application startup.\n\nIf you still cannot resolve this issue, please open a bug with your specific\nconfiguration to help improve error message.");
        }
        return eVar;
    }

    public static boolean e(InputConnection inputConnection, Editable editable, int i10, int i11, boolean z10) {
        return androidx.emoji2.text.h.c(inputConnection, editable, i10, i11, z10);
    }

    public static boolean f(Editable editable, int i10, KeyEvent keyEvent) {
        return androidx.emoji2.text.h.d(editable, i10, keyEvent);
    }

    public static e g(c cVar) {
        e eVar = f2563p;
        if (eVar == null) {
            synchronized (f2561n) {
                try {
                    eVar = f2563p;
                    if (eVar == null) {
                        eVar = new e(cVar);
                        f2563p = eVar;
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
        }
        return eVar;
    }

    public static boolean h() {
        return f2563p != null;
    }

    private boolean j() {
        return d() == 1;
    }

    private void l() {
        this.f2564a.writeLock().lock();
        try {
            if (this.f2575l == 0) {
                this.f2566c = 0;
            }
            this.f2564a.writeLock().unlock();
            if (d() == 0) {
                this.f2568e.a();
            }
        } catch (Throwable th) {
            this.f2564a.writeLock().unlock();
            throw th;
        }
    }

    public int c() {
        return this.f2574k;
    }

    public int d() {
        this.f2564a.readLock().lock();
        try {
            return this.f2566c;
        } finally {
            this.f2564a.readLock().unlock();
        }
    }

    public boolean i() {
        return this.f2573j;
    }

    public void k() {
        a0.h.g(this.f2575l == 1, "Set metadataLoadStrategy to LOAD_STRATEGY_MANUAL to execute manual loading");
        if (j()) {
            return;
        }
        this.f2564a.writeLock().lock();
        try {
            if (this.f2566c == 0) {
                this.f2564a.writeLock().unlock();
                return;
            }
            this.f2566c = 0;
            this.f2564a.writeLock().unlock();
            this.f2568e.a();
        } catch (Throwable th) {
            this.f2564a.writeLock().unlock();
            throw th;
        }
    }

    void m(Throwable th) {
        ArrayList arrayList = new ArrayList();
        this.f2564a.writeLock().lock();
        try {
            this.f2566c = 2;
            arrayList.addAll(this.f2565b);
            this.f2565b.clear();
            this.f2564a.writeLock().unlock();
            this.f2567d.post(new f(arrayList, this.f2566c, th));
        } catch (Throwable th2) {
            this.f2564a.writeLock().unlock();
            throw th2;
        }
    }

    void n() {
        ArrayList arrayList = new ArrayList();
        this.f2564a.writeLock().lock();
        try {
            this.f2566c = 1;
            arrayList.addAll(this.f2565b);
            this.f2565b.clear();
            this.f2564a.writeLock().unlock();
            this.f2567d.post(new f(arrayList, this.f2566c));
        } catch (Throwable th) {
            this.f2564a.writeLock().unlock();
            throw th;
        }
    }

    public CharSequence o(CharSequence charSequence) {
        return p(charSequence, 0, charSequence == null ? 0 : charSequence.length());
    }

    public CharSequence p(CharSequence charSequence, int i10, int i11) {
        return q(charSequence, i10, i11, Integer.MAX_VALUE);
    }

    public CharSequence q(CharSequence charSequence, int i10, int i11, int i12) {
        return r(charSequence, i10, i11, i12, 0);
    }

    public CharSequence r(CharSequence charSequence, int i10, int i11, int i12, int i13) {
        boolean z10;
        a0.h.g(j(), "Not initialized yet");
        a0.h.d(i10, "start cannot be negative");
        a0.h.d(i11, "end cannot be negative");
        a0.h.d(i12, "maxEmojiCount cannot be negative");
        a0.h.b(i10 <= i11, "start should be <= than end");
        if (charSequence == null) {
            return null;
        }
        a0.h.b(i10 <= charSequence.length(), "start should be < than charSequence length");
        a0.h.b(i11 <= charSequence.length(), "end should be < than charSequence length");
        if (charSequence.length() == 0 || i10 == i11) {
            return charSequence;
        }
        if (i13 != 1) {
            z10 = i13 != 2 ? this.f2570g : false;
        } else {
            z10 = true;
        }
        return this.f2568e.b(charSequence, i10, i11, i12, z10);
    }

    public void s(AbstractC0023e abstractC0023e) {
        a0.h.f(abstractC0023e, "initCallback cannot be null");
        this.f2564a.writeLock().lock();
        try {
            if (this.f2566c == 1 || this.f2566c == 2) {
                this.f2567d.post(new f(abstractC0023e, this.f2566c));
            } else {
                this.f2565b.add(abstractC0023e);
            }
        } finally {
            this.f2564a.writeLock().unlock();
        }
    }

    public void t(AbstractC0023e abstractC0023e) {
        a0.h.f(abstractC0023e, "initCallback cannot be null");
        this.f2564a.writeLock().lock();
        try {
            this.f2565b.remove(abstractC0023e);
        } finally {
            this.f2564a.writeLock().unlock();
        }
    }

    public void u(EditorInfo editorInfo) {
        if (!j() || editorInfo == null) {
            return;
        }
        if (editorInfo.extras == null) {
            editorInfo.extras = new Bundle();
        }
        this.f2568e.c(editorInfo);
    }

    /* JADX INFO: renamed from: androidx.emoji2.text.e$e, reason: collision with other inner class name */
    /* JADX INFO: compiled from: EmojiCompat.java */
    public static abstract class AbstractC0023e {
        public void b() {
        }

        public void a(Throwable th) {
        }
    }
}
