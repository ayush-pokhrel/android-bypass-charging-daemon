package androidx.emoji2.text;

import android.graphics.Typeface;
import android.util.SparseArray;
import java.io.IOException;
import java.nio.ByteBuffer;

/* JADX INFO: compiled from: MetadataRepo.java */
/* JADX INFO: loaded from: classes.dex */
public final class m {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final h0.b f2633a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private final char[] f2634b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private final a f2635c = new a(1024);

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private final Typeface f2636d;

    /* JADX INFO: compiled from: MetadataRepo.java */
    static class a {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private final SparseArray<a> f2637a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private g f2638b;

        private a() {
            this(1);
        }

        a a(int i10) {
            SparseArray<a> sparseArray = this.f2637a;
            if (sparseArray == null) {
                return null;
            }
            return sparseArray.get(i10);
        }

        final g b() {
            return this.f2638b;
        }

        void c(g gVar, int i10, int i11) {
            a aVarA = a(gVar.b(i10));
            if (aVarA == null) {
                aVarA = new a();
                this.f2637a.put(gVar.b(i10), aVarA);
            }
            if (i11 > i10) {
                aVarA.c(gVar, i10 + 1, i11);
            } else {
                aVarA.f2638b = gVar;
            }
        }

        a(int i10) {
            this.f2637a = new SparseArray<>(i10);
        }
    }

    private m(Typeface typeface, h0.b bVar) {
        this.f2636d = typeface;
        this.f2633a = bVar;
        this.f2634b = new char[bVar.k() * 2];
        a(bVar);
    }

    private void a(h0.b bVar) {
        int iK = bVar.k();
        for (int i10 = 0; i10 < iK; i10++) {
            g gVar = new g(this, i10);
            Character.toChars(gVar.f(), this.f2634b, i10 * 2);
            h(gVar);
        }
    }

    public static m b(Typeface typeface, ByteBuffer byteBuffer) throws IOException {
        try {
            androidx.core.os.h.a("EmojiCompat.MetadataRepo.create");
            return new m(typeface, l.b(byteBuffer));
        } finally {
            androidx.core.os.h.b();
        }
    }

    public char[] c() {
        return this.f2634b;
    }

    public h0.b d() {
        return this.f2633a;
    }

    int e() {
        return this.f2633a.l();
    }

    a f() {
        return this.f2635c;
    }

    Typeface g() {
        return this.f2636d;
    }

    void h(g gVar) {
        a0.h.f(gVar, "emoji metadata cannot be null");
        a0.h.b(gVar.c() > 0, "invalid metadata codepoint length");
        this.f2635c.c(gVar, 0, gVar.c() - 1);
    }
}
