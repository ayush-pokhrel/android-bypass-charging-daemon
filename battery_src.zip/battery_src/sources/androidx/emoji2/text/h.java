package androidx.emoji2.text;

import android.text.Editable;
import android.text.Selection;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.method.MetaKeyKeyListener;
import android.view.KeyEvent;
import android.view.inputmethod.InputConnection;
import java.util.Arrays;

/* JADX INFO: compiled from: EmojiProcessor.java */
/* JADX INFO: loaded from: classes.dex */
final class h {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final e.i f2600a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private final m f2601b;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private e.d f2602c;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private final boolean f2603d;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private final int[] f2604e;

    /* JADX INFO: compiled from: EmojiProcessor.java */
    private static final class a {
        static int a(CharSequence charSequence, int i10, int i11) {
            int length = charSequence.length();
            if (i10 < 0 || length < i10 || i11 < 0) {
                return -1;
            }
            while (true) {
                boolean z10 = false;
                while (i11 != 0) {
                    i10--;
                    if (i10 < 0) {
                        return z10 ? -1 : 0;
                    }
                    char cCharAt = charSequence.charAt(i10);
                    if (z10) {
                        if (!Character.isHighSurrogate(cCharAt)) {
                            return -1;
                        }
                        i11--;
                    } else if (!Character.isSurrogate(cCharAt)) {
                        i11--;
                    } else {
                        if (Character.isHighSurrogate(cCharAt)) {
                            return -1;
                        }
                        z10 = true;
                    }
                }
                return i10;
            }
        }

        static int b(CharSequence charSequence, int i10, int i11) {
            int length = charSequence.length();
            if (i10 < 0 || length < i10 || i11 < 0) {
                return -1;
            }
            while (true) {
                boolean z10 = false;
                while (i11 != 0) {
                    if (i10 >= length) {
                        if (z10) {
                            return -1;
                        }
                        return length;
                    }
                    char cCharAt = charSequence.charAt(i10);
                    if (z10) {
                        if (!Character.isLowSurrogate(cCharAt)) {
                            return -1;
                        }
                        i11--;
                        i10++;
                    } else if (!Character.isSurrogate(cCharAt)) {
                        i11--;
                        i10++;
                    } else {
                        if (Character.isLowSurrogate(cCharAt)) {
                            return -1;
                        }
                        i10++;
                        z10 = true;
                    }
                }
                return i10;
            }
        }
    }

    /* JADX INFO: compiled from: EmojiProcessor.java */
    static final class b {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private int f2605a = 1;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private final m.a f2606b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        private m.a f2607c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        private m.a f2608d;

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        private int f2609e;

        /* JADX INFO: renamed from: f, reason: collision with root package name */
        private int f2610f;

        /* JADX INFO: renamed from: g, reason: collision with root package name */
        private final boolean f2611g;

        /* JADX INFO: renamed from: h, reason: collision with root package name */
        private final int[] f2612h;

        b(m.a aVar, boolean z10, int[] iArr) {
            this.f2606b = aVar;
            this.f2607c = aVar;
            this.f2611g = z10;
            this.f2612h = iArr;
        }

        private static boolean d(int i10) {
            return i10 == 65039;
        }

        private static boolean f(int i10) {
            return i10 == 65038;
        }

        private int g() {
            this.f2605a = 1;
            this.f2607c = this.f2606b;
            this.f2610f = 0;
            return 1;
        }

        private boolean h() {
            if (this.f2607c.b().j() || d(this.f2609e)) {
                return true;
            }
            if (this.f2611g) {
                if (this.f2612h == null) {
                    return true;
                }
                if (Arrays.binarySearch(this.f2612h, this.f2607c.b().b(0)) < 0) {
                    return true;
                }
            }
            return false;
        }

        int a(int i10) {
            m.a aVarA = this.f2607c.a(i10);
            int iG = 2;
            if (this.f2605a != 2) {
                if (aVarA == null) {
                    iG = g();
                } else {
                    this.f2605a = 2;
                    this.f2607c = aVarA;
                    this.f2610f = 1;
                }
            } else if (aVarA != null) {
                this.f2607c = aVarA;
                this.f2610f++;
            } else if (f(i10)) {
                iG = g();
            } else if (!d(i10)) {
                if (this.f2607c.b() != null) {
                    iG = 3;
                    if (this.f2610f != 1 || h()) {
                        this.f2608d = this.f2607c;
                        g();
                    } else {
                        iG = g();
                    }
                } else {
                    iG = g();
                }
            }
            this.f2609e = i10;
            return iG;
        }

        g b() {
            return this.f2607c.b();
        }

        g c() {
            return this.f2608d.b();
        }

        boolean e() {
            return this.f2605a == 2 && this.f2607c.b() != null && (this.f2610f > 1 || h());
        }
    }

    h(m mVar, e.i iVar, e.d dVar, boolean z10, int[] iArr) {
        this.f2600a = iVar;
        this.f2601b = mVar;
        this.f2602c = dVar;
        this.f2603d = z10;
        this.f2604e = iArr;
    }

    private void a(Spannable spannable, g gVar, int i10, int i11) {
        spannable.setSpan(this.f2600a.a(gVar), i10, i11, 33);
    }

    private static boolean b(Editable editable, KeyEvent keyEvent, boolean z10) {
        i[] iVarArr;
        if (g(keyEvent)) {
            return false;
        }
        int selectionStart = Selection.getSelectionStart(editable);
        int selectionEnd = Selection.getSelectionEnd(editable);
        if (!f(selectionStart, selectionEnd) && (iVarArr = (i[]) editable.getSpans(selectionStart, selectionEnd, i.class)) != null && iVarArr.length > 0) {
            for (i iVar : iVarArr) {
                int spanStart = editable.getSpanStart(iVar);
                int spanEnd = editable.getSpanEnd(iVar);
                if ((z10 && spanStart == selectionStart) || ((!z10 && spanEnd == selectionStart) || (selectionStart > spanStart && selectionStart < spanEnd))) {
                    editable.delete(spanStart, spanEnd);
                    return true;
                }
            }
        }
        return false;
    }

    static boolean c(InputConnection inputConnection, Editable editable, int i10, int i11, boolean z10) {
        int iMax;
        int iMin;
        if (editable != null && inputConnection != null && i10 >= 0 && i11 >= 0) {
            int selectionStart = Selection.getSelectionStart(editable);
            int selectionEnd = Selection.getSelectionEnd(editable);
            if (f(selectionStart, selectionEnd)) {
                return false;
            }
            if (z10) {
                iMax = a.a(editable, selectionStart, Math.max(i10, 0));
                iMin = a.b(editable, selectionEnd, Math.max(i11, 0));
                if (iMax == -1 || iMin == -1) {
                    return false;
                }
            } else {
                iMax = Math.max(selectionStart - i10, 0);
                iMin = Math.min(selectionEnd + i11, editable.length());
            }
            i[] iVarArr = (i[]) editable.getSpans(iMax, iMin, i.class);
            if (iVarArr != null && iVarArr.length > 0) {
                for (i iVar : iVarArr) {
                    int spanStart = editable.getSpanStart(iVar);
                    int spanEnd = editable.getSpanEnd(iVar);
                    iMax = Math.min(spanStart, iMax);
                    iMin = Math.max(spanEnd, iMin);
                }
                int iMax2 = Math.max(iMax, 0);
                int iMin2 = Math.min(iMin, editable.length());
                inputConnection.beginBatchEdit();
                editable.delete(iMax2, iMin2);
                inputConnection.endBatchEdit();
                return true;
            }
        }
        return false;
    }

    static boolean d(Editable editable, int i10, KeyEvent keyEvent) {
        boolean zB;
        if (i10 != 67) {
            zB = i10 != 112 ? false : b(editable, keyEvent, true);
        } else {
            zB = b(editable, keyEvent, false);
        }
        if (!zB) {
            return false;
        }
        MetaKeyKeyListener.adjustMetaAfterKeypress(editable);
        return true;
    }

    private boolean e(CharSequence charSequence, int i10, int i11, g gVar) {
        if (gVar.d() == 0) {
            gVar.k(this.f2602c.a(charSequence, i10, i11, gVar.h()));
        }
        return gVar.d() == 2;
    }

    private static boolean f(int i10, int i11) {
        return i10 == -1 || i11 == -1 || i10 != i11;
    }

    private static boolean g(KeyEvent keyEvent) {
        return !KeyEvent.metaStateHasNoModifiers(keyEvent.getMetaState());
    }

    CharSequence h(CharSequence charSequence, int i10, int i11, int i12, boolean z10) {
        p pVar;
        int iCharCount;
        i[] iVarArr;
        boolean z11 = charSequence instanceof n;
        if (z11) {
            ((n) charSequence).a();
        }
        if (!z11) {
            try {
                pVar = charSequence instanceof Spannable ? new p((Spannable) charSequence) : (!(charSequence instanceof Spanned) || ((Spanned) charSequence).nextSpanTransition(i10 + (-1), i11 + 1, i.class) > i11) ? null : new p(charSequence);
            } finally {
                if (z11) {
                    ((n) charSequence).d();
                }
            }
        }
        if (pVar != null && (iVarArr = (i[]) pVar.getSpans(i10, i11, i.class)) != null && iVarArr.length > 0) {
            for (i iVar : iVarArr) {
                int spanStart = pVar.getSpanStart(iVar);
                int spanEnd = pVar.getSpanEnd(iVar);
                if (spanStart != i11) {
                    pVar.removeSpan(iVar);
                }
                i10 = Math.min(spanStart, i10);
                i11 = Math.max(spanEnd, i11);
            }
        }
        if (i10 != i11 && i10 < charSequence.length()) {
            if (i12 != Integer.MAX_VALUE && pVar != null) {
                i12 -= ((i[]) pVar.getSpans(0, pVar.length(), i.class)).length;
            }
            b bVar = new b(this.f2601b.f(), this.f2603d, this.f2604e);
            int iCodePointAt = Character.codePointAt(charSequence, i10);
            int i13 = 0;
            p pVar2 = pVar;
            loop1: while (true) {
                iCharCount = i10;
                while (true) {
                    if (i10 >= i11 || i13 >= i12) {
                        break loop1;
                    }
                    int iA = bVar.a(iCodePointAt);
                    if (iA == 1) {
                        iCharCount += Character.charCount(Character.codePointAt(charSequence, iCharCount));
                        if (iCharCount < i11) {
                            iCodePointAt = Character.codePointAt(charSequence, iCharCount);
                        }
                        i10 = iCharCount;
                    } else if (iA == 2) {
                        i10 += Character.charCount(iCodePointAt);
                        if (i10 < i11) {
                            iCodePointAt = Character.codePointAt(charSequence, i10);
                        }
                    } else if (iA != 3) {
                    }
                }
                if (z10 || !e(charSequence, iCharCount, i10, bVar.c())) {
                    if (pVar2 == null) {
                        pVar2 = new p((Spannable) new SpannableString(charSequence));
                    }
                    a(pVar2, bVar.c(), iCharCount, i10);
                    i13++;
                }
            }
            if (bVar.e() && i13 < i12 && (z10 || !e(charSequence, iCharCount, i10, bVar.b()))) {
                if (pVar2 == null) {
                    pVar2 = new p(charSequence);
                }
                a(pVar2, bVar.b(), iCharCount, i10);
            }
            return pVar2 != null ? pVar2.b() : charSequence;
        }
        return charSequence;
    }
}
