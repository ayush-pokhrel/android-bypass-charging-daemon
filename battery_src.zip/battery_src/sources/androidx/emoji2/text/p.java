package androidx.emoji2.text;

import android.text.PrecomputedText;
import android.text.Spannable;
import android.text.SpannableString;
import java.util.stream.IntStream;

/* JADX INFO: compiled from: UnprecomputeTextOnModificationSpannable.java */
/* JADX INFO: loaded from: classes.dex */
class p implements Spannable {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private boolean f2644a = false;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private Spannable f2645b;

    /* JADX INFO: compiled from: UnprecomputeTextOnModificationSpannable.java */
    private static class a {
        static IntStream a(CharSequence charSequence) {
            return charSequence.chars();
        }

        static IntStream b(CharSequence charSequence) {
            return charSequence.codePoints();
        }
    }

    /* JADX INFO: compiled from: UnprecomputeTextOnModificationSpannable.java */
    static class b {
        b() {
        }

        boolean a(CharSequence charSequence) {
            throw null;
        }
    }

    /* JADX INFO: compiled from: UnprecomputeTextOnModificationSpannable.java */
    static class c extends b {
        c() {
        }

        @Override // androidx.emoji2.text.p.b
        boolean a(CharSequence charSequence) {
            return (charSequence instanceof PrecomputedText) || (charSequence instanceof androidx.core.text.c);
        }
    }

    p(Spannable spannable) {
        this.f2645b = spannable;
    }

    private void a() {
        Spannable spannable = this.f2645b;
        if (!this.f2644a && c().a(spannable)) {
            this.f2645b = new SpannableString(spannable);
        }
        this.f2644a = true;
    }

    static b c() {
        return new c();
    }

    Spannable b() {
        return this.f2645b;
    }

    @Override // java.lang.CharSequence
    public char charAt(int i10) {
        return this.f2645b.charAt(i10);
    }

    @Override // java.lang.CharSequence
    public IntStream chars() {
        return a.a(this.f2645b);
    }

    @Override // java.lang.CharSequence
    public IntStream codePoints() {
        return a.b(this.f2645b);
    }

    @Override // android.text.Spanned
    public int getSpanEnd(Object obj) {
        return this.f2645b.getSpanEnd(obj);
    }

    @Override // android.text.Spanned
    public int getSpanFlags(Object obj) {
        return this.f2645b.getSpanFlags(obj);
    }

    @Override // android.text.Spanned
    public int getSpanStart(Object obj) {
        return this.f2645b.getSpanStart(obj);
    }

    @Override // android.text.Spanned
    public <T> T[] getSpans(int i10, int i11, Class<T> cls) {
        return (T[]) this.f2645b.getSpans(i10, i11, cls);
    }

    @Override // java.lang.CharSequence
    public int length() {
        return this.f2645b.length();
    }

    @Override // android.text.Spanned
    public int nextSpanTransition(int i10, int i11, Class cls) {
        return this.f2645b.nextSpanTransition(i10, i11, cls);
    }

    @Override // android.text.Spannable
    public void removeSpan(Object obj) {
        a();
        this.f2645b.removeSpan(obj);
    }

    @Override // android.text.Spannable
    public void setSpan(Object obj, int i10, int i11, int i12) {
        a();
        this.f2645b.setSpan(obj, i10, i11, i12);
    }

    @Override // java.lang.CharSequence
    public CharSequence subSequence(int i10, int i11) {
        return this.f2645b.subSequence(i10, i11);
    }

    @Override // java.lang.CharSequence
    public String toString() {
        return this.f2645b.toString();
    }

    p(CharSequence charSequence) {
        this.f2645b = new SpannableString(charSequence);
    }
}
