package androidx.emoji2.text;

import android.content.Context;
import android.content.pm.PackageManager;
import android.database.ContentObserver;
import android.graphics.Typeface;
import android.os.Handler;
import java.nio.ByteBuffer;
import java.util.concurrent.Executor;
import java.util.concurrent.ThreadPoolExecutor;

/* JADX INFO: compiled from: FontRequestEmojiCompatConfig.java */
/* JADX INFO: loaded from: classes.dex */
public class j extends e.c {

    /* JADX INFO: renamed from: j, reason: collision with root package name */
    private static final a f2618j = new a();

    /* JADX INFO: compiled from: FontRequestEmojiCompatConfig.java */
    public static class a {
        public Typeface a(Context context, z.g.b bVar) throws PackageManager.NameNotFoundException {
            return z.g.a(context, null, new z.g.b[]{bVar});
        }

        public z.g.a b(Context context, z.e eVar) throws PackageManager.NameNotFoundException {
            return z.g.b(context, null, eVar);
        }

        public void c(Context context, ContentObserver contentObserver) {
            context.getContentResolver().unregisterContentObserver(contentObserver);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX INFO: compiled from: FontRequestEmojiCompatConfig.java */
    static class b implements e.g {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private final Context f2619a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private final z.e f2620b;

        /* JADX INFO: renamed from: c, reason: collision with root package name */
        private final a f2621c;

        /* JADX INFO: renamed from: d, reason: collision with root package name */
        private final Object f2622d = new Object();

        /* JADX INFO: renamed from: e, reason: collision with root package name */
        private Handler f2623e;

        /* JADX INFO: renamed from: f, reason: collision with root package name */
        private Executor f2624f;

        /* JADX INFO: renamed from: g, reason: collision with root package name */
        private ThreadPoolExecutor f2625g;

        /* JADX INFO: renamed from: h, reason: collision with root package name */
        e.h f2626h;

        /* JADX INFO: renamed from: i, reason: collision with root package name */
        private ContentObserver f2627i;

        /* JADX INFO: renamed from: j, reason: collision with root package name */
        private Runnable f2628j;

        b(Context context, z.e eVar, a aVar) {
            a0.h.f(context, "Context cannot be null");
            a0.h.f(eVar, "FontRequest cannot be null");
            this.f2619a = context.getApplicationContext();
            this.f2620b = eVar;
            this.f2621c = aVar;
        }

        private void b() {
            synchronized (this.f2622d) {
                try {
                    this.f2626h = null;
                    ContentObserver contentObserver = this.f2627i;
                    if (contentObserver != null) {
                        this.f2621c.c(this.f2619a, contentObserver);
                        this.f2627i = null;
                    }
                    Handler handler = this.f2623e;
                    if (handler != null) {
                        handler.removeCallbacks(this.f2628j);
                    }
                    this.f2623e = null;
                    ThreadPoolExecutor threadPoolExecutor = this.f2625g;
                    if (threadPoolExecutor != null) {
                        threadPoolExecutor.shutdown();
                    }
                    this.f2624f = null;
                    this.f2625g = null;
                } catch (Throwable th) {
                    throw th;
                }
            }
        }

        private z.g.b e() {
            try {
                z.g.a aVarB = this.f2621c.b(this.f2619a, this.f2620b);
                if (aVarB.c() == 0) {
                    z.g.b[] bVarArrB = aVarB.b();
                    if (bVarArrB == null || bVarArrB.length == 0) {
                        throw new RuntimeException("fetchFonts failed (empty result)");
                    }
                    return bVarArrB[0];
                }
                throw new RuntimeException("fetchFonts failed (" + aVarB.c() + ")");
            } catch (PackageManager.NameNotFoundException e10) {
                throw new RuntimeException("provider not found", e10);
            }
        }

        @Override // androidx.emoji2.text.e.g
        public void a(e.h hVar) {
            a0.h.f(hVar, "LoaderCallback cannot be null");
            synchronized (this.f2622d) {
                this.f2626h = hVar;
            }
            d();
        }

        void c() {
            synchronized (this.f2622d) {
                try {
                    if (this.f2626h == null) {
                        return;
                    }
                    try {
                        z.g.b bVarE = e();
                        int iB = bVarE.b();
                        if (iB == 2) {
                            synchronized (this.f2622d) {
                            }
                        }
                        if (iB != 0) {
                            throw new RuntimeException("fetchFonts result is not OK. (" + iB + ")");
                        }
                        try {
                            androidx.core.os.h.a("EmojiCompat.FontRequestEmojiCompatConfig.buildTypeface");
                            Typeface typefaceA = this.f2621c.a(this.f2619a, bVarE);
                            ByteBuffer byteBufferA = androidx.core.graphics.h.a(this.f2619a, null, bVarE.d());
                            if (byteBufferA == null || typefaceA == null) {
                                throw new RuntimeException("Unable to open file.");
                            }
                            m mVarB = m.b(typefaceA, byteBufferA);
                            androidx.core.os.h.b();
                            synchronized (this.f2622d) {
                                try {
                                    e.h hVar = this.f2626h;
                                    if (hVar != null) {
                                        hVar.b(mVarB);
                                    }
                                } catch (Throwable th) {
                                    throw th;
                                }
                            }
                            b();
                        } catch (Throwable th2) {
                            androidx.core.os.h.b();
                            throw th2;
                        }
                    } catch (Throwable th3) {
                        synchronized (this.f2622d) {
                            try {
                                e.h hVar2 = this.f2626h;
                                if (hVar2 != null) {
                                    hVar2.a(th3);
                                }
                                b();
                            } catch (Throwable th4) {
                                throw th4;
                            }
                        }
                    }
                } catch (Throwable th5) {
                    throw th5;
                }
            }
        }

        void d() {
            synchronized (this.f2622d) {
                try {
                    if (this.f2626h == null) {
                        return;
                    }
                    if (this.f2624f == null) {
                        ThreadPoolExecutor threadPoolExecutorB = androidx.emoji2.text.b.b("emojiCompat");
                        this.f2625g = threadPoolExecutorB;
                        this.f2624f = threadPoolExecutorB;
                    }
                    this.f2624f.execute(new Runnable() { // from class: androidx.emoji2.text.k
                        @Override // java.lang.Runnable
                        public final void run() {
                            this.f2629a.c();
                        }
                    });
                } catch (Throwable th) {
                    throw th;
                }
            }
        }

        public void f(Executor executor) {
            synchronized (this.f2622d) {
                this.f2624f = executor;
            }
        }
    }

    public j(Context context, z.e eVar) {
        super(new b(context, eVar, f2618j));
    }

    public j c(Executor executor) {
        ((b) a()).f(executor);
        return this;
    }
}
