package androidx.emoji2.text;

import android.annotation.SuppressLint;
import android.graphics.Paint;
import android.text.style.ReplacementSpan;

/* JADX INFO: compiled from: EmojiSpan.java */
/* JADX INFO: loaded from: classes.dex */
public abstract class i extends ReplacementSpan {

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    private final g f2614b;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final Paint.FontMetricsInt f2613a = new Paint.FontMetricsInt();

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    private short f2615c = -1;

    /* JADX INFO: renamed from: d, reason: collision with root package name */
    private short f2616d = -1;

    /* JADX INFO: renamed from: e, reason: collision with root package name */
    private float f2617e = 1.0f;

    i(g gVar) {
        a0.h.f(gVar, "metadata cannot be null");
        this.f2614b = gVar;
    }

    public final g a() {
        return this.f2614b;
    }

    final int b() {
        return this.f2615c;
    }

    @Override // android.text.style.ReplacementSpan
    public int getSize(Paint paint, @SuppressLint({"UnknownNullness"}) CharSequence charSequence, int i10, int i11, Paint.FontMetricsInt fontMetricsInt) {
        paint.getFontMetricsInt(this.f2613a);
        Paint.FontMetricsInt fontMetricsInt2 = this.f2613a;
        this.f2617e = (Math.abs(fontMetricsInt2.descent - fontMetricsInt2.ascent) * 1.0f) / this.f2614b.e();
        this.f2616d = (short) (this.f2614b.e() * this.f2617e);
        short sI = (short) (this.f2614b.i() * this.f2617e);
        this.f2615c = sI;
        if (fontMetricsInt != null) {
            Paint.FontMetricsInt fontMetricsInt3 = this.f2613a;
            fontMetricsInt.ascent = fontMetricsInt3.ascent;
            fontMetricsInt.descent = fontMetricsInt3.descent;
            fontMetricsInt.top = fontMetricsInt3.top;
            fontMetricsInt.bottom = fontMetricsInt3.bottom;
        }
        return sI;
    }
}
