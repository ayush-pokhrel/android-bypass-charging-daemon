package androidx.emoji2.text;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/* JADX INFO: compiled from: MetadataListReader.java */
/* JADX INFO: loaded from: classes.dex */
class l {

    /* JADX INFO: compiled from: MetadataListReader.java */
    private static class a implements c {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private final ByteBuffer f2630a;

        a(ByteBuffer byteBuffer) {
            this.f2630a = byteBuffer;
            byteBuffer.order(ByteOrder.BIG_ENDIAN);
        }

        @Override // androidx.emoji2.text.l.c
        public void a(int i10) throws IOException {
            ByteBuffer byteBuffer = this.f2630a;
            byteBuffer.position(byteBuffer.position() + i10);
        }

        @Override // androidx.emoji2.text.l.c
        public int b() throws IOException {
            return l.d(this.f2630a.getShort());
        }

        @Override // androidx.emoji2.text.l.c
        public long c() throws IOException {
            return l.c(this.f2630a.getInt());
        }

        @Override // androidx.emoji2.text.l.c
        public int d() throws IOException {
            return this.f2630a.getInt();
        }

        @Override // androidx.emoji2.text.l.c
        public long getPosition() {
            return this.f2630a.position();
        }
    }

    /* JADX INFO: compiled from: MetadataListReader.java */
    private static class b {

        /* JADX INFO: renamed from: a, reason: collision with root package name */
        private final long f2631a;

        /* JADX INFO: renamed from: b, reason: collision with root package name */
        private final long f2632b;

        b(long j10, long j11) {
            this.f2631a = j10;
            this.f2632b = j11;
        }

        long a() {
            return this.f2631a;
        }
    }

    /* JADX INFO: compiled from: MetadataListReader.java */
    private interface c {
        void a(int i10) throws IOException;

        int b() throws IOException;

        long c() throws IOException;

        int d() throws IOException;

        long getPosition();
    }

    private static b a(c cVar) throws IOException {
        long jC;
        cVar.a(4);
        int iB = cVar.b();
        if (iB > 100) {
            throw new IOException("Cannot read metadata.");
        }
        cVar.a(6);
        int i10 = 0;
        while (true) {
            if (i10 >= iB) {
                jC = -1;
                break;
            }
            int iD = cVar.d();
            cVar.a(4);
            jC = cVar.c();
            cVar.a(4);
            if (1835365473 == iD) {
                break;
            }
            i10++;
        }
        if (jC != -1) {
            cVar.a((int) (jC - cVar.getPosition()));
            cVar.a(12);
            long jC2 = cVar.c();
            for (int i11 = 0; i11 < jC2; i11++) {
                int iD2 = cVar.d();
                long jC3 = cVar.c();
                long jC4 = cVar.c();
                if (1164798569 == iD2 || 1701669481 == iD2) {
                    return new b(jC3 + jC, jC4);
                }
            }
        }
        throw new IOException("Cannot read metadata.");
    }

    static h0.b b(ByteBuffer byteBuffer) throws IOException {
        ByteBuffer byteBufferDuplicate = byteBuffer.duplicate();
        byteBufferDuplicate.position((int) a(new a(byteBufferDuplicate)).a());
        return h0.b.h(byteBufferDuplicate);
    }

    static long c(int i10) {
        return ((long) i10) & 4294967295L;
    }

    static int d(short s10) {
        return s10 & 65535;
    }
}
