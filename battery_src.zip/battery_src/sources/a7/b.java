package a7;

import android.util.Log;

/* JADX INFO: compiled from: Debug.java */
/* JADX INFO: loaded from: classes2.dex */
public class b {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static boolean f128a = false;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static boolean f129b = false;

    public static boolean a() {
        return f129b;
    }

    public static boolean b() {
        return f128a;
    }

    public static void c(String str) {
        d("PhysicsWorld", str);
    }

    public static void d(String str, String str2) {
        Log.d(str, str2);
    }
}
