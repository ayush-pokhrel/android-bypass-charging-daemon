package a7;

/* JADX INFO: compiled from: Compat.java */
/* JADX INFO: loaded from: classes2.dex */
public class a {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public static float f125a = 0.008333334f;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public static float f126b = 0.1f;

    /* JADX INFO: renamed from: c, reason: collision with root package name */
    public static float f127c = 160.0f;

    public static float a(float f10) {
        return (d.c(f10) * 2.8600001f) + 2.2141f;
    }

    public static boolean b(float f10) {
        return f10 < f126b;
    }

    public static float c(float f10) {
        return f10 * f127c;
    }

    public static float d(float f10) {
        return f10 / f127c;
    }

    public static void e(float f10) {
        f127c = (f10 * 55.0f) + 0.5f;
        f126b = d(0.1f);
    }

    public static void f(float f10) {
        f125a = f10;
    }
}
