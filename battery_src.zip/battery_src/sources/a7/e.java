package a7;

/* JADX INFO: compiled from: Vector.java */
/* JADX INFO: loaded from: classes2.dex */
public class e {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public float f132a;

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public float f133b;

    public e() {
        this(0.0f, 0.0f);
    }

    public final e a(e eVar) {
        this.f132a += eVar.f132a;
        this.f133b += eVar.f133b;
        return this;
    }

    public final e b(float f10) {
        this.f132a *= f10;
        this.f133b *= f10;
        return this;
    }

    public final e c() {
        this.f132a = -this.f132a;
        this.f133b = -this.f133b;
        return this;
    }

    public final e d(float f10, float f11) {
        this.f132a = f10;
        this.f133b = f11;
        return this;
    }

    public final e e(e eVar) {
        this.f132a = eVar.f132a;
        this.f133b = eVar.f133b;
        return this;
    }

    public final void f() {
        this.f132a = 0.0f;
        this.f133b = 0.0f;
    }

    public final e g(e eVar) {
        this.f132a -= eVar.f132a;
        this.f133b -= eVar.f133b;
        return this;
    }

    public final String toString() {
        return "(" + this.f132a + "," + this.f133b + ")";
    }

    public e(float f10, float f11) {
        this.f132a = f10;
        this.f133b = f11;
    }
}
