package a7;

/* JADX INFO: compiled from: Mat22.java */
/* JADX INFO: loaded from: classes2.dex */
public class c {

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    public final e f130a = new e();

    /* JADX INFO: renamed from: b, reason: collision with root package name */
    public final e f131b = new e();

    public static final void b(c cVar, e eVar, e eVar2) {
        e eVar3 = cVar.f130a;
        float f10 = eVar3.f132a * eVar.f132a;
        e eVar4 = cVar.f131b;
        float f11 = eVar4.f132a;
        float f12 = eVar.f133b;
        eVar2.f132a = f10 + (f11 * f12);
        eVar2.f133b = (eVar3.f133b * eVar.f132a) + (eVar4.f133b * f12);
    }

    public final c a() {
        e eVar = this.f130a;
        float f10 = eVar.f132a;
        e eVar2 = this.f131b;
        float f11 = eVar2.f132a;
        float f12 = eVar.f133b;
        float f13 = eVar2.f133b;
        float f14 = (f10 * f13) - (f11 * f12);
        if (f14 != 0.0f) {
            f14 = 1.0f / f14;
        }
        eVar.f132a = f13 * f14;
        float f15 = -f14;
        eVar2.f132a = f11 * f15;
        eVar.f133b = f15 * f12;
        eVar2.f133b = f14 * f10;
        return this;
    }
}
